# uBIM viewer, Python rewrite — plan

Written 15 Nov 2026. Spec of record: `../ubim/` (the DeepSeek pack, items 33/33a). New code: `../ubim2/`.
This plan is mine; it is not inherited from any harness run. Where the old pack says "Java class X", I say
"module Y" and carry the *behaviour*, not the code.

## 1. What I checked before planning (FACT, this box, 15 Nov 2026)

| Check | Result |
|---|---|
| `SCAN_085.fls` in the pack root | present, 191,418,368 B, sha256 starts `152ca5dee9762ac3` — matches `01-context.md` |
| Python `.fls` Grey decode, written from scratch today | **all reference numbers match**, including `sha256 a94f3e1e…8975c` (see §4) |
| Time for that decode | **4.1 s** for 43,260,448 cells (numpy vectorised), i.e. the 120 s budget in the pack is not at risk |
| `olefile` 0.46, `numpy` 1.25.2, `Pillow` 12.3.0, `scipy` 1.13.0 present | yes |
| Maven / JDK 17 on this box | **absent** (Java 11 only, `$HOME` is read-only) — irrelevant now, which is one reason the rewrite is attractive |
| FARO grey HD JPEG (needed for the alignment gate) | **not on this box yet** — must be fetched (see §8) |
| Existing app size | 29 Java files / 11.8 k lines, 6.6 k lines of TS, 60+ routes, 23 web test modules |

The existing app's feature set (from `WebServer` routes and `README.md`): auth + sessions + CSRF, users, invites,
share links, audit log, project catalogue, WebShare map tiles, OSM proxy, pano viewer, point/distance/polyline/area
measurement, plan height, shared layer with soft delete and undo, DXF import/export, thumbnails, CRS, per-user
settings, admin pages, depth batch (`.fls`/`.f3s`), and the shipped display-only "Laser intensity map".

## 2. The three.js question (asked directly — here is the researched answer)

**Is three.js suitable? Technically yes. I recommend not using it for v1 of this rewrite.**

Measured, not guessed:

| Fact | Number | Source |
|---|---|---|
| `three@0.183.2/build/three.module.min.js` | **359,158 B**, self-contained ESM, zero `from"three"` imports | downloaded and inspected today |
| Unminified same file | 639,046 B; `three.core.min.js` is 382,617 B | same |
| No-build usage | works with `<script type="importmap">{"imports":{"three":"/static/vendor/three.module.min.js"}}</script>` — no npm, no bundler | three.js docs / SO 79904178 (2026) |
| Tessellation error of the current approach (sphere 64×40, camera at centre) | **≈0.01 px** at 8190-wide scale | computed: the chord subtends the same angle as the arc; texture-coordinate non-linearity is O(α³), α=2.8° |

So the usual argument "a sphere mesh is not pixel-exact" is **false** at this size — I checked it rather than repeating
it. The real arguments are:

1. Everything three.js is good at here, we do not need. Picks are **server-side** (`POST /api/p/{id}/pick` returns a
   project point); there is no client raycasting. The camera is yaw/pitch/zoom, ~40 lines, and must reproduce the
   existing drag-keeps-point-under-cursor behaviour anyway, so `OrbitControls` is not used. Overlays
   (DXF, measurement lines, scan dots) are projected polylines, i.e. 2D canvas work, not a scene graph.
2. The pano is one job: full-screen inverse-projection (per-pixel ray direction) → equirect sample with the
   `project.ts` constants. That is ~250 lines of WebGL2 in one file, ~25 KB of our own source, no vendor tree, and
   the mapping lives in **one** auditable formula that the same numbers in Python can be checked against offline.
3. The intensity work needs per-tile level switching, `MAX_TEXTURE_SIZE`/8192 caps, LRU eviction and "one texel ≤ one
   device pixel". In three.js you end up writing a custom `ShaderMaterial` for that anyway — at which point the
   library is providing a texture uploader.
4. It honours "no JS in the front end" literally: `index.html` + ES modules + CSS, nothing vendored.

**Where three.js becomes the right call:** item 33b/33c (point clouds, dense top view) and E57 previews. Those need
matrices, instancing, culling and depth sorting that I do not want to hand-roll. Because it ships as one ESM file,
adding it later is a 359 KB copy plus an import map — no build step, no lockfile — so choosing "no three.js now"
does **not** lock the project out later. That is the whole reason I am comfortable deciding this now.

Alternatives considered and rejected: Babylon.js (much larger), OGL (~40 KB, but then we own the same shaders *plus*
a young library), Photo Sphere Viewer (built on three.js, so it is three.js with extra opinions).

## 3. Stack

| Layer | Choice | Why |
|---|---|---|
| Server | Python 3.11/3.12, **FastAPI + uvicorn**, single worker, jobs on a bounded thread pool | JSON in/out, typed models, no build; CPU-bound decode must stay off the event loop |
| DB | `sqlite3` from stdlib, WAL, one connection under a lock, schema versioned by a `meta` row | same as today, no ORM |
| Imaging | `Pillow` + `numpy` | PNG tiles, JPEG pano downscales, resampling |
| Auth | stdlib `hashlib.scrypt`, server-side session rows, CSRF token per session, HttpOnly+SameSite cookies | no passlib/bcrypt dependency |
| Frontend | static `index.html`, hand-written ES modules, one `<canvas>` WebGL2 for the pano, one 2D canvas for overlays, no bundler, no vendor JS | per §2 |
| Tests | `pytest` + `httpx.TestClient`; the pack's *numbers* (sha256, stats, tolerances) become test constants | the Java suite cannot run here |

Dependency list to pin: `fastapi`, `uvicorn[standard]`, `pillow`, `numpy`, `scipy` (alignment correlation only),
`pytest`, `httpx`. Everything else stdlib. Installed into a venv inside the project, not into `$HOME`.

**Deployment risk first, not last:** Python 3.9+ does not support Windows 8 / Server 2012 non-R2 (NT 6.2); the
current production VM is exactly that. Options: (a) target a Linux host / container and keep the VM as a browser-only
client, (b) cap syntax at 3.8 and use the last 3.8 build, (c) upgrade the VM. I will write 3.8-compatible code
(no `match`, no `X | Y` at runtime, no `tomllib`) so (b) stays available, and flag it in the report.

## 4. Decoder spec, verified today (`formats/`)

`fls.py` + `cfb.py`. Verified against SCAN_085: 43,260,448 cells, 2,499,780 zeros, 0 negatives, min non-zero 1,
max 2,780, 534 cells > 2047, mean non-zero 653.841, p1/p50/p99 = 6/201/1787, sum 26,650,989,673,
sha256 `a94f3e1e12feec561a09d8a4022ae3201c7a9357d83817590c7c1c32f9d8975c`.

- OLE container via `olefile` (read-only, bounded reads). `Main` text gives `NumRows`, `NumCols`,
  `RowStartAngle`, `RowEndAngle`, `StorageDistFact`, `NumGreyBits`, `VertResolutionFactor`.
- `Scans/1/{Dist,Grey}N` are raw-deflate gzip streams whose trailer may be short → `zlib.decompressobj(-15)`
  after the 10-byte header. Inflated text starts `\n…DataFormat 1\nScan2DataBase <cells> { `.
- Varint: bit 7 continuation, **bit 6 sign**, bits 0–5 low magnitude, then 7 bits LSB-first. Values are signed
  deltas from the previous row of the same column; each column starts at 0. Decode is vectorised with numpy
  (`ends = flatnonzero((b & 0x80) == 0)`, gather into an (n, L) matrix, mask by record length, sign, `cumsum` per
  column) — that is what made 43 M cells take 4 s.
- **New finding, not in the pack:** each Grey stream inflates to **two records more** than `DataRect` implies
  (21,630,226 vs 21,630,224 for Grey0). I trim to the cell count derived from `DataRect`; a stream that yields
  *fewer* records is an error, and more than 4 extra is an error. Whether every `.fls` does this is UNKNOWN — one
  file only. Code path: `decode_stream(..., expect_cells)`.
- Azimuth: `Scans/1/Calib` `HorCalibData <cols> { ` + cols × (double angle, double small); local azimuth = −angle.
  Linear `col·360/cols` is wrong by up to ~1° — never use it.
- Elevation: `RowStartAngle − (row + ROW_SHIFT)·rowStep`, `ROW_SHIFT = 8.0` fitted on SCAN_085, env-overridable,
  **not** re-fitted. Same function for depth and intensity.
- `f3s.py`: OLE + gzip `ScanInfo_*` + the `Point2dSet` quadtree walk into a 10240×5120 grid, caps as in `docs/F3S.md`.
  This is the largest porting job (1,006 Java lines) and it is only needed for `.f3s`-only projects. Phase 4.

## 5. Intensity product (`products/intensity.py`)

- Source: 11-bit (observed 12-bit) `Grey` cells, never the FARO JPEG.
- Normalisation per scan: `lo` = p0.5, `hi` = p99.5 of non-zero cells, linear to 1–255, clamp; 0 stays 0 (no grey
  value). `lo`/`hi`/raw max stored in `meta.json` and returned by the meta endpoint. No gamma/equalisation.
- Level 0: `W = NumCols`, `H = round(W·180.65/360)` = 5086 for SCAN_085; each cell remapped through the Calib
  azimuth table and `elevation()`, pixels below the scanned band = 0. Rows are written in **bands** so peak heap
  stays ≤ 384 MiB; a scan is never held as more than one byte per cell at a time plus the delta stream.
- Pyramid: 512×512 tiles, level n+1 = 2×2 mean ignoring zeros, top level = first ≤ 2048 px wide; `grey` (8-bit grey)
  and `rainbow` (8-bit RGB from the same stops as `intensityRamp.ts`) variants; `meta.json` per §R36.
- Manifest `.ubim/manifest.json` beside the source (fallback `UBIM_DATA/processed/<project>/<scan>/`), freshness on
  size+mtime+version, `.part` + atomic rename, resumable per band, low-disk guard at 10 GB, never writes the source.
- Serving: `/api/p/{id}/intensity/{scanId}/meta` and `.../{ramp}/{level}/{col}/{row}`, catalogue `hasIntensity`,
  `Cache-Control: private` + ETag. Path never built from a request string: scanId → catalogue → manifest.

## 6. Phases (each ends runnable, with its own gate)

| # | Deliverable | Gate |
|---|---|---|
| P0 | This probe + plan | done today (§1, §2) |
| P1 | `cfb.py`, `fls.py` (headers, streams, varint, calib, elevation), depth + grey decode, CLI `probe` | the §4 numbers reproduce in pytest on the real file; synthetic-file tests for truncation/oversize/bad varint |
| P2 | Static shell: login-free **pano viewer** against a project folder (index/home, project catalogue, pano look/zoom, no measurement) | opens SCAN_085's `_hd` JPEG from a temp project fixture, 60 fps drag on the test box, WebGL-missing message |
| P3 | Intensity product end-to-end: process CLI → tiles → serve → client renders tiles with Grey/Rainbow and Auto/Standard/Max | sha256 + stats gate, tile counts, level choice unit tests, and a **Python-side alignment render** vs the FARO JPEG (§8) |
| P4 | Depth: `.fls` pick/plan-height parity; `.f3s` port + `.ubimdepth` sidecar; process job (queue, cancel ≤2 s, resume, caps, low disk) | pick parity vs the old app's JSON on fixed yaw/pitch; kill-and-resume byte-identical tiles |
| P5 | Measurement + overlay layer parity: point/distance/polyline/area, snap, undo, soft delete, DXF import/export, CRS | geometry unit tests + DXF round-trip fixtures |
| P6 | Map and home: WebShare map tiles, coverage images, scan dots, thumbnails, OSM proxy | tile route bounds/traversal tests |
| P7 | Auth and admin parity: users, invites, shares, audit, settings, IP-allow admin gate | gate tests: outside allow list → identical 404, CSRF 403, no XFF |
| P8 | Packaging: `uvicorn` runner, service wrapper for Windows, `deploy/` scripts, backup/restore of the DB | start/stop smoke test, no new ports, 127.0.0.1:8431 default |

## 7. What replaces the pack's acceptance suite

The pack's T1 (`mvn test`, 133 tests) cannot carry over. What carries over is the **evidence**:

- R0.2 stats + sha256 → `tests/test_intensity_real.py` (must run, not skip).
- R34 alignment → measured, printed, fail on median |dx| > 1 px / |dy| > 2 px at 8190.
- R20/R21 heap, R22 caps, R23 disk, R6 clamp, R12–R14 manifest/resume → unit tests with injected values.
- R37 traversal/gate → `httpx` tests against the same paths the old `IntensityServeTest` used.
- T6 perf → `pytest -m perf`: SCAN_085 full process ≤ 120 s wall, peak heap ≤ 384 MiB, second run cached ≤ 2 s,
  tile fetch ≤ 50 ms median on loopback.

`checks/run-all.sh` will be replaced by `make check` (lint + pytest + a real-file run) writing `test-log.txt`.

## 8. Blockers and UNKNOWNs

1. **FARO grey HD JPEG missing**: `04af88b2-…_grey_hd.jpg` (8190×4161) is not on this box. It is the only way to
   prove R34 alignment and "sharper than FARO". I need that one file (or the whole `Images/` folder for one scan).
   Everything else can proceed without it.
2. **Two extra records per Grey stream** — one file measured; assume and verify per file at decode time.
3. **`.f3s` intensity** — still UNKNOWN whether a per-point intensity stream exists; the trailing 4 bytes are RGB+0xFF
   per the pack's probe. v1 ships `.f3s` depth only and keeps FARO `_grey_hd.jpg` for those scans (R33 fallback).
4. **Windows Server 2012 / Python version** (§3).
5. **No sample project folder** on this box: only the raw `.fls`. A WebShare project tree (or a synthetic fixture that
   copies its layout: `Revisions/1/WebShareData/…`) is needed for P2 onward. I will generate a synthetic one from
   the FARO JPEGs once I have them.

## 9. Three decisions, then I build

**Decided 15 Nov 2026** (user): target is a **local Docker implementation** with no specific
platform requirements; scope is **full parity before this replaces anything**; the FARO grey HD
JPEG for the alignment gate was supplied and has been measured against (§Progress log below).

The three questions I had are answered, in the same order: hand-rolled WebGL2 (§2) rather than
vendoring three.js; a Linux container, so Python 3.12 and no Server 2012 ceiling; full parity
with the route list in §1 before this replaces the Java app.

## Progress log

### P1 — decoder: done and gated
`tests/test_fls_real.py` passes against `SCAN_085.fls` in 4.4 s with every reference number
exact (43,260,448 cells, 2,499,780 zeros, max 2,780, 534 cells above 2047, mean non-zero
653.841, p1/p50/p99 6/201/1787, sha256 `a94f3e1e…d8975c`). Banded decoding is byte-identical
to a full-stream decode for bands 0/512/2560/4096, at about 40 MiB peak per band.

### Intensity level 0 — rendered end to end
`python -m ubim.products.render --fls SCAN_085.fls --out out` produces a 10136 × 5086 image
(one pixel per scan column, square angular pixels) in 9.6 s total, 6.1 s of it rendering, with
a 2.6 MB peak working set. Per-scan bounds came out at p0.5 = 5 and p99.5 = 1819, raw max
2,780; 40,330,167 pixels are non-zero. Decoding is cached per scan: re-inflating the grey
streams once per strip made the first version 2.5× slower.

### R34 alignment — measured, and one real finding
Two independent measurements against FARO's own grey HD panorama:

- Global, at 2048 px wide with a ±40 px search: NCC **0.88 at exactly zero offset**. The scan
  geometry and the panorama agree on where things are, over the whole sphere.
- Local, on the 8190 × 4161 grid: median |dx| **0.79 px**, median |dy| **1.79 px**. The
  horizontal residual is a constant, consistent with a half-pixel sampling convention
  (pixel centres versus pixel edges), not a mapping error.
- The vertical residual is **not** constant: it runs from about +4 px at the top to −2 px at
  the bottom. That is a scale disagreement, and it implies FARO's JPEG spans roughly **180.1°**
  vertically rather than the 180.65° the current client assumes. Over 4161 rows that is up to
  7 px of drift — which is exactly the sort of slow creep that makes a grey overlay feel like
  it never sits still. Treat 180.1 as a one-scan measurement (UNKNOWN whether it is constant
  across FIRMWARE/FARO versions) until a second project folder confirms it.

Consequence for the rewrite: our intensity image is placed from scan geometry (Calib table,
RowStartAngle, ROW_SHIFT), which is the truth. The FARO JPEG must be placed with *its* span,
so the two modes line up with each other. That means the client should read the span from the
project metadata if present, and otherwise use the measured value, not 180.65.

## Progress log — viewer, products and packaging (this round)

Done and verified against SCAN_085 on this machine:

- **Orientation fix.** The panorama shader sampled the texture with `u = (az - az0)/2π`, while
  every product is built with `x = (az0 - az)/2π`. The view was therefore mirrored left-to-right
  relative to the data. Fixed in `static/js/gl.js`; the grey and intensity modes now show the
  same scene, and picks land in the same place the eye sees. This was a real defect, not a
  cosmetic one: measured distances were read from the mirrored column.
- **Depth product.** Dist streams decode like Grey. Values are stored raw in a `uint32` grid
  (`depth.grid`, 10136×5086) with a `depth.json` beside it; build time 7.1 s. Largest raw range
  15.9 M at `StorageDistFact = 100000`, i.e. 158 m; `raw / factor` gives metres and matches the
  scene (car at 12.6 m, wall at 27 m, ground at 4 m from the head). The scale is still an
  *inference* from the factor, not from a survey — the API returns raw units and metres side by
  side and the manifest keeps the factor.
- **Tile index.** `pyramid.build` now records which tiles exist per level (`tileIndex`), and the
  client requests only those. Empty areas cost no requests and produce no 404 noise; depth level
  0 has 106 occupied tiles of 360.
- **Picker hardening.** The viewer only asks for a range when the depth product exists, so a
  fresh project records directions and no failed requests.
- **Ranges in metres.** Features store `r` in metres, so DXF and JSON exports carry a real unit.
- **Tests.** `tests/test_web.py` (24 tests: gate, sessions, CSRF, roles, 404 parity, measurement
  round trip, exports, admin), `tests/test_units.py` (17: hashing, store schema, slugs, pyramid
  occupancy, depth sampling, DXF) plus the existing decoder tests. Whole suite: 47 passed.
  `tests/test_fls_real.py` now defaults to the reference scan when it is present.
- **Packaging.** `Dockerfile` (non-root uid 10001, `/data` volume, healthcheck, `/app` chowned
  after COPY — without that the runtime user cannot read the modules) and `compose.yaml`.
  Image builds and serves `/login` 200 as uid 10001; the data volume gets `secret.key`,
  `ubim.sqlite3` and `initial-admin.txt`.

Still open: `.f3s` octree (no sample file on this box to validate a port against), map view, and
the 180.1° versus 180.65° vertical span question recorded above.

## Progress log — spec alignment and site plan (16 Nov 2026)

Read the 15 Nov 2026 build spec (Grok Bot page, 52 k chars) and wrote the requirement-by-ID
mapping in `docs/SPEC-ALIGNMENT.md`. New code this round:

- **Site plan** (`ubim/products/plan.py`, product `plan`). Unprojects every range cell into the
  scan frame and keeps the highest return per 8 cm cell on a 2048² raster. 19.4 M returns,
  231 k filled cells, 5 s, extents 169 m, heights −2.9 to 8.7 m. Served as
  `/p/{slug}/s/{name}/plan/meta` and `plan.png`; the project page draws it with the scan dot and
  says plainly that positions are the scan origin until registration exists. Nothing is
  interpolated: cells with no return stay black, which is why one scan shows a wedge and a
  blind spot rather than a filled rectangle.
- **Measurement geometry** (`ubim/measure.py`). Length, plan distance, signed and absolute
  vertical, Newell area, perimeter, best-fit plane with RMS, max residual, inclination and
  centroid. Attached to every feature by the API, so the number in the panel is the number in
  the export. Tests: 100 m² square, 1 m² squares in XY/XZ/tilted, 45° plane, angles-only case.
- **Laser-return snapping** (`depth.nearest`). With snapping on, an empty pixel takes the
  nearest real return within ±3 cells and the reply says `snapped`, the cell offset and the
  snapped angles. `POST /pick` takes `snap: false` for exact-ray picks. Tested on a synthetic
  16×8 grid, including the window limit and the azimuth seam.
- **Labels** are stripped of `<`, `>` and control characters and capped at 120 characters
  (spec L1), at write time in the store.
- **DXF** now declares AC1009, `$INSUNITS 6` (metres) and `$MEASUREMENT 1`, so AutoCAD imports
  at the right scale without asking.
- Ranges are stored in metres; the earlier raw-unit features in the dev database were migrated
  once (1 of 8 rows) rather than special-cased in code.

Suite: 62 passed. Dev server: `--port 8431 --data-dir ./data-dev`.

## .f3s (C5) — the 2026 format

Two real samples arrived on 16 Nov 2026 (`New_Project_Scan_071.f3s`, 176 MB;
`New_Projectl_Scan_021.f3s`, 700 MB — the `l` is in the file name). Both are OLE/CFB containers,
so the existing `cfb` reader opens them; the payload is an iQscene octree
(`DataBase`, `PointData/FullDensity/Header`, `OctreeLeafPointData`, `ScanPoints`). The reference
implementation is `F3sDepth.java` (1006 lines) in the Java repo. The port is in progress; the
spec is explicit that a `.f3s` stores **colour** in its trailing bytes, not intensity, so the
intensity product must keep falling back to FARO `_grey` until an intensity source is proven.

## .f3s integrated (16 Nov 2026)

The port landed and works end to end on both samples. Numbers from this machine:

| sample | points | non-zero cells | range min/median/max | decode |
|---|---|---|---|---|
| New_Project_Scan_071.f3s (176 MB) | 17,166,892 (exactly the declared total) | 16.80 M (32.0 %) | 2.25 / 5.29 / 594.7 m | 5.7 s |
| New_Projectl_Scan_021.f3s (700 MB) | 69,236,940 (exactly declared) | 17.56 M (33.5 %) | 0.78 / 3.75 / 152.7 m | 16.8 s, 313 MB peak RSS |

Products build from them the same way as `.fls`: depth grid 10240 × 5120 (`distFact` 1e6,
`coordinateMap: local`), site plan (339 k cells at 0.078 m, and 687 k at 0.042 m for 021), picks
that return metres, and a panorama from the colour luma because the format has no scalar
intensity. Total 10 s for depth + plan on 071. The plan of 071 shows a recognisable courtyard —
rectangular buildings, trees, a car, the nadir hole at the apex — which is the evidence that the
per-node "local" coordinate map is right, not merely plausible.

Format: CFB; `DataBase`/`Nodes_*`/`Header` are gzip with a truncated trailer; streams 0-999 are
inner pages (packed `LeafIndexInfo` groups), 1000+ are `OctreeLeaf` pages with
`OctreeLeafPointData`/`ScanPoints`; a record is 3 × LE int16 + RGB + 0xFF.

Still UNKNOWN, and left as UNKNOWN in the code: the unit string (none is declared), what the
trailing 0xFF means, and the RGB channel order. `scan_position` is None and the transform is
identity for both samples, so a real project is still needed to exercise registration.

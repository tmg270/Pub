# uBIM viewer (Python + HTML)

A self-hosted viewer for FARO Focus scan projects. It reads `.fls` scans directly, renders the
panorama, builds high-resolution intensity and range products, and lets you measure in 3-D.
The back end is Python (FastAPI, SQLite); the front end is plain HTML, CSS and ES modules with
WebGL2. There is no build step and no JavaScript dependency to install — the browser loads the
files in `ubim/static` exactly as they are.

## What works today

| Area | State |
|---|---|
| `.fls` decode (intensity, range, calibration, images) | Done, byte-exact against the Java reference data |
| Panorama viewer, HD/grey/intensity/depth modes, grid | Done |
| Intensity product at native resolution (10 136 × 5 086) with tile pyramid | Done, ~18 s per scan |
| Range product with a pick endpoint (azimuth/elevation → distance in metres) | Done, ~7 s per scan |
| Measurements: points, lines, polylines, areas; layers; undo; DXF and JSON export | Done |
| Measurement values (slope/plan/signed height, area, perimeter, plane fit with RMS) computed server-side | Done |
| Photographic panorama as native-resolution tiles (`.fls`, built on demand) | Done |
| Nearest-return snapping on picks (±3 cells, reported, can be turned off) | Done |
| Site plan product: top-down raster of the range data with clickable scan locations | Done on the project page (positions need registration) |
| Users, invites, roles (admin/editor/viewer), audit log, IP allow list | Done |
| Docker packaging | Done (`Dockerfile`, `compose.yaml`) |
| `.f3s` (the 2026 project format) | Range decode, depth product, site plan, picks and a colour panorama work (5.7 s for a 176 MB scan; 16.8 s for 700 MB). A scan with no WebShare images gets a panorama stitched from its own colour product (`X-Pano-Source: colour-luma`) |
| Map view, per-scan registration, sharing links | Done — the map plots the position a project declares; it does not derive one |

## Documentation

| document | what it covers |
|---|---|
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | how the parts fit: request flow, build flow, storage, security model, deliberate limits |
| [docs/DATA-FORMATS.md](docs/DATA-FORMATS.md) | the `.fls` and `.f3s` containers, panorama geometry, range scaling, product file layout |
| [docs/OPERATIONS.md](docs/OPERATIONS.md) | install, container, every setting, first run, library discovery, backup, troubleshooting |
| [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md) | the test suite, conventions, adding a route or a product, debugging the interface |
| [docs/API.md](docs/API.md) | every endpoint with the capability it checks, generated from the code |
| [docs/MODULES.md](docs/MODULES.md) | module-by-module reference, generated from the docstrings |
| [docs/SPEC-ALIGNMENT.md](docs/SPEC-ALIGNMENT.md) | each requirement of the build spec, its state, and the evidence for it |

Every module, class and function in `ubim/` carries a docstring; the module reference is
generated from them.

## Quick start (Docker)

```sh
# 1. Put your scan trees somewhere the container can read, e.g. ./scans
# 2. Optionally pin the first administrator password:
export UBIM_ADMIN_PASSWORD='choose-something-long'
docker compose up --build -d
```

Open `http://<host>:8431`. If you did not set a password, the app generates one on first start
and writes it to `/data/initial-admin.txt` inside the `ubim-data` volume
(`docker compose exec ubim cat /data/initial-admin.txt`).

Then, in the app: **Projects → Add project**, and give the path *inside the container*
(`/scans/MyProject` for a WebShare project tree, or `/scans/FlatFolder` for a folder of loose
`.fls` files). Registering a project never writes to it: scans are opened read-only.

Products (the intensity and range pyramids) are written beside the scan when that tree is
writable, otherwise under the data directory — which is the case when `/scans` is mounted
read-only, as in the compose file.

## Using the viewer

Open a project, choose a scan, and press **Intensity** or **Depth** in the toolbar to build the
product the first time (a background job; the panel shows progress). After that the modes open
instantly from tiles.

Measurements are stored as directions (azimuth, elevation and range), never as screen pixels, so
they stay correct at any zoom and in any mode. Pick **Point**, **Line**, **Area** or **Finish** to
draw, **Undo** to step back one action, and export with the buttons in the side panel (`.dxf` for
SCENE/CAD, `.json` for everything).

Distances need the range product. If it has not been built, points are still recorded with their
direction and get a range once the product exists. The values shown next to each measurement are
computed by the server from the stored angles and ranges (`ubim/measure.py`), so the figure in
the panel and the figure in the export are the same number.

The project page shows a **site plan**: a top-down raster built from the range product of a scan
(`ubim/products/plan.py`), with the scan location on it. Cells with no return stay black. Scan
positions are the scan origin until a registration transform is applied, and the page says so.

`docs/SPEC-ALIGNMENT.md` maps every requirement ID in the 15 Nov 2026 build spec to what this
port does today, with the gaps named.

## Configuration

All settings are environment variables; none are required.

| Variable | Default | Meaning |
|---|---|---|
| `UBIM_DATA_DIR` | `/data` | Database, sessions, thumbnails, fallback product store |
| `UBIM_ALLOW_CIDRS` | empty (everyone) | Comma-separated allow list. Requests from outside get an identical 404 on every path |
| `UBIM_ADMIN_PASSWORD` | generated | Password for the first `admin`, used only when the database is new |
| `UBIM_WORKERS` | `2` | Product build threads |
| `UBIM_SECURE_COOKIES` | `0` | Set to `1` behind TLS |
| `UBIM_PRODUCT_PLACEMENT` | `beside` | `beside` writes products next to the scan; anything else keeps them under the data directory |
| `UBIM_DISK_GUARD_GB` | `10` | Stop building when free space drops below this |
| `UBIM_ALLOW_ANONYMOUS_BROWSE` | `0` | Let unauthenticated visitors see projects without measuring |

## Security model

Every request passes the IP allow list first; outside it, every path returns the same 404 so the
app's shape is not visible. Sessions are random 256-bit ids in an `HttpOnly`, `SameSite=Lax`
cookie; state-changing requests additionally need a per-session `X-CSRF-Token` header. Passwords
are stored as scrypt hashes. The CSP forbids inline script, so all behaviour lives in
`ubim/static/js`. The admin password is never stored in plain text.

## Repository layout

```
ubim/formats/     .fls container and stream decoding (read-only)
ubim/products/    intensity, range, tile pyramids, product build orchestration
ubim/             web app: api, pages, auth, store, projects, jobs
ubim/static/      the whole front end (HTML shell, CSS, ES modules, WebGL2 renderer)
tests/            unit and web tests; the real-scan test uses SCAN_085 when present
docs/             architecture, formats, operations, development, API and module references
PLAN.md           decisions, measurements and the running progress log
```

## Tests

```sh
python -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-dev.txt
.venv/bin/python -m pytest tests -q
```

The suite covers the decoder, the intensity/range mapping, the auth and CSRF rules, the IP gate,
the measurement round trip and the DXF writer. Tests that need the shipped reference scan skip
when it is absent.

## Docker

The image carries the app and its Python dependencies; the front end is the ES modules in
`ubim/static`, so there is no build step for the browser and no JavaScript dependency to
install. `docker compose up --build` starts it on port 8431 with a named volume for the
database and a scan mount from `$UBIM_SCANS` (default `./samples`).

Use a named volume for `/data`: a named volume inherits the ownership the image set on that
directory (uid 10001), while a bind mount arrives owned by whoever created it on the host, and
the app then fails with `Permission denied: /data/secret.key` on first start. For a bind mount,
`chown -R 10001:10001 <host directory>` once. The first start writes the administrator
password to `/data/initial-admin.txt`.

## Known limits

- A product built before the gap filling existed still shows the thin dark lines a sparse
  `.f3s` grid leaves. Rebuild the product (`POST /api/p/{slug}/s/{name}/process`) to get the
  interpolated version; the filling only touches cells with at least three filled neighbours.

- `.f3s` ranges are micrometres by inference: the container declares no unit string, so
  `range_scale = 1e-6` comes from the reference reader plus plausibility (a 5,286,326 raw value
  lands at 5.29 m in a street scene). Treat absolute distances from `.f3s` as provisional until
  one is checked against a known dimension.
- A `.f3s` stores RGB in its trailing record bytes, not scalar intensity, so its panorama is
  "colour luma" and the manifest records `derivedFrom: f3s colour luma`. The RGB channel order
  and the meaning of the trailing 0xFF byte are assumptions.
- The range scale comes from `StorageDistFact` in the scan header and is *inferred*:
  `raw / 100000` metres fits the scene (largest range 569 m, a car at 12.6 m) but has not been
  checked against a survey. Treat absolute distances as provisional until you compare one
  known distance with SCENE.
- Panorama alignment between the FARO JPEG and the decoded intensity map measured a median
  offset under 2 px on SCAN_085, with a slight vertical drift that suggests the JPEG spans about
  180.1° rather than the 180.65° used for the product. One scan, so the mapping constants are
  kept as measured and the residual is documented rather than tuned away.
- No map view yet. Products are built on demand, not watched for changes.

## Exports

Marks travel three ways: DXF (layers, colours, lineweights, a comment naming the declared CRS —
declared, never applied), CSV (one row per vertex with the angles and the metres they imply) and
E57 (a real point cloud written through libE57Format, i.e. `pye57`, one point per vertex with a
position, in the scan's own frame). A vertex whose range never resolved is left out rather than
placed at the origin.

Importing a DWG needs a converter on `PATH` (GNU LibreDWG's `dwg2dxf`/`dwgread`, or ODA File
Converter). None is bundled: DWG is binary, no Python wheel parses it, and Debian trixie does not
package LibreDWG. Without one, an upload is refused with the fix named instead of decoded wrongly.

## Running the image

`docker build -t ubim:latest .` then

```
docker run -d -p 8431:8431 \
  -e UBIM_ADMIN_PASSWORD='…' -e UBIM_ALLOW_CIDRS='10.0.0.0/8' \
  -v ubim-data:/data -v /path/to/scans:/scans:ro ubim:latest
```

The container runs as its own user, so give it a named volume for `/data`. A bind mount keeps the
host's owner and the app then cannot write `/data/secret.key`; it says so, naming the uid, and the
fix is `chown` the directory, `--user $(id -u):$(id -g)`, or the named volume above. Scans are
mounted read-only on purpose: the app never writes to a source file.

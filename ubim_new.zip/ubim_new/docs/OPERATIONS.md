# Running it

The application is a Python process with a data directory. It has no external dependencies at
runtime beyond its Python packages, and it makes no outbound calls except to OpenStreetMap for
map tiles, which are cached after the first fetch.

## Local install

```
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python -m ubim --port 8431 --data-dir ./data
```

The first start creates `data/secret.key` (mode 0600) and the database. When no user exists the
application writes an initial administrator password to `initial-admin.txt` in the data
directory, or uses `UBIM_ADMIN_PASSWORD` when it is set; the file is removed once a user exists.

Open `http://<host>:8431/` and sign in.

## Container

```
docker build -t ubim:latest .
docker run -d --name ubim -p 8431:8431 \
  -e UBIM_ADMIN_PASSWORD='change-me' \
  -e UBIM_ALLOW_CIDRS='192.168.0.0/16' \
  -v ubim-data:/data \
  -v /path/to/scans:/scans:ro \
  ubim:latest
```

`compose.yaml` is the same thing with the variables filled from the environment.

Two things about the container matter:

- **`/data` must be writable by the container's user.** The image runs as `ubim` (uid 1000). A
  named volume works because Docker gives it to that user. A bind mount keeps the host's owner,
  and the app then cannot write `secret.key`; it says so, naming the uid, and the fix is to
  `chown` the directory, run with `--user $(id -u):$(id -g)`, or use a named volume.
- **Scans are mounted read-only on purpose.** The application never writes to a source file;
  products go beside the scan when that folder is writable, otherwise into the data directory.

## Configuration

Every setting is an environment variable with the `UBIM_` prefix (or a command-line flag where
one exists). The defaults are for a local tool; a deployment that is reachable by others should
set the allow list and secure cookies.

| variable | default | meaning |
| --- | --- | --- |
| `UBIM_DATA_DIR` | `/data` | database, secret, caches, project working files |
| `UBIM_HOST` / `UBIM_PORT` | `0.0.0.0` / `8431` | bind address and port |
| `UBIM_ALLOW_CIDRS` | empty | comma-separated networks allowed to connect; empty allows all |
| `UBIM_SECURE_COOKIES` | `0` | mark the session cookie `Secure` (set when served over HTTPS) |
| `UBIM_ALLOW_ANONYMOUS` | `0` | allow use without a session (sign-in still needed for writes) |
| `UBIM_ALLOW_ANONYMOUS_BROWSE` | `0` | allow reads without a session |
| `UBIM_SESSION_HOURS` | `12` | how long a sign-in lasts |
| `UBIM_INVITE_HOURS` / `UBIM_SHARE_HOURS` | `72` / `720` | lifetime of invitation codes and share links |
| `UBIM_MAX_UPLOAD_MB` | `512` | largest drawing upload accepted |
| `UBIM_MAX_BUILD_MB` | `2048` | memory ceiling for one build; a build above it is refused with the numbers |
| `UBIM_DISK_GUARD_GB` | `10` | free space below which a build is refused, and which the panel warns about |
| `UBIM_WORKERS` | `2` | build workers |
| `UBIM_PRODUCT_PLACEMENT` | `beside` | write products beside the scan, or under `UBIM_DATA_DIR` |
| `UBIM_LIBRARY_ROOT` | empty | folder that discovery walks for project folders |
| `UBIM_VERSION` | package version | what `/healthz` and the System tab report |

## First run and accounts

1. Start it. If `UBIM_ADMIN_PASSWORD` is unset, read `initial-admin.txt` from the data directory
   and sign in as `admin`.
2. Change the password in Admin → Users.
3. Create further accounts by invitation (Admin → Invites), or let people redeem a code.

Roles are `viewer`, `editor` and `admin`; the capability each holds is in `auth.CAPABILITIES`
(`viewer` may read and measure, `editor` may also change layers and measurements, `admin` holds
everything). A new account is a viewer unless the invitation says otherwise.

### When the password does not work

The password is written to `initial-admin.txt` once, when the database is first created. A file
that has survived from an earlier instance, or a volume reused with a different database, then
shows a password the database never had. The sign-in log says which part failed — `no such user`,
`account disabled` or `wrong password` — so a stale file can be told from a typo:

```
docker compose logs ubim | grep "login failed"
```

Set a new password from inside the container, whether or not you can sign in:

```
docker compose exec ubim python -m ubim --data-dir /data --set-password admin
```

It reads the password from `UBIM_ADMIN_PASSWORD`, or asks for it when it runs on a terminal,
hashes it, ends that user's sessions, and exits without starting a server. `--password` works
as well, with the caveat that it is then visible in the process list.

## Registering a scan library

A project is a folder holding scans, or a WebShare folder whose `Revisions/<rev>/Scans/` holds
them. Point `UBIM_LIBRARY_ROOT` at the parent folder, then Admin → Library → *Find folders*
registers what it finds; *What would be added* is the same walk without writing. Discovery
skips a folder that already has a project, and reports what it skipped and why.

Products are built from the project page, per scan. The Library tab prices the products each
scan would need (`estimate_mib`) and can clear them; clearing is always safe, because a product
is derived from the scan and rebuilding produces the same pixels.

## Backup and restore

Stop the process, copy the data directory, start it again. That covers users, projects, layers,
measurements, drawings and settings. Products are derived: they can be excluded from a backup
and rebuilt, at the cost of the build time (roughly a few minutes per scan on the reference
hardware).

A single SQLite file can be copied while running if the copy is taken with `sqlite3 .backup` or
after a checkpoint; the simple rule is to stop first.

## Health and monitoring

`GET /healthz` answers `{"ok": true, "version": …}` without a session and is what the image's
health check calls. The System tab shows version, uptime, paths, free disk, counts and the allow
list. The audit log is in Admin → Audit, and is also queryable at `/api/admin/audit`.

The disk guard is enforced before a build and shown in the scan panel (`Disk free … below the
guard`), so an operator sees the same number the build would refuse on. There is no background
alerting; the warning appears when someone looks at a scan.

## Troubleshooting

| symptom | cause and fix |
| --- | --- |
| `Permission denied: '/data/secret.key'` | bind mount owned by the host user; use a named volume, `chown`, or `--user $(id -u):$(id -g)` |
| every request is 404 | the allow list does not include the client; `UBIM_ALLOW_CIDRS` is the gate, and `deny_status` is 404 by design |
| a build is refused with "needs about N MiB" | raise `UBIM_MAX_BUILD_MB`, or build the products one kind at a time |
| a build is refused with "only N GiB free" | clear old products (Admin → Library), or lower `UBIM_DISK_GUARD_GB` |
| a DWG upload is refused with a hint | no converter on `PATH`; install `libredwg-tools` (Debian trixie does not package it, so use the ODA converter or a newer base image) |
| depth is blank | the scan's ranges did not decode plausibly; check the build's job message, and the depth manifest's `maxRaw` |
| the map is empty | the tiles could not be fetched; the map needs outbound access once, then it is cached |
| a page shows yesterday's script | hard-reload once; the static URLs carry a build stamp, so this should not happen |
| `database is locked` | two processes on one data directory; run one, or point the second at another directory |
| sign-in refused with the password from `initial-admin.txt` | the file and the database disagree (reused volume); `docker compose logs ubim \| grep "login failed"` says which, and `--set-password` fixes it |

## Upgrading

The schema migrates on start (`Store.init`), adding columns and tables as needed. Stop the old
process, replace the code, start it again. A downgrade is not handled: take a copy of the data
directory first if that matters.

The product layout is versioned by its manifests. When a manifest lacks a field the current
code needs, the product is treated as stale and rebuilt rather than guessed at.

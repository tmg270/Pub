# Working on it

The tree is plain Python and plain ES modules. There is no build step, no bundler and no
dependency that needs a toolchain: editing a file is the whole cycle. Python edits need the
server restarted; script and style edits are picked up on reload because the static URLs carry a
build stamp.

## Layout

```
ubim/                 the application
  formats/            .fls and .f3s readers, compound file wrapper
  products/           intensity, depth, plan, photograph, the combined build
  static/js/          the interface: viewer, project, admin, home, map
  static/css/         one stylesheet
tests/                pytest suite, real-scan tests skip when the sample is absent
docs/                 this documentation
Dockerfile            python:3.12-slim, non-root user, health check
requirements*.txt     runtime and development pins
pyproject.toml        package metadata and pytest settings
```

## Running the tests

```
.venv/bin/pip install -r requirements-dev.txt
.venv/bin/python -m pytest tests -q
```

186 tests, about a minute and a half on the reference machine. The suite uses a temporary data
directory per test and a TestClient; the tests that need a real scan look for one in the project
root and skip with a reason when it is not there. Nothing in the suite writes to a source scan.

Test files are named for the behaviour they check (`test_dual_build.py`, `test_memory_cap.py`,
`test_project_crs.py`, …). A test that reproduces a bug should fail before the fix and pass
after; several tests in the suite exist because a bug shipped once:

- `test_dual_build.py` compares the combined build against a fresh sequential build, byte for
  byte — the first attempt reused the wrong index space and differed by two million pixels.
- `test_memory_cap.py` checks the refusal message contains the numbers.
- `test_snap.py` covers the panorama azimuth sign, which was inverted once.

## Conventions

- **Docstrings.** Every module, class and function has one, including nested helpers: say what it
  does and, where it matters, why it is done that way. The module reference in
  [MODULES.md](MODULES.md) is generated from them, so a missing docstring is visible as a blank
  entry.
- **No JavaScript dependencies.** A new behaviour is a function in an existing module or a new
  one, imported with a relative path. Nothing is installed and nothing is transpiled.
- **Source scans are never written.** Any new output goes beside the scan or into the data
  directory.
- **Capabilities at the top of a route.** A route starts with `require(request, capability)`;
  the API reference is generated from those calls, so an omission is visible.
- **Writes are audited.** A new state change calls `Store.audit`.
- **Honest limits.** When something is a declaration, a heuristic or an approximation, the
  docstring says so. The spec alignment document marks a requirement done only when a test or a
  measurement backs it.

## Adding a route

1. Put it in the matching `api_*.py` module, as a function whose first line is
   `require(request, capability)`.
2. Give it a docstring: the endpoint reference is generated from the first line.
3. Add a test that exercises it through `TestClient`, including the unauthorised case.
4. Regenerate the reference if you keep generated docs: `python gendocs.py` from the workspace
   root writes `docs/API.md` and `docs/MODULES.md` from the live application.

## Adding a product

A product is a folder under `<scan>.ubim/` with a manifest and tiles. To add one:

1. Write a module in `ubim/products/` with `build(scan_path, product, progress=None)` and
   `load_meta(product)`; write tiles through `pyramid.write_level` so the tree matches the
   others.
2. Record the source in the manifest (size, mtime, digest) — `is_fresh` is what stops a stale
   product being served.
3. Wire it into `products_api.build_products` and the product state map, and add its estimate to
   `estimate_mib`, or the memory guard will not know about it.
4. Add it to the interface only after the manifest exists: a missing product must render as
   "not built yet", not as an error.

## The combined build

`products/dual.py` exists because intensity and depth both need the grey and range streams. The
combined path decodes once and keeps a uint16 scratch image. Two rules keep it correct, and both
have a comment in the code because getting them wrong is silent:

- A strip's rows are output columns, not scan columns: never feed `sample_strip`'s output back
  into `render_strip`.
- The wrap seam splits a strip in two, and the filters must run on each half separately; running
  them on the concatenation moves one pixel at the seam.

## Debugging the interface

The viewer draws with WebGL2 and keeps a probe in the DOM (`#plan-probe`, the HUD, the compass
text), so a headless browser can assert on state rather than on a screenshot. When a script
change does not appear to take effect, check that the URL carries the current build stamp; the
server sets `no-store` on the interface.

## Known gaps

These are deliberate and documented in [SPEC-ALIGNMENT.md](SPEC-ALIGNMENT.md): no job priority,
no filesystem watcher, no background alerting, E57 exports marks rather than the point cloud, and
DWG import depends on an external converter.

# Architecture

The application reads FARO laser scans from disk, turns them into image pyramids, and serves a
browser interface for looking at them and measuring on them. It is a single Python process with
a SQLite file and a folder of product files; there is no message queue, no external service and
no build step.

This document describes how the parts fit together and why they are arranged that way. The
per-module reference is in [MODULES.md](MODULES.md); the endpoint list is in [API.md](API.md);
the on-disk formats are in [DATA-FORMATS.md](DATA-FORMATS.md).

## Constraints that shaped it

- **No JavaScript dependencies.** The interface is hand-written ES modules and WebGL2. There is
  no bundler, no framework and no `node_modules`, so a checkout runs as it is and nothing has to
  be rebuilt after an edit. Pages are Python strings (`ubim/pages.py`), scripts are served from
  `ubim/static/`.
- **Source scans are read-only.** A `.fls` or `.f3s` is opened, read and closed. Everything the
  application produces is written beside it, under `<scan>.ubim/`, or into the data directory.
  Nothing rewrites a scan, so a library can be mounted read-only.
- **One process, bounded memory.** A build decodes a scan in strips and writes tiles as it goes.
  Peak memory is one strip plus one level-0 image, and a build is refused up front when the
  estimate exceeds `UBIM_MAX_BUILD_MB` or the free disk is under the guard.
- **Local-first.** No outbound calls at runtime except the map tiles, which are cached on disk
  after the first fetch. The database is a file. Backups are a copy of the data directory.

## Components

| area | modules | role |
| --- | --- | --- |
| containers | `formats/cfb.py`, `formats/fls.py`, `formats/f3s.py` | read the compound files, decode range and grey strips |
| products | `products/*`, `products_api.py`, `products/dual.py` | build intensity, depth, plan and photograph pyramids beside a scan |
| measurements | `measure.py`, `api_measure.py`, `dxf.py`, `dwg.py`, `e57.py` | points, distances, areas, heights, drawing import and export |
| registration | `registration.py`, `gps.py` | the transform between scan and project frames, position from the scan's own GPS |
| serving | `app.py`, `api.py`, `api_settings.py`, `pages.py`, `tiles.py` | routes, pages, static files, map tiles |
| accounts | `auth.py`, `store.py` | users, sessions, invitations, shares, audit |
| jobs | `jobs.py` | the build worker pool and its progress records |
| library | `library.py`, `projects.py` | finding project folders, registering scans, pricing products |
| interface | `static/js/*`, `static/css/*` | the viewer, the project page, the admin tabs, the map |

## A page request

1. `app.py` runs the allow-list middleware first: a request from outside `UBIM_ALLOW_CIDRS` is
   answered with `deny_status` (404 by default) before any route sees it.
2. The session middleware reads the `ubim_sid` cookie and loads the session from SQLite, so a
   route can ask `require(request, capability)` without doing its own lookup.
3. `pages.py` renders HTML into a shell that carries the build stamp: the newest file time under
   `ubim/static`. Script and CSS URLs include that stamp, so an edited interface is a different
   URL and a browser cannot keep running yesterday's module.
4. The browser fetches the module graph from `/static/<stamp>/…`, which `app.py` serves with
   `Cache-Control: no-store`.
5. The page's script calls the JSON API for the data it needs.

## A build

A build is the only expensive operation, and it is deliberately explicit: nothing is built until
someone asks for it.

1. `POST /api/p/{slug}/s/{name}/process` names the kinds to build.
2. `products_api.build_products` estimates memory and disk, and refuses with the numbers when
   either cannot be met. It also refuses when the scan's products were built from a different
   version of the scan.
3. `jobs.start` hands the work to a small thread pool and returns a job id immediately.
4. The worker opens the scan, decodes strips through `formats/fls.py`, and writes tiles level by
   level. Intensity and depth together take the combined path (`products/dual.py`), which
   decodes the grey and range streams once and feeds both products, because the two separate
   builds walk the same bytes three times otherwise.
5. Progress is written to an in-memory job record that the interface polls; the finished
   manifest is written beside the tiles.
6. The worker never holds the whole scan. It keeps one strip, the scratch grey image when the
   combined path is used, and the level-0 image the pyramid needs.

A build writes beside the scan when the scan's folder is writable, and under the data directory
otherwise (`UBIM_PRODUCT_PLACEMENT`). The manifest records which scan it came from, by size,
mtime and digest, so a rebuilt source is never served from old tiles.

## Storage

```
/data                        UBIM_DATA_DIR
  ubim.sqlite3               users, sessions, projects, scans, layers, features, audit
  secret.key                 instance secret, 0600
  cache/tiles/{z}/{x}/{y}.png  map tiles, written on first fetch
  thumbs/                    generated thumbnails
  projects/<slug>/           project working files when products cannot sit beside a scan
<scan folder>
  SCAN_085.fls               the source, never written
  SCAN_085.fls.ubim/         products: intensity/, depth/, plan/, photo/, scratch
```

The products are a set of manifests and tile trees, not an archive: deleting the folder and
rebuilding produces the same pixels, which is what makes the cache safe to clear. The admin
Library tab prices the set and can clear it.

## Security model

- **Reachability.** The allow list is enforced in middleware, and it is the only thing that
  decides whether a caller gets in at all. It is not a substitute for authentication when the
  application is exposed.
- **Authentication.** Passwords are scrypt hashes with the parameters stored with them. A
  session is a random id in an HttpOnly cookie, with a per-session CSRF token that every write
  must send as `X-CSRF-Token`. Sessions expire, and the expiry is checked on load, not only when
  the cookie is set.
- **Authorisation.** Capabilities are `view`, `edit_layers`, `manage_projects`, `manage_users`
  and `admin`, checked by `require()` at the top of each route. Roles map to sets of
  capabilities in `auth.CAPABILITIES`; an unknown role holds nothing.
- **Writes are audited.** Every state change goes through `Store.audit`, which records the user,
  the action, the detail and the address.
- **Content Security Policy.** Pages carry a policy that allows the application's own scripts
  only, with no inline event handlers.
- **The interface cannot reach outside the static tree.** The static route resolves the path and
  refuses anything that escapes it.

## Deliberate limits

- Measurements live in the scan's frame. A project frame can be declared and a transform
  applied, but a scan without a registration is treated as axis-aligned.
- The declared CRS is a label. Coordinates are not reprojected, and nothing checks that the
  declaration matches the numbers.
- The map plots the position a project declares; it does not read positions out of every scan.
- E57 export writes the marks, not the point cloud.
- DWG import needs an external converter (`dwg2dxf`, `dwgread` or the ODA converter) on `PATH`.
- There is no filesystem watcher: a new folder is registered by running discovery.
- Jobs run in submission order. There is no priority and no cancellation mid-build.

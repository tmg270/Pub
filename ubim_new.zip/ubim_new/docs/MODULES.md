# Module reference

What each module is for and what it exposes. Generated from the module and
function docstrings, so it describes the code as it stands.

## `ubim/__init__.py`

uBIM viewer: reading FARO scans, building products, and serving the interface.

The package is deliberately plain: no framework beyond FastAPI, no bundled JavaScript, and no
build step. Modules are grouped by what they do — ``formats`` reads the files, ``products``
turns a scan into tiles, ``api*`` serves it, ``pages`` writes the HTML.

## `ubim/__main__.py`

``python -m ubim`` — run the server.

Kept deliberately thin: configuration comes from the environment (see :mod:`ubim.config`),
and the only arguments are the ones you want to override while developing.

| name | purpose |
| --- | --- |
| `main` | Run the server: parse ``--host``/``--port``/``--data-dir``, load the configuration and serve the app. |

## `ubim/accuracy.py`

What these numbers are, and what they are not.

The same sentence goes into the scan panel, the JSON, the DXF (as 999 comments) and the CSV
(as a leading ``#`` line) so a file that leaves the app still carries its caveat.

## `ubim/api.py`

JSON API.

Paths in requests are only ever used as *keys* (slug, scan name, integers); the filesystem
paths behind them come from the database. That is what makes traversal impossible rather
than merely unlikely: ``../x``, ``%2e%2e`` and friends simply fail to match a row.

| name | purpose |
| --- | --- |
| `store` | The store for this application instance. |
| `config` | The configuration for this application instance. |
| `session` | The session the middleware attached, or None when the request is anonymous. |
| `require` | The session if it holds ``capability``, else a 401 or 403 that says which one was needed. |
| `project_or_404` | The project for a slug, or a 404 that names the slug. |
| `scan_or_404` | The scan row for a name inside a project, or a 404 that names the scan. |
| `me` | Who the caller is, what they may do, and the CSRF token to send with writes. |
| `login` | Sign in with a name and password; the session cookie is set on the response. |
| `logout` | End the session and clear the cookie. |
| `list_projects` | Every project with its scan count and position, for the home page. |
| `add_project` | Register a folder as a project; scans are discovered from the folder, not supplied by the caller. |
| `get_project` | One project with its scans, drawings, layers, frame, position and declared CRS. |
| `disk_state` | Free space under the data directory, and the guard a build must leave behind. |
| `scan_meta` | One scan's geometry, panorama roles, product state, and what a build would need in memory and disk. |
| `set_pose` | Record a scan's transform into the project frame. |
| `pano_image` | The panorama image for one role, optionally scaled, straight from the source file's stored JPEG. |
| `thumbnail` | A small square preview of a scan, cached beside the scan's products. |
| `product_state` | Whether each product exists, when it was built, and whether it still matches the scan. |
| `process` | Queue a build for the kinds asked for, refusing before it starts when memory or disk cannot take it. |
| `job_state` | A job's progress: stage, counts, and the result when it finished. |
| `intensity_meta` | The intensity product's manifest, or a 404 before it is built. |
| `intensity_tile` | One intensity tile, as a PNG, from the requested ramp and level. |
| `photo_meta` | The photograph product's manifest. |
| `photo_tile` | One tile of the photograph pyramid. |
| `depth_meta` | The depth product's manifest: bounds, ranges and the ramp it was written with. |
| `depth_tile` | One tile of the depth pyramid. |
| `plan_meta_route` | The plan product's manifest, including the placement it was drawn with. |
| `plan_image_route` | The plan image, filled or outlined, at the size asked for. |
| `plan_tile_route` | One tile of the plan pyramid. |
| `pick` | Distance and height at an azimuth/elevation, used for measuring on the panorama. |
| `admin_library` | The catalogue: what is registered, where it lives, and what it costs on disk. |
| `admin_discover` | Walk the library root (or a given folder) and register project folders it does not know. |
| `admin_cache` | What the products cost per scan, and which of them no longer match their scan. |
| `admin_cache_clear` | Remove product directories. Scans are never touched, and every product can be rebuilt. |
| `admin_users` | Every user, with role, state and when they last signed in. |
| `admin_user_create` | Create a user; the password is hashed here and never stored as sent. |
| `admin_user_update` | Change a user's role, password or disabled state. |
| `admin_invite_create` | Create an invitation code for a role and lifetime. |
| `admin_invites` | The invitation codes with their state and who redeemed them. |
| `admin_share_create` | Create a share link for a project, optionally read-only and time-limited. |
| `admin_shares` | The share links, by project. |
| `admin_audit` | The audit log, newest first, paged. |
| `admin_system` | Version, uptime, paths, disk, counts and the allow list, for the System tab. |
| `save_view` | Store the picture the viewer sent as this project's picture. |
| `get_view` | The saved picture, or 404 when the project has none yet. |
| `neighbours` | The project's other scans as seen from one scan: which way, how far, or not apart. |

## `ubim/api_drawings.py`

Imported CAD drawings: they belong to the project, not to one scan.

A drawing is stored in the project frame (metres, Z up) because that is what a CAD file means.
To show it over a scan it is expressed in that scan's frame, which needs the scan's
registration; with no registration the drawing is read as being in the scan's own frame and
the response says so (``assumedFrame``). Nothing is draped here: a flat drawing is drawn flat
and the height it should sit at is a question for the viewer, not for the importer.

| name | purpose |
| --- | --- |
| `rows_for` | The project's live drawings, newest first; deleted ones are left out. |
| `frame_for` | The project's declared placement of its drawings, if one has been recorded. |
| `place` | A drawing vertex in the scan's frame, given the project's declared mapping. |
| `as_features` | Drawing shapes as measurement-shaped features for one scan, plus how many were dropped. |
| `read_drawing_frame` | How the project's drawings are placed in the scan frame: origin, rotation and scale. |
| `write_drawing_frame` | Declare how this project's drawings line up with its scans, or clear the declaration. |
| `import_drawing` | Import a DXF sent as text, or a DWG sent as base64 that a converter turns into DXF. |
| `drawings_for_scan` | The project's drawings expressed in one scan's frame, ready to be drawn over it. |
| `list_drawings` | The project's drawings with their shape counts and metadata, without the geometry. |
| `delete_drawing` | Soft-delete a drawing, so its geometry can be recovered from the row. |
| `JSONResponseCompat` | A JSON response with an explicit status code, used for a 201 with a body. |

## `ubim/api_measure.py`

Measurement and annotation routes.

Features live on layers owned by the project, not by the scan, so the same layer can carry
notes gathered from several scans of the same site. Each feature carries the scan it was
measured on inside its geometry, and every write lands under a fresh ``undo_group`` so an
undo is a single, atomic revert of one user action rather than a guess.

| name | purpose |
| --- | --- |
| `clean_label` | Strip angle brackets and control characters from a user label, and cap its length. |
| `list_layers` | The project's layers, with visibility and ownership. |
| `create_layer` | Add a layer; the colour and name are the caller's, the owner is the session's user. |
| `update_layer` | Change a layer's name, colour or visibility. |
| `delete_layer` | Soft-delete a layer, leaving its features attributed to it in the history. |
| `list_features` | The measurements recorded on one scan, with their points and computed metrics. |
| `create_feature` | Record a measurement: its kind, points, label, layer and the metrics the points imply. |
| `update_feature` | Change a feature's points, label, layer or note, keeping the previous version in the history. |
| `plan_at` | What is under a hovered plan position: bearing, distance and the return found there. |
| `plan_points` | Every mark of this scan as a position on its site plan, for dragging in plan view. |
| `delete_feature` | Soft-delete a feature, keeping the row for the history and the audit trail. |
| `undo` | Revert the scan's most recent measurement change, and return what was undone. |
| `to_xyz` | Scan-frame position of a direction/range pair, in the scan's own units. |
| `layer_name` | A DXF layer per measurement layer, named after whoever owns it. |
| `dxf_document` | A minimal DXF R12 file: points, polylines and labels, no external dependencies. |
| `export_dxf` | The project's marks and drawings as DXF, with layers and a comment naming the declared CRS. |
| `export_csv` | Every mark of this scan as rows a surveyor can open in a spreadsheet. |
| `export_e57` | The same marks as an E57 point cloud, for a viewer or a point-cloud tool. |
| `export_json` | The marks and drawings as JSON, for a script rather than a drawing tool. |
| `project_thumb` | A project thumbnail, made from the first scan that has a panorama. |
| `feature_revisions` | The stored versions of one feature, which is what undo and the history panel read. |
| `restore_feature` | Put a measurement back to an earlier version, including one that was deleted. |

## `ubim/api_settings.py`

Per-user preferences, where a project sits in the world, and map tiles.

Three small things that share a reason to exist: the home page can show the projects as a
list or on a map, it remembers which one a user last chose, and a project only appears on
the map once somebody has said where it is. Nothing here guesses a coordinate: a project
without a declared position is reported as unplaced and listed as such.

Map tiles are fetched by the server, never linked from the page, so the browser talks only
to this app; the tiles are cached on disk and a failure is a blank tile rather than an
error the viewer has to handle.

| name | purpose |
| --- | --- |
| `read_settings` | The settings the caller may see: their own account, and the instance's declared defaults. |
| `write_settings` | Per-user preferences. ``detail`` is how much of the panorama to pull: auto decides, |
| `locations` | Every project with the position it declares, placed or not. |
| `read_location` | A project's declared position and CRS. |
| `scan_gps` | The fix the scanner itself recorded, if it recorded one. |
| `location_from_scan` | Adopt a scan's own GPS fix as the project's position, labelled as such. |
| `write_crs` | Record the coordinate reference system the project's numbers are in. |
| `write_location` | Set a project's position by hand, recording that the source is manual. |
| `tile` | One OpenStreetMap tile, served from the disk cache when it is there and fetched once when it is not. |

## `ubim/app.py`

The ASGI application: gate, sessions, CSRF, security headers, pages.

Order matters here and is deliberate:

1. The IP gate runs first, before routing and before sessions, and answers a plain 404 for
   everything outside the allow list. An outsider cannot tell a real path from a missing one.
2. Sessions are loaded from the cookie for requests that survive the gate.
3. Every state-changing request must carry the session's CSRF token, except login (there is
   no session yet) and invite redemption (the token is the authorisation).

| name | purpose |
| --- | --- |
| `create_app` | Assemble the application: middleware, session loading, routers, static files and the startup checks. |
| `register_static` | Serve the interface under a build-stamped prefix. |
| `RevalidatingStatic` | Static files that always revalidate. |
| `create_from_env` | The application as the container and ``python -m ubim`` start it: configuration from the environment, a migrated store, and the app. |
| `seed` | Create the first administrator on an empty database and record how to log in. |

## `ubim/auth.py`

Passwords, sessions, CSRF tokens and roles.

Passwords are scrypt (``hashlib.scrypt``) with a per-user salt and parameters stored in the
hash string, so the parameters can be raised later without invalidating existing users.
Sessions are opaque random ids in a cookie; the CSRF token is per session and must be sent
in ``X-CSRF-Token`` on every state-changing request.

| name | purpose |
| --- | --- |
| `can` | Whether a role holds a capability. Unknown roles hold nothing. |
| `hash_password` | A scrypt hash as ``scrypt$n$r$p$salt$hash``, with the parameters kept so a stored hash stays verifiable if the defaults change. |
| `verify_password` | Whether ``password`` matches a stored hash, in constant time, without raising on a malformed hash. |
| `Session` | A signed-in session: who, the cookie id, the CSRF token, and when it expires. |
| `create_user` | Create a user with a hashed password; the name is trimmed and must be unique. |
| `count_users` | How many users exist, which is what decides whether the first-run setup is offered. |
| `authenticate` | The user row for a name and password, or None. An unknown name still runs one hash so the timing does not reveal which names exist. |
| `create_session` | Start a session for a user and return it with its CSRF token; the id is the cookie value. |
| `load_session` | The live session for a cookie value, or None when it is missing, expired or revoked. |
| `destroy_session` | End a session, so the cookie value stops working even if it is replayed. |
| `purge_expired` | Delete sessions that have run out, and return how many went. |
| `csrf_ok` | Whether the supplied token matches the session's, in constant time. |
| `new_token` | A URL-safe random token for cookies, CSRF values and share links. |
| `invite_code` | Human-typable invite code, unambiguous alphabet, 8 groups of 4 would be overkill. |
| `create_invite` | An invitation code with a role and a lifetime, recorded with who created it. |
| `redeem_invite` | Create the user an invitation describes, and mark the code used; fails if it is unknown or spent. |

## `ubim/config.py`

Runtime configuration, read once at start-up.

Everything has a working default so the container starts with no configuration at all, and
every value can be overridden by an environment variable. Nothing here talks to the network.

| name | purpose |
| --- | --- |
| `parse_networks` | Parse a comma separated CIDR list; anything invalid raises at start-up, not later. |
| `Config` | Everything the deployment decides: paths, limits, allow list, cookie flags and the instance secret. |
| `load` | Build the configuration from the environment, and refuse to start on a value that cannot work. |

## `ubim/dwg.py`

DWG import by conversion (spec D2).

DWG is a closed binary format: unlike DXF it has no plain-text form and no reader in the standard
library. Rather than pretend, this module hands the file to a converter if one is installed and
refuses clearly if none is. The conversion is to DXF, which the importer already reads, so a
converted drawing keeps its layers, colours and lineweights.

Recognised converters: ``dwg2dxf`` and ``dwgread`` (GNU LibreDWG), plus ODA File Converter when
it is callable in batch mode. Nothing is bundled: ``pip install`` has no wheel that carries a DWG
parser, and the slim image ships none, so the error says what to install.

| name | purpose |
| --- | --- |
| `NoConverter` | No DWG converter was found on PATH. |
| `ConversionFailed` | A converter ran but produced nothing usable. |
| `looks_like_dwg` | Whether the bytes begin like a DWG (``AC10`` and a version tail). |
| `find_converter` | The first DWG converter on PATH, or None. |
| `to_dxf` | Convert DWG bytes to DXF text, or raise with a message that names the fix. |

## `ubim/dxf.py`

Reading 2D CAD drawings (DXF) so they can be laid over a scan.

Only the entities that carry a line on a site plan are read: LINE, LWPOLYLINE, POLYLINE
(with its VERTEX records), POINT, CIRCLE and TEXT. Everything else is skipped rather than
guessed at, and the report says how many entities were skipped so an import that looks empty
can be explained.

Coordinates are drawing coordinates. A DXF with no elevation is a flat drawing, and a flat
drawing has no height relative to a scan — that is reported, not invented: :func:`read`
returns ``flat`` true when every vertex sits at Z=0.

| name | purpose |
| --- | --- |
| `aci_colour` | A hex colour for an ACI number, or None for by-layer/unknown. |
| `Shape` | One drawing entity: its kind, layer, points and any text. |
| `Drawing` | A drawing on its way to DXF: entities, layer table and the declared frame. |
| `read` | Parse the entities of a DXF text into shapes in drawing units. |
| `extent` | Drawing extent in metres, so an import can be checked against the site. |

## `ubim/e57.py`

E57 export (spec D5).

An E57 file is a container of point clouds, so what comes out of here is the geometry of the
marks: one point per vertex, in the scan's own frame. No axis swap is applied — X forward, Y left,
Z up is written as it is, and the export says so rather than quietly re-orienting the data.

Written with libE57Format through pye57; the file is a real E57, not a renamed CSV, and the tests
read it back with the same library to prove it.

| name | purpose |
| --- | --- |
| `MissingDependency` | pye57 is not installed, so E57 export cannot run. |
| `points_from_features` | Vertices with a position, plus the metadata row for each one. |
| `write` | Write one scan of points and return what was written. |

## `ubim/formats/__init__.py`

Readers for the on-disk scan containers.

``fls`` is the FARO laser-scan container (OLE compound file with deflated range strips),
``f3s`` the 2026 sample layout (a compound file with ten-byte leaf records), and ``cfb`` the
small compound-file reader they both use.

## `ubim/formats/cfb.py`

Bounded reader for the OLE/CFB containers FARO writes (``.fls``, ``.f3s``).

Only what the viewer needs: list the streams, ask how big one is, and read it with a
hard ceiling so a hostile or broken file cannot make us allocate a gigabyte. Every call
takes the ceiling from the caller; nothing here trusts a length inside the file.

``olefile`` parses the sector table and the directory. This module adds the caps and the
error types the rest of the app raises, and it guarantees we never touch the file after
``close()``.

| name | purpose |
| --- | --- |
| `FormatError` | The file is not a FARO container we can read. |
| `StreamTooLarge` | A stream is bigger than the caller's ceiling, checked before reading it. |
| `OleContainer` | A read-only OLE file with per-read byte limits. |
| `require` | Assert a condition with a message naming what the file was expected to contain. |
| `first_matching` | The first stream name matching a regular expression, or None. |

## `ubim/formats/f3s.py`

FARO ``.f3s`` reader: the iQscene point octree, ported from ``F3sDepth.java``.

A ``.f3s`` is an OLE/CFB container, like a ``.fls``. The octree description is the
gzip-compressed ``DataBase`` stream plus ``Nodes_<n>`` streams; the points live in
``PointData/FullDensity/OctreeLeaf_<n>`` streams. Those streams come in two shapes and
the Java reference handles both:

* inner page (``OctreeNode``): ``LeafIndexInfo`` rows (``NodeID``, ``StartIndex``,
  ``NumPoints``), then the byte marker ``PointData `` and, packed in header order,
  ``NumPoints x 10`` bytes of records. ``StartIndex`` is not an offset into the page.
* leaf page (``OctreeLeaf``): ancestry index rows, ``PointData ``,
  ``OctreeLeafPointData`` (``NumScanPoints``), ``ScanPoints `` and that many records.
  Only the page's own count is stored; the ancestor rows repeat counts from other pages.

A record is three little-endian int16 (x, y, z in 1/65536 of a node box) followed by
three RGB bytes and a constant 0xFF byte. The record has no scalar intensity; a
luminance can only be derived from the RGB, which :meth:`F3sFile.intensity` does.

The stored coordinate bits are mapped through the file's construction grid. As in the
Java, centred and corner global maps are voted on against the declared node boxes; if
neither fits, the per-node map ``box + (int16 + 32768) / 65536 * size`` is used, gated by
a plausibility test (median range 1-150 m, at most 0.01% of points inside 0.3 m). Both
samples in this project take the per-node map. The Java's own note records the same on
its checked file.

UNKNOWN: the container declares no unit string (``scale`` therefore carries the Java's
map name, and :attr:`F3sFile.range_scale` carries the inferred unit); the 0xFF byte has
no known meaning; the RGB channel order is assumed R, G, B.

Ranges are returned as stored, in micrometres. The Java multiplies by ``1e-6`` to get
metres; that factor is exposed as :attr:`F3sFile.range_scale` and never applied silently.

World frame: ``DataBase`` declares ``OriginWS``, ``EdgeLengthWS`` and ``NumCellsInRow``,
the construction grid the coordinates are quantised into. A stored cell ``c`` maps to
the world point ``originWS + c / NumCellsInRow * EdgeLengthWS`` metres, which is the
frame :meth:`F3sFile.world_xyz` reconstructs. The scan's own ``Position`` and
``Transformation`` attributes live in ``ScanInfo_0``; both samples store an identity
transformation and an empty position, so their scanner sits at the world origin.

| name | purpose |
| --- | --- |
| `F3sFile` | One decoded ``.f3s`` scan. Build it with :meth:`read`. |

## `ubim/formats/fls.py`

FARO ``.fls`` reader: header, OLE streams, varint columns, angles.

Everything here was measured against a real file (SCAN_085, 191,418,368 B) and the
decode is checked by ``tests/test_fls_real.py`` against a reference sha256. The format
notes live in ``docs/FORMATS.md``; the short version:

* ``Main`` is text with ``Name "X"\nValue N`` pairs.
* ``Scans/1/DistN`` and ``Scans/1/GreyN`` are raw-deflate streams (the gzip trailer may
  be missing) whose text header ends at ``{ ``; after that come varint records.
* A record is a signed delta from the previous row in the same column: bit 7 means
  another byte follows, bit 6 is the sign, bits 0-5 are the low magnitude bits, later
  bytes carry 7 bits least-significant first. Every column starts at 0.
* ``Scans/1/Calib`` holds one (double angle, double reserved) pair per column; the local
  azimuth is ``-angle``. A linear model is wrong by up to about 1 degree.

Nothing in this module writes to the source file, and every allocation is bounded by a
constant that is checked before the allocation happens.

| name | purpose |
| --- | --- |
| `FlsHeader` | The geometry a FARO scan declares: image size, angular spans, offsets, camera calibration and the elevation of the first row. |
| `StreamRect` | One data stream and the grid rectangle it holds. |
| `inflate_gzip_prefix` | Inflate a gzip stream that may be missing its trailer. |
| `read_header` | The scan geometry the file declares: columns, rows, angular spans, offsets and the camera calibration. |
| `read_rect` | The rectangle one stream covers, and the kind of data it holds. |
| `list_streams` | Dist and Grey streams, in index order, with their rectangles checked. |
| `streams_of` | The streams of one kind: range, grey, colour or distance. |
| `read_azimuths` | Per-column local azimuth in radians (``-angle`` from the Calib table). |
| `VarintColumns` | One inflated data stream, decoded in column bands. |
| `decode_varints` | Decode ``records`` varints into an int32 array shaped ``(records // rows, rows)``. |
| `FlsFile` | A ``.fls`` opened for reading: header, streams, angles, per-band decode. |
| `GreyStats` | The R0.2 measurements, accumulated band by band so the grid is never held whole. |
| `grey_statistics` | Convenience wrapper: feed an iterable of blocks through :class:`GreyStats`. |

## `ubim/gps.py`

The scanner's own GPS fix, when the file carries one.

Both formats keep a text attribute block: ``Main`` in a ``.fls`` and ``ScanInfo_0`` in a
``.f3s``. Among the attributes is ``GPSNMEA``, a run of sentences the scanner logged at the
time of the scan. A GGA sentence with a non-zero fix quality carries a latitude, a longitude
and an altitude, which is the only geographic statement either format makes.

What it is not: a survey. The fix is what the scanner's own receiver managed, typically a few
metres to tens of metres, and RMC's course-over-ground is the direction the scanner was
*travelling*, not the way it was pointing — so nothing here orients a scene.

| name | purpose |
| --- | --- |
| `attribute_block` | The text attribute block of a scan, whichever format it is. |
| `ddmm_to_degrees` | ``5322.2706`` is 53 degrees and 22.2706 minutes, not fifty-three thousand. |
| `parse` | A fix from the logged sentences, or ``None`` when the scanner had none. |
| `read` | The fix recorded with a scan, or ``None`` when it has none or cannot be read. |

## `ubim/jobs.py`

Background jobs for product building.

One small thread pool, jobs tracked in memory with their progress. A job is deliberately
not persisted: if the process restarts, the product manifest on disk is the truth and the job
is simply started again. Progress is reported through a callback so the builder code does
not need to know about HTTP.

| name | purpose |
| --- | --- |
| `get` | A copy of the job's state, or None when the id is unknown. |
| `list_recent` | The most recent jobs, newest first, for the admin Scans panel. |
| `start` | Queue a build for one scan and return the job id; the caller does not wait. |
| `shutdown` | Stop accepting work and join the pool; called on application shutdown. |

## `ubim/library.py`

Finding project folders under a library root, and accounting for the product cache.

Spec C1: one configured root, a catalogue, and a cache that can be measured and cleared. There is
no filesystem watcher — discovery is something an administrator asks for, and it says what it found
rather than assuming a folder it cannot parse is empty.

Nothing here writes to a scan. The cache commands only ever remove a product directory, which the
app can always rebuild from the scan it sits beside.

| name | purpose |
| --- | --- |
| `find_projects` | Project folders under ``root``: itself if it holds scans, else its children. |
| `discover` | Compare the folders under ``root`` with the catalogue, and register what is new. |
| `catalogue` | Every catalogued project, with its scans, position and what it costs on disk. |
| `cache_report` | What the products for each scan cost, and whether they still match the scan. |
| `clear_cache` | Remove product directories. The scans themselves are never touched. |

## `ubim/measure.py`

Geometry for measurements: lengths, areas, planes and heights.

The store keeps azimuth, elevation and range, which is the raw truth. Everything a surveyor
reads off a measurement — a length, an area, how far the points stray from a plane — is
computed here from those, in metres, and returned alongside the stored points so the client
never has to do trigonometry of its own and cannot drift from the server.

A measurement with any point lacking a range is a direction-only measurement: it reports the
angles but no lengths, rather than pretending a number exists.

| name | purpose |
| --- | --- |
| `to_xyz` | Cartesian metres in the scan frame, or None when the point has no range. |
| `metrics` | Computed values for one stored feature. Never raises on incomplete data. |

## `ubim/pages.py`

HTML pages.

These are server-rendered shells, not templates: the client fetches JSON and builds the
interface itself. Keeping the pages static means the Content-Security-Policy can forbid
inline script entirely (only ``style`` allows ``unsafe-inline`` for the few computed sizes).

| name | purpose |
| --- | --- |
| `build_id` | A stamp that changes when any interface file changes. |
| `page` | Render a page inside the shared shell: navigation, the session's name, the script and the CSS build stamp. |
| `home` | The project list, with a map view for the projects that declare a position. |
| `login_page` | The sign-in form, or a redirect home when already signed in. |
| `admin_page` | The administration page; its tabs are filled by admin.js from the API. |
| `project_page` | A project: its scans, the plan, the drawings and the declared position. |
| `scan_page` | The panorama viewer for one scan. |
| `do_login` | Check the credentials, start a session, and send the browser back to where it was going. |
| `do_logout` | End the session and clear the cookie; the CSRF token is checked first. |
| `redeem` | Turn an invitation code into a user, then sign that user in. |
| `healthz` | A liveness answer for the container health check: version and ok. |

## `ubim/products/__init__.py`

Product builders: range grids, intensity images, plan renders and tile pyramids.

Every builder writes beside the scan (``<scan>.ubim/``) and never touches the source file.
``dual`` builds intensity and depth from one decode; the rest build one product each.

## `ubim/products/build.py`

Building the intensity product.

Two passes over the scan: one histogram to find the per-scan normalisation bounds, then the
render. The rendered grid is held in memory for the pyramid because the pyramid needs to
halve it anyway; at 10 136 x 5 086 that is 51 MB, inside the pack's 384 MiB budget for one
worker.

| name | purpose |
| --- | --- |
| `build` | Build one product from a scan, dispatching on the kind; the caller gets a manifest path and progress counts. |
| `values_from_raw` | Normalise a pre-sampled raw grey image the way the render pass does. |
| `build_from_luma` | Colour product for a ``.f3s`` scan, from the colour channels the file actually stores. |
| `load_meta` | A product's manifest, or None when the product has not been built. |
| `is_fresh` | A product is fresh when it was built from this exact file, by version. |

## `ubim/products/depth.py`

Depth (range) product.

The distances are decoded from ``Scans/1/Dist*`` with the same reader as the grey map and
written into the same angular grid as the intensity image, so a pixel at (x, y) in either
product is the same direction in the world. The grid is kept on disk as a flat array rather
than in memory: at 10 136 x 5 086 it is about 100 MB, and picking a point only needs one
cell.

Values are stored raw, and the scale comes from ``StorageDistFact`` in the scan header: the
largest range in SCAN_085 is 15 876 675 units against a factor of 100 000, which is 158.8 m —
a believable distance for the buildings in that scene. That is an inference from the data,
not from a FARO document, so the viewer reports raw units next to metres and the factor is
kept in the manifest. Anyone measuring something critical should check one known distance
against SCENE before trusting the absolute scale.

| name | purpose |
| --- | --- |
| `build_grid` | Decode every range stream into the angular grid and write it to ``target``. |
| `read_grid` | The range grid as a memory-mapped uint32 array, so a tile read does not load 200 MiB. |
| `build_f3s` | Depth product for a ``.f3s`` scan. |
| `build` | Build the whole depth product: grid file plus a display pyramid. |
| `load_meta` | A depth product's manifest, or None when it has not been built. |
| `neighbourhood` | How much return there is around one cell, and whether the cell sits at the grid edge. |
| `sample` | Raw range at a direction, using the same azimuth/elevation model as the products. |
| `nearest` | Nearest non-zero return within ``cells`` grid cells of a direction. |

## `ubim/products/dual.py`

One decode pass feeding every product that needs the scan body (spec C2).

Building intensity and depth separately walks the scan three times: once for the grey
histogram, once for the grey render, once for the range strips. The streams are the same
bytes each time. This module walks them once, keeping the sampled raw grey image next to the
range grid, then finishes both products from what it kept.

The raw grey image is a scratch file, not a product: it is uint16 because raw intensity runs to
1819 on the reference scan, and it is deleted once the tiles exist. Peak memory stays at one
strip plus the uint8 image the pyramid needs, which is what the separate builds already cost.

| name | purpose |
| --- | --- |
| `build` | Build the intensity and depth products from a single decode of ``scan_path``. |

## `ubim/products/intensity.py`

High-resolution laser intensity map: angles, normalisation, band rendering.

The geometry is the viewer's, not an approximation of it. A pixel at column ``x`` of an
intensity image is azimuth ``az0 - 2*pi*x/width``; a pixel at row ``y`` is elevation
``top - y*span/height``. Those three constants are the ones the panorama client uses, so
a pixel in this image and a pixel on the pano sphere are the same direction. Any change
here must be made in ``static/js/gl.js`` too, which is why the numbers are served to
the client from :data:`MAPPING` instead of being typed twice.

Sampling is nearest neighbour between neighbouring scan cells only (R32 allows nearest or
linear between neighbours; we do nearest, which never invents a value that no cell holds,
and record it in the manifest).

| name | purpose |
| --- | --- |
| `level0_size` | Native level-0 size: one pixel per scan column, square angular pixels. |
| `pixel_azimuth` | Azimuth in radians for every output column, wrapped to (-pi, pi]. |
| `pixel_elevation` | Elevation in radians for every output row (row 0 is the top of the pano). |
| `source_columns` | Nearest scan column for every output column, using the Calib table. |
| `source_rows` | Nearest scan row for every output row, or -1 outside the scanned band. |
| `normalise_band` | Linear map of raw grey to 1-255; raw 0 stays 0, everything else clamps. |
| `grey_bounds` | p0.5 and p99.5 of the non-zero cells, from a histogram of raw values. |
| `rainbow_stops` | The web client's rainbow ramp, as 8-bit RGB for t = 0..255. |
| `StripPlan` | One strip of output columns: which scan columns feed which output column. |
| `plan_strip` | Plan a strip of ``width`` output columns starting at ``x0``. |
| `wrap_split` | Index where the source columns wrap around the azimuth seam, or ``len`` if none. |
| `fill_slivers` | Replace thin empty runs with the mean of the values around them. |
| `despeckle` | Remove thin dark lines that the beam pattern leaves across a surface. |
| `suppress_column_lines` | Replace the vertical dark lines that a skipped scan column leaves behind. |
| `sample_strip` | Raw grey arranged into the output grid: the sampling half of :func:`render_strip`. |
| `render_strip` | Render one strip: raw grey in, ``(height, width)`` uint8 out, 0 where there is no value. |
| `scan_column_range` | The contiguous span of source columns a strip needs (call :func:`wrap_split` first). |
| `grey_histogram` | Histogram of all non-zero grey values in a scan, without holding the grid. |

## `ubim/products/photo.py`

A photographic panorama as a tile pyramid.

The viewer used to draw the FARO panorama as one JPEG capped at 4096 wide, which throws away
most of a 10136-pixel scan image and goes soft as soon as you zoom. This product keeps the
native pixels in 512-pixel tiles and successive levels, the same shape the intensity and depth
products use, so the viewer can load only the detail the user is looking at.

The source is the scan's own WebShare photograph. A ``.f3s`` has no photograph — its colour
product is a render of the point colours — so the photo product is only built for a scan that
has one.

| name | purpose |
| --- | --- |
| `build` | Tile the scan's photograph. Raises when the scan has no photograph to tile. |
| `load_meta` | A photograph product's manifest, or None. |
| `tile_path` | Where one tile of the photograph pyramid is stored. |
| `is_fresh` | Whether the product was built from the scan as it stands now, by size, mtime and digest. |

## `ubim/products/plan.py`

Top-down site plan, made from the range product.

Spec section 6 (P1-P3) wants a plan view of the site with the scans placed on it. A real
WebShare project ships plan imagery, but a folder of loose scans does not, and the plan must
still show where the scan stood. So this builds one from the data that exists: every range
cell is unprojected into the scan frame and rasterised into a top-down grid, keeping the
highest return per cell. Nothing is interpolated: a cell with no return stays empty, which is
why a single scan shows a ring of ground rather than a filled rectangle.

Heights are in metres above the scanner, in the scan's own frame. That frame is only the
survey frame once a registration transform is known; the manifest records which it is.

| name | purpose |
| --- | --- |
| `fill_gaps` | Close the gaps between returns so a wall reads as a wall, not a dotted line. |
| `build` | Rasterise the range product into a site plan and return its manifest. |
| `tile_path` | Where one tile of the plan pyramid is stored. |
| `scaled` | The plan at a requested width, cached beside it. ``filled`` selects the gap-filled copy. |
| `load` | A plan product's manifest, or None. |

## `ubim/products/pyramid.py`

Tile pyramid writer shared by the intensity and depth products.

Tiles are 512x512 PNGs named ``<ramp>/L<level>/<col>/<row>.png``. Empty tiles are not
written at all: a hole is cheaper than a file full of zeros, and the client treats a missing
tile as transparent. Levels are built by halving the grid, and every level records its own
dimensions in the manifest so a client never has to guess.

Writes go to ``<target>.part`` first and are renamed at the end, so a half-built product is
never visible as a finished one (the manifest is the last thing written).

| name | purpose |
| --- | --- |
| `tile_path` | Where one tile of an intensity pyramid is stored. |
| `build` | Write every level of a pyramid and return its manifest. |
| `read_manifest` | An intensity pyramid's manifest, or None. |
| `find_tile` | Resolve a tile inside a built product, validating the indices against the manifest. |

## `ubim/products/render.py`

Render the level-0 intensity image for a scan, strip by strip.

Decoding is column-major and the output is written in column strips, so the scan band we
hold is exactly the band we need: about 9 MB of source for a 512-pixel strip of
SCAN_085, plus the strip itself. Nothing full-size is ever allocated (the pack's R20).

``python -m ubim.products.render --fls FILE --out DIR`` writes ``level0.png`` plus the
per-scan ``meta.json`` and prints the measurements.

| name | purpose |
| --- | --- |
| `kind_streams` | Inflate and index a scan's streams once, not once per strip. |
| `decode_columns` | Raw values for global scan columns ``[c0, c1)``, shape ``(c1-c0, rows)`` int32. |
| `level0_strips` | Yield ``(x0, uint8 image strip)`` for the whole level-0 image, in column order. |
| `render_level0` | The whole level-0 image. For tests and previews; the tiler streams instead. |
| `main` | Command line entry: render a scan's products into a folder, with a progress line. |

## `ubim/products_api.py`

Glue between the HTTP routes and the product code.

Everything the API needs to know about a scan's products lives here, so the routes stay
free of filesystem details. Paths are always derived from the scan path in the database,
never from anything in the request.

| name | purpose |
| --- | --- |
| `mapping` | The intensity ramp definitions, as the API reports them. |
| `open_scan` | Open a scan for reading, choosing the reader by suffix. |
| `product_dir` | Where a scan's products live: beside the scan, under the data root when that is not writable. |
| `summary` | What products exist for this scan, and whether they match the scan on disk. |
| `intensity_meta` | The intensity manifest, or None. |
| `intensity_tile` | The path of one intensity tile, or None when it is outside the manifest. |
| `depth_meta` | The depth manifest, or None. |
| `depth_tile` | The path of one depth tile, or None. |
| `depth_ready` | True when a range product exists for this scan (built by the job or another process). |
| `pick` | Distance at a direction. Angles arrive in degrees because that is what the client has. |
| `estimate_mib` | Rough memory each requested kind would need, and the total. |
| `build_products` | Build the requested products. Raises if the disk guard or the memory cap would be crossed. |
| `forget` | Remove a scan's products, leaving the source file untouched. |
| `pano_fallback` | A JPEG panorama for a scan that has no FARO images, made from its colour product. |
| `photo_meta` | The photograph manifest, or None. |
| `photo_tile` | The path of one photograph tile, or None. |
| `plan_meta` | The plan manifest, or None. |
| `plan_probe` | What the scan sees at a point on its own site plan. |
| `plan_scaled` | The plan at a requested width, so a page can ask for what it will display. |
| `plan_tile` | The path of one plan tile, or None. |
| `plan_image` | The plan image path for the filled or outlined variant. |

## `ubim/projects.py`

Reading a WebShare project folder, and building a fixture that looks like one.

The on-disk layout is the one the Java app reads (``docs``/pack 01-context.md):

    <project>/Revisions/<rev>/Scans/<name>.fls            older projects
    <project>/Revisions/<rev>/_3Scans/<name>.f3s         2026 projects
    <project>/Revisions/<rev>/WebShareData/Images/<id>{,_hd,_grey,_grey_hd,_thumbnail,...}.jpg

Nothing here copies the scan contents by default: a project is registered by path, and scans
are only ever opened read-only. When the tree and the data directory are on the same
filesystem a fixture uses hard links, so making one costs no space.

| name | purpose |
| --- | --- |
| `ProjectError` | A project folder does not look usable. |
| `DiscoveredScan` | One scan found on disk: its path, size, suffix and the revision folder it came from. |
| `Discovery` | What a folder walk found: usable scans, skipped files and the reasons. |
| `discover` | Walk a project folder and return what is there, without opening any scan body. |
| `slugify` | A URL-safe slug from a project name. |
| `unique_slug` | A slug not already taken, with a numeric suffix when the plain one is. |
| `register` | Register a project folder. Scans are referenced, never modified. |
| `project` | The project row for a slug, or None. |
| `scans_for` | The scans of a project, with their cached geometry. |
| `scan` | The scan row for a name inside a project, or None. |
| `image_for` | Which stored panorama to show: the preferred role when present, else the first. |
| `product_root` | Where this scan's products live: beside the scan if that tree is writable. |
| `create_fixture` | Build a minimal WebShare-shaped tree so the viewer can be developed offline. |

## `ubim/registration.py`

Scan registration: the rigid transform from a scan's own frame to the project frame.

A measurement is stored in the frame of the scan it was taken in (azimuth, elevation,
range), because that is what the instrument measured. To draw it in a neighbouring scan, or
to place scan locations on a site plan, those coordinates have to cross into a shared frame.
That crossing is a rigid transform per scan — a rotation about the vertical and a translation
— which is what a registration provides.

Nothing here guesses. A scan with no transform is treated as being at the origin with no
rotation, and the caller is expected to say so: the plan marks such scans "position not
registered" rather than pretending the identity is a survey.

| name | purpose |
| --- | --- |
| `pose_matrix` | A 4x4 transform from a scan position and a heading, in degrees anticlockwise from +X. |
| `is_identity` | Whether a matrix is (within rounding) the identity, which is the common case for an unregistered scan. |
| `multiply` | Compose two 4x4 transforms, the left applied after the right. |
| `inverse` | Inverse of a rigid transform: transpose the rotation and undo the translation. |
| `apply` | Transform one point by a 4x4 matrix. |
| `local_from_world` | The point in the frame of the scan that produced ``pose``. |
| `azimuth_elevation` | Angles and distance for a point in a scan frame, in the viewer's convention. |
| `project` | Express a project-frame point in one scan's frame. |
| `parse` | Read a stored transform, tolerating absence and the JSON array form. |
| `dump` | A matrix as plain nested lists, for JSON. |

## `ubim/routes/__init__.py`

Marker package for the API modules.

Routes live in ``api.py`` and the ``api_*`` modules; this package exists so that the router
namespace is explicit rather than implied by filenames.

## `ubim/store.py`

SQLite persistence: users, sessions, projects, shares, layers, features, audit.

One file, standard library only. Every write goes through :class:`Store` so that the same
transaction boundaries are used everywhere, and soft deletes record an undo group so the
"undo last delete" behaviour from the Java app can be reproduced exactly.

| name | purpose |
| --- | --- |
| `now` | The current time as an integer epoch second, which is what every created/updated column stores. |
| `Store` | Thread-safe access to one SQLite file. |

## `ubim/tiles.py`

Derived images: downscaled panoramas and thumbnails, cached on disk.

The HD panorama is 8190 x 4161; as a GPU texture that is 136 MB decoded, which is more than
some clients will give us. Serving a 4096-wide version (34 MB decoded) is visually lossless
at typical field of view and keeps the texture inside a sane budget. Anything smaller than
the ceiling is served untouched.

| name | purpose |
| --- | --- |
| `panorama_cache` | A JPEG of the panorama no wider than ``max_size``. |
| `thumbnail_cache` | Square-ish thumbnail cropped from the centre of the panorama. |
| `image_size` | The pixel dimensions of an image file, read from its header. |

## `ubim/web.py`

Small request helpers shared by the app and the pages, to keep imports acyclic.

| name | purpose |
| --- | --- |
| `client_ip` | The address the request came from, or None when there is no client. |
| `wants_json` | Whether the caller expects JSON rather than a redirect: an /api path, or an Accept that asks for it. |

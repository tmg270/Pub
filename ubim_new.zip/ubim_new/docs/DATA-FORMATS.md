# On-disk formats

Two scan containers are read, and four products are written. This document records what each
one is, how it is decoded, and where the decoding is approximate. Numbers here are the ones in
the code, not roundings of them.

## Compound file container

Both `.fls` and `.f3s` are OLE compound files (the format also called CFB), which is what the
original Windows software wrote. `formats/cfb.py` reads the directory entries and hands out
streams by path; `olefile` does the heavy lifting, and the wrapper keeps the file closed on every
exit path.

Streams are usually deflated. Some carry a short text preamble (a `ScanInfo_0` or `Main`
attribute block) with a name, a position and a serial number.

## `.fls` — FARO laser scan

A scan container holds, per scan:

| stream group | content |
| --- | --- |
| range streams | per-column varint records of raw range, signed-delta encoded |
| grey streams | per-column varint records of intensity in the scan's own units |
| colour streams | RGB, when the scanner captured it |
| `Calib` / attribute blocks | camera calibration, the per-column azimuth table, GPS sentences |

Geometry comes from `read_header`: the image size, the horizontal and vertical angular spans,
vertical offset, and the camera calibration. `FlsHeader.row_for` and `FlsFile.azimuth` convert an
angle to a pixel. When a scan carries the `Calib` azimuth table the per-column azimuth is read
from it (`read_azimuths`, degrees stored as `-angle`); when it does not, the header's linear span
is used, and the code says so, because the linear model is off by about a degree at the seam.

Range values are decoded column by column (`VarintColumns`), then scaled by the file's distance
factor. For the reference scan the factor is `100000`, so `maxRaw` 56,995,013 is 569.95 m.

Intensity is *not* normalised in the file: the reference scan runs 0…2780 with a usable band
around 5…1819, which is why the intensity product records percentile bounds rather than assuming
8 bits.

## `.f3s` — the 2026 sample layout

A different container with the same idea, and different numbers:

- `COLS = 10240`, `ROWS = 5120`: the raster the file describes.
- Leaves are ten-byte records, and the range unit is `RANGE_SCALE = 1e-6` (micrometres), so the
  depth product's `distFact` is `1e6`, not the `.fls` `1e5`.
- The file announces an octree: a grid origin, a cell edge and cell counts. `_collect_nodes`
  reads the nodes and their boxes, and the decoder decides between the file's coordinate modes
  by counting how many points fall inside each node's box (`_Tally.choose`).
- `_RangeStats` checks that the decoded ranges look like a room rather than a mis-scaled grid
  before anything is written; a file whose ranges are implausible is rejected with a message
  rather than producing a blank image.

The 2026 samples carry no usable GPS, so their projects have no position until one is set by
hand — the project page says `manual` when that is the case.

## Panorama geometry

The panorama is an equirectangular image of the scan's own frame. The constants are shared by
the decoder, the measurement code and the products:

```
AZ0_DEG  = -0.07     azimuth of column 0
TOP_DEG  = 90.18     elevation of row 0
SPAN_DEG = 180.65    vertical span, degrees
```

Azimuth *decreases* with column, so the column for an azimuth is `(AZ0 - azimuth) * width / 360`,
with the sign handled explicitly where the panorama is projected. Getting this sign wrong mirrored the panorama
and made the compass read backwards, which is why it is written down here.

Level-0 size is derived, not stored: one pixel per scan column, and a height that keeps the
angular pixels square (`intensity.level0_size`).

## Products

Products are written beside the scan as `<scan>.ubim/`, never into it:

```
<scan>.ubim/
  intensity/manifest.json, grey/L0..Ln/, rainbow/L0..Ln/
  depth/depth.json, depth.grid, depth_tiles/L0..Ln/
  plan/plan.json, plan.png, plan-filled.png, plan_tiles/L0..Ln/
  photo/photo.json, photo_tiles/L0..Ln/
```

Manifests are JSON and record the source (size, mtime, digest), the geometry used, the bounds,
and the ramp parameters, so a tile read cannot be served against a different scan.

`depth.grid` is a raw array, `dtype` and shape from `depth.json` (`uint32`, height × width).
Values are raw range units, and metres are `raw / distFact`; the manifest carries `maxRaw`,
`maxMetres`, the display percentiles and the palette bounds. The grid is memory-mapped on read
(`depth.read_grid`), so a tile request does not pull 200 MiB into the process.

Tile trees are `L{level}/{col}/{row}.png` with 512-pixel tiles, level 0 being the native raster,
each level half the size of the one before. A tile that would be empty is not
written, and the manifest lists what exists.

## GPS in the scan

`GPSNMEA` is a newline-separated set of NMEA sentences. `gps.py` reads GGA and RMC, converts
`ddmm.mmmm` to degrees with the hemisphere, and returns a position only when the fix quality is
usable. The project page shows the source it used (`scan GPS (SCAN_085)`, `manual`, or nothing)
rather than presenting a position without provenance.

## What is approximate

- The `.fls` linear azimuth model, when a scan has no `Calib` table, is off by up to about 1°.
- `.f3s` coordinate-mode selection is a heuristic (most points inside the node box), not a
  documented flag; a file that defeats it is reported as implausible, not silently wrong.
- Intensity percentiles are per-scan, so two scans' grey images are not photometrically
  comparable.
- The panorama is a projection: areas measured on it are corrected by the projection factor, but
  measurements are taken from range, not from the image.

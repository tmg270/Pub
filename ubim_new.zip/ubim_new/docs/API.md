# HTTP API

Every endpoint the application serves. The capability column is what the endpoint
checks: `view` for anything that reads, `edit_layers` for a measurement or a
drawing or a project position, `manage_projects` for a build or a project,
`manage_users` and `admin` for the administration tabs. A dash means the endpoint
is reachable without a session (sign-in, health, static files).

All paths are under the application root; `/api` endpoints answer JSON. A write
needs the session's `X-CSRF-Token` header as well as the cookie, and a JSON body.

| method | path | capability | what it does |
| --- | --- | --- | --- |
| GET | `/api/admin/audit` | admin | The audit log, newest first, paged. |
| GET | `/api/admin/cache` | manage_projects | What the products cost per scan, and which of them no longer match their scan. |
| POST | `/api/admin/cache/clear` | manage_projects | Remove product directories. Scans are never touched, and every product can be rebuilt. |
| GET | `/api/admin/invites` | manage_users | The invitation codes with their state and who redeemed them. |
| POST | `/api/admin/invites` | manage_users | Create an invitation code for a role and lifetime. |
| GET | `/api/admin/library` | manage_projects | The catalogue: what is registered, where it lives, and what it costs on disk. |
| POST | `/api/admin/library/discover` | manage_projects | Walk the library root (or a given folder) and register project folders it does not know. |
| GET | `/api/admin/shares` | admin | The share links, by project. |
| POST | `/api/admin/shares` | admin | Create a share link for a project, optionally read-only and time-limited. |
| GET | `/api/admin/system` | admin | Version, uptime, paths, disk, counts and the allow list, for the System tab. |
| GET | `/api/admin/users` | manage_users | Every user, with role, state and when they last signed in. |
| POST | `/api/admin/users` | manage_users | Create a user; the password is hashed here and never stored as sent. |
| PATCH | `/api/admin/users/{user_id}` | manage_users | Change a user's role, password or disabled state. |
| GET | `/api/jobs/{job_id}` | view | A job's progress: stage, counts, and the result when it finished. |
| GET | `/api/locations` | view | Every project with the position it declares, placed or not. |
| POST | `/api/login` | — | Sign in with a name and password; the session cookie is set on the response. |
| POST | `/api/logout` | — | End the session and clear the cookie. |
| GET | `/api/me` | — | Who the caller is, what they may do, and the CSRF token to send with writes. |
| GET | `/api/p/{slug}` | view | One project with its scans, drawings, layers, frame, position and declared CRS. |
| PUT | `/api/p/{slug}/crs` | edit_layers | Record the coordinate reference system the project's numbers are in. |
| GET | `/api/p/{slug}/drawing-frame` | view | How the project's drawings are placed in the scan frame: origin, rotation and scale. |
| PUT | `/api/p/{slug}/drawing-frame` | edit_layers | Declare how this project's drawings line up with its scans, or clear the declaration. |
| GET | `/api/p/{slug}/drawings` | view | The project's drawings with their shape counts and metadata, without the geometry. |
| POST | `/api/p/{slug}/drawings` | edit_layers | Import a DXF sent as text, or a DWG sent as base64 that a converter turns into DXF. |
| DELETE | `/api/p/{slug}/drawings/{drawing_id}` | edit_layers | Soft-delete a drawing, so its geometry can be recovered from the row. |
| GET | `/api/p/{slug}/layers` | — | The project's layers, with visibility and ownership. |
| POST | `/api/p/{slug}/layers` | edit_layers | Add a layer; the colour and name are the caller's, the owner is the session's user. |
| DELETE | `/api/p/{slug}/layers/{layer_id}` | edit_layers | Soft-delete a layer, leaving its features attributed to it in the history. |
| PATCH | `/api/p/{slug}/layers/{layer_id}` | edit_layers | Change a layer's name, colour or visibility. |
| GET | `/api/p/{slug}/location` | view | A project's declared position and CRS. |
| PUT | `/api/p/{slug}/location` | edit_layers | Set a project's position by hand, recording that the source is manual. |
| POST | `/api/p/{slug}/location/from-scan` | edit_layers | Adopt a scan's own GPS fix as the project's position, labelled as such. |
| GET | `/api/p/{slug}/s/{name}/depth/meta` | view | The depth product's manifest: bounds, ranges and the ramp it was written with. |
| GET | `/api/p/{slug}/s/{name}/depth/{level}/{col}/{row}.png` | view | One tile of the depth pyramid. |
| GET | `/api/p/{slug}/s/{name}/drawings` | view | The project's drawings expressed in one scan's frame, ready to be drawn over it. |
| GET | `/api/p/{slug}/s/{name}/export.csv` | — | Every mark of this scan as rows a surveyor can open in a spreadsheet. |
| GET | `/api/p/{slug}/s/{name}/export.dxf` | — | The project's marks and drawings as DXF, with layers and a comment naming the declared CRS. |
| GET | `/api/p/{slug}/s/{name}/export.e57` | — | The same marks as an E57 point cloud, for a viewer or a point-cloud tool. |
| GET | `/api/p/{slug}/s/{name}/export.json` | — | The marks and drawings as JSON, for a script rather than a drawing tool. |
| GET | `/api/p/{slug}/s/{name}/features` | — | The measurements recorded on one scan, with their points and computed metrics. |
| POST | `/api/p/{slug}/s/{name}/features` | edit_layers | Record a measurement: its kind, points, label, layer and the metrics the points imply. |
| DELETE | `/api/p/{slug}/s/{name}/features/{feature_id}` | edit_layers | Soft-delete a feature, keeping the row for the history and the audit trail. |
| PATCH | `/api/p/{slug}/s/{name}/features/{feature_id}` | edit_layers | Change a feature's points, label, layer or note, keeping the previous version in the history. |
| POST | `/api/p/{slug}/s/{name}/features/{feature_id}/restore` | edit_layers | Put a measurement back to an earlier version, including one that was deleted. |
| GET | `/api/p/{slug}/s/{name}/features/{feature_id}/revisions` | view | The stored versions of one feature, which is what undo and the history panel read. |
| GET | `/api/p/{slug}/s/{name}/gps` | view | The fix the scanner itself recorded, if it recorded one. |
| GET | `/api/p/{slug}/s/{name}/intensity/meta` | view | The intensity product's manifest, or a 404 before it is built. |
| GET | `/api/p/{slug}/s/{name}/intensity/{ramp}/{level}/{col}/{row}.png` | view | One intensity tile, as a PNG, from the requested ramp and level. |
| GET | `/api/p/{slug}/s/{name}/meta` | view | One scan's geometry, panorama roles, product state, and what a build would need in memory and disk. |
| GET | `/api/p/{slug}/s/{name}/neighbours` | view | The project's other scans as seen from one scan: which way, how far, or not apart. |
| GET | `/api/p/{slug}/s/{name}/pano/{role}` | view | The panorama image for one role, optionally scaled, straight from the source file's stored JPEG. |
| GET | `/api/p/{slug}/s/{name}/photo/meta` | view | The photograph product's manifest. |
| GET | `/api/p/{slug}/s/{name}/photo/{level}/{col}/{row}.png` | view | One tile of the photograph pyramid. |
| POST | `/api/p/{slug}/s/{name}/pick` | view | Distance and height at an azimuth/elevation, used for measuring on the panorama. |
| GET | `/api/p/{slug}/s/{name}/plan.png` | view | The plan image, filled or outlined, at the size asked for. |
| GET | `/api/p/{slug}/s/{name}/plan/at` | view | What is under a hovered plan position: bearing, distance and the return found there. |
| GET | `/api/p/{slug}/s/{name}/plan/meta` | view | The plan product's manifest, including the placement it was drawn with. |
| GET | `/api/p/{slug}/s/{name}/plan/points` | view | Every mark of this scan as a position on its site plan, for dragging in plan view. |
| GET | `/api/p/{slug}/s/{name}/plan/tile/{level}/{col}/{row}.png` | view | One tile of the plan pyramid. |
| POST | `/api/p/{slug}/s/{name}/pose` | edit_layers | Record a scan's transform into the project frame. |
| POST | `/api/p/{slug}/s/{name}/process` | manage_projects | Queue a build for the kinds asked for, refusing before it starts when memory or disk cannot take it. |
| GET | `/api/p/{slug}/s/{name}/products` | view | Whether each product exists, when it was built, and whether it still matches the scan. |
| GET | `/api/p/{slug}/s/{name}/thumb` | view | A small square preview of a scan, cached beside the scan's products. |
| POST | `/api/p/{slug}/s/{name}/undo` | edit_layers | Revert the scan's most recent measurement change, and return what was undone. |
| GET | `/api/p/{slug}/thumb-preview` | — | A project thumbnail, made from the first scan that has a panorama. |
| GET | `/api/p/{slug}/view` | view | The saved picture, or 404 when the project has none yet. |
| POST | `/api/p/{slug}/view` | edit_layers | Store the picture the viewer sent as this project's picture. |
| GET | `/api/projects` | view | Every project with its scan count and position, for the home page. |
| POST | `/api/projects` | manage_projects | Register a folder as a project; scans are discovered from the folder, not supplied by the caller. |
| GET | `/api/settings` | view | The settings the caller may see: their own account, and the instance's declared defaults. |
| PUT | `/api/settings` | view | Per-user preferences. ``detail`` is how much of the panorama to pull: auto decides, |
| GET | `/api/tiles/{z}/{x}/{y}.png` | view | One OpenStreetMap tile, served from the disk cache when it is there and fetched once when it is not. |
| GET | `/healthz` | — | A liveness answer for the container health check: version and ok. |

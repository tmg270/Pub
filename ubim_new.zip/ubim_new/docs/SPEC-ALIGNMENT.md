# Spec alignment — the 15 Nov 2026 build spec against this port

Source: <https://ubim-viewer-full-system-build-spec-from-txtx.pages.grok.bot/> (read 16 Nov 2026).
This page maps that specification's requirement IDs to what this Python/HTML port actually does
today, so the next steps are chosen from evidence rather than from memory. Status words:

- **done** — implemented and exercised (a test, or a measured run against SCAN_085).
- **partial** — some of the requirement works; the gap is named.
- **not started** — no code yet.
- **blocked** — cannot be finished without data that is not on this machine.

Nothing here is a claim about the Java reference build; it describes this port only.

## 4 Accounts, roles, invites, access — mostly done

| ID | Status | Notes |
|---|---|---|
| A1-A6 (accounts, roles, invites, gate, sessions) | done | scrypt hashes, invite redemption, viewer/editor/admin capabilities, IP allow list returning an identical 404, HttpOnly SameSite cookie, per-session CSRF. Tests in `tests/test_web.py`. |

## 5 Project home

| ID | Status | Notes |
|---|---|---|
| H1 list, assigned-only, empty state | done | `/` lists only projects the session may open. |
| H1 map, remembered choice | done | `/api/settings` stores `list`/`map` per user; the canvas map draws OSM tiles through `/api/tiles` and marks only projects whose position is declared. |
| H2 card thumbnail, scan count | done | thumbnail comes from `WebShareData/Images` via `/thumb`. |
| H2 "Save as thumbnail" from the view | done | viewer control "Save view" posts the rendered PNG to `/api/p/{slug}/view`; the project page shows it, served `no-store`. |
| H3 metadata: location, CRS, products | done | The project page's metadata line now reads scan count, revision, position and CRS in one place, and the project JSON carries `location` (`lat`, `lon`, `source`, `placed`) and `crs`. A project can declare a CRS (`PUT /p/{slug}/crs`): `epsg:27700` is normalised to `EPSG:27700`, a local grid name is kept as written, `EPSG:abc` is refused and an empty value clears it. The declaration is metadata only - nothing reprojects because of it - and the drawing export repeats it as a `999` comment "CRS (declared, not applied)", so the DXF never pretends to carry a projection. Importing a folder now adopts the position it already holds: registration reads the first three scans' `GPSNMEA` and stores `scan GPS (<scan>)`, so SCAN_085 came up at 53.234500, -1.449195 (6 satellites, HDOP 1.1) instead of waiting for someone to type it in; a scan with no sentences leaves the project unplaced rather than at 0,0. Verified in the browser: the line read "1 scan · no position recorded · CRS not declared", declaring EPSG:27700 turned it into "… CRS EPSG:27700 (declared)" with the toast "CRS declared as EPSG:27700", and the export carried "CRS (declared, not applied): EPSG:27700". Six tests. Honest limit: this is not a CRS database - the user supplies the code, and nothing here knows what EPSG:27700 means. |
       first fix it finds and says so, so a project no longer arrives unplaced when its scans know
       where they were taken; a typed position overwrites the label with "declared". CRS is still absent: neither format states one, so a drawing's placement has to be declared by hand. |
| H4 OSM tiles, key never in the browser | done | `/api/tiles/{z}/{x}/{y}.png` fetches server-side, caches to disk, returns a blank tile offline. No key is needed for OSM; the user agent identifies the app. |

## 6 Project site map

| ID | Status | Notes |
|---|---|---|
| P1 plan with clickable scan locations | done | The project page overlays the scan position on a 2048² top-down plan and now answers a hover: `/plan/at?x=&y=` converts the hovered pixel to scan-frame metres, reports the exact distance and bearing from the scanner, and looks the return up in the range product along that bearing — the elevation and height when a return is within reach, otherwise the nearest real return on that line of sight, labelled as such (`hit: false`), because the plan keeps ground the range grid only sampled coarsely. The card also shows the photograph at the hovered bearing. A click on a scan dot opens that scan's viewer. |
| P2 multi-resolution plan pyramid behind auth | done | `plan_tiles/L{0,1,2}/<col>/<row>.png` (2048/1024/512, 15/4/1 occupied tiles, 512-pixel tiles) written beside the plan, served by `/plan/tile/{level}/{col}/{row}.png`, and `/plan.png?size=N` serving a cached downscale for the page's own width — the project page now asks for 1024 instead of the 2048 original. Both routes require `view()`. No zoom widget yet: the levels exist so a zoom can load only what it shows. |
| P3 densified/filled top view toggle | done | the plan carries `plan.png` and a densified `plan-filled.png` (`fill_gaps`: two rounds of growing occupied cells into the holes at 80% brightness, so a wall reads as a wall while the dimmer value says nothing measured it). The stage has a `Fill gaps` toggle that swaps the image, and the manifest reports both `cells` (339,460) and `filledCells` (664,721). Density still modulates brightness, so a lone return stays faint. |
| P4 aerial imagery toggle | done | The plan's metadata already carries its bounds in metres, and a project's declared position is the only geographic anchor in the data. The toggle draws OSM tiles through the existing proxy, sized and placed from those two, and states its assumption in the note: the plan is read as north-up with the declared position at its origin. With no declared position it stays hidden. |
| P5 north mini-map with FOV wedge | done | viewer control "North" draws a dial with the view direction and a field-of-view wedge. Cardinal letters treat the scan's azimuth zero as north, which is stated in the code because no scan carries a north reference. |

The plan is built from data, not from a plan image: a real WebShare project ships a plan
pyramid, and this port should prefer that when it exists. That is a small addition to
`plan.py` (load the project's plan tiles, fall back to the raster).

## 7 Panoramic view

| ID | Status | Notes |
|---|---|---|
| V1 open, grab drag, zoom, fullscreen, wording | done | drag, wheel/+/− zoom, a Full control that asks for full screen, and a double-click that flies the view to that spot over 320 ms. Going back is the project breadcrumb, not a map button. |
| V2 3D scan dots with jump, taper, hide while measuring | done | `GET /api/p/{slug}/s/{name}/neighbours` reports every other scan of the project in this scan's frame: direction, distance, and whether it is posed. The viewer draws them as amber rings whose size falls with distance, hides them while a tool is active, and jumps to a scan when its dot is clicked. Scans with no registration share the origin, so they are reported as coincident and named in the status line instead of being pointed at. Four tests cover coincidence, a recorded pose, clearing it, and a missing scan. |
| V3 colour, laser intensity map, rainbow ramp, FARO grey fallback | done | grey, intensity (grey and rainbow ramps, real per-cell values) and depth all work. The detail control is Auto / Standard / Max, saved per user as a `detail` setting and restored on load; Auto decides from `MAX_TEXTURE_SIZE` and the device pixel ratio, and every request is clamped to what the GPU reports, because asking for a 10240-wide texture on an 8192 GPU uploads nothing and looks like a broken product. A `.f3s` project with no WebShare images still gets the stitched `colour-luma` panorama, labelled as such in the response header. |
| V4 tiled multi-resolution panorama, deep zoom | done | `photo_tiles/L<n>/<col>/<row>.png` plus `photo.json`, built from the scan's own WebShare photograph at its native size (SCAN_085: 8190×4161, five levels, 137 tiles at level 0, 16 MB in total) and served tile by tile through `/photo/{level}/{col}/{row}.png`. The grey view loads the tiles when the product exists, so detail is native rather than one 4096-wide JPEG; the single-image path stays for a scan with no product yet, and the panel offers `Build photo`. Tiles are PNG because re-encoding JPEG crops lifted the black level of flat sky per tile, and the surface is filled opaque so a skipped black tile cannot show through as a rectangle. A `.f3s` has no photograph — its colour product is a render of the point colours — so the photo product is only offered for `.fls`. | 
| V5 depth image per scan, normals later | done | `depth.json` plus `depth.grid` give the range image per scan, and `GET .../depth/meta` reports the levels, the point count and the true maximum. The display pyramid is clamped to the 95th percentile of filled cells with a square-root gamma (31.9 m and 21.7 m on the two samples) and the manifest keeps `maxRaw`/`maxMetres` (594.74 m) alongside `rampMaxMetres` — the ramp is presentation, the maximum is the measurement. Two bugs made this view blank: a linear ramp against the 594 m tail, and `_halve` clipping raw grids to uint8, which blackened every level below the first; `tests/test_pyramid_levels.py` now pins the second. |
| V6 progress with a percentage, missing WebGL message | done | jobs report stage and percentage and tile loading shows done/total with a percentage. With WebGL2 refused (getContext returning null, injected in the browser) the page replaces the canvas with `This browser cannot create a WebGL2 context…` instead of sitting on "Loading scan…"; verified by loading the viewer in a context whose init script refuses WebGL. |
| V7 loupe, annotation text size, logo | done | the Loupe control magnifies the region under the pointer from the frame just drawn, annotation text sizes are legible at 1300×900 and 1200×800, and the header now carries an inline SVG compass mark, so it needs no image request and scales with the text. |

## 8 Measurements and snapping

| ID | Status | Notes |
|---|---|---|
| M1 XYZ, distance (slope/plan/signed V), polyline, polygon area with plane fit | done for point/line/area | `ubim/measure.py` computes length, plan distance, signed and absolute vertical, area (Newell), perimeter, best-fit plane with RMS and inclination. Unit tests cover a 10 m × 10 m square (100 m²), a 1 m square in XY, XZ and tilted (1.000 m²), and a 45° plane. No angle tool, no volume, no section. |
| M2 projected picks, miss = no point, 20 m flag | done | A pick is a server-side range lookup; a miss answers `metres: null` with `reason: no-return` instead of inventing a point, and spans over 20 m carry a warning. The per-pick "height uncertain" flag exists: a pick carries `support` (returns in a 5×5 window), `heightUncertain` and the reasons (`isolated-return`, `snapped-far` over one cell, `grid-edge`), the flag is stored on the point, survives a reload and is reported as `metrics.heightUncertain`. Queued picks exist too: a click made before the depth product exists keeps its angles as pending, and finishing the mark resolves them if the product has arrived, reporting how many were filled. Verified end to end with a two-click line: 2.438 m, `complete: true`, `heightUncertain: false`. Limit: `support < 3` is a heuristic for a doubtful height, not an error bar. |
| M3 laser-return snapping | done | `depth.nearest()` searches ±3 cells, reports `snapped` and the offset, and the toolbar has a `Snap` toggle whose state is sent with every pick (`snap: false` records the clicked direction); tests cover the window, the offset and the seam. Vertex and edge snapping are not implemented — the spec asks for laser-return snapping, which is what this is. |
| M4 units, 4 dp, rich readouts, list behaviour, fly-to | done | metres with 4 dp in the readouts and exports, the value on screen is the server's number, and double-click flies the view. The measurements panel now keeps its scroll position when it re-renders after a save or delete, instead of jumping to the top. |
| M5 accuracy statement | done | `ubim/accuracy.py` holds one statement, and it is served in the scan meta, shown in the viewer's `Accuracy` section, written into the JSON as `accuracy`, into the DXF as 999 comment pairs and into the CSV as a leading `#` line (tests parse past it). |
| M6 plan-view vertex drag | done | `GET .../plan/points` returns each mark as metres and as a fraction of the plan, and `PATCH .../features/{id}` accepts `pointsXY`, so a drag sends metres and the server converts them to azimuth, elevation and distance with the same function the viewer measures with. Height is preserved because a plan drag moves horizontally. Four tests cover the projection, the conversion, keeping the height, and a scan with no plan. |

## 9 Shared annotation store

| ID | Status | Notes |
|---|---|---|
| L1 one store per project, cross-scan projection, soft delete, undo, label cleaning | done | features live on project layers, soft delete, undo and label cleaning; with a stored transform for both scans a measurement is projected into the scan being viewed (`from_other_scan`, `source_scan`), and without one it stays where it was measured. |
| L2 owner, colour, timestamps, version/revision, restore | done | every create, edit, delete and restore writes a numbered revision (`feature_revisions`); restoring a version puts a measurement — including a deleted one — back to that snapshot as a new version. Tests cover edit-then-rollback and delete-then-recover. |
| L3 "Save with label" dialog | done | finishing a mark opens an in-page dialog for an optional label, saved with the mark and carried into the export; cancelling keeps the draft so the mark is not lost. The Finish control enables as soon as the first point exists. |

## 10 DXF and interchange

| ID | Status | Notes |
|---|---|---|
| D1 export that opens in AutoCAD | done | ASCII AC1009 (R12) with `$INSUNITS 6` (metres) and 4 dp coordinates, one DXF layer per measurement layer named `L<id>_<owner>` (sanitised to the 31-character, no-punctuation rule), points, polylines and text labels, and the accuracy caveat as 999 comments. `tests/test_dxf_colour.py` reads the export back with ezdxf — an independent reader, not this code — and checks metres, the entities and the layer names. AutoCAD itself has not been tried. |
| D2 DXF/DWG import with colours, widths, distances off | done | DXF: entities are read with their colours, lineweights and layer names, placed in the scan frame, and distances are measured from the model rather than trusted from the file (`tests/test_dxf.py`, `tests/test_dxf_colour.py`). DWG: no Python wheel carries a DWG parser and the slim image ships none, so the import converts first — `ubim/dwg.py` drives `dwg2dxf`/`dwgread` (GNU LibreDWG) or ODA File Converter when one is on `PATH`, parses the DXF it produces, and refuses with the fix named (415, "install GNU LibreDWG (`apt install libredwg-tools`)") when there is none. The endpoint also accepts a base64 upload now, so a binary drawing can actually be sent. `tests/test_dwg_import.py` (3) proves the whole path with a stub converter, including that the colour survives. Limit: the converter is not bundled — this workstation and the image have no LibreDWG (Debian trixie does not package it), so DWG works where one is installed. |
| D3 Z=0 warning and drape to the cloud | done | a flat drawing is reported flat at import; over a scan it is drapeable: `GET /api/p/{slug}/s/{name}/drawings?height=` projects the shapes into that scan's frame at a height the user names, and the viewer's Drawings control strokes them as dashed cyan over the panorama. Four tests cover the projection, the height, an absurd height and a missing scan. |
| D4 explicit CRS mapping | done | A project can declare the origin, rotation and scale that turn a drawing's own coordinates into the scan's metres (`GET`/`PUT /p/{slug}/drawing-frame`), and the form sits under Drawings. The mapping is applied when a drawing is projected, so changing it moves drawings already imported, and clearing it returns them to being read as they are. Six tests cover the unmapped reading, an origin, a rotation, a scale, clearing, and a refused scale. What it is not: a CRS database. The user supplies the numbers; nothing here knows what EPSG:27700 means. |
| D5 CSV / E57 | done | CSV: one row per vertex with the angles, the metres they imply, the mark's metrics repeated per row and a leading comment carrying the accuracy caveat (`tests/test_csv_export.py`). E57: `GET /api/p/{slug}/s/{name}/export.e57` writes a real E57 container through libE57Format (`ubim/e57.py`, pye57), one point per vertex that has a position, in the scan's own frame with no axis swap — stated in the module and in the response. A vertex whose range was never resolved is left out rather than written as a zero at the origin (`tests/test_e57_export.py` reads the file back with the same library and checks both). Honest limit: it is a point cloud of the marks, not of the scan; exporting the full cloud would be tens of millions of points and is not offered yet. |

## 11 Ingest and processing

| ID | Status | Notes |
|---|---|---|
| C1 discover folders, catalogue, cache | done | `UBIM_LIBRARY_ROOT` names a folder whose children are project folders; `POST /api/admin/library/discover` walks it (or a folder given in the request), registers what the catalogue does not know, reports what it already knew, and takes `dryRun` to answer "what would be added" without writing. A folder counts as a project only when scans sit where a project keeps them — in it, in `Scans/`, `_3Scans/`, or `Revisions/<n>/Scans` — so the library root itself is not mistaken for one. `GET /api/admin/library` is the catalogue: folder, scan count, position, CRS, product size, and whether the folder still exists (a registered project whose folder has gone is reported as missing, not dropped). `GET /api/admin/cache` prices the products per scan and lists the kinds that no longer match their scan; `POST /api/admin/cache/clear` deletes product directories only — never a scan — and audits how much it freed. The Administration page has a Library tab with all three actions. No filesystem watcher: discovery is asked for, and the tests (`tests/test_library.py`, 4) cover dry runs, registration, a vanished folder and a clear that leaves the scan in place. |
| C2 one pass per scan feeding every product | done | A request for intensity and depth together now decodes the scan once (`ubim/products/dual.py`): the strip loop fills the range grid and keeps the sampled raw grey image beside it, the bounds come from the histogram of the greys that same pass decoded, and both products are finished from what was kept — the uint16 scratch image is deleted once the tiles exist. It is not "similar": `tests/test_dual_build.py` builds both ways on SCAN_085 and requires the range grid and all 508 intensity tiles to be byte-identical, with every manifest field equal apart from timings. Measured on the reference scan: 22.9 s for both products, against about 18 s for intensity and 6 s for depth when built separately, so the saving is one decode rather than a dramatic one. Priority for the scan being viewed is still not implemented: jobs run in submission order. |
| C3 admin "Process scans" UI with per-scan state | done | the admin Scans tab lists every project scan with its depth/intensity/plan state read from the products on disk, and a Process button that runs the job and follows its percentage. |
| C4 memory caps | done | Decoding is stream-by-stream and strip-by-strip, and a build is now refused before it starts if it cannot fit: `UBIM_MAX_BUILD_MB` (default 2048) caps the estimated peak, `POST .../process` answers 409 with both figures ("246 MiB needed for depth, the cap is 100 MiB"), and the scan meta carries `memory` — per-kind estimates from the header's own geometry (196.7 MiB intensity, 245.8 MiB depth, 32 MiB plan, 121.9 MiB photograph on SCAN_085) plus the cap. The build button shows the figure before it is pressed. `ubim/products/dual.py` keeps the peak at one strip plus the uint8 image the pyramid needs. Honest limit: the estimate is per-kind upper bound, not a measured peak, and the 700 MB `.f3s` sample is still the real test. |
| C5 `.f3s` support | done for range; UNKNOWNs named | `ubim/formats/f3s.py` reads the iQscene octree: 071 = 17,166,892 points (exactly declared), 16.8 M non-zero cells, 2.25/5.29/594.7 m band, 5.7 s; 021 = 69,236,940 points, 17.6 M cells, 0.78/3.75/152.7 m, 16.8 s, 313 MB peak. Depth, plan, picks and a colour-luma panorama all build from it (10 s total, 21 s for 021). UNKNOWN: no unit string is declared, so `range_scale = 1e-6` is inference from the Java constant plus plausibility; the 0xFF byte's meaning; RGB channel order assumed. Records are 3 × int16 + RGB + 0xFF — colour, never intensity. |

## 12-15 Storage, API, security, deployment

| Area | Status | Notes |
|---|---|---|
| storage layout | done | products beside the source as `<scan>.ubim/`, app data separate; the spec's `.ubimdepth` (UBD1) sidecar name is not used because the spec calls its paths examples. The catalogue prices what each scan's products cost and can clear them (`ubim/library.py`). |
| security S1-S4 | done | allow list, HTTPS assumed at the proxy (`UBIM_SECURE_COOKIES`), CSRF, scrypt, audit log, health endpoint on the app port. |
| backups S5 | documented, not automated | README says what to back up (app data, never the project tree). |
| observability S6 | done | structured audit rows for every write, job progress with stage and counts, `/healthz`, and the disk guard is both enforced before a build (it refuses with the free space and the guard in the message) and visible: scan meta carries `freeMiB`/`guardMiB`/`low` and the panel shows "Disk free … below the guard" before the build button is pressed. Limit: no background alerting — the warning is seen when someone looks at a scan, not pushed. |

## Next steps, in order

1. **Finish `.f3s`** (C5). Two samples are on disk; the port is in progress. Everything else
   about 2026 projects (colour panoramas, depth, plan) depends on it.
2. **Registration** (P1, V2, L1 cross-scan). Read the scan transforms from the project
   metadata, store them per scan, and project features between scans. Without this, dots and
   cross-scan measurements cannot be correct, so it comes before the map view.
3. **Panorama tiling** (V4): serve the photographic panorama as a pyramid like the products,
   so deep zoom is not limited to 4096 px.
4. **DXF import** (D2/D3): add an `xyz` geometry kind to the store, then import polylines with
   colours and widths, warn on Z=0, and drape.
5. **Home and plan extras** (H1/H2/H4, P2/P5): saved settings, save-as-thumbnail, map view,
   plan pyramid, north mini-map.
6. **Store versioning and labelled drafts** (L2/L3).

## Rendering notes

**Compass bearings.** The panorama products lay azimuth out as `az0 - 2πx/width`: the stored
azimuth falls as you look right, which is the opposite of a compass bearing. The dial and the
grid labels therefore show `-azimuth`, so turning right runs N → E as a reader expects, and
the stored azimuth is untouched. North itself is assumed to be azimuth zero; neither `.fls`
nor `.f3s` carries a north reference.

- **Thin gaps in a `.f3s` grid.** The 2026 file leaves a column empty here and there and the
  product used to draw those cells as near-black, which read as dark scratches over the
  ground and the vehicles. `products.intensity.fill_slivers` fills a cell only when at least
  three of its eight neighbours hold a value, and `suppress_column_lines` replaces a pixel
  that is darker than the surface on both sides of it. Both run at build time, so a rebuilt
  product carries the correction; a product built before this change still shows the lines
  until it is rebuilt. The manifest records `filled: "thin gaps interpolated from
  neighbouring cells"`. The same pass runs on the `.fls` strip renderer.
- **Viewer chrome.** The scan page is a full-height stage: the toolbar wraps inside it, the
  title floats over the panorama and the page does not scroll, so the controls cannot sit
  below the fold at any window size.

## Packaging

- `Dockerfile` builds the app and its Python dependencies; the front end needs no build step
  because it is plain ES modules. Verified: `docker build` succeeds and the container serves
  the sign-in page and creates the first administrator (uid 10001, `/data` volume).
- `docker compose up --build` is the documented entry point. `/data` has to be a named volume
  or an existing directory owned by uid 10001: a bind mount arrives owned by the host user and
  the app stops with `Permission denied: /data/secret.key` rather than writing as root.

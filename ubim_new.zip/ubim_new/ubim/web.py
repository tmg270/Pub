"""Small request helpers shared by the app and the pages, to keep imports acyclic."""

from __future__ import annotations

from fastapi import Request

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "same-origin",
    "X-Frame-Options": "SAMEORIGIN",
    "Content-Security-Policy": (
        "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
        "script-src 'self'; connect-src 'self'; worker-src 'self' blob:; base-uri 'none'; "
        "form-action 'self'; frame-ancestors 'self'"
    ),
}


def client_ip(request: Request) -> str | None:
    """The address the request came from, or None when there is no client."""
    return request.client.host if request.client else None


def wants_json(request: Request) -> bool:
    """Whether the caller expects JSON rather than a redirect: an /api path, or an Accept that asks for it."""
    path = request.url.path
    if path.startswith("/api/"):
        return True
    accept = request.headers.get("accept", "")
    return "application/json" in accept and "text/html" not in accept

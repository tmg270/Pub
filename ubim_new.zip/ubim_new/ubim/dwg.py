"""DWG import by conversion (spec D2).

DWG is a closed binary format: unlike DXF it has no plain-text form and no reader in the standard
library. Rather than pretend, this module hands the file to a converter if one is installed and
refuses clearly if none is. The conversion is to DXF, which the importer already reads, so a
converted drawing keeps its layers, colours and lineweights.

Recognised converters: ``dwg2dxf`` and ``dwgread`` (GNU LibreDWG), plus ODA File Converter when
it is callable in batch mode. Nothing is bundled: ``pip install`` has no wheel that carries a DWG
parser, and the slim image ships none, so the error says what to install.
"""

from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

#: The signature every DWG begins with (AC1015 = R2000, AC1032 = R2018, ...).
MAGIC = b"AC10"

HINT = (
    "DWG needs a converter: install GNU LibreDWG (`apt install libredwg-tools`) or save the "
    "drawing as DXF. DWG is binary, so it is not read directly."
)


class NoConverter(RuntimeError):
    """No DWG converter was found on PATH."""


class ConversionFailed(RuntimeError):
    """A converter ran but produced nothing usable."""


def looks_like_dwg(data: bytes) -> bool:
    """Whether the bytes begin like a DWG (``AC10`` and a version tail)."""
    return data[:4] == MAGIC


def find_converter() -> str | None:
    """The first DWG converter on PATH, or None."""
    for name in ("dwg2dxf", "dwgread", "ODAFileConverter"):
        found = shutil.which(name)
        if found:
            return found
    return None


def to_dxf(data: bytes, *, timeout: int = 120) -> str:
    """Convert DWG bytes to DXF text, or raise with a message that names the fix."""
    converter = find_converter()
    if converter is None:
        raise NoConverter(HINT)
    name = Path(converter).name
    with tempfile.TemporaryDirectory(prefix="ubim-dwg-") as workspace:
        source = Path(workspace) / "drawing.dwg"
        source.write_bytes(data)
        target = Path(workspace) / "drawing.dxf"
        if name == "dwgread":
            command = [converter, "-O", "DXF", "-o", str(target), str(source)]
        elif name == "ODAFileConverter":
            # ODA works on directories: an input folder, an output folder, then the versions.
            out_dir = Path(workspace) / "out"
            out_dir.mkdir()
            command = [converter, workspace, str(out_dir), "ACAD2018", "DXF", "0", "1", "*.DWG"]
            target = out_dir / "drawing.dxf"
        else:
            command = [converter, "-o", str(target), str(source)]
        try:
            result = subprocess.run(command, capture_output=True, timeout=timeout, check=False)
        except subprocess.TimeoutExpired as exc:
            raise ConversionFailed(f"the DWG converter took longer than {timeout}s") from exc
        except OSError as exc:
            raise ConversionFailed(f"could not run {name}: {exc}") from exc
        if not target.exists():
            detail = (result.stderr or result.stdout or b"").decode("utf-8", "replace").strip()
            raise ConversionFailed(f"{name} did not produce a DXF" + (f": {detail[:200]}" if detail else ""))
        return target.read_text(encoding="utf-8", errors="replace")

"""The ASGI application: gate, sessions, CSRF, security headers, pages.

Order matters here and is deliberate:

1. The IP gate runs first, before routing and before sessions, and answers a plain 404 for
   everything outside the allow list. An outsider cannot tell a real path from a missing one.
2. Sessions are loaded from the cookie for requests that survive the gate.
3. Every state-changing request must carry the session's CSRF token, except login (there is
   no session yet) and invite redemption (the token is the authorisation).
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles

from . import api_drawings, api_settings, auth, pages
from .config import Config
from .store import Store
from .web import SECURITY_HEADERS, client_ip, wants_json

log = logging.getLogger("ubim")

STATIC_DIR = Path(__file__).with_name("static")
UNSAFE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
#: Paths that state-change without a session: nothing to compare a token against yet.
CSRF_EXEMPT = {"/api/login", "/api/invite/accept", "/api/logout", "/login", "/logout", "/invite"}

def create_app(config: Config, store: Store) -> FastAPI:
    """Assemble the application: middleware, session loading, routers, static files and the startup checks."""
    app = FastAPI(title="uBIM viewer", version=config.app_version, docs_url=None, redoc_url=None, openapi_url=None)
    app.state.config = config
    app.state.store = store
    app.state.started = time.time()

    @app.middleware("http")
    async def guard(request: Request, call_next):
        """Refuse a request from outside the allow list before it reaches a route, and answer in the shape the caller expects."""
        ip = client_ip(request)
        if not config.allows(ip):
            # Identical response for every path outside the allow list (R40).
            return PlainTextResponse("Not Found", status_code=config.deny_status, headers=SECURITY_HEADERS)

        session = auth.load_session(store, request.cookies.get("ubim_sid"))
        request.state.session = session
        request.state.ip = ip
        request.state.share = None

        path = request.url.path
        if request.method in UNSAFE_METHODS and path not in CSRF_EXEMPT:
            supplied = request.headers.get("x-csrf-token")
            if supplied is None:
                supplied = request.headers.get("x-xsrf-token")
            if session is not None and not auth.csrf_ok(session, supplied):
                store.audit("csrf", session.user_id, path, ip, 403)
                if wants_json(request):
                    return JSONResponse({"error": "csrf"}, status_code=403)
                return PlainTextResponse("Forbidden: bad CSRF token", status_code=403)

        response = await call_next(request)
        for name, value in SECURITY_HEADERS.items():
            response.headers.setdefault(name, value)
        response.headers.setdefault("X-Robots-Tag", "noindex")
        if path.startswith("/api/"):
            response.headers.setdefault("Cache-Control", "no-store")
        return response

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):
        """Turn an unexpected exception into a 500 that keeps the message but not the traceback, and log it."""
        log.exception("unhandled error on %s", request.url.path)
        if wants_json(request):
            return JSONResponse({"error": "internal", "detail": str(exc)}, status_code=500)
        return PlainTextResponse("Internal Server Error", status_code=500)

    if STATIC_DIR.is_dir():
        register_static(app)

    from .api import router as api_router
    from .api_measure import router as measure_router

    app.include_router(api_router)
    app.include_router(measure_router)
    app.include_router(api_drawings.router, prefix="/api")
    app.include_router(api_settings.router)
    app.include_router(pages.router)
    return app


def register_static(app: FastAPI) -> None:
    """Serve the interface under a build-stamped prefix.

    A browser may keep a module it fetched before an edit and reuse it on a heuristic, which
    makes a change appear not to have happened. Stamping the prefix with the newest file in
    the tree changes the URL of the scripts and of everything they import, so an edited
    interface is a different URL rather than the same one with new bytes behind it.
    """
    import mimetypes

    from fastapi.responses import FileResponse

    @app.get("/static/{build}/{path:path}")
    async def static_file(build: str, path: str):
        """Serve a file from the interface tree under a build-stamped prefix, and 404 one that escapes the tree."""
        target = (STATIC_DIR / path).resolve()
        if not str(target).startswith(str(STATIC_DIR.resolve())) or not target.is_file():
            raise HTTPException(status_code=404, detail="not found")
        media, _ = mimetypes.guess_type(target.name)
        return FileResponse(
            target,
            media_type=media or "application/octet-stream",
            headers={"Cache-Control": "no-store"},
        )


class RevalidatingStatic(StaticFiles):
    """Static files that always revalidate.

    Without a Cache-Control header a browser is free to reuse its copy of a script on a
    heuristic, and an edit then appears not to have happened until a hard reload. ``no-cache``
    still allows a cheap 304 when nothing changed, which is what a local tool wants.
    """

    async def get_response(self, path, scope):
        """Serve the file and make sure the browser revalidates it next time."""
        response = await super().get_response(path, scope)
        # A module graph keeps its imports; a revalidated script can still be the stale one
        # while its child module is older. no-store costs a few kilobytes on a local tool and
        # means an edit is always the edit that runs.
        response.headers["Cache-Control"] = "no-store"
        return response


def create_from_env() -> FastAPI:
    """The application as the container and ``python -m ubim`` start it: configuration from the environment, a migrated store, and the app."""
    from .config import load

    config = load()
    store = Store(config.db_path)
    store.set_meta("version", config.app_version)
    app = create_app(config, store)
    seed(store, config)
    return app


def seed(store: Store, config: Config) -> None:
    """Create the first administrator on an empty database and record how to log in.

    The password is generated, printed once to the log and written to
    ``<data>/initial-admin.txt`` (mode 600). Nothing is overwritten if a user already exists.
    """
    if auth.count_users(store) > 0:
        return
    import os
    import secrets

    password = os.environ.get("UBIM_ADMIN_PASSWORD") or secrets.token_urlsafe(12)
    auth.create_user(store, "admin", password, role="admin")
    note = config.data_dir / "initial-admin.txt"
    note.write_text(
        "uBIM initial administrator\n\nuser: admin\npassword: "
        f"{password}\n\nChange it after the first login.\n"
    )
    try:
        note.chmod(0o600)
    except OSError:
        pass
    log.warning("created administrator 'admin'; password written to %s", note)

"""Passwords, sessions, CSRF tokens and roles.

Passwords are scrypt (``hashlib.scrypt``) with a per-user salt and parameters stored in the
hash string, so the parameters can be raised later without invalidating existing users.
Sessions are opaque random ids in a cookie; the CSRF token is per session and must be sent
in ``X-CSRF-Token`` on every state-changing request.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import time
from dataclasses import dataclass

from .store import Store, now

#: scrypt cost parameters. n=2**14, r=8, p=1 is about 16 MiB and 40 ms here, which is a
#: sensible interactive cost without needing native dependencies.
SCRYPT_N = 1 << 14
SCRYPT_R = 8
SCRYPT_P = 1
DKLEN = 32

ROLES = ("admin", "editor", "viewer")
#: Capability table. Anything not listed is denied, so a new capability must be granted.
CAPABILITIES = {
    "admin": {"view", "measure", "edit_layers", "manage_projects", "manage_users", "manage_shares", "admin"},
    "editor": {"view", "measure", "edit_layers"},
    "viewer": {"view", "measure"},
}


def can(role: str | None, capability: str) -> bool:
    """Whether a role holds a capability. Unknown roles hold nothing."""
    return capability in CAPABILITIES.get(role or "", set())


def _b64(raw: bytes) -> str:
    """Base64 text for the stored hash components."""
    return base64.b64encode(raw).decode("ascii")


def _unb64(text: str) -> bytes:
    """Decode a stored base64 component."""
    return base64.b64decode(text.encode("ascii"))


def hash_password(password: str, *, n: int = SCRYPT_N, r: int = SCRYPT_R, p: int = SCRYPT_P) -> str:
    """A scrypt hash as ``scrypt$n$r$p$salt$hash``, with the parameters kept so a stored hash stays verifiable if the defaults change."""
    if not password:
        raise ValueError("password must not be empty")
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=n, r=r, p=p, dklen=DKLEN, maxmem=64 * 1024 * 1024)
    return f"scrypt${n}${r}${p}${_b64(salt)}${_b64(digest)}"


def verify_password(stored: str, password: str) -> bool:
    """Whether ``password`` matches a stored hash, in constant time, without raising on a malformed hash."""
    try:
        scheme, n, r, p, salt, digest = stored.split("$")
        if scheme != "scrypt":
            return False
        expected = hashlib.scrypt(
            password.encode("utf-8"), salt=_unb64(salt), n=int(n), r=int(r), p=int(p),
            dklen=len(_unb64(digest)), maxmem=64 * 1024 * 1024,
        )
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(expected, _unb64(digest))


@dataclass
class Session:
    """A signed-in session: who, the cookie id, the CSRF token, and when it expires."""
    id: str
    user_id: int
    csrf: str
    expires: int
    role: str
    name: str
    settings: dict

    @property
    def expired(self) -> bool:
        """Whether the session has run out of time."""
        return self.expires <= int(time.time())


def create_user(store: Store, name: str, password: str, *, role: str = "viewer", email: str | None = None) -> int:
    """Create a user with a hashed password; the name is trimmed and must be unique."""
    name = name.strip()
    if not name:
        raise ValueError("user name must not be empty")
    if role not in ROLES:
        raise ValueError(f"unknown role {role!r}")
    existing = store.one("SELECT id FROM users WHERE lower(name) = lower(?)", (name,))
    if existing:
        raise ValueError(f"user {name!r} already exists")
    return store.execute(
        "INSERT INTO users(name, email, password_hash, role, created) VALUES(?,?,?,?,?)",
        (name, email, hash_password(password), role, now()),
    )


def set_password(store: Store, name: str, password: str) -> None:
    """Replace a user's password and end their sessions.

    Used by ``python -m ubim --set-password`` when the first-run password has been lost.
    The name is matched case-insensitively, as sign-in does; an unknown name is an error
    rather than a silent no-op, because a typo that changes nothing is worse than a failure.
    """
    if not password:
        raise ValueError("password must not be empty")
    row = store.one("SELECT id FROM users WHERE lower(name) = lower(?)", (name.strip(),))
    if row is None:
        raise ValueError(f"no user named {name!r}")
    store.execute("UPDATE users SET password_hash = ? WHERE id = ?", (hash_password(password), row["id"]))
    store.execute("DELETE FROM sessions WHERE user_id = ?", (row["id"],))


def count_users(store: Store) -> int:
    """How many users exist, which is what decides whether the first-run setup is offered."""
    return int(store.scalar("SELECT COUNT(*) FROM users") or 0)


def authenticate(store: Store, name: str, password: str) -> int | None:
    """The user row for a name and password, or None. An unknown name still runs one hash so the timing does not reveal which names exist."""
    row = store.one("SELECT id, password_hash, disabled FROM users WHERE lower(name) = lower(?)", (name.strip(),))
    if row is None or row["disabled"]:
        # Still run the hash so a missing user and a wrong password cost the same time.
        verify_password(row["password_hash"], password) if row else _dummy_hash(password)
        return None
    if not verify_password(row["password_hash"], password):
        return None
    return int(row["id"])


_DUMMY = hash_password("ubim-dummy-password")
_DUMMY_LOCK = None


def _dummy_hash(password: str) -> None:
    """Spend the same time as a real check would, for a name that does not exist."""
    verify_password(_DUMMY, password)


def create_session(store: Store, user_id: int, *, hours: int, ip: str | None, agent: str | None) -> Session:
    """Start a session for a user and return it with its CSRF token; the id is the cookie value."""
    sid = secrets.token_urlsafe(32)
    csrf = secrets.token_urlsafe(32)
    created = now()
    expires = created + hours * 3600
    store.execute(
        "INSERT INTO sessions(id, user_id, created, last_seen, expires, csrf, ip, agent) VALUES(?,?,?,?,?,?,?,?)",
        (sid, user_id, created, created, expires, csrf, ip, (agent or "")[:400]),
    )
    row = store.one("SELECT name, role, settings FROM users WHERE id = ?", (user_id,))
    return Session(sid, user_id, csrf, expires, row["role"], row["name"], _settings(row))


def load_session(store: Store, session_id: str | None) -> Session | None:
    """The live session for a cookie value, or None when it is missing, expired or revoked."""
    if not session_id:
        return None
    row = store.one(
        "SELECT s.id, s.user_id, s.csrf, s.expires, s.last_seen, u.role, u.name, u.settings, u.disabled "
        "FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ?",
        (session_id,),
    )
    if row is None or row["disabled"]:
        return None
    if row["expires"] <= now():
        store.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
        return None
    # Touch at most once a minute so reads do not all become writes.
    if now() - row["last_seen"] > 60:
        store.execute("UPDATE sessions SET last_seen = ? WHERE id = ?", (now(), session_id))
    return Session(row["id"], int(row["user_id"]), row["csrf"], int(row["expires"]), row["role"], row["name"], _settings(row))


def _settings(row) -> dict:
    """The session's stored settings as a dict; malformed JSON becomes an empty dict rather than an error."""
    import json

    try:
        return json.loads(row["settings"] or "{}")
    except (json.JSONDecodeError, TypeError, IndexError):
        return {}


def destroy_session(store: Store, session_id: str | None) -> None:
    """End a session, so the cookie value stops working even if it is replayed."""
    if session_id:
        store.execute("DELETE FROM sessions WHERE id = ?", (session_id,))


def purge_expired(store: Store) -> int:
    """Delete sessions that have run out, and return how many went."""
    return store.execute("DELETE FROM sessions WHERE expires <= ?", (now(),))


def csrf_ok(session: Session, supplied: str | None) -> bool:
    """Whether the supplied token matches the session's, in constant time."""
    return bool(supplied) and hmac.compare_digest(session.csrf, supplied)


def new_token(bytes_: int = 24) -> str:
    """A URL-safe random token for cookies, CSRF values and share links."""
    return secrets.token_urlsafe(bytes_)


def invite_code() -> str:
    """Human-typable invite code, unambiguous alphabet, 8 groups of 4 would be overkill."""
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "-".join("".join(secrets.choice(alphabet) for _ in range(4)) for _ in range(2))


def create_invite(store: Store, *, role: str, hours: int, created_by: int | None) -> str:
    """An invitation code with a role and a lifetime, recorded with who created it."""
    code = invite_code()
    store.execute(
        "INSERT INTO invites(code, role, created, expires, created_by) VALUES(?,?,?,?,?)",
        (code, role, now(), now() + hours * 3600, created_by),
    )
    return code


def redeem_invite(store: Store, code: str, name: str, password: str) -> int:
    """Create the user an invitation describes, and mark the code used; fails if it is unknown or spent."""
    code = code.strip().upper()
    row = store.one("SELECT * FROM invites WHERE code = ?", (code,))
    if row is None:
        raise ValueError("invite not found")
    if row["used_by"] is not None:
        raise ValueError("invite already used")
    if row["expires"] <= now():
        raise ValueError("invite expired")
    user_id = create_user(store, name, password, role=row["role"])
    store.execute("UPDATE invites SET used_by = ?, used_at = ? WHERE code = ?", (user_id, now(), code))
    return user_id

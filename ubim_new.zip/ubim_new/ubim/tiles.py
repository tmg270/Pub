"""Derived images: downscaled panoramas and thumbnails, cached on disk.

The HD panorama is 8190 x 4161; as a GPU texture that is 136 MB decoded, which is more than
some clients will give us. Serving a 4096-wide version (34 MB decoded) is visually lossless
at typical field of view and keeps the texture inside a sane budget. Anything smaller than
the ceiling is served untouched.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

from PIL import Image

from .config import Config

Image.MAX_IMAGE_PIXELS = 400_000_000


def _cache_path(config: Config, kind: str, source: Path, size: int, suffix: str) -> Path:
    """The cache file for one tile: kind, level and coordinates, keyed by the source's size and mtime so a rebuilt source is not served from an old tile."""
    stat = source.stat()
    key = f"{source.resolve()}|{stat.st_size}|{int(stat.st_mtime)}|{size}|{kind}"
    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()[:32]
    return config.cache_dir / "images" / f"{digest}{suffix}"


def _write_atomic(target: Path, image: Image.Image, **save_kwargs) -> None:
    """Write an image to a temporary name and rename it into place, so a reader never sees half a tile."""
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".part")
    image.save(temporary, **save_kwargs)
    temporary.replace(target)


def panorama_cache(source: Path, config: Config, max_size: int) -> Path:
    """A JPEG of the panorama no wider than ``max_size``."""
    source = Path(source)
    with Image.open(source) as opened:
        width, height = opened.size
        if width <= max_size:
            return source
        target = _cache_path(config, "pano", source, max_size, ".jpg")
        if target.exists():
            return target
        scale = max_size / width
        resized = opened.convert("RGB").resize((max_size, max(1, round(height * scale))), Image.LANCZOS)
    _write_atomic(target, resized, format="JPEG", quality=88, optimize=True, progressive=True)
    return target


def thumbnail_cache(source: Path, config: Config, size: int) -> Path:
    """Square-ish thumbnail cropped from the centre of the panorama."""
    source = Path(source)
    target = _cache_path(config, "thumb", source, size, ".jpg")
    if target.exists():
        return target
    with Image.open(source) as opened:
        width, height = opened.size
        side = min(width, height)
        left = (width - side) // 2
        top = max(0, (height - side) // 2)
        box = (left, top, left + side, top + side)
        thumb = opened.convert("RGB").resize((size, size), Image.LANCZOS, box=box)
    _write_atomic(target, thumb, format="JPEG", quality=82, optimize=True, progressive=True)
    return target


def image_size(source: Path) -> tuple[int, int]:
    """The pixel dimensions of an image file, read from its header."""
    with Image.open(source) as opened:
        return opened.size

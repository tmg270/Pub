"""Per-user preferences, where a project sits in the world, and map tiles.

Three small things that share a reason to exist: the home page can show the projects as a
list or on a map, it remembers which one a user last chose, and a project only appears on
the map once somebody has said where it is. Nothing here guesses a coordinate: a project
without a declared position is reported as unplaced and listed as such.

Map tiles are fetched by the server, never linked from the page, so the browser talks only
to this app; the tiles are cached on disk and a failure is a blank tile rather than an
error the viewer has to handle.
"""

from __future__ import annotations

import time
import urllib.error
import urllib.request

from fastapi import APIRouter, Body, HTTPException, Request, Response
from fastapi.responses import FileResponse

from . import gps, projects
from .api import client_ip, config, project_or_404, require, store

router = APIRouter(prefix="/api")

VIEWS = ("list", "map")
DETAILS = ("auto", "standard", "max")
TILE_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
TILE_AGENT = "ubim-viewer/1.0 (local FARO viewer)"
# A 1x1 transparent PNG, used when a tile cannot be fetched (offline, rate limited).
BLANK = bytes.fromhex(
    "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489"
    "0000000d49444154789c6360000002000154a24f5f0000000049454e44ae426082"
)


# -- preferences ----------------------------------------------------------

@router.get("/settings")
async def read_settings(request: Request):
    """The settings the caller may see: their own account, and the instance's declared defaults."""
    current = require(request, "view")
    stored = {}
    if current is not None:
        for row in store(request).query(
            "SELECT key, value FROM settings WHERE user_id = ?", (current.user_id,)
        ):
            stored[row["key"]] = row["value"]
    view = stored.get("view") if stored.get("view") in VIEWS else "list"
    detail = stored.get("detail") if stored.get("detail") in DETAILS else "auto"
    return {"view": view, "views": list(VIEWS), "detail": detail, "details": list(DETAILS)}


@router.put("/settings")
async def write_settings(request: Request, payload: dict = Body(...)):
    """Per-user preferences. ``detail`` is how much of the panorama to pull: auto decides,
    standard keeps textures bounded, max asks for every pixel the product has."""
    current = require(request, "view")
    chosen = {}
    if "view" in payload:
        view = str(payload.get("view", "")).strip()
        if view not in VIEWS:
            raise HTTPException(status_code=400, detail=f"view must be one of {', '.join(VIEWS)}")
        chosen["view"] = view
    if "detail" in payload:
        detail = str(payload.get("detail", "")).strip()
        if detail not in DETAILS:
            raise HTTPException(status_code=400, detail=f"detail must be one of {', '.join(DETAILS)}")
        chosen["detail"] = detail
    if not chosen:
        raise HTTPException(status_code=400, detail="nothing to save: send view or detail")
    if current is None:
        raise HTTPException(status_code=401, detail="not signed in")
    if current is not None:
        connection = store(request).connect()
        for key, value in chosen.items():
            connection.execute(
                "INSERT INTO settings (user_id, key, value) VALUES (?, ?, ?) "
                "ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value",
                (current.user_id, key, value),
            )
        connection.commit()
    return {**{"view": None, "detail": None}, **chosen}


# -- placement ------------------------------------------------------------

@router.get("/locations")
async def locations(request: Request):
    """Every project with the position it declares, placed or not."""
    require(request, "view")
    rows = store(request).query(
        "SELECT slug, name, lat, lon, location_source FROM projects ORDER BY name"
    )
    return {
        "projects": [
            {
                "slug": row["slug"],
                "name": row["name"],
                "lat": row["lat"],
                "lon": row["lon"],
                "placed": row["lat"] is not None and row["lon"] is not None,
                "source": row["location_source"],
            }
            for row in rows
        ]
    }


@router.get("/p/{slug}/location")
async def read_location(request: Request, slug: str):
    """A project's declared position and CRS."""
    require(request, "view")
    found = project_or_404(request, slug)
    return {
        "lat": found["lat"],
        "lon": found["lon"],
        "placed": found["lat"] is not None,
        "source": found["location_source"],
    }


@router.get("/p/{slug}/s/{name}/gps")
async def scan_gps(request: Request, slug: str, name: str):
    """The fix the scanner itself recorded, if it recorded one.

    This is evidence, not a decision: the project's position stays whatever was declared for
    it. ``POST /p/{slug}/location/from-scan`` is how a person adopts it.
    """
    require(request, "view")
    found = project_or_404(request, slug)
    row = projects.scan(store(request), found["id"], name)
    if row is None:
        raise HTTPException(status_code=404, detail="scan not found")
    return {"scan": name, "gps": gps.read(row["path"]), "units": "degrees"}


@router.post("/p/{slug}/location/from-scan")
async def location_from_scan(request: Request, slug: str, payload: dict = Body(...)):
    """Adopt a scan's own GPS fix as the project's position, labelled as such."""
    current = require(request, "edit_layers")
    found = project_or_404(request, slug)
    name = payload.get("scan")
    row = projects.scan(store(request), found["id"], str(name)) if name else None
    if row is None:
        raise HTTPException(status_code=404, detail="scan not found")
    fix = gps.read(row["path"])
    if fix is None:
        raise HTTPException(status_code=409, detail=f"{name} recorded no GPS fix")
    connection = store(request).connect()
    connection.execute(
        "UPDATE projects SET lat = ?, lon = ?, location_source = ?, updated = ? WHERE id = ?",
        (fix["lat"], fix["lon"], f"scan GPS ({name})", time.time(), found["id"]),
    )
    connection.commit()
    store(request).audit("project.location.gps", current.user_id, {"scan": name, **fix}, client_ip(request), 200)
    return {"lat": fix["lat"], "lon": fix["lon"], "placed": True, "source": f"scan GPS ({name})", "gps": fix}


@router.put("/p/{slug}/crs")
async def write_crs(request: Request, slug: str, payload: dict = Body(...)):
    """Record the coordinate reference system the project's numbers are in.

    Nothing is reprojected: neither FARO format states a CRS, so this says what a person has
    written down, and the drawing export repeats it as a comment rather than pretending the
    DXF carries a projection.
    """
    current = require(request, "edit_layers")
    found = project_or_404(request, slug)
    raw = str(payload.get("crs") or "").strip()
    if not raw:
        value = None
    else:
        if len(raw) > 64:
            raise HTTPException(status_code=400, detail="crs is at most 64 characters")
        value = raw.upper() if raw.lower().startswith("epsg") else raw
        if value.lower().startswith("epsg:") and not value.split(":", 1)[1].isdigit():
            raise HTTPException(status_code=400, detail="EPSG codes are numeric, e.g. EPSG:27700")
    store(request).execute("UPDATE projects SET crs = ?, updated = ? WHERE id = ?", (value, time.time(), found["id"]))
    store(request).audit("project.crs", current.user_id, {"crs": value}, client_ip(request), 200)
    return {"crs": value}


@router.put("/p/{slug}/location")
async def write_location(request: Request, slug: str, payload: dict = Body(...)):
    """Set a project's position by hand, recording that the source is manual."""
    current = require(request, "edit_layers")
    found = project_or_404(request, slug)
    lat = payload.get("lat")
    lon = payload.get("lon")
    if lat is None or lon is None:
        lat = lon = None
    else:
        try:
            lat = float(lat)
            lon = float(lon)
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail="lat and lon must be numbers") from None
        if not -90.0 <= lat <= 90.0:
            raise HTTPException(status_code=400, detail="lat must be between -90 and 90")
        if not -180.0 <= lon <= 180.0:
            raise HTTPException(status_code=400, detail="lon must be between -180 and 180")
    connection = store(request).connect()
    connection.execute(
        "UPDATE projects SET lat = ?, lon = ?, location_source = ?, updated = ? WHERE id = ?",
        (lat, lon, "declared" if lat is not None else None, time.time(), found["id"]),
    )
    connection.commit()
    store(request).audit(
        "project.location",
        current.user_id if current else None,
        f"{slug} {lat},{lon}" if lat is not None else f"{slug} cleared",
    )
    return {"lat": lat, "lon": lon, "placed": lat is not None}


# -- tiles ----------------------------------------------------------------

@router.get("/tiles/{z}/{x}/{y}.png")
async def tile(request: Request, z: int, x: int, y: int):
    """One OpenStreetMap tile, served from the disk cache when it is there and fetched once when it is not."""
    require(request, "view")
    if not 0 <= z <= 19:
        raise HTTPException(status_code=400, detail="zoom must be 0..19")
    span = 1 << z
    if not (0 <= x < span and 0 <= y < span):
        raise HTTPException(status_code=400, detail="tile is outside the zoom level")
    cache = config(request).data_dir / "cache" / "tiles" / str(z) / str(x)
    path = cache / f"{y}.png"
    headers = {"Cache-Control": "private, max-age=604800"}
    if path.is_file():
        return FileResponse(path, media_type="image/png", headers={**headers, "X-Tile-Cache": "hit"})

    request_url = TILE_URL.format(z=z, x=x, y=y)
    try:
        with urllib.request.urlopen(
            urllib.request.Request(request_url, headers={"User-Agent": TILE_AGENT}), timeout=6
        ) as response:
            body = response.read()
    except (urllib.error.URLError, TimeoutError, OSError):
        return Response(content=BLANK, media_type="image/png",
                        headers={**headers, "X-Tile-Cache": "offline"})
    if not body:
        return Response(content=BLANK, media_type="image/png",
                        headers={**headers, "X-Tile-Cache": "empty"})
    cache.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".part")
    temporary.write_bytes(body)
    temporary.replace(path)
    return Response(content=body, media_type="image/png",
                    headers={**headers, "X-Tile-Cache": "miss"})

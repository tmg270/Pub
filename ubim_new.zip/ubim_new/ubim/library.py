"""Finding project folders under a library root, and accounting for the product cache.

Spec C1: one configured root, a catalogue, and a cache that can be measured and cleared. There is
no filesystem watcher — discovery is something an administrator asks for, and it says what it found
rather than assuming a folder it cannot parse is empty.

Nothing here writes to a scan. The cache commands only ever remove a product directory, which the
app can always rebuild from the scan it sits beside.
"""

from __future__ import annotations

import os
from pathlib import Path

from . import products_api, projects
from .config import Config

#: A folder is a candidate when it holds scan files directly, under ``Scans/``, under a
#: ``Revisions/<n>/Scans`` tree, or in the 2026 ``_3Scans`` layout.
SCAN_SUFFIXES = (".fls", ".f3s")


def _scans_directly_in(folder: Path) -> bool:
    """Whether scan files sit in this folder, or in the places a project keeps them."""
    folder = Path(folder)
    candidates = [folder, folder / "Scans", folder / "_3Scans"]
    revisions = folder / "Revisions"
    if not revisions.is_dir():
        revisions = folder / "Revision"
    if revisions.is_dir():
        for entry in revisions.iterdir():
            if entry.is_dir() and entry.name.isdigit():
                candidates.append(entry / "Scans")
                candidates.append(entry / "_3Scans")
    for place in candidates:
        try:
            if any(item.suffix.lower() in SCAN_SUFFIXES for item in place.iterdir() if item.is_file()):
                return True
        except OSError:
            continue
    return False


def _has_scans(folder: Path, depth: int = 3) -> bool:
    """Whether any scan file lives within ``depth`` levels of ``folder``."""
    folder = Path(folder)
    base_depth = len(folder.parts)
    for current, dirs, files in os.walk(folder):
        here = Path(current)
        if len(here.parts) - base_depth >= depth:
            dirs[:] = []
        if any(name.lower().endswith(SCAN_SUFFIXES) for name in files):
            return True
    return False


def find_projects(root: Path, *, limit: int = 500) -> list[Path]:
    """Project folders under ``root``: itself if it holds scans, else its children.

    Deliberately shallow: a library is a folder of project folders, and walking an entire tree
    would turn a large NAS into a minute of silence.
    """
    root = Path(root).expanduser()
    if not root.is_dir():
        raise FileNotFoundError(f"{root} is not a directory")
    found: list[Path] = []
    if _scans_directly_in(root):
        found.append(root)
    for entry in sorted(root.iterdir()):
        if len(found) >= limit:
            break
        # A project folder holds scans where a project puts them; a library folder does not,
        # which is why the root is tested directly rather than by descent.
        if entry.is_dir() and not entry.name.startswith(".") and _scans_directly_in(entry):
            found.append(entry)
    return found


def discover(store, config: Config, root: Path | None = None, *, dry_run: bool = False) -> dict:
    """Compare the folders under ``root`` with the catalogue, and register what is new."""
    base = Path(root) if root is not None else config.library_root
    if base is None:
        return {"root": None, "added": [], "known": [], "error": "no library root configured (UBIM_LIBRARY_ROOT)"}
    try:
        found = find_projects(base)
    except FileNotFoundError as exc:
        return {"root": str(base), "added": [], "known": [], "error": str(exc)}
    known = {str(Path(row["path"]).resolve()) for row in store.query("SELECT path FROM projects")}
    added, already = [], []
    for folder in found:
        target = str(folder.resolve())
        if target in known:
            already.append(folder.name)
            continue
        if dry_run:
            added.append({"name": folder.name, "path": target, "registered": False})
            continue
        try:
            made = projects.register(store, folder)
        except Exception as exc:  # noqa: BLE001 - one bad folder must not stop the walk
            added.append({"name": folder.name, "path": target, "error": str(exc)})
            continue
        added.append({"name": made["name"], "path": target, "slug": made["slug"], "registered": True})
    return {"root": str(base), "added": added, "known": already, "dryRun": dry_run}


def _tree_bytes(folder: Path) -> int:
    """Total size of the files under a folder, counting only what can be stat'ed."""
    total = 0
    for current, _dirs, files in os.walk(folder):
        for name in files:
            try:
                total += (Path(current) / name).stat().st_size
            except OSError:
                pass
    return total


def catalogue(store, config: Config) -> dict:
    """Every catalogued project, with its scans, position and what it costs on disk.

    A project whose folder has gone is reported as missing rather than silently dropped: the
    catalogue is evidence of what was registered, not a mirror of the filesystem.
    """
    rows = []
    total_products = 0
    for project in store.query("SELECT * FROM projects ORDER BY name"):
        scans = projects.scans_for(store, project["id"])
        exists = Path(project["path"]).is_dir()
        product_bytes = 0
        for scan in scans:
            root = products_api.product_dir(Path(scan["path"]), config)
            if root.is_dir():
                product_bytes += _tree_bytes(root)
        total_products += product_bytes
        rows.append({
            "slug": project["slug"],
            "name": project["name"],
            "path": project["path"],
            "exists": exists,
            "revision": project["revision"],
            "located": project["lat"] is not None and project["lon"] is not None,
            "crs": project["crs"],
            "scanCount": len(scans),
            "productMiB": round(product_bytes / (1 << 20), 1),
        })
    return {"projects": rows, "count": len(rows), "productMiB": round(total_products / (1 << 20), 1)}


def cache_report(store, config: Config) -> dict:
    """What the products for each scan cost, and whether they still match the scan."""
    scans = []
    for project in store.query("SELECT id, slug, name FROM projects ORDER BY name"):
        for scan in projects.scans_for(store, project["id"]):
            path = Path(scan["path"])
            root = products_api.product_dir(path, config)
            size = _tree_bytes(root) if root.is_dir() else 0
            summary = products_api.summary(path, config)
            scans.append({
                "project": project["slug"],
                "scan": scan["name"],
                "path": str(path),
                "productDir": str(root),
                "exists": root.is_dir(),
                "bytes": size,
                "MiB": round(size / (1 << 20), 1),
                "built": [kind for kind in ("intensity", "depth", "plan", "photo") if summary.get(kind, {}).get("built")],
                "stale": [kind for kind in ("intensity", "depth", "plan", "photo") if summary.get(kind, {}).get("built") and not summary.get(kind, {}).get("fresh", True)],
            })
    return {"scans": scans, "bytes": sum(item["bytes"] for item in scans),
            "MiB": round(sum(item["bytes"] for item in scans) / (1 << 20), 1)}


def clear_cache(store, config: Config, *, project: str | None = None, scan: str | None = None) -> dict:
    """Remove product directories. The scans themselves are never touched."""
    targets = []
    for row in store.query("SELECT id, slug FROM projects" + (" WHERE slug = ?" if project else ""),
                           (project,) if project else ()):
        for item in projects.scans_for(store, row["id"]):
            if scan and item["name"] != scan:
                continue
            targets.append((row["slug"], item["name"], Path(item["path"])))
    if not targets:
        raise LookupError("no scan matched")
    removed = []
    freed = 0
    for slug, name, path in targets:
        root = products_api.product_dir(path, config)
        if not root.is_dir():
            continue
        size = _tree_bytes(root)
        # Only ever the product directory, and only when it is not the scan itself.
        if root.resolve() == path.resolve():
            continue
        import shutil

        shutil.rmtree(root)
        freed += size
        removed.append({"project": slug, "scan": name, "MiB": round(size / (1 << 20), 1)})
    return {"removed": removed, "freedMiB": round(freed / (1 << 20), 1), "count": len(removed)}

"""Measurement and annotation routes.

Features live on layers owned by the project, not by the scan, so the same layer can carry
notes gathered from several scans of the same site. Each feature carries the scan it was
measured on inside its geometry, and every write lands under a fresh ``undo_group`` so an
undo is a single, atomic revert of one user action rather than a guess.
"""

from __future__ import annotations

import csv
import io
import json
import math
import re
import tempfile
import textwrap
import time
from pathlib import Path

from fastapi import APIRouter, Body, HTTPException, Request, Response
from fastapi.responses import FileResponse, JSONResponse

from . import api_drawings, auth, e57, measure, products_api, projects, registration, tiles
from .accuracy import ACCURACY
from .web import client_ip

router = APIRouter(prefix="/api")

#: Spec L1: labels carry no markup and no control characters, and are capped.
LABEL_MAX = 120


def clean_label(value) -> str | None:
    """Strip angle brackets and control characters from a user label, and cap its length."""
    if value is None:
        return None
    text = "".join(character for character in str(value) if character >= " " and character not in "<>")
    text = " ".join(text.split())
    return text[:LABEL_MAX] or None


def _store(request: Request):
    """The store for this application instance."""
    return request.app.state.store


def _config(request: Request):
    """The configuration for this application instance."""
    return request.app.state.config


def _session(request: Request):
    """The session the middleware attached, or None."""
    return getattr(request.state, "session", None)


def _require(request: Request, capability: str = "view"):
    """The session if it holds ``capability``, else 401/403."""
    current = _session(request)
    if current is None:
        if capability == "view" and _config(request).allow_anonymous_browse:
            return None
        raise HTTPException(status_code=401, detail="not signed in")
    if not auth.can(current.role, capability):
        raise HTTPException(status_code=403, detail="not allowed")
    return current


def _project(request: Request, slug: str) -> dict:
    """The project for a slug, or a 404 that names it."""
    found = projects.project(_store(request), slug)
    if found is None:
        raise HTTPException(status_code=404, detail="project not found")
    return found


def _scan(request: Request, found: dict, name: str) -> dict:
    """The scan row inside a project, or a 404."""
    row = projects.scan(_store(request), found["id"], name)
    if row is None:
        raise HTTPException(status_code=404, detail="scan not found")
    return row


def _layer_ids(found: dict, store) -> list[int]:
    """The live layer ids of a project, which is what a feature may point at."""
    rows = store.query("SELECT id FROM layers WHERE project_id = ? AND deleted_at IS NULL", (found["id"],))
    return [row["id"] for row in rows]


def _record_revision(store, project_id: int, feature_id: int, action: str, user_id: int | None) -> int:
    """Snapshot a feature's current state as its next version.

    Every accepted change is kept, including a delete, so a measurement can be put back the
    way it was rather than only "undeleted" as whatever it last became.
    """
    row = store.one("SELECT * FROM features WHERE id = ?", (feature_id,))
    if row is None:
        return 0
    version = int(store.scalar(
        "SELECT COALESCE(MAX(version), 0) FROM feature_revisions WHERE feature_id = ?", (feature_id,)
    ) or 0) + 1
    store.execute(
        "INSERT INTO feature_revisions (feature_id, project_id, version, kind, geom, label, layer_id, action, created, created_by)"
        " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (feature_id, project_id, version, row["kind"], row["geom"], row["label"], row["layer_id"], action, int(time.time()), user_id),
    )
    return version


def _revision_list(store, feature_id: int) -> list[dict]:
    """The revision history of one feature, newest first."""
    rows = store.query(
        "SELECT version, kind, label, action, created, created_by, geom FROM feature_revisions"
        " WHERE feature_id = ? ORDER BY version",
        (feature_id,),
    )
    out = []
    for row in rows:
        item = {key: row[key] for key in ("version", "kind", "label", "action", "created", "created_by")}
        try:
            item["points"] = len(json.loads(row["geom"]).get("points") or [])
        except (json.JSONDecodeError, TypeError):
            item["points"] = 0
        out.append(item)
    return out


def _pose_of(store, project_id: int, scan_name: str):
    """The stored transform for a scan, or None when it has never been registered."""
    row = store.one("SELECT pose FROM scans WHERE project_id = ? AND name = ?", (project_id, scan_name))
    if row is None:
        return None
    return registration.parse(row["pose"])


def _as_world(points: list[dict], pose) -> list[tuple[float, float, float]]:
    """Project-frame positions for stored points, or an empty list if any lacks a range."""
    out = []
    for point in points:
        local = measure.to_xyz(point)
        if local is None:
            return []
        out.append(registration.apply(pose, local) if pose else local)
    return out


def _features_for(found: dict, store, scan: str) -> list[dict]:
    """Features of this project, expressed in the frame of ``scan``.

    A measurement is stored in the scan it was taken in. With a registration for both scans
    it is projected into the frame being viewed, so one shared 3D space is what the user sees;
    without one it stays in its own scan, because inventing a position would be worse than
    showing nothing. A rigid transform preserves distances, so the metrics computed on the
    projected points are the same numbers as the ones computed where it was measured.
    """
    ids = _layer_ids(found, store)
    if not ids:
        return []
    marks = ",".join("?" for _ in ids)
    rows = store.query(
        f"SELECT * FROM features WHERE layer_id IN ({marks}) AND deleted_at IS NULL ORDER BY id",
        tuple(ids),
    )
    here = _pose_of(store, found["id"], scan)
    found_rows = []
    for row in rows:
        try:
            geometry = json.loads(row["geom"])
        except json.JSONDecodeError:
            continue
        source = geometry.get("scan")
        points = geometry.get("points", [])
        if source != scan:
            there = _pose_of(store, found["id"], source)
            if there is None or here is None:
                continue  # no shared frame yet: leave it where it was measured
            world = _as_world(points, there)
            if not world:
                continue
            projected = []
            for point in world:
                seen = registration.project(point, here)
                projected.append({"az": seen["az"], "el": seen["el"], "r": seen["r"]})
            points = projected
        found_rows.append({
            "id": row["id"],
            "layer_id": row["layer_id"],
            "kind": row["kind"],
            "label": row["label"],
            "points": points,
            "source_scan": source,
            "from_other_scan": source != scan,
            "created": row["created"],
            "undo_group": row["undo_group"],
        })
    return found_rows


@router.get("/p/{slug}/layers")
async def list_layers(request: Request, slug: str):
    """The project's layers, with visibility and ownership."""
    _require(request)
    found = _project(request, slug)
    rows = _store(request).query(
        "SELECT l.*, (SELECT COUNT(*) FROM features f WHERE f.layer_id = l.id AND f.deleted_at IS NULL) AS marks "
        "FROM layers l WHERE l.project_id = ? AND l.deleted_at IS NULL ORDER BY l.id",
        (found["id"],),
    )
    return {"layers": [dict(row) for row in rows]}


@router.post("/p/{slug}/layers")
async def create_layer(request: Request, slug: str, payload: dict = Body(...)):
    """Add a layer; the colour and name are the caller's, the owner is the session's user."""
    current = _require(request, "edit_layers")
    found = _project(request, slug)
    name = str(payload.get("name", "")).strip()
    if not name:
        raise HTTPException(status_code=400, detail="name is required")
    now = int(time.time())
    store = _store(request)
    store.execute(
        "INSERT INTO layers(project_id, name, owner_id, colour, visible, created, updated) VALUES(?,?,?,?,?,?,?)",
        (found["id"], name[:120], current.user_id, str(payload.get("colour", "#ffcc00"))[:16], 1, now, now),
    )
    layer_id = store.scalar("SELECT last_insert_rowid()")
    store.audit("layer.create", current.user_id, {"project": slug, "name": name}, client_ip(request), 201)
    return JSONResponse({"id": layer_id, "name": name}, status_code=201)


@router.patch("/p/{slug}/layers/{layer_id}")
async def update_layer(request: Request, slug: str, layer_id: int, payload: dict = Body(...)):
    """Change a layer's name, colour or visibility."""
    current = _require(request, "edit_layers")
    found = _project(request, slug)
    store = _store(request)
    row = store.one("SELECT * FROM layers WHERE id = ? AND project_id = ? AND deleted_at IS NULL", (layer_id, found["id"]))
    if row is None:
        raise HTTPException(status_code=404, detail="layer not found")
    fields, values = [], []
    for key, column in (("name", "name"), ("colour", "colour"), ("visible", "visible")):
        if key in payload:
            fields.append(f"{column} = ?")
            values.append(payload[key] if key != "visible" else (1 if payload[key] else 0))
    if fields:
        values.extend([int(time.time()), layer_id])
        store.execute(f"UPDATE layers SET {', '.join(fields)}, updated = ? WHERE id = ?", tuple(values))
    store.audit("layer.update", current.user_id, {"layer": layer_id}, client_ip(request), 200)
    return {"ok": True}


@router.delete("/p/{slug}/layers/{layer_id}")
async def delete_layer(request: Request, slug: str, layer_id: int):
    """Soft-delete a layer, leaving its features attributed to it in the history."""
    current = _require(request, "edit_layers")
    found = _project(request, slug)
    store = _store(request)
    row = store.one("SELECT id FROM layers WHERE id = ? AND project_id = ? AND deleted_at IS NULL", (layer_id, found["id"]))
    if row is None:
        raise HTTPException(status_code=404, detail="layer not found")
    store.execute("UPDATE layers SET deleted_at = ?, deleted_by = ? WHERE id = ?", (int(time.time()), current.user_id, layer_id))
    store.audit("layer.delete", current.user_id, {"layer": layer_id}, client_ip(request), 200)
    return {"ok": True}


@router.get("/p/{slug}/s/{name}/features")
async def list_features(request: Request, slug: str, name: str):
    """The measurements recorded on one scan, with their points and computed metrics."""
    _require(request)
    found = _project(request, slug)
    row = _scan(request, found, name)
    store = _store(request)
    layers = store.query(
        "SELECT id, name, colour, visible FROM layers WHERE project_id = ? AND deleted_at IS NULL ORDER BY id",
        (found["id"],),
    )
    features = _features_for(found, store, row["name"])
    drawn, dropped = api_drawings.as_features(store, found, row)
    features.extend(drawn)
    for feature in features:
        feature["metrics"] = measure.metrics(feature)
    return {
        "scan": row["name"],
        "layers": [dict(entry) for entry in layers],
        "features": features,
        "drawings": {
            "shapes": len(drawn),
            "dropped": dropped,
            "assumedFrame": registration.parse(row["pose"]) is None,
        },
    }


@router.post("/p/{slug}/s/{name}/features")
async def create_feature(request: Request, slug: str, name: str, payload: dict = Body(...)):
    """Record a measurement: its kind, points, label, layer and the metrics the points imply."""
    current = _require(request, "edit_layers")
    found = _project(request, slug)
    row = _scan(request, found, name)
    kind = str(payload.get("kind", "point"))
    if kind not in ("point", "line", "polyline", "area"):
        raise HTTPException(status_code=400, detail="unknown kind")
    raw_points = payload.get("points") or []
    if not raw_points:
        raise HTTPException(status_code=400, detail="at least one point is required")
    points = []
    for point in raw_points:
        try:
            entry = {
                "az": float(point["az"]),
                "el": float(point["el"]),
                "r": float(point["r"]) if point.get("r") not in (None, "") else None,
            }
            if point.get("uncertain"):
                entry["uncertain"] = True
            points.append(entry)
        except (KeyError, TypeError, ValueError) as exc:
            raise HTTPException(status_code=400, detail="points need numeric az and el") from exc
    store = _store(request)
    layers = _layer_ids(found, store)
    layer_id = payload.get("layer_id")
    if layer_id not in layers:
        layer_id = layers[0] if layers else _default_layer(store, found, current)
    # A draft is a measurement the surveyor has not finished. It is stored like any other so
    # it survives a reload, and marked so the UI can tell the two apart.
    status = "draft" if str(payload.get("status", "final")) == "draft" else "final"
    geometry = {"scan": row["name"], "points": points, "status": status}
    group = auth.new_token(8)
    now = int(time.time())
    store.execute(
        "INSERT INTO features(layer_id, kind, geom, label, created, created_by, undo_group) VALUES(?,?,?,?,?,?,?)",
        (layer_id, kind, json.dumps(geometry), clean_label(payload.get("label")), now, current.user_id, group),
    )
    feature_id = store.scalar("SELECT last_insert_rowid()")
    version = _record_revision(store, found["id"], int(feature_id), "create", current.user_id)
    store.audit("feature.create", current.user_id, {"scan": row["name"], "kind": kind}, client_ip(request), 201)
    return JSONResponse(
        {"id": feature_id, "layer_id": layer_id, "kind": kind, "points": points,
         "label": payload.get("label"), "undo_group": group, "created": now, "status": status,
         "version": version, "metrics": measure.metrics({"kind": kind, "points": points})},
        status_code=201,
    )


def _default_layer(store, found: dict, current) -> int:
    """The layer a new feature goes on when the caller names none, created on first use."""
    now = int(time.time())
    store.execute(
        "INSERT INTO layers(project_id, name, owner_id, colour, visible, created, updated) VALUES(?,?,?,?,?,?,?)",
        (found["id"], "Measurements", current.user_id, "#ffd166", 1, now, now),
    )
    return int(store.scalar("SELECT last_insert_rowid()"))


@router.patch("/p/{slug}/s/{name}/features/{feature_id}")
async def update_feature(request: Request, slug: str, name: str, feature_id: int, payload: dict = Body(...)):
    """Change a feature's points, label, layer or note, keeping the previous version in the history."""
    current = _require(request, "edit_layers")
    found = _project(request, slug)
    row = _scan(request, found, name)
    store = _store(request)
    existing = store.one("SELECT * FROM features WHERE id = ? AND deleted_at IS NULL", (feature_id,))
    if existing is None or existing["layer_id"] not in _layer_ids(found, store):
        raise HTTPException(status_code=404, detail="feature not found")
    geometry = json.loads(existing["geom"])
    if payload.get("pointsXY"):
        # A vertex dragged in plan view arrives as metres on the site plan. Converting here
        # rather than in the browser keeps one implementation of the scan's frame.
        previous = geometry.get("points") or []
        converted = []
        for index, spot in enumerate(payload["pointsXY"]):
            x = float(spot["x"])
            y = float(spot["y"])
            old = previous[index] if index < len(previous) else {}
            radius_old = float(old.get("r") or 0.0)
            elevation_old = math.radians(float(old.get("el") or 0.0))
            z = radius_old * math.sin(elevation_old) if radius_old else 0.0
            azimuth, elevation, radius = registration.azimuth_elevation((x, y, z))
            converted.append({"az": round(azimuth, 6), "el": round(elevation, 6), "r": round(radius, 6)})
        geometry["points"] = converted
    if payload.get("points"):
        geometry["points"] = [
            {
                "az": float(p["az"]), "el": float(p["el"]),
                "r": (float(p["r"]) if p.get("r") is not None else None),
                **({"uncertain": True} if p.get("uncertain") else {}),
            }
            for p in payload["points"]
        ]
    if "label" in payload:
        store.execute("UPDATE features SET label = ? WHERE id = ?", (clean_label(payload["label"]), feature_id))
    if "status" in payload:
        geometry["status"] = "draft" if str(payload["status"]) == "draft" else "final"
    store.execute(
        "UPDATE features SET geom = ? WHERE id = ?",
        (json.dumps(geometry), feature_id),
    )
    version = _record_revision(store, found["id"], feature_id, "update", current.user_id)
    store.audit("feature.update", current.user_id, {"feature": feature_id}, client_ip(request), 200)
    return {"ok": True, "version": version, "status": geometry.get("status", "final")}


@router.get("/p/{slug}/s/{name}/plan/at")
async def plan_at(request: Request, slug: str, name: str, x: float, y: float):
    """What is under a hovered plan position: bearing, distance and the return found there."""
    _require(request, "view")
    found = _project(request, slug)
    row = _scan(request, found, name)
    probe = products_api.plan_probe(Path(row["path"]), _config(request), x, y)
    if probe is None:
        raise HTTPException(status_code=404, detail="that position is outside the plan")
    return probe


@router.get("/p/{slug}/s/{name}/plan/points")
async def plan_points(request: Request, slug: str, name: str):
    """Every mark of this scan as a position on its site plan, for dragging in plan view.

    The plan lives in the scan's own frame, so the conversion is the plain one: X forward, Y
    left, Z up, azimuth anticlockwise from +X — the same convention the viewer measures in.
    """
    _require(request, "view")
    found = _project(request, slug)
    row = _scan(request, found, name)
    meta = products_api.plan_meta(Path(row["path"]), _config(request))
    if meta is None:
        raise HTTPException(status_code=404, detail="no site plan for this scan yet")
    bounds = meta.get("bounds") or {}
    span_x = bounds.get("maxX", 0.0) - bounds.get("minX", 0.0)
    span_y = bounds.get("maxY", 0.0) - bounds.get("minY", 0.0)
    out = []
    for feature in _features_for(found, _store(request), name):
        if feature.get("from_other_scan"):
            continue
        points = []
        for point in feature.get("points") or []:
            radius = float(point.get("r") or 0.0)
            azimuth = math.radians(float(point.get("az") or 0.0))
            elevation = math.radians(float(point.get("el") or 0.0))
            ground = radius * math.cos(elevation)
            x = ground * math.cos(azimuth)
            y = ground * math.sin(azimuth)
            points.append({
                "x": round(x, 4),
                "y": round(y, 4),
                "z": round(radius * math.sin(elevation), 4),
                "fractionX": round((x - bounds["minX"]) / span_x, 6) if span_x else 0.0,
                "fractionY": round(1.0 - (y - bounds["minY"]) / span_y, 6) if span_y else 0.0,
            })
        out.append({
            "id": feature["id"],
            "kind": feature["kind"],
            "label": feature.get("label"),
            "layer_id": feature.get("layer_id"),
            "points": points,
        })
    return {"scan": name, "bounds": bounds, "features": out}


@router.delete("/p/{slug}/s/{name}/features/{feature_id}")
async def delete_feature(request: Request, slug: str, name: str, feature_id: int):
    """Soft-delete a feature, keeping the row for the history and the audit trail."""
    current = _require(request, "edit_layers")
    found = _project(request, slug)
    _scan(request, found, name)
    store = _store(request)
    existing = store.one("SELECT * FROM features WHERE id = ? AND deleted_at IS NULL", (feature_id,))
    if existing is None or existing["layer_id"] not in _layer_ids(found, store):
        raise HTTPException(status_code=404, detail="feature not found")
    store.execute(
        "UPDATE features SET deleted_at = ?, deleted_by = ? WHERE id = ?",
        (int(time.time()), current.user_id, feature_id),
    )
    version = _record_revision(store, found["id"], feature_id, "delete", current.user_id)
    store.audit("feature.delete", current.user_id, {"feature": feature_id}, client_ip(request), 200)
    return {"ok": True, "version": version}


@router.post("/p/{slug}/s/{name}/undo")
async def undo(request: Request, slug: str, name: str):
    """Revert the scan's most recent measurement change, and return what was undone."""
    current = _require(request, "edit_layers")
    found = _project(request, slug)
    row = _scan(request, found, name)
    store = _store(request)
    ids = _layer_ids(found, store)
    if not ids:
        return {"reverted": 0}
    marks = ",".join("?" for _ in ids)
    latest = store.one(
        f"SELECT undo_group FROM features WHERE layer_id IN ({marks}) AND deleted_at IS NULL "
        "AND undo_group IS NOT NULL ORDER BY id DESC LIMIT 1",
        tuple(ids),
    )
    if latest is None:
        return {"reverted": 0}
    rows = store.query(
        f"SELECT id FROM features WHERE undo_group = ? AND layer_id IN ({marks}) AND deleted_at IS NULL",
        (latest["undo_group"], *ids),
    )
    now = int(time.time())
    for entry in rows:
        store.execute("UPDATE features SET deleted_at = ?, deleted_by = ? WHERE id = ?", (now, current.user_id, entry["id"]))
    store.audit("feature.undo", current.user_id, {"scan": row["name"], "group": latest["undo_group"]}, client_ip(request), 200)
    return {"reverted": len(rows), "group": latest["undo_group"]}


# -- export ---------------------------------------------------------------

def to_xyz(point: dict) -> tuple[float, float, float] | None:
    """Scan-frame position of a direction/range pair, in the scan's own units."""
    radius = point.get("r")
    if radius is None:
        return None
    azimuth = math.radians(point["az"])
    elevation = math.radians(point["el"])
    return (
        radius * math.cos(elevation) * math.cos(azimuth),
        radius * math.cos(elevation) * math.sin(azimuth),
        radius * math.sin(elevation),
    )


def layer_name(layer_id: int, creator: str | None = None) -> str:
    """A DXF layer per measurement layer, named after whoever owns it.

    A DXF layer name may not contain < > / \\ " : ; ? * | = and is limited to 31 characters,
    so the creator's name is stripped down rather than trusted.
    """
    name = f"L{layer_id}"
    if creator:
        clean = re.sub(r'[<>/\\":;?*|=]', "_", creator).strip()[:24]
        if clean:
            name = f"{name}_{clean}"
    return name[:31]


def dxf_document(features: list[dict], scan_name: str, creators: dict | None = None, crs: str | None = None) -> str:
    """A minimal DXF R12 file: points, polylines and labels, no external dependencies."""
    lines = []
    # 999 is DXF's comment group: the caveat travels with the drawing.
    if crs:
        lines.extend(["999", f"CRS (declared, not applied): {crs}"])
    for chunk in textwrap.wrap(ACCURACY, 70):
        lines.extend(["999", chunk])
    lines.extend([
        "0", "SECTION", "2", "HEADER",
        # R12 (AC1009) is the most widely accepted ASCII DXF; the drawing is in metres, which
        # $INSUNITS = 6 declares so AutoCAD does not ask on import.
        "9", "$ACADVER", "1", "AC1009",
        "9", "$INSUNITS", "70", "6",
        "9", "$MEASUREMENT", "70", "1",
        "0", "ENDSEC", "0", "SECTION", "2", "ENTITIES",
    ])
    creators = creators or {}
    layer = lambda feature: layer_name(int(feature["layer_id"]), creators.get(int(feature["layer_id"])))
    for feature in features:
        points = feature.get("points") or []
        coords = [(to_xyz(point), point) for point in points]
        if feature["kind"] == "point" and coords:
            xyz = coords[0][0]
            if xyz:
                lines += ["0", "POINT", "8", layer(feature), "10", f"{xyz[0]:.4f}", "20", f"{xyz[1]:.4f}", "30", f"{xyz[2]:.4f}"]
        elif len(coords) > 1:
            lines += ["0", "POLYLINE", "8", layer(feature), "66", "1", "70", "1" if feature["kind"] == "area" else "0"]
            for xyz, _ in coords:
                if xyz is None:
                    continue
                lines += ["0", "VERTEX", "8", layer(feature),
                          "10", f"{xyz[0]:.4f}", "20", f"{xyz[1]:.4f}", "30", f"{xyz[2]:.4f}"]
            lines += ["0", "SEQEND"]
        label = feature.get("label") or ""
        if label and coords and coords[0][0]:
            xyz = coords[0][0]
            lines += ["0", "TEXT", "8", layer(feature),
                      "10", f"{xyz[0]:.4f}", "20", f"{xyz[1]:.4f}", "30", f"{xyz[2]:.4f}",
                      "40", "0.25", "1", label[:200]]
    lines += ["0", "ENDSEC", "0", "EOF"]
    return "\n".join(lines) + "\n"


@router.get("/p/{slug}/s/{name}/export.dxf")
async def export_dxf(request: Request, slug: str, name: str):
    """The project's marks and drawings as DXF, with layers and a comment naming the declared CRS."""
    _require(request)
    found = _project(request, slug)
    row = _scan(request, found, name)
    store = _store(request)
    features = _features_for(found, store, row["name"])
    creators = {
        int(layer_id): name
        for layer_id, name in store.query(
            "SELECT l.id, u.name FROM layers l LEFT JOIN users u ON u.id = l.owner_id WHERE l.project_id = ?",
            (found["id"],),
        )
    }
    document = dxf_document(features, row["name"], creators, found.get("crs"))
    stem = f"{found['slug']}-{row['name']}".replace("/", "-")
    return Response(
        document,
        media_type="application/dxf",
        headers={"Content-Disposition": f'attachment; filename="{stem}.dxf"'},
    )


CSV_COLUMNS = [
    "scan", "feature_id", "kind", "layer", "label", "status", "point_index",
    "az_deg", "el_deg", "r_m", "x_m", "y_m", "z_m",
    "length_m", "distance_m", "plan_m", "vertical_signed_m", "area_m2", "perimeter_m", "inclination_deg",
]


@router.get("/p/{slug}/s/{name}/export.csv")
async def export_csv(request: Request, slug: str, name: str):
    """Every mark of this scan as rows a surveyor can open in a spreadsheet.

    One row per vertex, with the angles as measured and the metres they imply in the scan's
    frame (X forward, Y left, Z up). The metrics of the mark repeat on each of its rows, so a
    pivot or a filter still has the numbers to hand.
    """
    _require(request)
    found = _project(request, slug)
    row = _scan(request, found, name)
    features = _features_for(found, _store(request), row["name"])
    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator="\n")
    # A leading # line keeps the caveat with the numbers; every spreadsheet shows it in the
    # first cell, and a script that wants only data can skip lines starting with #.
    buffer.write("# " + ACCURACY.replace('"', "'") + "\n")
    writer.writerow(CSV_COLUMNS)
    for feature in features:
        computed = measure.metrics(feature)
        plane = computed.get("plane") or {}
        for index, point in enumerate(feature.get("points") or []):
            xyz = measure.to_xyz(point) or (None, None, None)
            writer.writerow([
                row["name"],
                feature["id"],
                feature.get("kind") or "",
                feature.get("layer_id") if feature.get("layer_id") is not None else "",
                (feature.get("label") or "").replace("\n", " "),
                computed.get("status") or "",
                index + 1,
                point.get("az") if point.get("az") is not None else "",
                point.get("el") if point.get("el") is not None else "",
                point.get("r") if point.get("r") is not None else "",
                "" if xyz[0] is None else round(xyz[0], 4),
                "" if xyz[1] is None else round(xyz[1], 4),
                "" if xyz[2] is None else round(xyz[2], 4),
                computed.get("length", ""),
                computed.get("distance", ""),
                computed.get("plan", ""),
                computed.get("verticalSigned", ""),
                computed.get("area", ""),
                computed.get("perimeter", ""),
                plane.get("inclination", ""),
            ])
    stem = f"{found['slug']}-{row['name']}".replace("/", "-")
    return Response(
        buffer.getvalue(),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{stem}.csv"'},
    )


@router.get("/p/{slug}/s/{name}/export.e57")
async def export_e57(request: Request, slug: str, name: str):
    """The same marks as an E57 point cloud, for a viewer or a point-cloud tool.

    One point per vertex that actually has a position. The coordinates are the scan's own
    (X forward, Y left, Z up), written unchanged.
    """
    _require(request)
    found = _project(request, slug)
    row = _scan(request, found, name)
    features = _features_for(found, _store(request), row["name"])
    path = Path(tempfile.mkdtemp(prefix="ubim-e57-")) / "export.e57"
    try:
        written = e57.write(path, features, label=row["name"])
    except e57.MissingDependency as exc:
        raise HTTPException(status_code=501, detail=str(exc)) from exc
    stem = f"{found['slug']}-{row['name']}".replace("/", "-")
    headers = {
        "Content-Disposition": f'attachment; filename="{stem}.e57"',
        "X-UBIM-Points": str(written["points"]),
    }
    return Response(path.read_bytes(), media_type="application/e57", headers=headers)


@router.get("/p/{slug}/s/{name}/export.json")
async def export_json(request: Request, slug: str, name: str):
    """The marks and drawings as JSON, for a script rather than a drawing tool."""
    _require(request)
    found = _project(request, slug)
    row = _scan(request, found, name)
    features = _features_for(found, _store(request), row["name"])
    return JSONResponse({
        "project": found["slug"],
        "scan": row["name"],
        "frame": "scan-local azimuth/elevation, degrees, range in scan units",
        "accuracy": ACCURACY,
        "features": features,
    })


@router.get("/p/{slug}/thumb-preview")
async def project_thumb(request: Request, slug: str):
    """A project thumbnail, made from the first scan that has a panorama."""
    _require(request)
    found = _project(request, slug)
    rows = projects.scans_for(_store(request), found["id"])
    for row in rows:
        source = projects.image_for(row, preferred="thumbnail") or projects.image_for(row, preferred="grey_hd")
        if source is not None:
            path = tiles.thumbnail_cache(source, _config(request), 512)
            return FileResponse(path, media_type="image/jpeg", headers={"Cache-Control": "private, max-age=3600"})
        # A .f3s project can have no WebShare images at all. It does have the panorama the
        # colour fallback writes, which is a fair picture of the scan.
        fallback = sorted((Path(row["path"]).parent / (Path(row["path"]).name + ".ubim")).glob("pano_luma_512*"))
        if fallback:
            return FileResponse(fallback[0], media_type="image/jpeg",
                                headers={"Cache-Control": "private, max-age=3600"})
    raise HTTPException(status_code=404, detail="no imagery in this project")


def _owned_feature(store, found: dict, feature_id: int):
    """The feature row, provided its layer belongs to this project (deleted or not)."""
    row = store.one("SELECT * FROM features WHERE id = ?", (feature_id,))
    if row is None:
        return None
    layer = store.one("SELECT project_id FROM layers WHERE id = ?", (row["layer_id"],))
    if layer is None or layer["project_id"] != found["id"]:
        return None
    return row


@router.get("/p/{slug}/s/{name}/features/{feature_id}/revisions")
async def feature_revisions(request: Request, slug: str, name: str, feature_id: int):
    """The stored versions of one feature, which is what undo and the history panel read."""
    _require(request, "view")
    found = _project(request, slug)
    _scan(request, found, name)
    store = _store(request)
    if _owned_feature(store, found, feature_id) is None:
        raise HTTPException(status_code=404, detail="feature not found")
    return {"feature": feature_id, "revisions": _revision_list(store, feature_id)}


@router.post("/p/{slug}/s/{name}/features/{feature_id}/restore")
async def restore_feature(request: Request, slug: str, name: str, feature_id: int, payload: dict = Body(...)):
    """Put a measurement back to an earlier version, including one that was deleted."""
    current = _require(request, "edit_layers")
    found = _project(request, slug)
    _scan(request, found, name)
    store = _store(request)
    try:
        version = int(payload.get("version"))
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail="version is required") from exc
    snapshot = store.one(
        "SELECT * FROM feature_revisions WHERE feature_id = ? AND version = ?", (feature_id, version)
    )
    if snapshot is None:
        raise HTTPException(status_code=404, detail="no such version")
    store.execute(
        "UPDATE features SET kind = ?, geom = ?, label = ?, layer_id = ?, deleted_at = NULL, deleted_by = NULL WHERE id = ?",
        (snapshot["kind"], snapshot["geom"], snapshot["label"], snapshot["layer_id"], feature_id),
    )
    restored = _record_revision(store, found["id"], feature_id, f"restore:{version}", current.user_id)
    store.audit("feature.restore", current.user_id, {"feature": feature_id, "from": version}, client_ip(request), 200)
    return {"ok": True, "version": restored, "restored": version}

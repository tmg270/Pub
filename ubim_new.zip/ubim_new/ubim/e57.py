"""E57 export (spec D5).

An E57 file is a container of point clouds, so what comes out of here is the geometry of the
marks: one point per vertex, in the scan's own frame. No axis swap is applied — X forward, Y left,
Z up is written as it is, and the export says so rather than quietly re-orienting the data.

Written with libE57Format through pye57; the file is a real E57, not a renamed CSV, and the tests
read it back with the same library to prove it.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np


class MissingDependency(RuntimeError):
    """pye57 is not installed, so E57 export cannot run."""


def _pye57():
    """libE57Format through pye57, or an error that says how to install it."""
    try:
        import pye57  # noqa: PLC0415 - optional at import time
    except ModuleNotFoundError as exc:  # pragma: no cover - depends on the environment
        raise MissingDependency(
            "E57 export needs pye57 (libE57Format); install it with `pip install pye57`"
        ) from exc
    return pye57


def points_from_features(features) -> tuple[np.ndarray, list[dict]]:
    """Vertices with a position, plus the metadata row for each one.

    A vertex whose range is unknown has no position, and is left out rather than written as a
    zero at the origin: a point that is not there must not appear to be.
    """
    from . import measure

    xyz: list[tuple[float, float, float]] = []
    rows: list[dict] = []
    for feature in features:
        for index, point in enumerate(feature.get("points") or []):
            position = measure.to_xyz(point)
            if position is None or any(value is None for value in position):
                continue
            xyz.append(tuple(float(value) for value in position))
            rows.append({
                "feature": feature.get("id"),
                "kind": feature.get("kind"),
                "vertex": index + 1,
                "label": (feature.get("label") or "").replace("\n", " "),
            })
    return np.asarray(xyz, dtype="f8").reshape(-1, 3), rows


def write(path: Path, features, *, label: str | None = None) -> dict:
    """Write one scan of points and return what was written."""
    pye57 = _pye57()
    xyz, rows = points_from_features(features)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = pye57.E57(str(path), mode="w")
    try:
        if len(xyz):
            # pye57 wants the fields as separate arrays; float32 is what E57 stores.
            handle.write_scan_raw({
                "cartesianX": xyz[:, 0].astype("f4"),
                "cartesianY": xyz[:, 1].astype("f4"),
                "cartesianZ": xyz[:, 2].astype("f4"),
            })
    finally:
        handle.close()
    return {"points": int(len(xyz)), "path": str(path), "label": label, "bytes": path.stat().st_size,
            "frame": "scan frame: X forward, Y left, Z up (written unchanged, no axis swap)"}

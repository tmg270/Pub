"""JSON API.

Paths in requests are only ever used as *keys* (slug, scan name, integers); the filesystem
paths behind them come from the database. That is what makes traversal impossible rather
than merely unlikely: ``../x``, ``%2e%2e`` and friends simply fail to match a row.
"""

from __future__ import annotations

import io
import json
import shutil
import time
from pathlib import Path

from PIL import Image

from fastapi import APIRouter, Body, HTTPException, Request, Response
from fastapi.responses import FileResponse, JSONResponse

from . import auth, gps, jobs, library, products_api, projects, registration, tiles
from .accuracy import ACCURACY
from .web import client_ip

router = APIRouter(prefix="/api")


def store(request: Request):
    """The store for this application instance."""
    return request.app.state.store


def config(request: Request):
    """The configuration for this application instance."""
    return request.app.state.config


def session(request: Request):
    """The session the middleware attached, or None when the request is anonymous."""
    return getattr(request.state, "session", None)


def require(request: Request, capability: str = "view"):
    """The session if it holds ``capability``, else a 401 or 403 that says which one was needed."""
    current = session(request)
    if current is None:
        if capability == "view" and config(request).allow_anonymous_browse:
            return None
        raise HTTPException(status_code=401, detail="not signed in")
    if not auth.can(current.role, capability):
        raise HTTPException(status_code=403, detail="not allowed")
    return current


def project_or_404(request: Request, slug: str) -> dict:
    """The project for a slug, or a 404 that names the slug."""
    found = projects.project(store(request), slug)
    if found is None:
        raise HTTPException(status_code=404, detail="project not found")
    return found


def scan_or_404(request: Request, found: dict, name: str) -> dict:
    """The scan row for a name inside a project, or a 404 that names the scan."""
    row = projects.scan(store(request), found["id"], name)
    if row is None:
        raise HTTPException(status_code=404, detail="scan not found")
    return row


# -- identity -------------------------------------------------------------

@router.get("/me")
async def me(request: Request):
    """Who the caller is, what they may do, and the CSRF token to send with writes."""
    current = session(request)
    if current is None:
        return {"authenticated": False}
    return {
        "authenticated": True,
        "name": current.name,
        "role": current.role,
        "csrf": current.csrf,
        "capabilities": sorted(auth.CAPABILITIES.get(current.role, set())),
    }


@router.post("/login")
async def login(request: Request, payload: dict = Body(...)):
    """Sign in with a name and password; the session cookie is set on the response."""
    name = str(payload.get("name", ""))
    password = str(payload.get("password", ""))
    user_id = auth.authenticate(store(request), name, password)
    ip = client_ip(request)
    if user_id is None:
        store(request).audit("login", None, name, ip, 401)
        raise HTTPException(status_code=401, detail="bad credentials")
    created = auth.create_session(
        store(request), user_id, hours=config(request).session_hours, ip=ip,
        agent=request.headers.get("user-agent"),
    )
    store(request).audit("login", user_id, name, ip, 200)
    response = JSONResponse({"ok": True, "name": created.name, "role": created.role, "csrf": created.csrf})
    response.set_cookie(
        "ubim_sid", created.id, httponly=True, samesite="lax", secure=config(request).secure_cookies,
        max_age=config(request).session_hours * 3600, path="/",
    )
    return response


@router.post("/logout")
async def logout(request: Request):
    """End the session and clear the cookie."""
    current = session(request)
    if current is not None:
        auth.destroy_session(store(request), current.id)
        store(request).audit("logout", current.user_id, "", client_ip(request), 200)
    response = JSONResponse({"ok": True})
    response.delete_cookie("ubim_sid", path="/")
    return response


# -- projects -------------------------------------------------------------

@router.get("/projects")
async def list_projects(request: Request):
    """Every project with its scan count and position, for the home page."""
    require(request, "view")
    rows = store(request).query(
        "SELECT p.*, (SELECT COUNT(*) FROM scans s WHERE s.project_id = p.id) AS scans FROM projects p ORDER BY p.name"
    )
    return {
        "projects": [
            {
                "slug": row["slug"], "name": row["name"], "revision": row["revision"],
                "status": row["status"], "scans": row["scans"], "updated": row["updated"],
            }
            for row in rows
        ]
    }


@router.post("/projects")
async def add_project(request: Request, payload: dict = Body(...)):
    """Register a folder as a project; scans are discovered from the folder, not supplied by the caller."""
    require(request, "manage_projects")
    raw = str(payload.get("path", "")).strip()
    if not raw:
        raise HTTPException(status_code=400, detail="path is required")
    path = Path(raw).expanduser()
    if not path.is_dir():
        raise HTTPException(status_code=400, detail=f"{raw} is not a directory")
    try:
        created = projects.register(store(request), path, name=payload.get("name") or None)
    except projects.ProjectError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    store(request).audit("project.add", session(request).user_id, created["slug"], client_ip(request), 201)

    # Scans usually record the scanner's own GPS fix. Adopting it beats leaving the project at
    # no position at all, and the label keeps it clear that this is the scanner's receiver
    # talking, not a surveyed coordinate.
    connection = store(request).connect()
    for row in projects.scans_for(store(request), created["id"]):
        fix = gps.read(row["path"])
        if fix is None:
            continue
        label = f"scan GPS ({row['name']})"
        connection.execute(
            "UPDATE projects SET lat = ?, lon = ?, location_source = ?, updated = ? WHERE id = ?",
            (fix["lat"], fix["lon"], label, time.time(), created["id"]),
        )
        connection.commit()
        created.update({"lat": fix["lat"], "lon": fix["lon"], "locationSource": label})
        store(request).audit("project.location.gps", session(request).user_id,
                             {"scan": row["name"], **fix}, client_ip(request), 200)
        break
    return JSONResponse(created, status_code=201)


@router.get("/p/{slug}")
async def get_project(request: Request, slug: str):
    """One project with its scans, drawings, layers, frame, position and declared CRS."""
    require(request, "view")
    found = project_or_404(request, slug)
    rows = projects.scans_for(store(request), found["id"])
    for entry in rows:
        matrix = registration.parse(entry.get("pose"))
        entry["registered"] = matrix is not None
        entry["position"] = [matrix[0][3], matrix[1][3], matrix[2][3]] if matrix else None
        entry["pose"] = registration.dump(matrix) if matrix else None
    return {
        "slug": found["slug"],
        "name": found["name"],
        "revision": found["revision"],
        "scans": [
            {
                "name": row["name"], "kind": row["kind"], "size": row["size"],
                "registered": row["registered"], "position": row["position"],
                "images": sorted(row["images"].keys()),
                "products": products_api.summary(Path(row["path"]), config(request)),
            }
            for row in rows
        ],
        "meta": json.loads(found["meta"] or "{}"),
        "location": {
            "lat": found.get("lat"),
            "lon": found.get("lon"),
            "source": found.get("location_source"),
            "placed": found.get("lat") is not None and found.get("lon") is not None,
        },
        # Declared, not derived: no FARO format states a CRS, so this is a note the project
        # carries, and every consumer says "declared" rather than treating it as measured.
        "crs": found.get("crs"),
    }


def disk_state(cfg) -> dict:
    """Free space under the data directory, and the guard a build must leave behind."""
    try:
        free = shutil.disk_usage(cfg.data_dir).free / (1 << 20)
    except OSError:
        return {"freeMiB": None, "guardMiB": round(cfg.disk_guard_gb * 1024, 1)}
    guard = cfg.disk_guard_gb * 1024
    return {"freeMiB": round(free, 1), "guardMiB": round(guard, 1), "low": free < guard}


@router.get("/p/{slug}/s/{name}/meta")
async def scan_meta(request: Request, slug: str, name: str):
    """One scan's geometry, panorama roles, product state, and what a build would need in memory and disk."""
    require(request, "view")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    path = Path(row["path"])
    meta = {
        "project": found["slug"],
        "scan": row["name"],
        "kind": row["kind"],
        "size": row["size"],
        "mtime": row["mtime"],
        "mapping": products_api.mapping(),
        "accuracy": ACCURACY,
        "images": {k: f"/api/p/{found['slug']}/s/{row['name']}/pano/{k}" for k in sorted(row["images"])},
        "products": products_api.summary(path, config(request)),
        # What a build of each kind would need, so the panel can say so before it is pressed.
        "memory": {
            **products_api.estimate_mib(path, ["intensity", "depth", "photo", "plan"]),
            "capMiB": config(request).max_build_mb,
            # The guard that stops a build when the disk is nearly full is only useful if the
            # person pressing the button can see it coming (S6).
            **disk_state(config(request)),
        },
    }
    if row["kind"] == "fls":
        try:
            with products_api.open_scan(path) as scan:
                header = scan.header
                meta["geometry"] = {
                    "rows": header.rows,
                    "cols": header.cols,
                    "elevationTopDeg": header.elevation_deg(0.0),
                    "elevationBottomDeg": header.elevation_deg(header.rows - 1.0),
                    "azimuthFirstDeg": float(scan.azimuths_deg[0]) if scan.azimuths_deg is not None else None,
                    "azimuthLastDeg": float(scan.azimuths_deg[-1]) if scan.azimuths_deg is not None else None,
                    "hasAzimuthTable": scan.azimuths is not None,
                }
        except Exception as exc:  # noqa: BLE001 - a broken scan must not break the page
            meta["geometryError"] = str(exc)
    return meta


@router.post("/p/{slug}/s/{name}/pose")
async def set_pose(request: Request, slug: str, name: str, payload: dict = Body(...)):
    """Record a scan's transform into the project frame.

    Either a full 4x4 matrix (``{"matrix": [[...], ...]}``) or a position and heading
    (``{"x": .., "y": .., "z": .., "yawDeg": ..}``). Sending an empty body clears it, which
    puts the scan back to "position not registered".
    """
    current = require(request, "edit_layers")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    if payload.get("matrix") or payload.get("pose"):
        matrix = registration.parse(payload.get("matrix") or payload.get("pose"))
        if matrix is None:
            raise HTTPException(status_code=400, detail="matrix must be 16 numbers")
    elif any(key in payload for key in ("x", "y", "z", "yawDeg", "yaw")):
        try:
            matrix = registration.pose_matrix(
                float(payload.get("x", 0.0)),
                float(payload.get("y", 0.0)),
                float(payload.get("z", 0.0)),
                float(payload.get("yawDeg", payload.get("yaw", 0.0))),
            )
        except (TypeError, ValueError) as exc:
            raise HTTPException(status_code=400, detail="x, y, z and yawDeg must be numbers") from exc
    else:
        matrix = None
    store(request).execute(
        "UPDATE scans SET pose = ? WHERE id = ?",
        (json.dumps(registration.dump(matrix)) if matrix else "[]", row["id"]),
    )
    store(request).audit("scan.pose", current.user_id, f"{found['slug']}/{row['name']}", client_ip(request))
    return {
        "scan": row["name"],
        "registered": matrix is not None,
        "position": [matrix[0][3], matrix[1][3], matrix[2][3]] if matrix else None,
        "pose": registration.dump(matrix) if matrix else None,
    }


# -- panoramic imagery ----------------------------------------------------

@router.get("/p/{slug}/s/{name}/pano/{role}")
async def pano_image(request: Request, slug: str, name: str, role: str, max_size: int = 4096):
    """The panorama image for one role, optionally scaled, straight from the source file's stored JPEG."""
    require(request, "view")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    source = projects.image_for(row, preferred=role)
    if source is None:
        # No WebShare imagery for this scan (usual for a .f3s project): stitch the colour
        # product instead of returning nothing.
        fallback = products_api.pano_fallback(Path(row["path"]), config(request), max(1024, min(8190, int(max_size))))
        if fallback is None:
            raise HTTPException(status_code=404, detail="no image for this scan")
        return FileResponse(fallback, media_type="image/jpeg", headers={"Cache-Control": "private, max-age=300", "X-Pano-Source": "colour-luma"})
    max_size = max(1024, min(8190, int(max_size)))
    cached = tiles.panorama_cache(source, config(request), max_size)
    return FileResponse(cached, media_type="image/jpeg", headers={"Cache-Control": "private, max-age=86400"})


@router.get("/p/{slug}/s/{name}/thumb")
async def thumbnail(request: Request, slug: str, name: str, size: int = 512):
    """A small square preview of a scan, cached beside the scan's products."""
    require(request, "view")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    source = projects.image_for(row, preferred="thumbnail")
    if source is None:
        source = projects.image_for(row, preferred="grey_hd")
    if source is None:
        # A scan with no FARO imagery (an .f3s project) still has its own colour: use it,
        # and say so in a header rather than pretending a WebShare thumbnail exists.
        fallback = products_api.pano_fallback(Path(row["path"]), config(request), max(64, min(1024, size)))
        if fallback is None:
            raise HTTPException(status_code=404, detail="no image for this scan")
        return FileResponse(
            fallback,
            media_type="image/jpeg",
            headers={"Cache-Control": "private, max-age=3600", "X-Thumb-Source": "colour-luma"},
        )
    path = tiles.thumbnail_cache(source, config(request), max(64, min(1024, size)))
    return FileResponse(path, media_type="image/jpeg", headers={"Cache-Control": "private, max-age=86400"})


# -- products -------------------------------------------------------------

@router.get("/p/{slug}/s/{name}/products")
async def product_state(request: Request, slug: str, name: str):
    """Whether each product exists, when it was built, and whether it still matches the scan."""
    require(request, "view")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    return products_api.summary(Path(row["path"]), config(request))


@router.post("/p/{slug}/s/{name}/process")
async def process(request: Request, slug: str, name: str, payload: dict = Body(default={})):
    """Queue a build for the kinds asked for, refusing before it starts when memory or disk cannot take it."""
    require(request, "manage_projects")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    kinds = payload.get("kinds") or ["intensity"]
    # Spec C4: refuse a build that cannot fit instead of queueing a job that dies of it. The
    # estimate comes from the header, so the answer is immediate and names both figures.
    estimate = products_api.estimate_mib(Path(row["path"]), kinds)
    limit = config(request).max_build_mb
    if estimate["totalMiB"] is not None and estimate["totalMiB"] > limit:
        raise HTTPException(
            status_code=409,
            detail=(
                f"{estimate['totalMiB']:.0f} MiB needed for {', '.join(kinds)}, the cap is {limit} MiB "
                f"(UBIM_MAX_BUILD_MB); build one product at a time or raise the cap"
            ),
        )
    job = jobs.start(store(request), config(request), Path(row["path"]), kinds)
    store(request).audit("process", session(request).user_id, {"scan": row["name"], "kinds": kinds}, client_ip(request), 202)
    return JSONResponse(job, status_code=202)


@router.get("/jobs/{job_id}")
async def job_state(request: Request, job_id: str):
    """A job's progress: stage, counts, and the result when it finished."""
    require(request, "view")
    job = jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="job not found")
    return job


@router.get("/p/{slug}/s/{name}/intensity/meta")
async def intensity_meta(request: Request, slug: str, name: str):
    """The intensity product's manifest, or a 404 before it is built."""
    require(request, "view")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    meta = products_api.intensity_meta(Path(row["path"]), config(request))
    if meta is None:
        raise HTTPException(status_code=409, detail="intensity product not built")
    return meta


@router.get("/p/{slug}/s/{name}/intensity/{ramp}/{level}/{col}/{row}.png")
async def intensity_tile(request: Request, slug: str, name: str, ramp: str, level: int, col: int, row: int):
    """One intensity tile, as a PNG, from the requested ramp and level."""
    require(request, "view")
    found = project_or_404(request, slug)
    scan_row = scan_or_404(request, found, name)
    if ramp not in ("grey", "rainbow"):
        raise HTTPException(status_code=404, detail="unknown ramp")
    path = products_api.intensity_tile(Path(scan_row["path"]), config(request), ramp, level, col, row)
    if path is None:
        raise HTTPException(status_code=404, detail="no such tile")
    return FileResponse(path, media_type="image/png", headers={"Cache-Control": "private, max-age=3600"})


@router.get("/p/{slug}/s/{name}/photo/meta")
async def photo_meta(request: Request, slug: str, name: str):
    """The photograph product's manifest."""
    require(request, "view")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    meta = products_api.photo_meta(Path(row["path"]), config(request))
    if meta is None:
        raise HTTPException(status_code=409, detail="photo product not built")
    return meta


@router.get("/p/{slug}/s/{name}/photo/{level}/{col}/{row}.png")
async def photo_tile(request: Request, slug: str, name: str, level: int, col: int, row: int):
    """One tile of the photograph pyramid."""
    require(request, "view")
    found = project_or_404(request, slug)
    scan_row = scan_or_404(request, found, name)
    path = products_api.photo_tile(Path(scan_row["path"]), config(request), level, col, row)
    if path is None:
        raise HTTPException(status_code=404, detail="no such tile")
    return FileResponse(path, media_type="image/png", headers={"Cache-Control": "private, max-age=3600"})


@router.get("/p/{slug}/s/{name}/depth/meta")
async def depth_meta(request: Request, slug: str, name: str):
    """The depth product's manifest: bounds, ranges and the ramp it was written with."""
    require(request, "view")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    meta = products_api.depth_meta(Path(row["path"]), config(request))
    if meta is None:
        raise HTTPException(status_code=409, detail="depth product not built")
    return meta


@router.get("/p/{slug}/s/{name}/depth/{level}/{col}/{row}.png")
async def depth_tile(request: Request, slug: str, name: str, level: int, col: int, row: int):
    """One tile of the depth pyramid."""
    require(request, "view")
    found = project_or_404(request, slug)
    scan_row = scan_or_404(request, found, name)
    path = products_api.depth_tile(Path(scan_row["path"]), config(request), level, col, row)
    if path is None:
        raise HTTPException(status_code=404, detail="no such tile")
    return FileResponse(path, media_type="image/png", headers={"Cache-Control": "private, max-age=3600"})


@router.get("/p/{slug}/s/{name}/plan/meta")
async def plan_meta_route(request: Request, slug: str, name: str):
    """The plan product's manifest, including the placement it was drawn with."""
    require(request, "view")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    meta = products_api.plan_meta(Path(row["path"]), config(request))
    if meta is None:
        raise HTTPException(status_code=404, detail="no site plan for this scan yet")
    # Place every scan of the project on the plan, but only where a transform makes that
    # meaningful: the plan is drawn in this scan's frame, so another scan needs both its own
    # transform and this one's to be put in the right place.
    here = registration.parse(row["pose"])
    bounds = meta.get("bounds") or {}
    placed = []
    for entry in projects.scans_for(store(request), found["id"]):
        there = registration.parse(entry["pose"])
        item = {"name": entry["name"], "x": 0.0, "y": 0.0, "placed": False}
        if here is not None and there is not None and bounds:
            world = (there[0][3], there[1][3], there[2][3])
            local = registration.local_from_world(world, here)
            span_x = bounds["maxX"] - bounds["minX"]
            span_y = bounds["maxY"] - bounds["minY"]
            if span_x > 0 and span_y > 0:
                item["x"] = round((local[0] - bounds["minX"]) / span_x, 6)
                item["y"] = round(1.0 - (local[1] - bounds["minY"]) / span_y, 6)
                item["placed"] = True
        placed.append(item)
    meta["scans"] = placed
    meta["frame"] = "project" if here is not None else "scan"
    return meta


@router.get("/p/{slug}/s/{name}/plan.png")
async def plan_image_route(request: Request, slug: str, name: str, filled: int = 0, size: int = 0):
    """The plan image, filled or outlined, at the size asked for."""
    require(request, "view")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    if size:
        path = products_api.plan_scaled(Path(row["path"]), config(request), size, bool(filled))
    else:
        path = products_api.plan_image(Path(row["path"]), config(request), filled=bool(filled))
    if path is None:
        raise HTTPException(status_code=404, detail="no site plan for this scan yet")
    return FileResponse(path, media_type="image/png", headers={"Cache-Control": "private, max-age=300"})


@router.get("/p/{slug}/s/{name}/plan/tile/{level}/{col}/{row}.png")
async def plan_tile_route(request: Request, slug: str, name: str, level: int, col: int, row: int):
    """One tile of the plan pyramid."""
    require(request, "view")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    path = products_api.plan_tile(Path(row["path"]), config(request), level, col, row)
    if path is None:
        raise HTTPException(status_code=404, detail="no such plan tile")
    return FileResponse(path, media_type="image/png", headers={"Cache-Control": "private, max-age=300"})


@router.post("/p/{slug}/s/{name}/pick")
async def pick(request: Request, slug: str, name: str, payload: dict = Body(...)):
    """Distance and height at an azimuth/elevation, used for measuring on the panorama."""
    require(request, "view")
    found = project_or_404(request, slug)
    row = scan_or_404(request, found, name)
    azimuth = float(payload.get("az", 0.0))
    elevation = float(payload.get("el", 0.0))
    snap = bool(payload.get("snap", True))
    hit = products_api.pick(Path(row["path"]), config(request), azimuth, elevation, snap=snap)
    if hit is None:
        # Either the product is absent or this direction has no return. Answer 200 with a null
        # range in the second case so a hole in the scan is not an error in the console; the
        # caller can tell the two apart by whether ``metres`` is null.
        if not products_api.depth_ready(Path(row["path"]), config(request)):
            raise HTTPException(status_code=409, detail="depth product not built")
        return {"azimuthDeg": azimuth, "elevationDeg": elevation, "metres": None, "reason": "no-return"}
    return hit


# -- library and cache (spec C1) ------------------------------------------

@router.get("/admin/library")
async def admin_library(request: Request):
    """The catalogue: what is registered, where it lives, and what it costs on disk."""
    require(request, "manage_projects")
    return library.catalogue(store(request), config(request))


@router.post("/admin/library/discover")
async def admin_discover(request: Request, payload: dict = Body(default={})):
    """Walk the library root (or a given folder) and register project folders it does not know."""
    current = require(request, "manage_projects")
    root = payload.get("path")
    result = library.discover(
        store(request), config(request), Path(root) if root else None,
        dry_run=bool(payload.get("dryRun")),
    )
    if "error" in result and result["error"]:
        raise HTTPException(status_code=400, detail=result["error"])
    store(request).audit("library.discover", current.user_id, {"root": result.get("root"),
                         "added": [item.get("slug") or item.get("name") for item in result["added"]]},
                         client_ip(request), 200)
    return result


@router.get("/admin/cache")
async def admin_cache(request: Request):
    """What the products cost per scan, and which of them no longer match their scan."""
    require(request, "manage_projects")
    return library.cache_report(store(request), config(request))


@router.post("/admin/cache/clear")
async def admin_cache_clear(request: Request, payload: dict = Body(default={})):
    """Remove product directories. Scans are never touched, and every product can be rebuilt."""
    current = require(request, "manage_projects")
    try:
        result = library.clear_cache(
            store(request), config(request),
            project=payload.get("project") or None, scan=payload.get("scan") or None,
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    store(request).audit("library.cache.clear", current.user_id,
                         {"project": payload.get("project"), "scan": payload.get("scan"),
                          "freedMiB": result["freedMiB"]}, client_ip(request), 200)
    return result


# -- administration -------------------------------------------------------

@router.get("/admin/users")
async def admin_users(request: Request):
    """Every user, with role, state and when they last signed in."""
    require(request, "manage_users")
    rows = store(request).query("SELECT id, name, email, role, created, disabled FROM users ORDER BY name")
    return {"users": [dict(row) for row in rows]}


@router.post("/admin/users")
async def admin_user_create(request: Request, payload: dict = Body(...)):
    """Create a user; the password is hashed here and never stored as sent."""
    current = require(request, "manage_users")
    try:
        user_id = auth.create_user(
            store(request), str(payload.get("name", "")), str(payload.get("password", "")),
            role=str(payload.get("role", "viewer")), email=payload.get("email"),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    store(request).audit("user.create", current.user_id, payload.get("name"), client_ip(request), 201)
    return JSONResponse({"id": user_id}, status_code=201)


@router.patch("/admin/users/{user_id}")
async def admin_user_update(request: Request, user_id: int, payload: dict = Body(...)):
    """Change a user's role, password or disabled state."""
    current = require(request, "manage_users")
    row = store(request).one("SELECT * FROM users WHERE id = ?", (user_id,))
    if row is None:
        raise HTTPException(status_code=404, detail="user not found")
    if "role" in payload and payload["role"] not in auth.ROLES:
        raise HTTPException(status_code=400, detail="unknown role")
    if "role" in payload:
        store(request).execute("UPDATE users SET role = ? WHERE id = ?", (payload["role"], user_id))
    if "disabled" in payload:
        store(request).execute("UPDATE users SET disabled = ? WHERE id = ?", (1 if payload["disabled"] else 0, user_id))
    if payload.get("password"):
        store(request).execute("UPDATE users SET password_hash = ? WHERE id = ?", (auth.hash_password(payload["password"]), user_id))
    store(request).audit("user.update", current.user_id, {"id": user_id, **payload}, client_ip(request), 200)
    return {"ok": True}


@router.post("/admin/invites")
async def admin_invite_create(request: Request, payload: dict = Body(default={})):
    """Create an invitation code for a role and lifetime."""
    current = require(request, "manage_users")
    role = str(payload.get("role", "viewer"))
    if role not in auth.ROLES:
        raise HTTPException(status_code=400, detail="unknown role")
    code = auth.create_invite(
        store(request), role=role, hours=int(payload.get("hours", config(request).invite_hours)),
        created_by=current.user_id,
    )
    store(request).audit("invite.create", current.user_id, {"code": code, "role": role}, client_ip(request), 201)
    return JSONResponse({"code": code, "role": role}, status_code=201)


@router.get("/admin/invites")
async def admin_invites(request: Request):
    """The invitation codes with their state and who redeemed them."""
    require(request, "manage_users")
    rows = store(request).query(
        "SELECT i.*, u.name AS used_name FROM invites i LEFT JOIN users u ON u.id = i.used_by ORDER BY i.created DESC"
    )
    return {"invites": [dict(row) for row in rows]}


@router.post("/admin/shares")
async def admin_share_create(request: Request, payload: dict = Body(...)):
    """Create a share link for a project, optionally read-only and time-limited."""
    current = require(request, "admin")
    slug = str(payload.get("project", ""))
    found = project_or_404(request, slug)
    token = auth.new_token(18)
    hours = int(payload.get("hours", config(request).share_hours))
    store(request).execute(
        "INSERT INTO shares(token, project_id, role, created, expires, created_by) VALUES(?,?,?,?,?,?)",
        (token, found["id"], "viewer", int(time.time()), int(time.time()) + hours * 3600, current.user_id),
    )
    store(request).audit("share.create", current.user_id, {"project": slug, "hours": hours}, client_ip(request), 201)
    return JSONResponse({"token": token, "project": slug, "hours": hours}, status_code=201)


@router.get("/admin/shares")
async def admin_shares(request: Request):
    """The share links, by project."""
    require(request, "admin")
    rows = store(request).query(
        "SELECT s.token, s.role, s.created, s.expires, p.slug, p.name FROM shares s "
        "JOIN projects p ON p.id = s.project_id ORDER BY s.created DESC"
    )
    return {"shares": [dict(row) for row in rows]}


@router.get("/admin/audit")
async def admin_audit(request: Request, limit: int = 100, offset: int = 0):
    """The audit log, newest first, paged."""
    require(request, "admin")
    limit = max(1, min(500, int(limit)))
    offset = max(0, int(offset))
    rows = store(request).query(
        "SELECT a.*, u.name FROM audit a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT ? OFFSET ?",
        (limit, offset),
    )
    total = store(request).scalar("SELECT COUNT(*) FROM audit")
    return {"entries": [dict(row) for row in rows], "total": total}


@router.get("/admin/system")
async def admin_system(request: Request):
    """Version, uptime, paths, disk, counts and the allow list, for the System tab."""
    require(request, "admin")
    import shutil

    usage = shutil.disk_usage(config(request).data_dir)
    return {
        "version": config(request).app_version,
        "uptimeSeconds": int(time.time() - request.app.state.started),
        "dataDir": str(config(request).data_dir),
        "disk": {"total": usage.total, "free": usage.free, "used": usage.used},
        "guardBytes": int(config(request).disk_guard_gb * (1 << 30)),
        "projects": store(request).scalar("SELECT COUNT(*) FROM projects"),
        "scans": store(request).scalar("SELECT COUNT(*) FROM scans"),
        "sessions": store(request).scalar("SELECT COUNT(*) FROM sessions"),
        "allow": [str(n) for n in config(request).allow_networks] or ["everyone"],
    }


@router.post("/p/{slug}/view")
async def save_view(slug: str, request: Request):
    """Store the picture the viewer sent as this project's picture.

    The body is a PNG the browser rendered, so this route trusts it no further than its
    signature and size: anything else is rejected rather than written to disk.
    """
    require(request, "edit_layers")
    found = project_or_404(request, slug)
    data = await request.body()
    if not data:
        raise HTTPException(status_code=400, detail="empty image")
    if len(data) > 8 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="image larger than 8 MB")
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise HTTPException(status_code=415, detail="expected a PNG")
    try:
        with Image.open(io.BytesIO(data)) as probe:
            width, height = probe.size
    except Exception:
        raise HTTPException(status_code=415, detail="unreadable image")
    folder = Path(config(request).data_dir) / "views"
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"{found['slug']}.png"
    tmp = target.with_suffix(".png.tmp")
    tmp.write_bytes(data)
    tmp.replace(target)
    store(request).audit("project.view", None, found["slug"], client_ip(request), 200)
    return {"slug": found["slug"], "width": width, "height": height, "bytes": len(data)}


@router.get("/p/{slug}/view")
async def get_view(slug: str, request: Request):
    """The saved picture, or 404 when the project has none yet."""
    require(request, "view")
    found = project_or_404(request, slug)
    path = Path(config(request).data_dir) / "views" / f"{found['slug']}.png"
    if not path.exists():
        raise HTTPException(status_code=404, detail="no saved view")
    return FileResponse(path, media_type="image/png", headers={"Cache-Control": "no-store"})


@router.get("/p/{slug}/s/{name}/neighbours")
async def neighbours(request: Request, slug: str, name: str):
    """The project's other scans as seen from one scan: which way, how far, or not apart.

    Two scans whose pose is the identity share their origin, so no direction can be given;
    those are reported as ``coincident`` instead of being drawn at an angle nobody measured.
    """
    require(request, "view")
    found = project_or_404(request, slug)
    store_ = request.app.state.store
    row = projects.scan(store_, found["id"], name)
    if row is None:
        raise HTTPException(status_code=404, detail="scan not found")
    home = registration.parse(row.get("pose"))
    out = []
    for other in projects.scans_for(store_, found["id"]):
        if other["name"] == name:
            continue
        pose = registration.parse(other.get("pose"))
        origin = registration.apply(pose, (0.0, 0.0, 0.0)) if pose else (0.0, 0.0, 0.0)
        local = registration.local_from_world(origin, home) if home else origin
        azimuth, elevation, radius = registration.azimuth_elevation(local)
        apart = radius > 1e-3
        out.append({
            "scan": other["name"],
            "kind": other["kind"],
            "distance": round(radius, 3),
            "coincident": not apart,
            "az": round(azimuth, 3) if apart else None,
            "el": round(elevation, 3) if apart else None,
            "posed": pose is not None,
        })
    return {"scan": name, "units": "degrees", "neighbours": out}

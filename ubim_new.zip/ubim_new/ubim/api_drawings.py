"""Imported CAD drawings: they belong to the project, not to one scan.

A drawing is stored in the project frame (metres, Z up) because that is what a CAD file means.
To show it over a scan it is expressed in that scan's frame, which needs the scan's
registration; with no registration the drawing is read as being in the scan's own frame and
the response says so (``assumedFrame``). Nothing is draped here: a flat drawing is drawn flat
and the height it should sit at is a question for the viewer, not for the importer.
"""

from __future__ import annotations

import json
import math
import time

from fastapi import APIRouter, Body, HTTPException, Request

from . import dwg, dxf, projects, registration
from .api import project_or_404, require
from .web import client_ip

router = APIRouter()

MAX_TEXT = 20 * 1024 * 1024


def _store(request: Request):
    """The store for this application instance."""
    return request.app.state.store


def _project(request: Request, slug: str) -> dict:
    """The project for a slug, or a 404."""
    return project_or_404(request, slug)


def rows_for(store, project_id: int) -> list[dict]:
    """The project's live drawings, newest first; deleted ones are left out."""
    return store.query(
        "SELECT * FROM drawings WHERE project_id = ? AND deleted_at IS NULL ORDER BY id",
        (project_id,),
    )


def frame_for(store, project_id: int) -> dict | None:
    """The project's declared placement of its drawings, if one has been recorded."""
    row = store.one("SELECT * FROM drawing_frames WHERE project_id = ?", (project_id,))
    if row is None:
        return None
    return {
        "originX": row["origin_x"],
        "originY": row["origin_y"],
        "originZ": row["origin_z"],
        "rotationDeg": row["rotation"],
        "scale": row["scale"],
    }


def place(vertex, frame: dict | None) -> tuple[float, float, float]:
    """A drawing vertex in the scan's frame, given the project's declared mapping.

    Without a mapping the vertex is taken as already being in the scan frame, which is what
    a drawing exported from this viewer is. With one, the drawing's own coordinates are
    reduced to the declared origin, scaled, and rotated into the scan's forward direction.
    """
    x, y, z = (float(vertex[0]), float(vertex[1]), float(vertex[2]) if len(vertex) > 2 else 0.0)
    if frame is None:
        return x, y, z
    scale = float(frame["scale"])
    u = (x - float(frame["originX"])) * scale
    v = (y - float(frame["originY"])) * scale
    w = (z - float(frame["originZ"])) * scale
    angle = math.radians(float(frame["rotationDeg"]))
    return (u * math.cos(angle) - v * math.sin(angle), u * math.sin(angle) + v * math.cos(angle), w)


def as_features(store, found: dict, scan_row: dict, raise_m: float = 0.0) -> tuple[list[dict], int]:
    """Drawing shapes as measurement-shaped features for one scan, plus how many were dropped.

    A shape that lies at the scan's own position has no direction to show, so it is dropped
    and counted rather than drawn at a made-up angle. ``raise_m`` lifts the drawing before it
    is projected: a site plan is flat and has to be put at the height it describes, and that
    height is the caller's decision, not something the file states.
    """
    pose = registration.parse(scan_row.get("pose"))
    frame = frame_for(store, found["id"])
    out: list[dict] = []
    dropped = 0
    for row in rows_for(store, found["id"]):
        try:
            geometry = json.loads(row["geom"])
        except (TypeError, ValueError):
            continue
        for index, shape in enumerate(geometry.get("shapes") or []):
            points = []
            usable = True
            for vertex in shape.get("points") or []:
                if len(vertex) < 2:
                    usable = False
                    break
                local = place(vertex, frame)
                if pose:
                    local = registration.local_from_world(local, pose)
                if raise_m:
                    local = (local[0], local[1], local[2] + raise_m)
                azimuth, elevation, radius = registration.azimuth_elevation(local)
                if radius <= 1e-6:
                    usable = False
                    break
                points.append({"az": round(azimuth, 4), "el": round(elevation, 4), "r": round(radius, 4)})
            minimum = 2 if shape.get("kind") in ("line", "polyline") else 1
            if not usable or len(points) < minimum:
                dropped += 1
                continue
            out.append({
                "id": -(row["id"] * 100000 + index),
                "layer_id": row["id"],
                "kind": "line" if shape["kind"] in ("line", "polyline") else "point",
                "label": shape.get("label") or None,
                "points": points,
                "source": "dxf",
                "colour": shape.get("colour"),
                "widthMm": shape.get("widthMm"),
                "drawing": row["name"],
                "drawing_id": row["id"],
                "from_other_scan": False,
                "locked": True,
            })
    return out, dropped


@router.get("/p/{slug}/drawing-frame")
async def read_drawing_frame(request: Request, slug: str):
    """How the project's drawings are placed in the scan frame: origin, rotation and scale."""
    require(request, "view")
    found = _project(request, slug)
    frame = frame_for(_store(request), found["id"])
    return {"frame": frame, "placed": frame is not None, "units": "metres", "rotation": "degrees"}


@router.put("/p/{slug}/drawing-frame")
async def write_drawing_frame(request: Request, slug: str, payload: dict = Body(...)):
    """Declare how this project's drawings line up with its scans, or clear the declaration.

    Nothing in a DXF says where it sits in the world, so this is a declaration rather than a
    reading: without it the drawing is taken as already being in the scan's frame.
    """
    current = require(request, "edit_layers")
    found = _project(request, slug)
    store = _store(request)
    if not payload:
        store.execute("DELETE FROM drawing_frames WHERE project_id = ?", (found["id"],))
        store.audit("drawing.frame", current.user_id, {"cleared": True}, client_ip(request), 200)
        return {"frame": None, "placed": False}
    scale = float(payload.get("scale", 1.0))
    if not (scale > 0) or scale > 1e6:
        raise HTTPException(status_code=400, detail="scale must be greater than zero")
    frame = {
        "originX": float(payload.get("originX", 0.0)),
        "originY": float(payload.get("originY", 0.0)),
        "originZ": float(payload.get("originZ", 0.0)),
        "rotationDeg": float(payload.get("rotationDeg", 0.0)),
        "scale": scale,
    }
    if any(abs(value) > 1e9 for value in frame.values()):
        raise HTTPException(status_code=400, detail="a placement value is out of range")
    store.execute(
        """INSERT INTO drawing_frames(project_id, origin_x, origin_y, origin_z, rotation, scale, created, created_by)
           VALUES(?,?,?,?,?,?,?,?)
           ON CONFLICT(project_id) DO UPDATE SET origin_x = excluded.origin_x, origin_y = excluded.origin_y,
             origin_z = excluded.origin_z, rotation = excluded.rotation, scale = excluded.scale""",
        (found["id"], frame["originX"], frame["originY"], frame["originZ"], frame["rotationDeg"], scale, int(time.time()), current.user_id),
    )
    store.audit("drawing.frame", current.user_id, frame, client_ip(request), 200)
    return {"frame": frame, "placed": True}


@router.post("/p/{slug}/drawings")
async def import_drawing(request: Request, slug: str, payload: dict = Body(...)):
    """Import a DXF sent as text, or a DWG sent as base64 that a converter turns into DXF.

    Parsing happens here, not in the browser. A DWG is binary and has no reader in the standard
    library, so it is converted first (spec D2) and refused with the fix named if no converter is
    installed.
    """
    current = require(request, "edit_layers")
    found = _project(request, slug)
    text = payload.get("text") or ""
    encoded = payload.get("file")
    if not text and encoded:
        import base64
        import binascii

        try:
            raw = base64.b64decode(str(encoded), validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(status_code=400, detail="file is not valid base64") from exc
        if dwg.looks_like_dwg(raw):
            try:
                text = dwg.to_dxf(raw)
            except dwg.NoConverter as exc:
                raise HTTPException(status_code=415, detail=str(exc)) from exc
            except dwg.ConversionFailed as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
        else:
            text = raw.decode("utf-8", errors="replace")
    if not isinstance(text, str) or not text.strip():
        raise HTTPException(status_code=400, detail="text is required (the DXF file contents)")
    if len(text) > MAX_TEXT:
        raise HTTPException(status_code=413, detail="drawing is larger than 20 MB")
    name = str(payload.get("name") or "drawing.dxf").strip()[:120]
    parsed = dxf.read(text)
    if not parsed.shapes:
        raise HTTPException(
            status_code=400,
            detail=f"no usable entities found ({parsed.skipped} skipped)",
        )
    geometry = {
        "shapes": [
            {
                "kind": shape.kind,
                "points": [list(point) for point in shape.points],
                "label": shape.label,
                # Colour and lineweight travel with the shape: a drawing that comes in red and
                # thick should not arrive as a uniform blue hairline.
                "colour": shape.colour,
                "widthMm": shape.width_mm,
            }
            for shape in parsed.shapes
        ],
    }
    meta = {
        "units": parsed.units,
        "unitCode": parsed.unit_code,
        "flat": parsed.flat,
        "skipped": parsed.skipped,
        "closed": parsed.closed,
        "extent": dxf.extent(parsed),
    }
    store = _store(request)
    now = int(time.time())
    store.execute(
        "INSERT INTO drawings(project_id, name, geom, meta, created, created_by) VALUES(?,?,?,?,?,?)",
        (found["id"], name, json.dumps(geometry), json.dumps(meta), now, current.user_id),
    )
    drawing_id = int(store.scalar("SELECT last_insert_rowid()"))
    store.audit("drawing.import", current.user_id, {"drawing": name, "shapes": len(parsed.shapes)}, (request.client.host if request.client else None), 201)
    warning = None
    if parsed.flat:
        warning = "the drawing has no height (every vertex is at Z=0); it is shown at the scan's own level"
    return JSONResponseCompat({
        "id": drawing_id,
        "name": name,
        "shapes": len(parsed.shapes),
        "skipped": parsed.skipped,
        "units": parsed.units,
        "flat": parsed.flat,
        "extent": meta["extent"],
        "warning": warning,
    }, 201)


@router.get("/p/{slug}/s/{name}/drawings")
async def drawings_for_scan(request: Request, slug: str, name: str, height: float = 0.0):
    """The project's drawings expressed in one scan's frame, ready to be drawn over it."""
    require(request, "view")
    found = _project(request, slug)
    row = projects.scan(_store(request), found["id"], name)
    if row is None:
        raise HTTPException(status_code=404, detail="scan not found")
    if not -1000.0 <= height <= 1000.0:
        raise HTTPException(status_code=400, detail="height must be between -1000 and 1000 metres")
    store = _store(request)
    features, dropped = as_features(store, found, row, height)
    frame = frame_for(store, found["id"])
    return {
        "scan": name,
        "height": height,
        "units": "degrees",
        # assumedFrame is about the scan: with no pose of its own it is its own origin.
        # drawingPlaced is about the drawing: whether a placement was declared for it.
        "assumedFrame": registration.parse(row.get("pose")) is None,
        "drawingPlaced": frame is not None,
        "drawingFrame": frame,
        "dropped": dropped,
        "features": features,
    }


@router.get("/p/{slug}/drawings")
async def list_drawings(request: Request, slug: str):
    """The project's drawings with their shape counts and metadata, without the geometry."""
    require(request, "view")
    found = _project(request, slug)
    rows = rows_for(_store(request), found["id"])
    out = []
    for row in rows:
        try:
            meta = json.loads(row["meta"])
        except (TypeError, ValueError):
            meta = {}
        out.append({
            "id": row["id"], "name": row["name"], "created": row["created"],
            "shapes": len(json.loads(row["geom"]).get("shapes") or []), **meta,
        })
    return {"drawings": out}


@router.delete("/p/{slug}/drawings/{drawing_id}")
async def delete_drawing(request: Request, slug: str, drawing_id: int):
    """Soft-delete a drawing, so its geometry can be recovered from the row."""
    current = require(request, "edit_layers")
    found = _project(request, slug)
    store = _store(request)
    row = store.one("SELECT id FROM drawings WHERE id = ? AND project_id = ? AND deleted_at IS NULL", (drawing_id, found["id"]))
    if row is None:
        raise HTTPException(status_code=404, detail="drawing not found")
    store.execute(
        "UPDATE drawings SET deleted_at = ?, deleted_by = ? WHERE id = ?",
        (int(time.time()), current.user_id, drawing_id),
    )
    store.audit("drawing.delete", current.user_id, {"drawing": drawing_id}, (request.client.host if request.client else None))
    return {"ok": True}


def JSONResponseCompat(body, status_code: int = 200):
    """A JSON response with an explicit status code, used for a 201 with a body."""
    from fastapi.responses import JSONResponse

    return JSONResponse(body, status_code=status_code)

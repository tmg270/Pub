"""Reading a WebShare project folder, and building a fixture that looks like one.

The on-disk layout is the one the Java app reads (``docs``/pack 01-context.md):

    <project>/Revisions/<rev>/Scans/<name>.fls            older projects
    <project>/Revisions/<rev>/_3Scans/<name>.f3s         2026 projects
    <project>/Revisions/<rev>/WebShareData/Images/<id>{,_hd,_grey,_grey_hd,_thumbnail,...}.jpg

Nothing here copies the scan contents by default: a project is registered by path, and scans
are only ever opened read-only. When the tree and the data directory are on the same
filesystem a fixture uses hard links, so making one costs no space.
"""

from __future__ import annotations

import json
import os
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from .config import BESIDE, Config
from . import gps
from .store import Store, now

SCAN_SUFFIXES = (".fls", ".f3s")
#: Image variants in the order WebShare writes them. The empty suffix is the plain colour
#: panorama; the rest are the HD, grey and thumbnail variants.
IMAGE_VARIANTS = ("", "_hd", "_grey", "_grey_hd", "_thumbnail", "_grey_thumbnail", "_depth", "_depth_hd")
REVISION_DIR = re.compile(r"^Revisions?/(\d+)$", re.IGNORECASE)


class ProjectError(Exception):
    """A project folder does not look usable."""


@dataclass
class DiscoveredScan:
    """One scan found on disk: its path, size, suffix and the revision folder it came from."""
    name: str
    path: Path
    kind: str
    size: int
    mtime: int
    images: dict = field(default_factory=dict)


@dataclass
class Discovery:
    """What a folder walk found: usable scans, skipped files and the reasons."""
    root: Path
    revision: str | None = None
    scans: list[DiscoveredScan] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def usable(self) -> bool:
        """Whether the folder yielded any scans, which decides if it can be a project."""
        return bool(self.scans)

    def as_meta(self) -> dict:
        """The discovery result as the API reports it: what was found, what was skipped and why."""
        return {
            "revision": self.revision,
            "scans": [
                {
                    "name": s.name,
                    "file": _rel(s.path, self.root),
                    "kind": s.kind,
                    "size": s.size,
                    "mtime": s.mtime,
                    "images": {k: _rel(v, self.root) for k, v in s.images.items()},
                }
                for s in self.scans
            ],
            "warnings": self.warnings,
        }


def _rel(path: Path, root: Path) -> str:
    """A path relative to the data root when it is inside it, else as given."""
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return str(path)


def _scan_name(path: Path) -> str:
    """The scan's name: its file name without the suffix."""
    return path.stem


def _image_role(filename: str, scan_ids: set[str]) -> tuple[str, str] | None:
    """Split ``<id>_grey_hd.jpg`` into ``(id, "_grey_hd")``; ``None`` if it matches no scan."""
    stem = Path(filename).stem
    for variant in sorted(IMAGE_VARIANTS, key=len, reverse=True):
        if variant and stem.endswith(variant):
            base = stem[: -len(variant)]
            if base in scan_ids:
                return base, variant
    if stem in scan_ids:
        return stem, ""
    return None


def _revision_root(root: Path) -> tuple[Path, str | None]:
    """Find the newest ``Revisions/<n>`` under a project folder, or accept a bare folder."""
    revisions: list[tuple[int, Path]] = []
    revisions_dir = root / "Revisions"
    if not revisions_dir.is_dir():
        revisions_dir = root / "Revision"
    if revisions_dir.is_dir():
        for entry in revisions_dir.iterdir():
            if entry.is_dir() and entry.name.isdigit():
                revisions.append((int(entry.name), entry))
    if revisions:
        newest = max(revisions)[1]
        return newest, newest.name
    return root, None


def discover(root: Path) -> Discovery:
    """Walk a project folder and return what is there, without opening any scan body."""
    root = Path(root).expanduser().resolve()
    if not root.is_dir():
        raise ProjectError(f"{root} is not a directory")
    revision_path, revision = _revision_root(root)
    found = Discovery(root=root, revision=revision)

    scan_paths: list[Path] = []
    for folder in ("Scans", "_3Scans"):
        base = revision_path / folder
        if not base.is_dir():
            continue
        for path in sorted(base.rglob("*")):
            if path.is_file() and path.suffix.lower() in SCAN_SUFFIXES:
                scan_paths.append(path)
    if not scan_paths:
        # A bare folder containing scans (and maybe images) is still usable.
        for path in sorted(root.rglob("*")):
            if path.is_file() and path.suffix.lower() in SCAN_SUFFIXES:
                scan_paths.append(path)

    seen: dict[str, DiscoveredScan] = {}
    for path in scan_paths:
        name = _scan_name(path)
        if name in seen:
            found.warnings.append(f"duplicate scan name {name!r}: keeping {seen[name].path}")
            continue
        stat = path.stat()
        seen[name] = DiscoveredScan(
            name=name, path=path, kind=path.suffix.lower().lstrip("."), size=stat.st_size,
            mtime=int(stat.st_mtime),
        )

    images_dir = revision_path / "WebShareData" / "Images"
    if not images_dir.is_dir():
        images_dir = root / "WebShareData" / "Images"
    scan_ids = set(seen)
    if images_dir.is_dir():
        for path in sorted(images_dir.iterdir()):
            if not path.is_file() or path.suffix.lower() not in (".jpg", ".jpeg", ".png"):
                continue
            match = _image_role(path.name, scan_ids)
            if match is None:
                continue
            name, variant = match
            seen[name].images[variant or "colour"] = path
    elif any(p.suffix.lower() in (".jpg", ".jpeg") for p in root.iterdir() if p.is_file()):
        # Flat folder: attach loose images to the only scan when there is exactly one.
        loose = [p for p in root.iterdir() if p.is_file() and p.suffix.lower() in (".jpg", ".jpeg")]
        if len(seen) == 1:
            only = next(iter(seen.values()))
            for path in loose:
                role = "grey_hd" if "grey" in path.stem.lower() else "colour"
                only.images.setdefault(role, path)
            found.warnings.append("flat folder: loose images attached to the single scan by name")
        else:
            found.warnings.append(f"{len(loose)} loose images and {len(seen)} scans: not linked")

    found.scans = list(seen.values())
    if not found.scans:
        found.warnings.append("no .fls or .f3s files found")
    return found


def slugify(name: str) -> str:
    """A URL-safe slug from a project name."""
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or "project"


def unique_slug(store: Store, name: str) -> str:
    """A slug not already taken, with a numeric suffix when the plain one is."""
    base = slugify(name)
    candidate = base
    suffix = 2
    while store.one("SELECT 1 FROM projects WHERE slug = ?", (candidate,)):
        candidate = f"{base}-{suffix}"
        suffix += 1
    return candidate


def register(store: Store, root: Path, *, name: str | None = None, slug: str | None = None) -> dict:
    """Register a project folder. Scans are referenced, never modified.

    A folder that carries a GPS fix adopts it for the project's position, labelled with the scan
    it came from — the alternative is a project that knows exactly where it is and still shows no
    location until somebody types the numbers in by hand. Only the first three scans are read,
    because each one costs an attribute-block decode.
    """
    found = discover(root)
    if not found.usable:
        raise ProjectError(f"no scans in {found.root}")
    display = name or found.root.name
    slug = slug or unique_slug(store, display)
    meta = found.as_meta()
    lat = lon = source = None
    for scan in found.scans[:3]:
        try:
            fix = gps.read(scan.path)
        except Exception:  # noqa: BLE001 - a broken attribute block must not stop the import
            fix = None
        if fix:
            lat, lon, source = fix["lat"], fix["lon"], f"scan GPS ({scan.name})"
            meta["locationSource"] = source
            break
    project_id = store.execute(
        "INSERT INTO projects(slug, name, path, revision, status, meta, created, updated, lat, lon, location_source) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (slug, display, str(found.root), found.revision, "ready", json.dumps(meta), now(), now(), lat, lon, source),
    )
    for scan in found.scans:
        store.execute(
            "INSERT INTO scans(project_id, name, path, kind, size, mtime, meta, created) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (
                project_id, scan.name, str(scan.path), scan.kind, scan.size, scan.mtime,
                json.dumps({"images": {k: str(v) for k, v in scan.images.items()}}), now(),
            ),
        )
    return {"id": project_id, "slug": slug, "name": display, "path": str(found.root), "meta": meta}


def project(store: Store, slug: str) -> dict | None:
    """The project row for a slug, or None."""
    row = store.one("SELECT * FROM projects WHERE slug = ?", (slug,))
    if row is None:
        return None
    return dict(row)


def scans_for(store: Store, project_id: int) -> list[dict]:
    """The scans of a project, with their cached geometry."""
    rows = store.query("SELECT * FROM scans WHERE project_id = ? ORDER BY name", (project_id,))
    result = []
    for row in rows:
        item = dict(row)
        try:
            item["images"] = json.loads(item["meta"]).get("images", {})
        except (json.JSONDecodeError, TypeError):
            item["images"] = {}
        result.append(item)
    return result


def scan(store: Store, project_id: int, name: str) -> dict | None:
    """The scan row for a name inside a project, or None."""
    row = store.one("SELECT * FROM scans WHERE project_id = ? AND name = ?", (project_id, name))
    if row is None:
        return None
    item = dict(row)
    try:
        item["images"] = json.loads(item["meta"]).get("images", {})
    except (json.JSONDecodeError, TypeError):
        item["images"] = {}
    return item


def image_for(scan_row: dict, preferred: str = "grey_hd") -> Path | None:
    """Which stored panorama to show: the preferred role when present, else the first."""
    images = scan_row.get("images") or {}
    order = [preferred, "grey", "colour", "_hd", "colour_hd", ""]
    for key in order:
        if key in images:
            path = Path(images[key])
            if path.exists():
                return path
    for value in images.values():
        path = Path(value)
        if path.exists():
            return path
    return None


def product_root(scan_path: Path, config: Config) -> Path:
    """Where this scan's products live: beside the scan if that tree is writable."""
    if config.product_placement == BESIDE:
        candidate = scan_path.with_name(scan_path.name + ".ubim")
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            probe = candidate / ".writable"
            probe.write_bytes(b"")
            probe.unlink()
            return candidate
        except OSError:
            pass
    target = config.cache_dir / "products" / str(abs(hash(str(scan_path))) % (10**12)) / scan_path.name
    target.mkdir(parents=True, exist_ok=True)
    return target


def _link_or_copy(source: Path, target: Path) -> None:
    """Make the target point at the source, copying when a hard link is not possible."""
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        return
    try:
        os.link(source, target)
    except OSError:
        shutil.copy2(source, target)


def create_fixture(destination: Path, *, name: str, scans: list[Path], images: dict[str, Path] | None = None) -> Path:
    """Build a minimal WebShare-shaped tree so the viewer can be developed offline.

    It is *not* a substitute for a real project: it has one revision, no metadata.xml and
    links images to scans by filename convention. Everything it invents is recorded in
    ``FIXTURE.json`` inside the tree so nobody mistakes it for real project data.
    """
    destination = Path(destination).expanduser().resolve()
    revision = destination / "Revisions" / "1"
    (revision / "Scans").mkdir(parents=True, exist_ok=True)
    (revision / "WebShareData" / "Images").mkdir(parents=True, exist_ok=True)

    linked = []
    for offset, source in enumerate(scans):
        source = Path(source).resolve()
        if not source.is_file():
            raise ProjectError(f"missing scan {source}")
        scan_id = f"scan{offset:03d}"
        target = revision / "Scans" / f"{source.stem}.{source.suffix.lstrip('.')}"
        _link_or_copy(source, target)
        linked.append({"name": source.stem, "id": scan_id, "file": _rel(target, destination)})
        for role, image in (images or {}).items():
            image = Path(image)
            if not image.is_file():
                raise ProjectError(f"missing image {image}")
            suffix = "" if role in ("colour", "colour_hd") else f"_{role}"
            _link_or_copy(image, revision / "WebShareData" / "Images" / f"{scan_id}{suffix}{image.suffix}")

    manifest = {
        "fixture": True,
        "name": name,
        "created": now(),
        "note": "generated by ubim.projects.create_fixture; not real project data",
        "scans": linked,
        "images": {role: f"WebShareData/Images/scan000{'' if role in ('colour','colour_hd') else '_' + role}{Path(p).suffix}" for role, p in (images or {}).items()},
    }
    (destination / "FIXTURE.json").write_text(json.dumps(manifest, indent=2))
    return destination

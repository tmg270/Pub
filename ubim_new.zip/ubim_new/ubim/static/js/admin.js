// Administration: users, invites, shares, audit and system.
//
// Every mutating call goes through api.js, which attaches the session's CSRF token; the
// server rejects anything without it, so a page left open after a logout cannot write.

import { api, el, me, status, toast } from "./api.js";

const body = document.getElementById("tab-body");
const tabs = [...document.querySelectorAll("[data-tab]")];

let current = "users";

function table(headers, rows) {
  return el("table", {}, [
    el("thead", {}, [el("tr", {}, headers.map((header) => el("th", {}, header)))]),
    el("tbody", {}, rows.length ? rows : [el("tr", {}, [el("td", { colspan: String(headers.length), class: "muted" }, "Nothing here yet.")])]),
  ]);
}

function field(label, input) {
  return el("label", {}, [label, input]);
}

async function showUsers() {
  const { users } = await api("/api/admin/users");
  const create = el("form", {
    class: "stack",
    onsubmit: async (event) => {
      event.preventDefault();
      const name = create.querySelector("[name=name]").value.trim();
      const password = create.querySelector("[name=password]").value;
      const role = create.querySelector("[name=role]").value;
      try {
        await api("/api/admin/users", { method: "POST", body: { name, password, role } });
        toast(`Created ${name}`, "ok");
        refresh();
      } catch (error) { toast(error.message, "err"); }
    },
  }, [
    el("h2", {}, "New user"),
    field("Name", el("input", { name: "name", required: "", autocomplete: "off" })),
    field("Password", el("input", { name: "password", type: "password", required: "", minlength: "10", autocomplete: "new-password" })),
    field("Role", el("select", { name: "role" }, [
      el("option", { value: "viewer" }, "viewer"),
      el("option", { value: "editor" }, "editor"),
      el("option", { value: "admin" }, "admin"),
    ])),
    el("button", { class: "primary", type: "submit" }, "Create user"),
  ]);

  const rows = users.map((user) => el("tr", {}, [
    el("td", {}, user.name),
    el("td", {}, el("select", {
      onchange: async (event) => {
        try { await api(`/api/admin/users/${user.id}`, { method: "PATCH", body: { role: event.target.value } }); toast("role updated", "ok"); }
        catch (error) { toast(error.message, "err"); }
      },
    }, ["viewer", "editor", "admin"].map((role) => el("option", { value: role, selected: role === user.role ? "" : undefined }, role)))),
    el("td", {}, user.email || ""),
    el("td", {}, new Date(user.created * 1000).toLocaleString()),
    el("td", {}, el("button", {
      class: "link",
      onclick: async () => {
        try {
          await api(`/api/admin/users/${user.id}`, { method: "PATCH", body: { disabled: !user.disabled } });
          refresh();
        } catch (error) { toast(error.message, "err"); }
      },
    }, user.disabled ? "enable" : "disable")),
  ]));

  body.replaceChildren(el("div", { style: "display:grid;gap:20px;max-width:760px" }, [
    table(["Name", "Role", "Email", "Created", ""], rows),
    create,
  ]));
}

async function showInvites() {
  const { invites } = await api("/api/admin/invites");
  const roles = el("select", { name: "role" }, [
    el("option", { value: "viewer" }, "viewer"),
    el("option", { value: "editor" }, "editor"),
    el("option", { value: "admin" }, "admin"),
  ]);
  const form = el("form", {
    onsubmit: async (event) => {
      event.preventDefault();
      try {
        const created = await api("/api/admin/invites", { method: "POST", body: { role: roles.value, hours: 72 } });
        toast(`Invite ${created.code}`, "ok");
        refresh();
      } catch (error) { toast(error.message, "err"); }
    },
  }, [roles, el("button", { class: "primary", type: "submit" }, "Create invite")]);

  const rows = invites.map((invite) => el("tr", {}, [
    el("td", {}, el("code", {}, invite.code)),
    el("td", {}, invite.role),
    el("td", {}, new Date(invite.created * 1000).toLocaleDateString()),
    el("td", {}, invite.used_by ? `used by ${invite.used_name || invite.used_by}` : "unused"),
    el("td", {}, invite.used_at ? new Date(invite.used_at * 1000).toLocaleDateString() : new Date(invite.expires * 1000).toLocaleDateString()),
  ]));

  body.replaceChildren(el("div", { style: "display:grid;gap:20px" }, [
    el("h2", {}, "New invite"),
    el("p", { class: "muted small" }, "An invite lets someone set their own password once, then expires."),
    form,
    table(["Code", "Role", "Created", "State", "Expires"], rows),
  ]));
}

async function showShares() {
  const [{ shares }, { projects }] = await Promise.all([api("/api/admin/shares"), api("/api/projects")]);
  const project = el("select", { name: "project" }, projects.map((entry) => el("option", { value: entry.slug }, entry.name)));
  const form = el("form", {
    onsubmit: async (event) => {
      event.preventDefault();
      try {
        const created = await api("/api/admin/shares", { method: "POST", body: { project: project.value, hours: 24 * 7 } });
        toast(`Share ${created.token}`, "ok");
        refresh();
      } catch (error) { toast(error.message, "err"); }
    },
  }, [project, el("button", { class: "primary", type: "submit" }, "Create read-only share")]);

  const rows = shares.map((share) => el("tr", {}, [
    el("td", {}, el("code", {}, share.token)),
    el("td", {}, share.name),
    el("td", {}, new Date(share.created * 1000).toLocaleString()),
    el("td", {}, new Date(share.expires * 1000).toLocaleString()),
  ]));

  body.replaceChildren(el("div", { style: "display:grid;gap:20px" }, [
    el("h2", {}, "Read-only shares"),
    el("p", { class: "muted small" }, "A share gives one project to one link, for a fixed time."),
    form,
    table(["Token", "Project", "Created", "Expires"], rows),
  ]));
}

async function showAudit() {
  const data = await api("/api/admin/audit?limit=200");
  const rows = data.entries.map((entry) => el("tr", {}, [
    el("td", {}, new Date(entry.ts * 1000).toLocaleString()),
    el("td", {}, entry.name || "—"),
    el("td", {}, entry.action),
    el("td", {}, entry.status),
    el("td", { class: "small" }, typeof entry.detail === "string" ? entry.detail.slice(0, 120) : JSON.stringify(entry.detail)?.slice(0, 120) || ""),
    el("td", { class: "small" }, entry.ip || ""),
  ]));
  body.replaceChildren(el("div", { style: "display:grid;gap:12px" }, [
    el("h2", {}, `Audit log (${data.total} entries)`),
    table(["When", "User", "Action", "Status", "Detail", "From"], rows),
  ]));
}

async function showSystem() {
  const info = await api("/api/admin/system");
  const gib = (bytes) => `${(bytes / (1 << 30)).toFixed(1)} GiB`;
  const rows = [
    ["Version", info.version],
    ["Uptime", `${Math.round(info.uptimeSeconds / 60)} min`],
    ["Data directory", info.dataDir],
    ["Disk", `${gib(info.disk.used)} used, ${gib(info.disk.free)} free`],
    ["Disk guard", gib(info.guardBytes)],
    ["Projects", String(info.projects)],
    ["Scans", String(info.scans)],
    ["Sessions", String(info.sessions)],
    ["Allowed networks", info.allow.join(", ")],
  ];
  body.replaceChildren(el("div", { style: "display:grid;gap:8px;max-width:640px" },
    rows.map(([key, value]) => el("div", { class: "row" }, [el("span", {}, key), el("span", {}, value)]))));
}

// == LIBRARY ==
// Discovery is asked for, not watched (spec C1): the button walks the configured root and
// registers folders the catalogue does not know. The cache panel measures what the products
// cost and can clear them; a cleared product is rebuilt from the scan, never lost.
async function showLibrary() {
  const [catalogue, cache] = await Promise.all([api("/api/admin/library"), api("/api/admin/cache")]);
  const projects = el("table", { class: "table" }, [
    el("thead", {}, [el("tr", {}, [el("th", {}, "Project"), el("th", {}, "Folder"), el("th", {}, "Scans"),
      el("th", {}, "Products"), el("th", {}, "State")])]),
    el("tbody", {}, catalogue.projects.map((row) => el("tr", {}, [
      el("td", {}, row.name),
      el("td", { class: "mono small" }, row.path),
      el("td", {}, String(row.scanCount)),
      el("td", {}, `${row.productMiB} MiB`),
      el("td", {}, row.exists ? (row.located ? "placed" : "unplaced") : "folder missing"),
    ]))),
  ]);
  const discover = el("button", { class: "button", type: "button" }, "Find folders");
  const dryRun = el("button", { class: "button ghost", type: "button" }, "What would be added");
  const clear = el("button", { class: "button ghost", type: "button" }, "Clear all products");
  const run = async (label, call) => {
    try {
      const result = await call();
      // The panel is rebuilt after a change, so the summary goes to the toast rather than to a
      // paragraph the rebuild would wipe.
      const added = Array.isArray(result.added) ? result.added.length : 0;
      if (label === "Find folders") toast(added ? `${label}: ${added} registered` : "nothing new to register");
      else if (label === "What would be added") toast(added ? `${added} folder(s) would be added` : "nothing new to add");
      else toast(`${label}: ${result.freedMiB ?? 0} MiB freed`);
      if (label !== "What would be added") await showLibrary();
    } catch (error) {
      toast(error.message, "err");
    }
  };
  discover.addEventListener("click", () => run("Find folders", () => api("/api/admin/library/discover", { method: "POST", body: {} })));
  dryRun.addEventListener("click", () => run("What would be added", () => api("/api/admin/library/discover", { method: "POST", body: { dryRun: true } })));
  clear.addEventListener("click", () => {
    if (!confirm(`Delete ${cache.MiB} MiB of products? Every product can be rebuilt from its scan.`)) return;
    run("Clear all products", () => api("/api/admin/cache/clear", { method: "POST", body: {} }));
  });
  body.replaceChildren(el("div", { style: "display:grid;gap:12px" }, [
    el("div", { class: "actions" }, [discover, dryRun, clear]),
    el("p", { class: "muted small" }, `${catalogue.count} project(s), ${catalogue.productMiB} MiB of products.`),
    projects,
    el("p", { class: "muted small" }, `Cache: ${cache.MiB} MiB across ${cache.scans.filter((s) => s.exists).length} scan(s) with products.`),
  ]));
}

// == SCANS ==
// What has been processed for each scan, and a way to process the ones that have not been.
// The state comes from the product manifests, so it reflects the files on disk rather than
// a queue the server remembers.
async function waitForJob(id) {
  for (let attempt = 0; attempt < 600; attempt += 1) {
    const job = await api(`/api/jobs/${encodeURIComponent(id)}`);
    if (job.state === "done" || job.state === "failed") return job;
    status(`${job.message || "processing"} ${Math.round((job.progress || 0) * 100)}%`);
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  return { state: "timeout", message: "timed out" };
}

async function showScans() {
  const projects = await api("/api/projects");
  const list = projects.projects || projects;
  const rows = [];
  for (const project of list) {
    let detail;
    try {
      detail = await api(`/api/p/${encodeURIComponent(project.slug)}`);
    } catch {
      continue;
    }
    for (const scan of detail.scans) {
      const products = scan.products || {};
      const state = ["depth", "intensity", "plan"]
        .map((kind) => `${kind} ${products[kind]?.built ? "built" : "—"}`)
        .join(" · ");
      const build = el("button", { type: "button", class: "button ghost" }, "Process");
      build.onclick = async () => {
        build.disabled = true;
        try {
          const job = await api(`/api/p/${encodeURIComponent(project.slug)}/s/${encodeURIComponent(scan.name)}/process`,
            { method: "POST", body: { kinds: ["depth", "intensity", "plan"] } });
          const done = await waitForJob(job.id);
          if (done.state !== "done") throw new Error(done.message || done.state);
          await refresh();
        } catch (error) {
          status(error.message, "err");
          build.disabled = false;
        }
      };
      rows.push([
        el("a", { href: `/p/${encodeURIComponent(project.slug)}` }, project.name),
        scan.name,
        scan.kind.toUpperCase(),
        state,
        el("span", {}, [build]),
      ]);
    }
  }
  body.replaceChildren(rows.length
    ? table(["Project", "Scan", "Kind", "Products", ""], rows)
    : el("p", { class: "muted" }, "No scans registered."));
}

const views = {
  users: showUsers, invites: showInvites, shares: showShares, audit: showAudit,
  scans: showScans, library: showLibrary, system: showSystem,
};

async function refresh() {
  for (const tab of tabs) tab.setAttribute("aria-selected", tab.dataset.tab === current ? "true" : "false");
  body.replaceChildren(el("p", { class: "muted" }, "Loading…"));
  try {
    await (views[current] || showUsers)();
    status(current);
  } catch (error) {
    status(error.message, "err");
    body.replaceChildren(el("p", { class: "muted" }, error.message));
  }
}

for (const tab of tabs) {
  tab.addEventListener("click", () => { current = tab.dataset.tab; refresh(); });
}

me().then((who) => { if (!who.authenticated) location.href = "/login"; });
refresh();

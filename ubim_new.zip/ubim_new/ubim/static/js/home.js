import { api, el, me, status, toast } from "./api.js";

const target = document.getElementById("projects");

function card(project) {
  const link = `/p/${encodeURIComponent(project.slug)}`;
  const image = el("img", { alt: "", loading: "lazy", src: `/api/p/${encodeURIComponent(project.slug)}/thumb-preview` });
  image.addEventListener("error", () => { image.remove(); }, { once: true });
  return el("article", { class: "card" }, [
    image,
    el("div", { class: "body" }, [
      el("h3", {}, [el("a", { href: link }, project.name)]),
      el("div", { class: "meta" }, `${project.scans} scan${project.scans === 1 ? "" : "s"}${project.revision ? ` · revision ${project.revision}` : ""}`),
      el("div", { class: "actions" }, [el("a", { class: "button", href: `${link}` }, "Open")]),
    ]),
  ]);
}

async function load() {
  try {
    const who = await me();
    const data = await api("/api/projects");
    target.replaceChildren();
    if (!data.projects.length) {
      target.append(el("p", { class: "muted" }, "No projects yet."));
    } else {
      for (const project of data.projects) target.append(card(project));
    }
    if (who.capabilities?.includes("manage_projects")) target.append(addForm());
    status(`${data.projects.length} projects`);
  } catch (error) {
    status(error.message, "err");
    target.replaceChildren(el("p", { class: "muted" }, error.message));
  }
}

function addForm() {
  const input = el("input", { placeholder: "/path/to/project", "aria-label": "Project folder" });
  const name = el("input", { placeholder: "Display name (optional)", "aria-label": "Display name" });
  const form = el("form", {
    class: "card body",
    onsubmit: async (event) => {
      event.preventDefault();
      try {
        const created = await api("/api/projects", { method: "POST", body: { path: input.value.trim(), name: name.value.trim() || undefined } });
        toast(`Added ${created.name}`, "ok");
        await load();
      } catch (error) {
        toast(error.message, "err");
      }
    },
  }, [el("h3", {}, "Add a project"), input, name, el("button", { class: "primary", type: "submit" }, "Import folder")]);
  return form;
}

// == VIEW SWITCH ==
// The choice is the user's, so it is stored on the server rather than in this page; the
// map is drawn from the positions projects declare, and a project without one is listed
// under the map instead of being placed at a guess.
const viewButtons = [...document.querySelectorAll("#home-view button")];
const mapPanel = document.getElementById("home-map");
let currentView = "list";

function applyView(view, remember = false) {
  currentView = view === "map" ? "map" : "list";
  for (const button of viewButtons) {
    button.setAttribute("aria-pressed", String(button.dataset.view === currentView));
  }
  target.hidden = currentView !== "list";
  mapPanel.hidden = currentView !== "map";
  if (currentView === "map") drawMap();
  if (remember) {
    api("/api/settings", { method: "PUT", body: { view: currentView } }).catch((error) => status(error.message, "err"));
  }
}

for (const button of viewButtons) {
  button.addEventListener("click", () => applyView(button.dataset.view, true));
}

// == MAP ==
// A Web Mercator map on a canvas, so the interface needs no mapping library. Tiles come
// from this app's own route; OpenStreetMap is credited where its data is drawn.
const TILE = 256;
const mapCanvas = document.getElementById("home-map-canvas");
const mapNote = document.getElementById("map-note");
const tiles = new Map();
const state = { zoom: 2, cx: 0, cy: 0, markers: [], drag: null, moved: false };

function worldSize(zoom) {
  return TILE * 2 ** zoom;
}

function toWorld(lat, lon, zoom) {
  const size = worldSize(zoom);
  const clamped = Math.max(-85.05112878, Math.min(85.05112878, lat));
  const x = ((lon + 180) / 360) * size;
  const y = (1 - Math.log(Math.tan(Math.PI / 4 + (clamped * Math.PI) / 360)) / Math.PI) / 2 * size;
  return { x, y };
}

function toLatLon(x, y, zoom) {
  const size = worldSize(zoom);
  const lon = (x / size) * 360 - 180;
  const lat = (Math.atan(Math.sinh(Math.PI * (1 - (2 * y) / size))) * 180) / Math.PI;
  return { lat, lon };
}

function tile(z, x, y) {
  const key = `${z}/${x}/${y}`;
  if (!tiles.has(key)) {
    const image = new Image();
    image.src = `/api/tiles/${z}/${x}/${y}.png`;
    tiles.set(key, new Promise((resolve) => {
      image.onload = () => resolve(image);
      image.onerror = () => resolve(null);
    }));
  }
  return tiles.get(key);
}

function sizeCanvas() {
  const ratio = window.devicePixelRatio || 1;
  const box = mapCanvas.getBoundingClientRect();
  mapCanvas.width = Math.max(1, Math.round(box.width * ratio));
  mapCanvas.height = Math.max(1, Math.round(box.height * ratio));
  return { width: box.width, height: box.height, ratio };
}

function fit(placed) {
  if (!placed.length) {
    state.zoom = 2;
    const centre = toWorld(20, 0, 2);
    state.cx = centre.x;
    state.cy = centre.y;
    return;
  }
  let zoom = 17;
  const box = mapCanvas.getBoundingClientRect();
  for (; zoom > 1; zoom -= 1) {
    const points = placed.map((entry) => toWorld(entry.lat, entry.lon, zoom));
    const spanX = Math.max(...points.map((p) => p.x)) - Math.min(...points.map((p) => p.x));
    const spanY = Math.max(...points.map((p) => p.y)) - Math.min(...points.map((p) => p.y));
    if (spanX < box.width * 0.6 && spanY < box.height * 0.6) {
      state.zoom = zoom;
      break;
    }
  }
  if (zoom <= 1) state.zoom = 10;
  const points = placed.map((entry) => toWorld(entry.lat, entry.lon, state.zoom));
  state.cx = points.reduce((sum, p) => sum + p.x, 0) / points.length;
  state.cy = points.reduce((sum, p) => sum + p.y, 0) / points.length;
}

async function drawMap() {
  const { width, height, ratio } = sizeCanvas();
  const context = mapCanvas.getContext("2d");
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  context.fillStyle = "#10161d";
  context.fillRect(0, 0, width, height);

  let locations;
  try {
    locations = await api("/api/locations");
  } catch (error) {
    mapNote.textContent = error.message;
    return;
  }
  const placed = locations.projects.filter((entry) => entry.placed);
  const unplaced = locations.projects.filter((entry) => !entry.placed);
  // Refit when the set of placed projects changes, not on every redraw: panning must not
  // be undone by a repaint, but a newly placed project has to come into view.
  const signature = placed.map((entry) => `${entry.slug}:${entry.lat}:${entry.lon}`).join(",");
  if (signature !== state.signature) {
    fit(placed);
    state.signature = signature;
  }

  const zoom = state.zoom;
  const originX = state.cx - width / 2;
  const originY = state.cy - height / 2;
  const count = 2 ** zoom;
  const firstX = Math.floor(originX / TILE);
  const lastX = Math.floor((originX + width) / TILE);
  const firstY = Math.floor(originY / TILE);
  const lastY = Math.floor((originY + height) / TILE);
  const wanted = [];
  for (let x = firstX; x <= lastX; x += 1) {
    for (let y = firstY; y <= lastY; y += 1) {
      const wrapped = ((x % count) + count) % count;
      if (y < 0 || y >= count) continue;
      wanted.push({ x, y, wrapped });
    }
  }
  const drawn = await Promise.all(wanted.map((cell) => tile(zoom, cell.wrapped, cell.y)));
  drawn.forEach((image, index) => {
    if (!image) return;
    const cell = wanted[index];
    context.drawImage(image, cell.x * TILE - originX, cell.y * TILE - originY, TILE, TILE);
  });

  state.markers = placed.map((entry) => {
    const point = toWorld(entry.lat, entry.lon, zoom);
    return { ...entry, left: point.x - originX, top: point.y - originY };
  });
  for (const marker of state.markers) {
    context.beginPath();
    context.arc(marker.left, marker.top, 6, 0, Math.PI * 2);
    context.fillStyle = "#4aa3ff";
    context.fill();
    context.lineWidth = 2;
    context.strokeStyle = "#071018";
    context.stroke();
    // A label over map tiles needs its own background: white text alone disappears on a
    // light coastline and dark text disappears on a forest.
    context.font = "12px system-ui, sans-serif";
    const textWidth = context.measureText(marker.name).width;
    context.fillStyle = "rgba(10, 14, 20, .84)";
    context.beginPath();
    context.roundRect(marker.left + 10, marker.top - 9, textWidth + 12, 18, 5);
    context.fill();
    context.fillStyle = "#e8eef6";
    context.fillText(marker.name, marker.left + 16, marker.top + 4);
  }

  const credit = "© OpenStreetMap contributors";
  mapNote.textContent = unplaced.length
    ? `${credit} · ${unplaced.length} project${unplaced.length === 1 ? "" : "s"} without a position: ${unplaced.map((entry) => entry.name).join(", ")}`
    : credit;
}

mapCanvas.addEventListener("pointerdown", (event) => {
  state.drag = { x: event.clientX, y: event.clientY, cx: state.cx, cy: state.cy };
  state.moved = false;
  mapCanvas.setPointerCapture(event.pointerId);
  mapCanvas.classList.add("dragging");
});

mapCanvas.addEventListener("pointermove", (event) => {
  if (!state.drag) return;
  const dx = event.clientX - state.drag.x;
  const dy = event.clientY - state.drag.y;
  if (Math.abs(dx) + Math.abs(dy) > 3) state.moved = true;
  state.cx = state.drag.cx - dx;
  state.cy = state.drag.cy - dy;
  drawMap();
});

mapCanvas.addEventListener("pointerup", (event) => {
  const drag = state.drag;
  state.drag = null;
  mapCanvas.classList.remove("dragging");
  if (!drag || state.moved) return;
  const box = mapCanvas.getBoundingClientRect();
  const x = event.clientX - box.left;
  const y = event.clientY - box.top;
  const hit = state.markers.find((marker) => Math.hypot(marker.left - x, marker.top - y) < 12);
  if (hit) location.href = `/p/${encodeURIComponent(hit.slug)}`;
});

mapCanvas.addEventListener("wheel", (event) => {
  event.preventDefault();
  zoomBy(event.deltaY < 0 ? 1 : -1, event);
}, { passive: false });

function zoomBy(step, event = null) {
  const next = Math.max(1, Math.min(18, state.zoom + step));
  if (next === state.zoom) return;
  const box = mapCanvas.getBoundingClientRect();
  const px = event ? event.clientX - box.left : box.width / 2;
  const py = event ? event.clientY - box.top : box.height / 2;
  const before = toLatLon(state.cx - box.width / 2 + px, state.cy - box.height / 2 + py, state.zoom);
  state.zoom = next;
  const after = toWorld(before.lat, before.lon, next);
  state.cx = after.x - (px - box.width / 2);
  state.cy = after.y - (py - box.height / 2);
  drawMap();
}

document.getElementById("map-in").addEventListener("click", () => zoomBy(1));
document.getElementById("map-out").addEventListener("click", () => zoomBy(-1));
window.addEventListener("resize", () => { if (currentView === "map") drawMap(); });

// == START ==
(async () => {
  let view = "list";
  try {
    view = (await api("/api/settings")).view;
  } catch { /* an anonymous browse session may not have one; the list is the default */ }
  await load();
  applyView(view);
})();

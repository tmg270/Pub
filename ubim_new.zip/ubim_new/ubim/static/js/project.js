import { api, el, status, toast } from "./api.js";

const slug = document.getElementById("project").dataset.slug;
const target = document.getElementById("scans");
const metaLine = document.getElementById("project-meta");

function scanCard(scan) {
  const href = `/p/${encodeURIComponent(slug)}/${encodeURIComponent(scan.name)}`;
  const thumb = el("img", { alt: "", loading: "lazy", src: `/api/p/${encodeURIComponent(slug)}/s/${encodeURIComponent(scan.name)}/thumb?size=512` });
  thumb.addEventListener("error", () => { thumb.replaceWith(el("div", { class: "empty" }, "no imagery")); }, { once: true });
  const hasIntensity = scan.products?.intensity?.built;
  return el("article", { class: "card" }, [
    thumb,
    el("div", { class: "body" }, [
      el("h3", {}, [el("a", { href }, scan.name)]),
      el("div", { class: "meta" }, [
        `${(scan.size / (1 << 20)).toFixed(1)} MiB · ${scan.kind.toUpperCase()}`,
        hasIntensity ? " · intensity" : "",
        scan.products?.depth?.built ? " · depth" : "",
      ].join("")),
      el("div", { class: "actions" }, [el("a", { class: "button", href }, "Open viewer")]),
    ]),
  ]);
}

async function load() {
  try {
    const data = await api(`/api/p/${encodeURIComponent(slug)}`);
    const position = data.location?.placed
      ? `${data.location.lat.toFixed(5)}, ${data.location.lon.toFixed(5)}${data.location.source ? ` (${data.location.source})` : ""}`
      : "no position recorded";
    metaLine.textContent = [
      `${data.scans.length} scan${data.scans.length === 1 ? "" : "s"}`,
      data.revision ? `revision ${data.revision}` : "",
      position,
      data.crs ? `CRS ${data.crs} (declared)` : "CRS not declared",
    ].filter(Boolean).join(" · ");
    const crsInput = document.getElementById("project-crs");
    const crsSave = document.getElementById("project-crs-save");
    if (crsInput) crsInput.value = data.crs || "";
    if (crsSave && crsInput) {
      crsSave.onclick = async () => {
        try {
          const saved = await api(`/api/p/${encodeURIComponent(slug)}/crs`, { method: "PUT", body: { crs: crsInput.value } });
          toast(saved.crs ? `CRS declared as ${saved.crs}` : "CRS cleared");
          await load();
        } catch (error) {
          toast(error.message, "err");
        }
      };
    }
    target.replaceChildren();
    if (!data.scans.length) target.append(el("p", { class: "muted" }, "This project has no scans."));
    for (const scan of data.scans) target.append(scanCard(scan));
    status("ready");
    await loadPlan(data.scans);
  } catch (error) {
    status(error.message, "err");
    target.replaceChildren(el("p", { class: "muted" }, error.message));
  }
}

load();

// == SITE PLAN ==
// The plan is a raster of the range product, so a scan with no products has nothing to show.
async function loadPlan(scans) {
  const section = document.getElementById("site-plan");
  const stage = document.getElementById("plan-stage");
  const image = document.getElementById("plan-image");
  const dots = document.getElementById("plan-dots");
  const note = document.getElementById("plan-note");
  const build = document.getElementById("plan-build");
  const ready = scans.filter((scan) => scan.products?.plan?.built);
  const base = (scan) => `/api/p/${encodeURIComponent(slug)}/s/${encodeURIComponent(scan.name)}`;

  if (!ready.length) {
    section.hidden = false;
    stage.hidden = true;
    note.textContent = "No site plan yet. A plan is built from the depth product of a scan.";
    build.hidden = !scans.some((scan) => scan.products?.depth?.built);
    if (!build.hidden) {
      build.onclick = async () => {
        build.disabled = true;
        status("Building site plan…");
        try {
          const job = await api(`${base(scans.find((scan) => scan.products?.depth?.built))}/process`, {
            method: "POST", body: { kinds: ["plan"] },
          });
          const done = await waitForJob(job.id);
          if (done.state !== "done") throw new Error(done.message || done.state);
          await load();
        } catch (error) {
          status(error.message, "err");
          build.disabled = false;
        }
      };
    }
    return;
  }

  const scan = ready[0];
  let meta;
  try {
    meta = await api(`${base(scan)}/plan/meta`);
  } catch {
    section.hidden = true;
    return;
  }
  section.hidden = false;
  stage.hidden = false;
  build.hidden = true;
  const planUrl = (densified) => `${base(scan)}/plan.png?v=${meta.builtAt}&size=1024${densified ? "&filled=1" : ""}`;
  image.src = planUrl(false);

  // The honest raster is sparse: a scan sees through railings and past kerbs. "Fill gaps"
  // grows the returns into the holes at a dimmer value, which is the tell that it is a shape
  // rather than a measurement.
  const fill = document.getElementById("plan-fill");
  fill.hidden = !meta.filledImage;
  fill.onclick = () => {
    const densified = fill.getAttribute("aria-pressed") !== "true";
    fill.setAttribute("aria-pressed", String(densified));
    image.src = planUrl(densified);
    note.dataset.mode = densified ? "filled" : "raw";
  };
  const span = Math.max(meta.bounds.maxX - meta.bounds.minX, meta.bounds.maxY - meta.bounds.minY);
  note.textContent = `${scan.name} · ${span.toFixed(0)} m across · ${meta.cellMetres.toFixed(2)} m per pixel · heights ${meta.heightRange[0].toFixed(1)} to ${meta.heightRange[1].toFixed(1)} m`;

  // The server places scans as fractions of the plan when a registration exists; an
  // unregistered scan is its own origin, which is the only position the data supports.
  const place = (site) => (site.placed
    ? { left: `${site.x * 100}%`, top: `${site.y * 100}%` }
    : { left: "50%", top: "50%" });
  dots.replaceChildren();
  for (const site of meta.scans || []) {
    const dot = el("a", {
      class: "scan-dot",
      href: `/p/${encodeURIComponent(slug)}/${encodeURIComponent(site.name || scan.name)}`,
      title: site.placed ? site.name : `${site.name || scan.name} (position not registered)`,
      style: Object.entries(place(site)).map(([key, value]) => `${key}:${value}`).join(";"),
    }, [el("span", {}, site.name || scan.name)]);
    dots.append(dot);
  }
  loadAerial(meta);
  wirePlanProbe(scan, meta);
  await loadPlanHandles(scan, meta);
  if ((meta.scans || []).some((site) => !site.placed)) {
    note.textContent += " · positions are each scan's own origin until a registration is recorded";
  } else if ((meta.scans || []).length > 1) {
    note.textContent += ` · ${meta.scans.length} scan positions from the registration`;
  }
}

// == PLAN PROBE ==
// Hovering the plan answers "what is there?". The plan alone gives a ground position, so the
// bearing and distance come from the cursor and the height comes from the range product, which
// is the only thing that knows how high the return at that bearing was. Nothing is guessed: when
// no return is near the hovered distance the card says so.
function wirePlanProbe(scan, meta) {
  const stage = document.getElementById("plan-stage");
  const probe = document.getElementById("plan-probe");
  if (!stage || !probe) return;
  const bounds = meta.bounds || {};
  const spanX = bounds.maxX - bounds.minX;
  const spanY = bounds.maxY - bounds.minY;
  if (!(spanX > 0 && spanY > 0)) return;
  const pano = `/api/p/${encodeURIComponent(slug)}/s/${encodeURIComponent(scan.name)}/pano/grey_hd?max_size=1024`;
  let timer = null;
  let token = 0;
  const hide = () => { probe.hidden = true; };
  const show = (event, data, rect) => {
    const strip = el("span", { class: "pano" });
    strip.style.backgroundImage = `url("${pano}")`;
    strip.style.backgroundPosition = `${((data.azimuthDeg || 0) / 360) * 100}% center`;
    const lines = [
      el("div", {}, [el("b", {}, `${data.distanceM.toFixed(1)} m`), el("span", { class: "muted" }, ` · ${data.azimuthDeg.toFixed(0)}°`)],),
    ];
    if (data.hit) {
      lines.push(el("div", {}, `height ${data.heightM.toFixed(1)} m · ${data.elevationDeg.toFixed(0)}° up`));
    } else if (data.nearRangeM) {
      lines.push(el("div", { class: "muted" }, `no return there · nearest ${data.nearRangeM.toFixed(1)} m at ${data.nearElevationDeg.toFixed(0)}°`));
    } else {
      lines.push(el("div", { class: "muted" }, "no return on that line of sight"));
    }
    lines.push(strip);
    probe.replaceChildren(...lines);
    probe.hidden = false;
    const left = Math.min(rect.width - probe.offsetWidth - 8, Math.max(8, event.clientX - rect.left + 14));
    const top = Math.min(rect.height - probe.offsetHeight - 8, Math.max(8, event.clientY - rect.top + 14));
    probe.style.left = `${left}px`;
    probe.style.top = `${top}px`;
  };
  stage.addEventListener("pointerleave", hide);
  stage.addEventListener("pointermove", (event) => {
    const rect = stage.getBoundingClientRect();
    const fx = (event.clientX - rect.left) / rect.width;
    const fy = (event.clientY - rect.top) / rect.height;
    if (fx < 0 || fx > 1 || fy < 0 || fy > 1) { hide(); return; }
    const x = bounds.minX + fx * spanX;
    const y = bounds.minY + (1 - fy) * spanY;
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const mine = ++token;
      let data;
      try {
        data = await api(`/api/p/${encodeURIComponent(slug)}/s/${encodeURIComponent(scan.name)}/plan/at?x=${x.toFixed(2)}&y=${y.toFixed(2)}`);
      } catch {
        hide();
        return;
      }
      if (mine === token) show(event, data, rect);
    }, 120);
  });
}

// == PLAN VERTICES ==
// A mark can be moved in plan view. The drag happens here; the metres-to-angles conversion
// happens on the server, which is the only place that knows the scan's frame.
async function loadPlanHandles(scan, meta) {
  const layer = document.getElementById("plan-handles");
  if (!layer) return;
  layer.replaceChildren();
  const bounds = meta.bounds || {};
  const spanX = bounds.maxX - bounds.minX;
  const spanY = bounds.maxY - bounds.minY;
  if (!(spanX > 0 && spanY > 0)) return;
  let data;
  try {
    data = await api(`/api/p/${encodeURIComponent(slug)}/s/${encodeURIComponent(scan.name)}/plan/points`);
  } catch {
    return;
  }
  const metres = (fx, fy) => ({
    x: bounds.minX + fx * spanX,
    y: bounds.minY + (1 - fy) * spanY,
  });
  for (const feature of data.features || []) {
    const live = feature.points.map((point) => ({ x: point.x, y: point.y, fx: point.fractionX, fy: point.fractionY }));
    const handles = live.map((point, index) => {
      const handle = el("span", { class: "plan-handle", title: `${feature.kind}${feature.label ? ` · ${feature.label}` : ""}` });
      handle.style.left = `${point.fx * 100}%`;
      handle.style.top = `${point.fy * 100}%`;
      handle.dataset.index = String(index);
      handle.dataset.feature = String(feature.id);
      return handle;
    });
    for (const handle of handles) {
      handle.addEventListener("pointerdown", (event) => {
        event.preventDefault();
        const stage = document.getElementById("plan-stage").getBoundingClientRect();
        handle.setPointerCapture(event.pointerId);
        handle.classList.add("dragging");
        const move = (moveEvent) => {
          const fx = Math.min(1, Math.max(0, (moveEvent.clientX - stage.left) / stage.width));
          const fy = Math.min(1, Math.max(0, (moveEvent.clientY - stage.top) / stage.height));
          handle.style.left = `${fx * 100}%`;
          handle.style.top = `${fy * 100}%`;
          const index = Number(handle.dataset.index);
          live[index] = { ...metres(fx, fy), fx, fy };
        };
        const up = async () => {
          handle.removeEventListener("pointermove", move);
          handle.removeEventListener("pointerup", up);
          handle.removeEventListener("pointercancel", up);
          handle.classList.remove("dragging");
          const points = live.map((point) => ({ x: point.x, y: point.y }));
          try {
            await api(`/api/p/${encodeURIComponent(slug)}/s/${encodeURIComponent(scan.name)}/features/${encodeURIComponent(feature.id)}`, {
              method: "PATCH", body: { pointsXY: points },
            });
            status("mark moved");
            await loadPlanHandles(scan, meta);
          } catch (error) {
            status(error.message, "err");
            await loadPlanHandles(scan, meta);
          }
        };
        handle.addEventListener("pointermove", move);
        handle.addEventListener("pointerup", up);
        handle.addEventListener("pointercancel", up);
      });
    }
    layer.append(...handles);
  }
  if (!(data.features || []).length) layer.replaceChildren();
}

// == AERIAL BACKDROP (P4) ==
// A site plan is in metres and the scan frame's axes are not a map projection, so the only
// honest anchor is the position someone declared for the project. Everything here follows
// from that: the declared point is the plan's origin, its axes are read as east and north,
// and the note says so. With no declared position the toggle stays hidden.
const DEG_PER_METRE = 1 / 111320;
const TILE = 256;

function tileLatLon(x, y, z) {
  const n = 2 ** z;
  const lon = (x / n) * 360 - 180;
  const lat = (Math.atan(Math.sinh(Math.PI * (1 - (2 * y) / n))) * 180) / Math.PI;
  return { lon, lat };
}

async function loadAerial(meta) {
  const toggle = document.getElementById("plan-aerial-toggle");
  const layer = document.getElementById("plan-aerial");
  const note = document.getElementById("plan-note");
  let placement = null;
  try {
    placement = await api(`/api/p/${encodeURIComponent(slug)}/location`);
  } catch { placement = null; }
  if (!placement || !placement.placed || placement.lat == null || placement.lon == null) {
    toggle.hidden = true;
    return;
  }
  toggle.hidden = false;
  const lat0 = Number(placement.lat);
  const lon0 = Number(placement.lon);
  const bounds = meta.bounds || {};
  const corners = [
    [bounds.minX, bounds.minY], [bounds.maxX, bounds.minY],
    [bounds.minX, bounds.maxY], [bounds.maxX, bounds.maxY],
  ].map(([x, y]) => ({
    lon: lon0 + x * DEG_PER_METRE / Math.cos((lat0 * Math.PI) / 180),
    lat: lat0 + y * DEG_PER_METRE,
  }));
  const lonMin = Math.min(...corners.map((c) => c.lon));
  const lonMax = Math.max(...corners.map((c) => c.lon));
  const latMin = Math.min(...corners.map((c) => c.lat));
  const latMax = Math.max(...corners.map((c) => c.lat));
  const span = Math.max(
    (bounds.maxX - bounds.minX) * Math.cos((lat0 * Math.PI) / 180),
    bounds.maxY - bounds.minY,
  );
  // Three tiles across is enough to read the site and few enough to stay quick.
  const zoom = Math.max(3, Math.min(19, Math.floor(Math.log2((156543 * Math.cos((lat0 * Math.PI) / 180) * TILE * 3) / Math.max(40, span)))));
  const n = 2 ** zoom;
  const x0 = Math.floor(((lonMin + 180) / 360) * n);
  const x1 = Math.floor(((lonMax + 180) / 360) * n);
  const latToY = (lat) => Math.floor(((1 - Math.log(Math.tan((lat * Math.PI) / 180) + 1 / Math.cos((lat * Math.PI) / 180)) / Math.PI) / 2) * n);
  const y0 = latToY(latMax);
  const y1 = latToY(latMin);

  const draw = () => {
    layer.replaceChildren();
    for (let x = x0; x <= x1; x += 1) {
      for (let y = y0; y <= y1; y += 1) {
        const top = tileLatLon(x, y, zoom);
        const bottom = tileLatLon(x + 1, y + 1, zoom);
        const left = ((top.lon - lonMin) / (lonMax - lonMin)) * 100;
        const right = ((bottom.lon - lonMin) / (lonMax - lonMin)) * 100;
        const upper = ((latMax - top.lat) / (latMax - latMin)) * 100;
        const lower = ((latMax - bottom.lat) / (latMax - latMin)) * 100;
        const image = el("img", {
          class: "plan-tile",
          alt: "",
          src: `/api/tiles/${zoom}/${x}/${y}.png`,
          style: `left:${left}%;top:${upper}%;width:${right - left}%;height:${lower - upper}%`,
        });
        layer.append(image);
      }
    }
  };
  toggle.onclick = () => {
    const on = layer.hidden;
    layer.hidden = !on;
    toggle.classList.toggle("on", on);
    if (on) {
      draw();
      note.textContent += " · aerial imagery assumes the plan is north-up with the declared position at its origin";
    }
  };
}

async function waitForJob(id) {
  for (let attempt = 0; attempt < 240; attempt += 1) {
    const job = await api(`/api/jobs/${encodeURIComponent(id)}`);
    if (job.state === "done" || job.state === "failed") return job;
    document.getElementById("plan-note").textContent = `Processing… ${Math.round((job.progress || 0) * 100)}%`;
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  return { state: "timeout" };
}

// == DRAWINGS ==
// A DXF is imported through the server, which parses it; the browser only reads the file.
// == DRAWING PLACEMENT (D4) ==
// A DXF's coordinates are the draughtsman's, not ours. The form declares the origin, rotation
// and scale that turn them into the scan's metres; the server applies it when the drawing is
// projected, so changing it moves existing drawings rather than only the next import.
async function loadFrame() {
  const note = document.getElementById("frame-note");
  const fields = ["x", "y", "z", "rotation", "scale"].map((name) => document.getElementById(`frame-${name}`));
  const save = document.getElementById("frame-save");
  const clear = document.getElementById("frame-clear");
  if (!save) return;
  const fill = (frame) => {
    fields[0].value = frame ? frame.originX : "";
    fields[1].value = frame ? frame.originY : "";
    fields[2].value = frame ? frame.originZ : "";
    fields[3].value = frame ? frame.rotationDeg : "";
    fields[4].value = frame ? frame.scale : "";
  };
  const read = async () => {
    try {
      const data = await api(`/api/p/${encodeURIComponent(slug)}/drawing-frame`);
      fill(data.frame);
      note.textContent = data.frame
        ? `Placed: origin ${data.frame.originX}, ${data.frame.originY}, ${data.frame.originZ} · rotation ${data.frame.rotationDeg}° · scale ${data.frame.scale}.`
        : "A drawing carries its own coordinates. Declare where they sit in the scans, or leave this empty when the drawing is already in the scan's frame.";
    } catch (error) {
      note.textContent = error.message;
    }
  };
  save.onclick = async () => {
    const number = (input) => (input.value.trim() === "" ? 0 : Number(input.value));
    try {
      await api(`/api/p/${encodeURIComponent(slug)}/drawing-frame`, {
        method: "PUT",
        body: {
          originX: number(fields[0]), originY: number(fields[1]), originZ: number(fields[2]),
          rotationDeg: number(fields[3]), scale: fields[4].value.trim() === "" ? 1 : Number(fields[4].value),
        },
      });
      status("drawing placement saved");
      await read();
    } catch (error) {
      status(error.message, "err");
    }
  };
  clear.onclick = async () => {
    try {
      await api(`/api/p/${encodeURIComponent(slug)}/drawing-frame`, { method: "PUT", body: {} });
      status("drawing placement cleared");
      await read();
    } catch (error) {
      status(error.message, "err");
    }
  };
  await read();
}

async function loadDrawings() {
  const section = document.getElementById("drawings");
  const list = document.getElementById("drawing-list");
  const input = document.getElementById("drawing-file");
  const button = document.getElementById("drawing-import");
  const note = document.getElementById("drawing-note");
  if (!section) return;
  section.hidden = false;

  const base = `/api/p/${encodeURIComponent(slug)}/drawings`;
  const refresh = async () => {
    list.replaceChildren();
    try {
      const data = await api(base);
      if (!data.drawings.length) {
        list.append(el("li", {}, "No drawings imported."));
        return;
      }
      for (const drawing of data.drawings) {
        const remove = el("button", { type: "button", class: "button ghost", title: "Remove" }, "Remove");
        remove.onclick = async () => {
          try {
            await api(`${base}/${drawing.id}`, { method: "DELETE" });
            await refresh();
            status(`Removed ${drawing.name}`);
          } catch (error) { status(error.message, "err"); }
        };
        const flat = drawing.flat ? " · flat (no height)" : "";
        list.append(el("li", {}, [
          `${drawing.name} · ${drawing.shapes} shape${drawing.shapes === 1 ? "" : "s"}${flat}`,
          " ",
          remove,
        ]));
      }
    } catch (error) {
      list.append(el("li", {}, error.message));
    }
  };

  button.onclick = async () => {
    const file = input.files?.[0];
    if (!file) { status("Choose a .dxf file first", "err"); return; }
    button.disabled = true;
    status(`Reading ${file.name}…`);
    try {
      const text = await file.text();
      const result = await api(base, { method: "POST", body: { name: file.name, text } });
      note.textContent = `${result.name}: ${result.shapes} shape${result.shapes === 1 ? "" : "s"} imported`
        + (result.warning ? ` · ${result.warning}` : "");
      input.value = "";
      await refresh();
      toast(`Imported ${result.shapes} shape${result.shapes === 1 ? "" : "s"}`);
    } catch (error) {
      status(error.message, "err");
    } finally {
      button.disabled = false;
    }
  };

  await refresh();
}

loadDrawings();
loadFrame();

// == MAP POSITION ==
// Declaring where a project is; nothing here is derived from the scan geometry.
async function loadPlacement() {
  const section = document.getElementById("placement");
  if (!section) return;
  section.hidden = false;
  const lat = document.getElementById("place-lat");
  const lon = document.getElementById("place-lon");
  const note = document.getElementById("place-note");
  const base = `/api/p/${encodeURIComponent(slug)}/location`;

  const show = (data) => {
    lat.value = data.placed ? String(data.lat) : "";
    lon.value = data.placed ? String(data.lon) : "";
    const source = data.source ? ` (${data.source})` : "";
    note.textContent = data.placed
      ? `placed at ${Number(data.lat).toFixed(5)}, ${Number(data.lon).toFixed(5)}${source}`
      : "not placed yet";
  };
  try {
    show(await api(base));
  } catch (error) {
    note.textContent = error.message;
  }

  document.getElementById("place-save").onclick = async () => {
    try {
      show(await api(base, { method: "PUT", body: { lat: Number(lat.value), lon: Number(lon.value) } }));
      toast("Position saved");
    } catch (error) {
      status(error.message, "err");
    }
  };
  // The scanner logs its own GPS fix, and that is better evidence than a guess: offer each
  // scan of the project by name and adopt the fix only when someone asks for it.
  const chooser = document.getElementById("place-scan");
  if (chooser) {
    const project = await api(`/api/p/${encodeURIComponent(slug)}`).catch(() => ({ scans: [] }));
    for (const scan of project.scans || []) {
      chooser.append(el("option", { value: scan.name }, scan.name));
    }
    document.getElementById("place-gps").onclick = async () => {
      try {
        const adopted = await api(`/api/p/${encodeURIComponent(slug)}/location/from-scan`, {
          method: "POST", body: { scan: chooser.value },
        });
        show(adopted);
        toast(`Position from ${chooser.value}: ${adopted.gps.satellites || "no"} satellites`);
      } catch (error) {
        status(error.message, "err");
      }
    };
  }

  document.getElementById("place-clear").onclick = async () => {
    try {
      show(await api(base, { method: "PUT", body: {} }));
      toast("Position cleared");
    } catch (error) {
      status(error.message, "err");
    }
  };
}

loadPlacement();

// == PROJECT PICTURE ==
// A view saved from the viewer becomes the picture the project is known by. Asking the
// server for it and hiding the element on 404 keeps the page honest: no picture, no frame.
(async () => {
  const image = document.getElementById("project-picture");
  if (!image) return;
  try {
    const response = await fetch(`/api/p/${encodeURIComponent(slug)}/view`, { cache: "no-store" });
    if (!response.ok) return;
    image.src = URL.createObjectURL(await response.blob());
    image.hidden = false;
  } catch { /* a project without a saved view simply has no picture */ }
})();

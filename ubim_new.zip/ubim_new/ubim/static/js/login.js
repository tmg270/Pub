// The login page is a plain form; this only surfaces why a redirect landed here.
import { status } from "./api.js";

const params = new URLSearchParams(location.search);
if (params.get("failed")) status("Wrong user or password.", "err");
const error = params.get("error");
if (error) status(error, "err");

// Two-dimensional overlay on top of the panorama: angular grid, crosshair and measurements.
//
// Measurements are stored as directions (azimuth, elevation) plus a range, never as screen
// pixels, so they survive zooming, resizing and reopening. Each segment is sampled and
// projected separately; a segment that crosses behind the camera is broken rather than drawn
// through the viewer.

const COLOURS = ["#ffd166", "#4ea1ff", "#56d364", "#ff8fab", "#c792ea"];

export class Overlay {
  constructor(canvas, renderer) {
    this.canvas = canvas;
    this.renderer = renderer;
    this.context = canvas.getContext("2d");
    this.features = [];
    this.drawings = [];
    this.markers = [];
    this.measuring = false;
    this.selected = null;
    this.draft = null;
    this.showGrid = true;
  }

  resize() {
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.round(this.canvas.clientWidth * ratio);
    const height = Math.round(this.canvas.clientHeight * ratio);
    if (this.canvas.width !== width || this.canvas.height !== height) {
      this.canvas.width = width;
      this.canvas.height = height;
    }
    this.context.setTransform(ratio, 0, 0, ratio, 0, 0);
    this.width = this.canvas.clientWidth;
    this.height = this.canvas.clientHeight;
  }

  project(azimuth, elevation) {
    return this.renderer.anglesToScreen(azimuth, elevation);
  }

  draw() {
    this.resize();
    const ctx = this.context;
    ctx.clearRect(0, 0, this.width, this.height);
    if (this.showGrid) this.drawGrid();
    this.drawCrosshair();
    for (const shape of this.drawings) this.drawDrawing(shape);
    if (!this.measuring) this.drawMarkers();
    for (const feature of this.features) this.drawFeature(feature, feature.id === this.selected);
    if (this.draft) this.drawFeature(this.draft, true, true);
  }

  drawGrid() {
    const ctx = this.context;
    ctx.save();
    ctx.lineWidth = 1;
    ctx.strokeStyle = "rgba(150, 175, 205, 0.22)";
    ctx.fillStyle = "rgba(180, 200, 225, 0.55)";
    ctx.font = "11px ui-monospace, monospace";
    const fov = this.renderer.fov;
    const stepAz = fov > 90 ? 45 : fov > 45 ? 30 : 15;
    const stepEl = stepAz / 2;

    for (let azimuth = -180; azimuth < 180; azimuth += stepAz) {
      const points = [];
      for (let elevation = -89; elevation <= 89; elevation += 2) {
        const hit = this.project((azimuth * Math.PI) / 180, (elevation * Math.PI) / 180);
        points.push(hit);
      }
      this.strokePolyline(points);
      // Labelled as a bearing, not as the stored azimuth: a bearing rises to the right, which
      // is what a reader expects of a compass, while the scan's azimuth rises to the left.
      const label = this.project((azimuth * Math.PI) / 180, (8 * Math.PI) / 180);
      if (label) ctx.fillText(`${(-azimuth + 360) % 360}°`, label.x + 4, label.y - 4);
    }
    for (let elevation = -75; elevation <= 90; elevation += stepEl) {
      const points = [];
      for (let azimuth = -180; azimuth <= 180; azimuth += 2) {
        const hit = this.project((azimuth * Math.PI) / 180, (elevation * Math.PI) / 180);
        points.push(hit);
      }
      this.strokePolyline(points);
      const label = this.project(0, (elevation * Math.PI) / 180);
      if (label) ctx.fillText(`${elevation}°`, label.x + 4, label.y - 4);
    }
    ctx.restore();
  }

  drawCrosshair() {
    const ctx = this.context;
    const cx = this.width / 2;
    const cy = this.height / 2;
    ctx.save();
    ctx.strokeStyle = "rgba(255,255,255,0.5)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx - 9, cy); ctx.lineTo(cx - 3, cy);
    ctx.moveTo(cx + 3, cy); ctx.lineTo(cx + 9, cy);
    ctx.moveTo(cx, cy - 9); ctx.lineTo(cx, cy - 3);
    ctx.moveTo(cx, cy + 3); ctx.lineTo(cx, cy + 9);
    ctx.stroke();
    ctx.restore();
  }

  strokePolyline(points) {
    const ctx = this.context;
    ctx.beginPath();
    let drawing = false;
    for (const point of points) {
      if (!point) { drawing = false; continue; }
      if (drawing) ctx.lineTo(point.x, point.y);
      else { ctx.moveTo(point.x, point.y); drawing = true; }
    }
    ctx.stroke();
  }

  // A draped drawing is not a measurement: it is fixed, so it is drawn thinner, dashed and
  // without the vertex handles that invite a click.
  drawDrawing(shape) {
    const ctx = this.context;
    const points = shape.points || [];
    if (points.length < 2) return;
    ctx.save();
    ctx.strokeStyle = shape.colour || "rgba(99, 210, 255, .92)";
    // A DXF lineweight is a plotted width in millimetres, which says nothing about pixels on
    // a screen, so it is used as a hint: heavier plotted lines are drawn heavier here.
    const millimetres = Number(shape.widthMm) || 0;
    ctx.lineWidth = Math.min(6, Math.max(1.2, 1.2 + millimetres / 2));
    ctx.setLineDash([6, 4]);
    const projected = [];
    for (let index = 0; index < points.length - 1; index += 1) {
      const from = points[index];
      const to = points[index + 1];
      const steps = Math.max(6, Math.round(angleBetween(from, to) * 40));
      for (let step = 0; step <= steps; step += 1) {
        projected.push(this.project(
          from.az + ((to.az - from.az) * step) / steps,
          from.el + ((to.el - from.el) * step) / steps,
        ));
      }
    }
    ctx.beginPath();
    this.strokePolyline(projected);
    ctx.restore();
  }

  // Other scans of this project, at their measured direction. A dot shrinks with distance so a
  // scan across the site does not look as close as the one beside you.
  drawMarkers() {
    const ctx = this.context;
    for (const marker of this.markers) {
      const point = this.project(marker.az, marker.el);
      if (!point) continue;
      const size = Math.max(5, Math.min(11, 150 / Math.max(1, marker.distance)));
      ctx.save();
      ctx.beginPath();
      ctx.arc(point.x, point.y, size, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255, 196, 92, .14)";
      ctx.strokeStyle = "rgba(255, 196, 92, .95)";
      ctx.lineWidth = 1.6;
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(point.x, point.y, 1.8, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255, 214, 140, .95)";
      ctx.fill();
      const text = `${marker.scan} · ${marker.distance.toFixed(1)} m`;
      ctx.font = "11px ui-sans-serif, system-ui, sans-serif";
      const width = ctx.measureText(text).width;
      ctx.fillStyle = "rgba(12, 16, 22, .78)";
      ctx.fillRect(point.x + size + 4, point.y - 9, width + 8, 17);
      ctx.fillStyle = "rgba(255, 226, 180, .96)";
      ctx.fillText(text, point.x + size + 8, point.y + 3);
      ctx.restore();
    }
  }

  markerAt(x, y, reach = 16) {
    for (const marker of this.markers) {
      const point = this.project(marker.az, marker.el);
      if (!point) continue;
      if ((point.x - x) ** 2 + (point.y - y) ** 2 <= reach * reach) return marker;
    }
    return null;
  }

  drawFeature(feature, isSelected, isDraft = false) {
    const ctx = this.context;
    const points = feature.points || [];
    if (!points.length) return;
    const colour = isDraft ? "#ffffff" : feature.colour || COLOURS[(feature.layer_id || 0) % COLOURS.length];
    ctx.save();
    ctx.strokeStyle = colour;
    ctx.fillStyle = colour;
    ctx.lineWidth = isSelected ? 2.5 : 1.8;
    ctx.setLineDash(isDraft ? [5, 4] : []);

    if (points.length > 1) {
      const projected = [];
      for (let index = 0; index < points.length - 1; index += 1) {
        const from = points[index];
        const to = points[index + 1];
        const steps = Math.max(8, Math.round(angleBetween(from, to) * 60));
        for (let step = 0; step <= steps; step += 1) {
          const azimuth = from.az + ((to.az - from.az) * step) / steps;
          const elevation = from.el + ((to.el - from.el) * step) / steps;
          projected.push(this.project(azimuth, elevation));
        }
      }
      if (feature.kind === "area" && points.length > 2) {
        ctx.beginPath();
        let drawing = false;
        for (const point of projected) {
          if (!point) { drawing = false; continue; }
          if (drawing) ctx.lineTo(point.x, point.y); else { ctx.moveTo(point.x, point.y); drawing = true; }
        }
        ctx.closePath();
        ctx.globalAlpha = 0.18;
        ctx.fill();
        ctx.globalAlpha = 1;
      }
      ctx.beginPath();
      this.strokePolyline(projected);
    }

    for (const point of points) {
      const hit = this.project(point.az, point.el);
      if (!hit) continue;
      ctx.beginPath();
      ctx.arc(hit.x, hit.y, isSelected ? 5 : 3.5, 0, Math.PI * 2);
      ctx.fillStyle = "#0b0e12";
      ctx.fill();
      ctx.strokeStyle = colour;
      ctx.stroke();
    }

    const label = feature.label || describe(feature);
    const anchor = this.project(points[0].az, points[0].el);
    if (label && anchor) {
      ctx.font = "12px ui-monospace, monospace";
      const width = ctx.measureText(label).width;
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = "#0b0e12";
      ctx.fillRect(anchor.x + 8, anchor.y - 22, width + 8, 16);
      ctx.globalAlpha = 1;
      ctx.fillStyle = colour;
      ctx.fillText(label, anchor.x + 12, anchor.y - 10);
    }
    ctx.restore();
  }
}

export function describe(feature) {
  const points = feature.points || [];
  if (feature.kind === "point" && points.length) {
    const point = points[0];
    return point.r ? `${point.r.toFixed(0)}` : "point";
  }
  if (points.length < 2) return "";
  let total = 0;
  for (let index = 0; index < points.length - 1; index += 1) {
    total += angleBetween(points[index], points[index + 1]);
  }
  return `${total.toFixed(1)}°`;
}

function angleBetween(a, b) {
  const cos = Math.sin(a.el) * Math.sin(b.el) + Math.cos(a.el) * Math.cos(b.el) * Math.cos(a.az - b.az);
  return Math.acos(Math.max(-1, Math.min(1, cos)));
}

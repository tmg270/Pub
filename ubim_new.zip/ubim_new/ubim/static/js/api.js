// Thin fetch wrapper: same-origin, cookie carrying, CSRF on every unsafe method.
let csrfToken = null;

export async function api(path, { method = "GET", body, raw = false, headers = {} } = {}) {
  const options = { method, credentials: "same-origin", headers: { ...headers } };
  if (body !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  if (method !== "GET" && !csrfToken) {
    // A POST made before the identity request has finished would carry no token and be
    // refused; wait for it instead of losing the user's edit.
    const who = await me();
    if (who?.authenticated) csrfToken = who.csrf;
  }
  if (method !== "GET" && csrfToken) options.headers["X-CSRF-Token"] = csrfToken;
  let response = await fetch(path, options);
  if (response.status === 403 && method !== "GET") {
    // A write refused for its token is worth one retry with a freshly read token: the
    // session's token can be newer than the one this page started with.
    const who = await me(true);
    if (who?.authenticated && who.csrf) {
      csrfToken = who.csrf;
      options.headers["X-CSRF-Token"] = who.csrf;
      response = await fetch(path, options);
    }
  }
  if (!response.ok) {
    let detail = response.statusText;
    try {
      const data = await response.json();
      detail = data.detail || data.error || detail;
    } catch { /* not JSON */ }
    const error = new Error(`${response.status} ${detail}`);
    error.status = response.status;
    throw error;
  }
  return raw ? response : response.json();
}

export async function me(force = false) {
  if (!me.cached || force) {
    me.cached = api("/api/me");
  }
  const who = await me.cached;
  if (who.authenticated) csrfToken = who.csrf;
  return who;
}

export function status(text, kind = "") {
  const node = document.getElementById("status");
  if (!node) return;
  node.textContent = text || "";
  node.className = `status ${kind}`.trim();
}

export function toast(text, kind = "") {
  const node = document.createElement("div");
  node.className = `toast ${kind}`.trim();
  node.textContent = text;
  document.body.appendChild(node);
  setTimeout(() => node.remove(), 4200);
}

export function el(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (key === "class") node.className = value;
    else if (key === "dataset") Object.assign(node.dataset, value);
    else if (key.startsWith("on")) node.addEventListener(key.slice(2), value);
    else if (value !== undefined && value !== null) node.setAttribute(key, value);
  }
  for (const child of [].concat(children)) {
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return node;
}

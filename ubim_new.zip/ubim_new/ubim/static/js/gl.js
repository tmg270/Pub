// Panorama renderer for WebGL2.
//
// There is no sphere mesh here. Every pixel casts one ray from the camera and looks up the
// equirectangular texture with the exact angle of that ray, so the mapping cannot drift from
// the data: no tessellation, no seams, no interpolation between rows. It is also the cheapest
// possible thing to draw — three vertices, one full-screen triangle.
//
// The camera is yaw/pitch/fov, expressed in the same azimuth/elevation frame the intensity
// and depth products use.

const VERT = `#version 300 es
const vec2 POS[3] = vec2[3](vec2(-1.0, -1.0), vec2(3.0, -1.0), vec2(-1.0, 3.0));
out vec2 vPos;
void main() {
  vPos = POS[gl_VertexID];
  gl_Position = vec4(vPos, 0.0, 1.0);
}`;

const FRAG = `#version 300 es
precision highp float;
in vec2 vPos;
out vec4 outColor;

uniform vec2 uRes;
uniform float uYaw;      // radians, azimuth of the view centre
uniform float uPitch;    // radians, elevation of the view centre
uniform float uFov;      // vertical field of view, degrees
uniform sampler2D uTex;
uniform vec3 uMapping;   // az0, top, span in degrees
uniform float uGain;
uniform int uHasTexture;
uniform int uChecker;    // 1 = draw the "no texture" checkerboard

const float PI = 3.141592653589793;

vec3 viewDirection(vec2 p) {
  float aspect = uRes.x / uRes.y;
  float t = tan(radians(uFov) * 0.5);
  vec3 f = vec3(cos(uPitch) * cos(uYaw), sin(uPitch), cos(uPitch) * sin(uYaw));
  vec3 r = normalize(cross(vec3(0.0, 1.0, 0.0), f));
  vec3 u = cross(f, r);
  return normalize(f + r * (p.x * aspect * t) + u * (p.y * t));
}

void main() {
  vec2 p = vPos;
  vec3 d = viewDirection(p);
  float elevation = asin(clamp(d.y, -1.0, 1.0));
  float azimuth = atan(d.z, d.x);

  float span = radians(uMapping.z);
  float top = radians(uMapping.y);
  float az0 = radians(uMapping.x);

  float v = (top - elevation) / span;
  if (v < 0.0 || v > 1.0) {
    outColor = vec4(0.06, 0.075, 0.09, 1.0);
    return;
  }

  if (uHasTexture == 0) {
    float check = mod(floor(p.x * 8.0) + floor(p.y * 8.0), 2.0);
    outColor = vec4(mix(vec3(0.10, 0.12, 0.15), vec3(0.13, 0.15, 0.19), check), 1.0);
    return;
  }

  // Column x of the products is azimuth az0 - 2*pi*x/width, so u = (az0 - az) / 2*pi.
  float delta = az0 - azimuth;
  delta = mod(delta + PI, 2.0 * PI) - PI;      // shortest way round the seam
  float u = delta / (2.0 * PI);
  if (u < 0.0) u += 1.0;

  vec4 texel = texture(uTex, vec2(u, v));
  if (texel.a < 0.5) {
    outColor = vec4(0.06, 0.075, 0.09, 1.0);
    return;
  }
  outColor = vec4(texel.rgb * uGain, 1.0);
}`;

function compile(gl, type, source) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    const log = gl.getShaderInfoLog(shader);
    gl.deleteShader(shader);
    throw new Error(`shader: ${log}`);
  }
  return shader;
}

export class PanoRenderer {
  constructor(canvas) {
    this.canvas = canvas;
    const gl = canvas.getContext("webgl2", {
      antialias: false, depth: false, stencil: false, alpha: false,
      preserveDrawingBuffer: false, powerPreference: "high-performance",
    });
    if (!gl) throw new Error("WebGL2 is not available in this browser");
    this.gl = gl;
    this.yaw = 0;
    this.pitch = 0;
    this.fov = 75;
    this.gain = 1.0;
    this.hasTexture = false;
    this.checker = true;
    this.mapping = { az0Deg: -0.07, topDeg: 90.18, spanDeg: 180.65 };
    this.texture = null;
    this.textureSize = [0, 0];

    const program = gl.createProgram();
    gl.attachShader(program, compile(gl, gl.VERTEX_SHADER, VERT));
    gl.attachShader(program, compile(gl, gl.FRAGMENT_SHADER, FRAG));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      throw new Error(`link: ${gl.getProgramInfoLog(program)}`);
    }
    this.program = program;
    this.uniforms = {};
    for (const name of ["uRes", "uYaw", "uPitch", "uFov", "uTex", "uMapping", "uGain", "uHasTexture", "uChecker"]) {
      this.uniforms[name] = gl.getUniformLocation(program, name);
    }
    this.vao = gl.createVertexArray();
    this.canvas.addEventListener("webglcontextlost", (event) => {
      event.preventDefault();
      this.hasTexture = false;
    });
  }

  resize() {
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.round(this.canvas.clientWidth * ratio));
    const height = Math.max(1, Math.round(this.canvas.clientHeight * ratio));
    if (this.canvas.width !== width || this.canvas.height !== height) {
      this.canvas.width = width;
      this.canvas.height = height;
    }
    return [width, height];
  }

  setMapping(mapping) {
    if (mapping) this.mapping = { ...this.mapping, ...mapping };
  }

  setTexture(source, width, height) {
    const gl = this.gl;
    if (this.texture) gl.deleteTexture(this.texture);
    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
    const wrap = gl.CLAMP_TO_EDGE;
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrap);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    this.texture = texture;
    this.textureSize = [width ?? source.width, height ?? source.height];
    this.hasTexture = true;
    this.checker = false;
  }

  clearTexture() {
    if (this.texture) {
      this.gl.deleteTexture(this.texture);
      this.texture = null;
    }
    this.hasTexture = false;
    this.checker = true;
  }

  draw() {
    const gl = this.gl;
    const [width, height] = this.resize();
    gl.viewport(0, 0, width, height);
    gl.useProgram(this.program);
    gl.uniform2f(this.uniforms.uRes, width, height);
    gl.uniform1f(this.uniforms.uYaw, this.yaw);
    gl.uniform1f(this.uniforms.uPitch, this.pitch);
    gl.uniform1f(this.uniforms.uFov, this.fov);
    gl.uniform1f(this.uniforms.uGain, this.gain);
    gl.uniform1i(this.uniforms.uHasTexture, this.hasTexture ? 1 : 0);
    gl.uniform1i(this.uniforms.uChecker, this.checker ? 1 : 0);
    gl.uniform3f(
      this.uniforms.uMapping,
      this.mapping.az0Deg, this.mapping.topDeg, this.mapping.spanDeg,
    );
    if (this.texture) {
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.texture);
      gl.uniform1i(this.uniforms.uTex, 0);
    }
    gl.bindVertexArray(this.vao);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }

  /** Pixel position (CSS pixels, origin top-left) to azimuth/elevation in radians. */
  screenToAngles(x, y) {
    const width = this.canvas.clientWidth || 1;
    const height = this.canvas.clientHeight || 1;
    const aspect = width / height;
    const t = Math.tan((this.fov * Math.PI) / 360);
    const px = (x / width) * 2 - 1;
    const py = 1 - (y / height) * 2;
    const f = [
      Math.cos(this.pitch) * Math.cos(this.yaw),
      Math.sin(this.pitch),
      Math.cos(this.pitch) * Math.sin(this.yaw),
    ];
    const r = normalize(cross([0, 1, 0], f));
    const up = cross(f, r);
    const d = normalize([
      f[0] + r[0] * px * aspect * t + up[0] * py * t,
      f[1] + r[1] * px * aspect * t + up[1] * py * t,
      f[2] + r[2] * px * aspect * t + up[2] * py * t,
    ]);
    const elevation = Math.asin(Math.max(-1, Math.min(1, d[1])));
    const azimuth = Math.atan2(d[2], d[0]);
    return { azimuth, elevation };
  }

  /** Azimuth/elevation in radians to CSS pixel position, or null when behind the camera. */
  anglesToScreen(azimuth, elevation) {
    const width = this.canvas.clientWidth || 1;
    const height = this.canvas.clientHeight || 1;
    const aspect = width / height;
    const t = Math.tan((this.fov * Math.PI) / 360);
    const d = [
      Math.cos(elevation) * Math.cos(azimuth),
      Math.sin(elevation),
      Math.cos(elevation) * Math.sin(azimuth),
    ];
    const f = [
      Math.cos(this.pitch) * Math.cos(this.yaw),
      Math.sin(this.pitch),
      Math.cos(this.pitch) * Math.sin(this.yaw),
    ];
    const r = normalize(cross([0, 1, 0], f));
    const up = cross(f, r);
    const z = dot(d, f);
    if (z <= 0.0001) return null;
    const px = dot(d, r) / z / (aspect * t);
    const py = dot(d, up) / z / t;
    return { x: (px + 1) * 0.5 * width, y: (1 - py) * 0.5 * height };
  }

  zoom(factor) {
    this.fov = Math.max(8, Math.min(110, this.fov * factor));
  }
}

function cross(a, b) {
  return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
}
function dot(a, b) {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}
function normalize(v) {
  const length = Math.hypot(v[0], v[1], v[2]) || 1;
  return [v[0] / length, v[1] / length, v[2] / length];
}

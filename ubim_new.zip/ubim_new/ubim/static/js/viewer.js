// The scan viewer.
//
// Modes switch between the FARO grey panorama that ships with the scan and the products this
// server builds from the .fls itself (intensity and depth). Both kinds of texture are drawn
// as plain equirectangular images through the ray-per-pixel shader in gl.js, so a change of
// mode never changes the geometry under a measurement.

import { api, el, me, status, toast } from "./api.js";
import { PanoRenderer } from "./gl.js";
import { Overlay, describe } from "./overlay.js";

const boot = JSON.parse(document.getElementById("boot").textContent);
const state = {
  project: boot.project,
  scan: boot.scan,
  meta: null,
  mode: "grey",
  ramp: "grey",
  detail: "auto",
  snap: true,
  hd: false,
  tool: null,
  draft: null,
  features: [],
  layers: [],
  selected: null,
  busy: false,
  canEdit: false,
  textureKey: "",
};

const canvas = document.getElementById("pano");
const compass = document.getElementById("compass");
// Declared here, before any toolbar is built: a control reads these while the toolbar is
// assembled, and a `let` further down the file would be in its temporal dead zone.
const drape = { on: false, height: 0 };
let loupeOn = false;
let pointer = null;
const loupe = document.getElementById("loupe");
const overlayCanvas = document.getElementById("overlay");
const panel = document.getElementById("panel");
const loading = document.getElementById("loading");

let renderer;
let overlay;
let needsDraw = true;

function setLoading(text) {
  if (!text) {
    loading.hidden = true;
    return;
  }
  loading.hidden = false;
  loading.textContent = text;
}

function apiPath(suffix = "") {
  return `/api/p/${encodeURIComponent(state.project)}/s/${encodeURIComponent(state.scan)}${suffix}`;
}

function draw() {
  if (!renderer) return;
  if (needsDraw) {
    renderer.draw();
    overlay.draw();
    if (!compass.hidden) drawCompass();
    needsDraw = false;
    if (loupeOn) drawLoupe();
  }
  requestAnimationFrame(draw);
}

function anglesAtEvent(event) {
  const rect = canvas.getBoundingClientRect();
  return renderer.screenToAngles(event.clientX - rect.left, event.clientY - rect.top);
}

// -- textures -------------------------------------------------------------

async function loadPanorama() {
  // A scan with a photograph product has it tiled at its native size, which is sharper than
  // any single capped JPEG and only loads the tiles in view.
  if (state.meta?.products?.photo?.built) {
    await loadTiles("photo");
    return;
  }
  const size = state.hd ? 8190 : 4096;
  const url = `${apiPath("/pano/grey_hd")}?max_size=${size}`;
  const image = new Image();
  image.decoding = "async";
  const loaded = new Promise((resolve, reject) => {
    image.onload = () => resolve();
    image.onerror = () => reject(new Error("panoramic image failed to load"));
  });
  image.src = url;
  setLoading("Loading grey panoramic image…");
  try {
    await loaded;
  } catch (error) {
    // A .f3s project may ship no FARO panorama at all. Rather than an empty view, show the
    // scan's own colour product and say that is what it is.
    await loadTiles("intensity");
    state.fallback = "colour";
    return;
  }
  renderer.setTexture(image, image.naturalWidth, image.naturalHeight);
  needsDraw = true;
}

function gpuLimit() {
  // Asking for a texture wider than MAX_TEXTURE_SIZE uploads nothing at all, which looks
  // exactly like a product that failed to build: a black screen. Clamp to what the GPU has.
  const limit = renderer?.gl?.getParameter(renderer.gl.MAX_TEXTURE_SIZE);
  return Number(limit) > 0 ? Number(limit) : 4096;
}

function pickLevel(levels, maxWidth) {
  // Levels run from largest to smallest; take the sharpest one that still fits the GPU budget.
  const sorted = [...levels].sort((a, b) => b.width - a.width);
  return sorted.find((level) => level.width <= maxWidth) || sorted[sorted.length - 1];
}

async function loadTiles(kind) {
  const meta = await ensureProductMeta(kind);
  const levels = meta.levels || [];
  if (!levels.length) throw new Error(`${kind} product has no levels`);
  const level = pickLevel(levels, Math.min(state.hd ? 8190 : 4096, gpuLimit()));
  const ramp = kind === "intensity" ? state.ramp : "grey";
  const key = `${kind}:${ramp}:${level.z}:${state.hd}`;
  if (state.textureKey === key) return;
  setLoading(`Loading ${kind} level ${level.z}…`);
  const surface = document.createElement("canvas");
  surface.width = level.width;
  surface.height = level.height;
  const context = surface.getContext("2d");
  if (kind === "photo") {
    // A photograph has no holes: fill the surface black first, so a tile the builder skipped
    // (a pure-black patch of sky) is black like its neighbours instead of letting the
    // background shade show through as a faint rectangle.
    context.fillStyle = "#000";
    context.fillRect(0, 0, level.width, level.height);
  } else {
    context.fillStyle = "rgba(0,0,0,0)";
    context.clearRect(0, 0, level.width, level.height);
  }

  const base = `/api/p/${encodeURIComponent(state.project)}/s/${encodeURIComponent(state.scan)}`;
  const path = kind === "intensity" ? "intensity" : kind === "photo" ? "photo" : "depth";
  const jobs = [];
  const tile = meta.tile || 512;
  const wanted = Array.isArray(level.tileIndex) ? new Set(level.tileIndex.map(([col, row]) => `${col},${row}`)) : null;
  for (let col = 0; col < level.cols; col += 1) {
    for (let row = 0; row < level.rows; row += 1) {
      if (wanted && !wanted.has(`${col},${row}`)) continue;
      const suffix = "png";
      const url = `${base}/${path}/${kind === "intensity" ? `${ramp}/` : ""}${level.z}/${col}/${row}.${suffix}`;
      jobs.push({ url, col, row });
    }
  }
  let done = 0;
  const workers = new Array(6).fill(0).map(async () => {
    while (jobs.length) {
      const job = jobs.shift();
      try {
        const response = await fetch(job.url, { credentials: "same-origin" });
        if (response.ok) {
          const bitmap = await createImageBitmap(await response.blob());
          context.drawImage(bitmap, job.col * tile, job.row * tile);
          bitmap.close?.();
        }
      } catch { /* a missing tile is a hole, not an error */ }
      done += 1;
      const total = done + jobs.length;
      if (done % 8 === 0) setLoading(`Loading ${kind} tiles ${done}/${total} (${Math.round((done / total) * 100)}%)…`);
    }
  });
  await Promise.all(workers);
  renderer.setTexture(surface, level.width, level.height);
  state.textureKey = key;
  needsDraw = true;
}

async function applyMode(mode) {
  if (state.busy) return;
  state.busy = true;
  try {
    if (mode !== state.mode) state.textureKey = "";
    state.mode = mode;
    if (mode === "grey") {
      await loadPanorama();
    } else {
      await loadTiles(mode);
    }
    if (state.fallback === "colour") {
      status("colour view (from the scan's colour; this project has no panorama image)");
      state.fallback = null;
    } else {
      status(`${mode} view`);
    }
  } catch (error) {
    toast(error.message, "err");
    status(error.message, "err");
  } finally {
    state.busy = false;
    setLoading("");
    syncToolbar();
  }
}

// -- input ----------------------------------------------------------------

function installInput() {
  let dragging = false;
  let lastX = 0;
  let lastY = 0;
  let moved = 0;

  canvas.addEventListener("pointerdown", (event) => {
    canvas.setPointerCapture(event.pointerId);
    dragging = true;
    moved = 0;
    lastX = event.clientX;
    lastY = event.clientY;
    canvas.classList.add("dragging");
  });

  canvas.addEventListener("pointermove", (event) => {
    if (!dragging) return;
    const dx = event.clientX - lastX;
    const dy = event.clientY - lastY;
    lastX = event.clientX;
    lastY = event.clientY;
    moved += Math.abs(dx) + Math.abs(dy);
    const scale = (renderer.fov / 90) * (Math.PI / 180) * 0.6;
    renderer.yaw -= dx * scale;
    renderer.pitch = Math.max(-1.45, Math.min(1.45, renderer.pitch + dy * scale));
    needsDraw = true;
  });

  canvas.addEventListener("pointerup", (event) => {
    canvas.classList.remove("dragging");
    dragging = false;
    if (moved < 6) handleClick(event);
  });

  canvas.addEventListener("wheel", (event) => {
    event.preventDefault();
    renderer.zoom(event.deltaY > 0 ? 1.12 : 1 / 1.12);
    needsDraw = true;
  }, { passive: false });

  window.addEventListener("keydown", (event) => {
    if (event.target instanceof HTMLInputElement) return;
    if (event.key === "g") { overlay.showGrid = !overlay.showGrid; needsDraw = true; }
    if (event.key === "1") applyMode("grey");
    if (event.key === "2") applyMode("intensity");
    if (event.key === "3") applyMode("depth");
    if (event.key === "+" || event.key === "=") { renderer.zoom(1 / 1.15); needsDraw = true; }
    if (event.key === "-") { renderer.zoom(1.15); needsDraw = true; }
    if (event.key === "Escape") { state.draft = null; overlay.draft = null; needsDraw = true; syncToolbar(); }
    if (event.key === "Enter" && state.draft) finishDraft();
    if ((event.key === "Delete" || event.key === "Backspace") && state.selected) deleteFeature(state.selected);
  });

  window.addEventListener("resize", () => { needsDraw = true; });
}

async function resolveRange(azimuth, elevation, point) {
  // A direction is worth recording on its own; the range only exists once the product does.
  // A click made before the depth product is built is queued on the point and resolved when
  // the mark is finished, so it is not silently turned into an angles-only point.
  if (!state.meta?.products?.depth?.built) {
    point.pending = true;
    return point;
  }
  try {
    const hit = await api(apiPath("/pick"), {
      method: "POST",
      // Snapping looks for a real return near the click; turning it off records the direction
      // that was actually clicked, which is what you want when lining up a photograph.
      body: { az: deg(azimuth), el: deg(elevation), snap: state.snap },
    });
    point.r = hit.metres ?? null;  // metres, so exports and DXF carry a real unit
    point.azimuthDeg = deg(azimuth);
    point.elevationDeg = deg(elevation);
    point.heightUncertain = Boolean(hit.heightUncertain);
    point.uncertainBecause = hit.uncertainBecause || [];
  } catch { /* a hole in the range map leaves r null */ }
  return point;
}

// A measurement's value comes from the server, which computes it from the stored angles and
// ranges. The client only formats it, so the number on screen is the number in the export.
function summaryLine(feature) {
  const values = feature.metrics || {};
  if (values.complete === false) return `${feature.kind} · angles only`;
  if (typeof values.area === "number") return `area ${values.area.toFixed(2)} m²`;
  if (typeof values.length === "number") return `${feature.kind} ${values.length.toFixed(2)} m`;
  if (typeof values.groundHeight === "number") return `point ${values.groundHeight.toFixed(2)} m high`;
  return `${feature.kind} ${describe(feature)}`.trim();
}

function measureText(feature) {
  const values = feature.metrics || {};
  const parts = [];
  if (values.heightUncertain) parts.push("height uncertain");
  if (typeof values.area === "number" && typeof values.perimeter === "number") parts.push(`perimeter ${values.perimeter.toFixed(2)} m`);
  if (values.plane?.rmsMetres !== undefined) parts.push(`plane ±${(values.plane.rmsMetres * 1000).toFixed(0)} mm`);
  if (values.verticalDrop !== undefined && values.verticalDrop > 0) parts.push(`drop ${values.verticalDrop.toFixed(2)} m`);
  if (values.warning) parts.push(`⚠ ${values.warning}`);
  return parts.join(" · ");
}

async function handleClick(event) {
  if (!state.tool) {
    // No tool, so a click on another scan's dot is a jump to that scan.
    const box = canvas.getBoundingClientRect();
    const hit = overlay.markerAt(event.clientX - box.left, event.clientY - box.top);
    // The page route is /p/{slug}/{scan}; only the API puts a scan under /s/.
    if (hit) location.href = `/p/${encodeURIComponent(state.project)}/${encodeURIComponent(hit.scan)}`;
    return;
  }
  const { azimuth, elevation } = anglesAtEvent(event);
  if (state.tool === "point") {
    const point = await resolveRange(azimuth, elevation, { az: azimuth, el: elevation, r: null });
    await createFeature({ kind: "point", points: [point] });
    syncToolbar();
    return;
  }
  state.draft = state.draft || { kind: state.tool, points: [] };
  state.draft.points.push(await resolveRange(azimuth, elevation, { az: azimuth, el: elevation, r: null }));
  overlay.draft = state.draft;
  needsDraw = true;
  syncToolbar();  // a new draft point is what enables Finish, so the bar has to hear about it
  status(`${state.draft.points.length} points — Enter to finish, Escape to cancel`);
}

function deg(radians) {
  return (radians * 180) / Math.PI;
}

// == TOOLS ==

const productMeta = { intensity: null, depth: null };
const toolbar = document.getElementById("toolbar");

async function ensureProductMeta(kind) {
  if (productMeta[kind]) return productMeta[kind];
  const endpoint = { intensity: "/intensity/meta", depth: "/depth/meta", photo: "/photo/meta" }[kind];
  if (!endpoint) throw new Error(`unknown product ${kind}`);
  const meta = await api(apiPath(endpoint));
  productMeta[kind] = meta;
  return meta;
}

function control(label, onClick, { active = false, title = "", disabled = false } = {}) {
  return el("button", {
    type: "button",
    title: title || label,
    "aria-pressed": active ? "true" : "false",
    disabled: disabled || undefined,
    onclick: onClick,
  }, label);
}

function group(...children) {
  return el("div", { class: "group" }, children);
}

function detailAllowsFull() {
  if (state.detail === "max") return gpuLimit() > 4096;
  if (state.detail === "standard") return false;
  // Auto: only ask for the full pyramid when the GPU can hold a texture that size and the
  // screen is dense enough that the difference would be visible.
  return gpuLimit() >= 8192 && (window.devicePixelRatio || 1) >= 1.5;
}

function setDetail(level) {
  state.detail = level;
  state.hd = detailAllowsFull();
  state.textureKey = "";
  applyMode(state.mode);
  api("/api/settings", { method: "PUT", body: { detail: level } }).catch(() => {});
  toast(`Detail: ${level === "auto" ? "auto" : level}`);
}

function buildToolbar() {
  const modes = group(
    control("Grey", () => applyMode("grey"), { active: state.mode === "grey", title: "FARO grey panoramic image (1)" }),
    control("Intensity", () => applyMode("intensity"), { active: state.mode === "intensity", title: "Intensity from the scan file (2)" }),
    control("Depth", () => applyMode("depth"), { active: state.mode === "depth", title: "Range image from the scan file (3)" }),
  );
  const look = group(
    control("Grey ramp", () => { state.ramp = "grey"; state.textureKey = ""; applyMode("intensity"); }, { active: state.ramp === "grey" }),
    control("Rainbow", () => { state.ramp = "rainbow"; state.textureKey = ""; applyMode("intensity"); }, { active: state.ramp === "rainbow" }),
    group(
      control("Auto", () => setDetail("auto"), { active: state.detail === "auto", title: "Pull what this screen can show" }),
      control("Standard", () => setDetail("standard"), { active: state.detail === "standard", title: "Bounded textures; least memory" }),
      control("Max", () => setDetail("max"), { active: state.detail === "max", title: "Every pixel the product has" }),
    ),
  );
  const tools = group(
    control("Snap", () => { state.snap = !state.snap; syncToolbar(); toast(`Snapping ${state.snap ? "on" : "off"}`); },
      { active: state.snap, title: "Search ±3 cells for a real laser return (off: record the clicked direction)" }),
    control("Point", () => setTool("point"), { active: state.tool === "point", disabled: !state.canEdit }),
    control("Line", () => setTool("line"), { active: state.tool === "line", disabled: !state.canEdit }),
    control("Area", () => setTool("area"), { active: state.tool === "area", disabled: !state.canEdit }),
    control("Finish", () => finishDraft(), { disabled: !state.draft }),
    control("Undo", () => undoLast(), { disabled: !state.canEdit }),
  );
  const cad = group(
    control("Drawings", () => { drape.on = !drape.on; loadDrawings(); syncToolbar(); }, { active: drape.on, title: "Show the project's drawings over the scan" }),
    control("Height", () => setDrapeHeight(), { disabled: !drape.on, title: "Height to drape the drawings at" }),
  );
  const view = group(
    control("Grid", () => { overlay.showGrid = !overlay.showGrid; needsDraw = true; syncToolbar(); }, { active: overlay.showGrid }),
    control("Reset", () => { renderer.yaw = 0; renderer.pitch = 0; renderer.fov = 75; needsDraw = true; }),
    control("Info", () => { panel.hidden = !panel.hidden; if (!panel.hidden) renderPanel(); syncToolbar(); }, { active: !panel.hidden }),
    control("North", () => {
      compass.hidden = !compass.hidden;
      if (!compass.hidden) drawCompass();
      syncToolbar();
    }, { active: !compass.hidden, title: "Compass and field of view" }),
    control("Loupe", () => { loupeOn = !loupeOn; loupe.hidden = !loupeOn; needsDraw = true; syncToolbar(); }, { active: loupeOn, title: "Magnifier that follows the pointer" }),
    control("Save view", () => saveView(), { title: "Use this view as the project picture (S)" }),
    control("Full", () => {
      const stage = document.getElementById("viewer");
      if (document.fullscreenElement) document.exitFullscreen();
      else if (stage?.requestFullscreen) stage.requestFullscreen();
      else status("this browser does not allow full screen", "err");
    }, { title: "Full screen (F)" }),
  );
  toolbar.replaceChildren(modes, look, tools, cad, view);
}

const syncToolbar = buildToolbar;

function setTool(tool) {
  state.tool = state.tool === tool ? null : tool;
  overlay.measuring = !!state.tool;
  state.draft = null;
  overlay.draft = null;
  needsDraw = true;
  syncToolbar();
  status(state.tool ? `${tool} tool: click to add points` : "view only");
}

function renderPanel() {
  if (!state.meta) return;
  const geometry = state.meta.geometry || {};
  const rows = [
    ["Scan", state.meta.scan],
    ["Kind", state.meta.kind],
    ["Size", `${(state.meta.size / (1 << 20)).toFixed(1)} MiB`],
    ["Grid", `${geometry.cols ?? "?"} × ${geometry.rows ?? "?"}`],
    ["Azimuth", geometry.azimuthFirstDeg != null ? `${geometry.azimuthFirstDeg.toFixed(2)}° … ${geometry.azimuthLastDeg?.toFixed(2)}°` : "n/a"],
    ["Elevation", geometry.elevationTopDeg != null ? `${geometry.elevationTopDeg.toFixed(2)}° … ${geometry.elevationBottomDeg.toFixed(2)}°` : "n/a"],
    ["Images", (Object.keys(state.meta.images || {}).join(", ") || "none")],
    ...(state.meta.memory?.capMiB ? [["Build cap", `${state.meta.memory.capMiB} MiB`]] : []),
    ...(state.meta.memory?.freeMiB != null ? [[
      "Disk free",
      `${(state.meta.memory.freeMiB / 1024).toFixed(1)} GiB` +
        (state.meta.memory.low ? ` — below the ${(state.meta.memory.guardMiB / 1024).toFixed(0)} GiB guard` : ""),
    ]] : []),
  ];
  const rowsNode = el("div", { style: "display:grid;gap:6px" }, rows.map(([key, value]) =>
    el("div", { class: "row" }, [el("span", {}, key), el("span", {}, String(value))])));

  const products = [];
  for (const kind of ["intensity", "depth", "photo"]) {
    const entry = state.meta.products?.[kind];
    if (kind === "photo" && !entry?.available && !entry?.built) continue;
    const built = entry?.built;
    products.push(el("div", { class: "row" }, [
      el("span", {}, kind),
      el("span", {}, built ? "built" : "not built"),
    ]));
    if (!built && state.canEdit) {
      // The server's own estimate, shown before the button is pressed rather than after a job
      // fails (spec C4). A kind the server could not size simply carries no figure.
      const need = state.meta.memory?.perKind?.[kind];
      const label = need ? `Build ${kind} (needs ~${need} MiB)` : `Build ${kind}`;
      products.push(el("div", { class: "actions" }, [control(label, () => buildProduct(kind))]));
    } else if (built && kind === "photo") {
      products.push(el("div", { class: "row" }, [
        el("span", {}, "tiles"),
        el("span", {}, `${entry?.width ?? "?"} × ${entry?.height ?? "?"}`),
      ]));
    }
  }

  const list = state.features.length
    ? el("ul", {}, state.features.map((feature) => el("li", {}, [
        el("span", {}, summaryLine(feature)),
        measureText(feature) ? el("div", { class: "muted small" }, measureText(feature)) : "",
        " ",
        state.canEdit ? el("button", { class: "link", onclick: () => deleteFeature(feature.id) }, "delete") : "",
      ])))
    : el("p", { class: "muted small" }, "No measurements on this scan yet.");

  const scroll = panel.scrollTop;
  panel.replaceChildren(
    el("h2", {}, "Scan"),
    rowsNode,
    el("h2", {}, "Products"),
    el("div", { style: "display:grid;gap:6px" }, products),
    el("h2", {}, "Measurements"),
    list,
    el("h2", {}, "Export"),
    el("div", { class: "actions" }, [
      el("a", { href: apiPath("/export.dxf"), download: "" }, "DXF"),
      el("a", { href: apiPath("/export.json"), download: "" }, "JSON"),
      el("a", { href: apiPath("/export.csv"), download: "" }, "CSV"),
      el("a", { href: apiPath("/export.e57"), download: "" }, "E57"),
    ]),
    el("h2", {}, "Accuracy"),
    el("p", { class: "muted small" }, state.meta.accuracy || "Readings are scan-local and not survey control."),
    el("p", { class: "muted small" }, "Drag to look, wheel to zoom. 1/2/3 switch modes, G toggles the grid."),
  );
  // Re-rendering replaces every node, so put the panel back where it was rather than jumping
  // to the top whenever a measurement is saved or deleted.
  panel.scrollTop = scroll;
}

async function buildProduct(kind) {
  try {
    const job = await api(apiPath("/process"), { method: "POST", body: { kinds: [kind] } });
    const bar = el("div", { class: "progress" }, [el("i")]);
    panel.append(bar);
    for (;;) {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      const progress = await api(`/api/jobs/${job.id}`);
      bar.firstChild.style.width = `${Math.round((progress.progress || 0) * 100)}%`;
      status(`${kind}: ${progress.stage || progress.state} ${Math.round((progress.progress || 0) * 100)}%`);
      if (progress.state === "done") { toast(`${kind} built`, "ok"); break; }
      if (progress.state === "failed") { toast(progress.message || "build failed", "err"); break; }
    }
    productMeta[kind] = null;
    state.textureKey = "";
    state.meta = await api(apiPath("/meta"));
    await applyMode(kind);
    renderPanel();
  } catch (error) {
    toast(error.message, "err");
  }
}

async function loadNeighbours() {
  try {
    const data = await api(apiPath("/neighbours"));
    const radians = Math.PI / 180;
    overlay.markers = (data.neighbours || [])
      .filter((other) => !other.coincident && other.az !== null)
      .map((other) => ({
        scan: other.scan,
        distance: other.distance,
        az: other.az * radians,
        el: other.el * radians,
      }));
    const hidden = (data.neighbours || []).filter((other) => other.coincident).length;
    if (hidden) {
      status(`${hidden} other scan${hidden === 1 ? "" : "s"} share this position, so there is no direction to draw yet`);
    }
    needsDraw = true;
  } catch (error) {
    overlay.markers = [];
  }
}

async function refreshFeatures() {
  try {
    const data = await api(apiPath("/features"));
    state.layers = data.layers || [];
    state.features = data.features || [];
    const visible = new Set(state.layers.filter((layer) => layer.visible).map((layer) => layer.id));
    overlay.features = state.features.filter((feature) => visible.has(feature.layer_id));
    needsDraw = true;
  } catch (error) {
    status(error.message, "err");
  }
}

async function createFeature(payload) {
  try {
    await api(apiPath("/features"), { method: "POST", body: payload });
    state.draft = null;
    overlay.draft = null;
    await refreshFeatures();
    status(`${payload.kind} saved`);
  } catch (error) {
    toast(error.message, "err");
  }
}

async function flushQueuedPicks(points) {
  // Queued picks: a point clicked before the depth product existed keeps its angles. If the
  // product has arrived by the time the mark is finished, the ranges are looked up now.
  const pending = points.filter((point) => point.pending);
  if (!pending.length) return points;
  if (!state.meta?.products?.depth?.built) {
    toast(`${pending.length} pick(s) have no range yet · build the depth product to fill them in`);
    return points;
  }
  await Promise.all(pending.map((point) => resolveRange(point.az, point.el, point)));
  const filled = pending.filter((point) => point.r !== null).length;
  if (filled) toast(`${filled} queued pick(s) resolved`);
  return points;
}

async function finishDraft() {
  if (!state.draft || state.draft.points.length < 2) return;
  const label = await askLabel(state.draft.kind);
  if (label === null) return;  // cancelled: the draft stays so the mark is not lost
  await flushQueuedPicks(state.draft.points);
  const points = state.draft.points.map((point) => ({
    az: point.az, el: point.el, r: point.r ?? null,
    ...(point.heightUncertain ? { uncertain: true } : {}),
  }));
  await createFeature({ kind: state.draft.kind, points, label: label || null });
  syncToolbar();
  if (!panel.hidden) renderPanel();
}

async function deleteFeature(featureId) {
  try {
    await api(apiPath(`/features/${featureId}`), { method: "DELETE" });
    if (state.selected === featureId) state.selected = null;
    await refreshFeatures();
    if (!panel.hidden) renderPanel();
  } catch (error) {
    toast(error.message, "err");
  }
}

async function undoLast() {
  try {
    const result = await api(apiPath("/undo"), { method: "POST", body: {} });
    await refreshFeatures();
    toast(result.reverted ? `undid ${result.reverted} mark(s)` : "nothing to undo");
    if (!panel.hidden) renderPanel();
  } catch (error) {
    toast(error.message, "err");
  }
}

function showNoWebGL() {
  // Without a WebGL2 context there is nothing to draw, so replace the canvas with a sentence
  // rather than leaving the page on "Loading scan…" for ever.
  const note = el("p", { class: "no-gl" },
    "This browser cannot create a WebGL2 context, so the panorama cannot be drawn here. " +
    "The measurements, plan and downloads below still work.");
  canvas.replaceWith(note);
  const bar = document.getElementById("toolbar") || document.querySelector(".toolbar, .controls");
  if (bar) bar.hidden = true;
  status("no WebGL2", "err");
}

async function boot0() {
  try {
    renderer = new PanoRenderer(canvas);
  } catch (error) {
    showNoWebGL();
  }
  if (renderer) {
    overlay = new Overlay(overlayCanvas, renderer);
    renderer.setMapping({ az0Deg: -0.07, topDeg: 90.18, spanDeg: 180.65 });
    installInput();
    draw();
  }

  const who = await me();
  state.canEdit = Boolean(who.capabilities?.includes("edit_layers"));

  // Detail is a per-user preference: the last choice decides how far the textures are pulled.
  try {
    const saved = await api("/api/settings");
    if (saved.detail) state.detail = saved.detail;
    state.hd = detailAllowsFull();
  } catch {
    state.hd = detailAllowsFull();
  }

  try {
    state.meta = await api(apiPath("/meta"));
    if (renderer && state.meta.mapping) renderer.setMapping(state.meta.mapping);
    if (renderer) {
      renderer.yaw = ((state.meta.geometry?.azimuthFirstDeg ?? 0) * Math.PI) / 180;
    }
  } catch (error) {
    toast(error.message, "err");
    status(error.message, "err");
    return;
  }
  syncToolbar();
  await refreshFeatures();
  await loadNeighbours();
  if (renderer) await applyMode("grey");
  window.ubim = { renderer, overlay, state, applyMode };
}

boot0();

// == DRAWN OVERLAYS ==
// A drawing is flat, so it is drawn at the height the user names rather than at a height this
// code invents. The server projects it into this scan's frame; the browser only strokes it.
async function loadDrawings() {
  if (!drape.on) {
    overlay.drawings = [];
    needsDraw = true;
    syncToolbar();
    return;
  }
  try {
    const data = await api(`${apiPath("/drawings")}?height=${encodeURIComponent(drape.height)}`);
    // The server projects in degrees, which is what its JSON says it does; the overlay draws in
    // radians, like every other feature it holds. The conversion happens here, once.
    overlay.drawings = (data.features || []).map((shape) => ({
      ...shape,
      points: (shape.points || []).map((point) => ({
        az: (point.az * Math.PI) / 180,
        el: (point.el * Math.PI) / 180,
        r: point.r,
      })),
    }));
    needsDraw = true;
    status(
      `${data.features.length} drawing shape${data.features.length === 1 ? "" : "s"} at ${drape.height} m` +
      (data.dropped ? `, ${data.dropped} too close to the scan position to show` : "") +
      (data.assumedFrame ? " (scan frame assumed: no registration)" : ""),
    );
  } catch (error) {
    overlay.drawings = [];
    needsDraw = true;
    toast(error.message, "err");
  }
}

async function setDrapeHeight() {
  const value = await askLabel("drape height", { numeric: true, value: String(drape.height), hint: "Metres above the scan's own origin. The drawing is flat; this is where it sits." });
  if (value === null) return;
  const height = Number(value);
  if (!Number.isFinite(height)) { toast("height must be a number", "err"); return; }
  drape.height = height;
  await loadDrawings();
}

// == COMPASS ==
// A dial showing where the viewer looks inside the scan's own azimuth frame, with the
// field of view drawn as a wedge. Cardinal letters treat the scan's azimuth zero as north:
// a .fls or .f3s carries no north reference, so this is stated rather than implied.
function drawCompass() {
  if (!compass || compass.hidden) return;
  const context = compass.getContext("2d");
  const size = compass.width;
  const centre = size / 2;
  const radius = centre - 8;
  context.clearRect(0, 0, size, size);
  context.beginPath();
  context.arc(centre, centre, radius, 0, Math.PI * 2);
  context.fillStyle = "rgba(10, 14, 20, .82)";
  context.fill();
  context.strokeStyle = "rgba(140, 165, 195, .55)";
  context.lineWidth = 1;
  context.stroke();

  context.font = "10px system-ui, sans-serif";
  context.textAlign = "center";
  context.textBaseline = "middle";
  for (let degrees = 0; degrees < 360; degrees += 30) {
    const radians = ((degrees - 90) * Math.PI) / 180;
    const inner = degrees % 90 === 0 ? radius - 10 : radius - 5;
    context.strokeStyle = degrees % 90 === 0 ? "rgba(200, 216, 236, .8)" : "rgba(140, 165, 195, .45)";
    context.beginPath();
    context.moveTo(centre + Math.cos(radians) * inner, centre + Math.sin(radians) * inner);
    context.lineTo(centre + Math.cos(radians) * (radius - 1), centre + Math.sin(radians) * (radius - 1));
    context.stroke();
  }
  const headings = [["N", 0], ["E", 90], ["S", 180], ["W", 270]];
  context.fillStyle = "#dbe6f4";
  for (const [letter, degrees] of headings) {
    const radians = ((degrees - 90) * Math.PI) / 180;
    context.fillText(letter, centre + Math.cos(radians) * (radius - 18), centre + Math.sin(radians) * (radius - 18));
  }

  // The panorama's columns run the other way round from a compass: turning the view to the
  // right lowers the stored azimuth, so a bearing (which rises clockwise) is its negation.
  // Without this the dial reads backwards — turn right and it swings towards west.
  const bearing = ((-renderer.yaw * 180) / Math.PI % 360 + 360) % 360;
  const aspect = compassAspect();
  const horizontal = Math.min(170, ((renderer.fov * Math.PI) / 180) * aspect * (180 / Math.PI));
  const start = ((bearing - horizontal / 2 - 90) * Math.PI) / 180;
  const end = ((bearing + horizontal / 2 - 90) * Math.PI) / 180;
  context.beginPath();
  context.moveTo(centre, centre);
  context.arc(centre, centre, radius - 4, start, end);
  context.closePath();
  context.fillStyle = "rgba(74, 163, 255, .34)";
  context.fill();

  context.strokeStyle = "#4aa3ff";
  context.lineWidth = 2;
  context.beginPath();
  context.moveTo(centre, centre);
  const reach = ((bearing - 90) * Math.PI) / 180;
  context.lineTo(centre + Math.cos(reach) * (radius - 4), centre + Math.sin(reach) * (radius - 4));
  context.stroke();

  context.fillStyle = "#e8eef6";
  context.font = "600 11px system-ui, sans-serif";
  context.fillText(`${bearing.toFixed(0)}°`, centre, centre + 22);
}

function compassAspect() {
  const stage = document.getElementById("viewer");
  if (!stage || !stage.clientHeight) return 1.6;
  return stage.clientWidth / stage.clientHeight;
}

// == SAVE VIEW ==
// The canvas is captured straight after a draw, because a WebGL drawing buffer is not kept
// between frames. The image goes to the server, which makes the project card use it.
async function saveView() {
  try {
    needsDraw = true;
    draw();
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
    if (!blob) throw new Error("could not read the view");
    const token = api.token ? api.token() : (await api("/api/me")).csrf;
    const response = await fetch(`/api/p/${encodeURIComponent(state.project)}/view`, {
      method: "POST",
      headers: { "Content-Type": "image/png", "X-CSRF-Token": token },
      body: blob,
    });
    if (!response.ok) throw new Error((await response.json().catch(() => ({}))).detail || `save failed (${response.status})`);
    const saved = await response.json();
    toast(`Project picture saved${saved.width ? ` (${saved.width}×${saved.height})` : ""}`, "ok");
  } catch (error) {
    toast(error.message, "err");
  }
}

// == LABEL DIALOG ==
// Saving a mark asks for its label in the page rather than through window.prompt, which is
// unstyled, blocks the canvas and cannot be reached with the keyboard the same way.
function askLabel(kind, { numeric = false, value = "", hint: hintText = "" } = {}) {
  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = numeric ? "number" : "text";
    if (numeric) { input.step = "0.05"; input.value = value; } else input.maxLength = 120;
    if (!numeric) input.placeholder = "e.g. doorway, kerb line, bay 4";
    input.setAttribute("aria-label", numeric ? String(kind) : `Label for this ${kind}`);
    const save = document.createElement("button");
    save.type = "submit";
    save.className = "primary";
    save.textContent = "Save";
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.textContent = "Cancel";
    const form = document.createElement("form");
    form.className = "dialog-card";
    const title = document.createElement("h2");
    title.textContent = numeric ? kind.charAt(0).toUpperCase() + kind.slice(1) : `Label this ${kind}`;
    const hint = document.createElement("p");
    hint.className = "muted small";
    hint.textContent = hintText || "Optional. It is stored with the mark and appears in the export.";
    const row = document.createElement("div");
    row.className = "dialog-row";
    row.append(save, cancel);
    form.append(title, hint, input, row);

    const back = document.createElement("div");
    back.className = "dialog-back";
    back.setAttribute("role", "dialog");
    back.setAttribute("aria-modal", "true");
    back.append(form);

    const close = (value) => {
      back.remove();
      document.removeEventListener("keydown", onKey, true);
      resolve(value);
    };
    const onKey = (event) => {
      if (event.key === "Escape") { event.stopPropagation(); close(null); }
    };
    form.addEventListener("submit", (event) => { event.preventDefault(); close(input.value.trim()); });
    cancel.addEventListener("click", () => close(null));
    back.addEventListener("pointerdown", (event) => { if (event.target === back) close(null); });
    document.addEventListener("keydown", onKey, true);
    document.getElementById("viewer").append(back);
    input.focus();
  });
}

// == LOUPE AND FLY-TO ==
// The loupe copies the region under the pointer out of the panorama canvas into a small round
// canvas, magnified. It is taken from the frame that has just been drawn, in the same turn,
// because the drawing buffer is not kept between frames.
canvas.addEventListener("pointermove", (event) => {
  const box = canvas.getBoundingClientRect();
  pointer = { x: event.clientX, y: event.clientY, localX: event.clientX - box.left, localY: event.clientY - box.top, inside: true };
  if (loupeOn) positionLoupe();
}, { passive: true });

canvas.addEventListener("pointerleave", () => {
  pointer = null;
  if (loupeOn) loupe.hidden = true;
});

function positionLoupe() {
  if (!loupeOn || !pointer) return;
  const box = document.getElementById("viewer").getBoundingClientRect();
  loupe.hidden = false;
  loupe.style.left = `${Math.min(box.width - 190, Math.max(4, pointer.localX + 24))}px`;
  loupe.style.top = `${Math.min(box.height - 190, Math.max(4, pointer.localY + 24))}px`;
}

function drawLoupe() {
  if (!loupeOn || !pointer) return;
  const context = loupe.getContext("2d");
  const size = loupe.width;
  const ratio = canvas.width / Math.max(1, canvas.clientWidth);
  const source = size / 2.4;
  const x = pointer.localX * ratio;
  const y = pointer.localY * ratio;
  context.clearRect(0, 0, size, size);
  context.save();
  context.beginPath();
  context.arc(size / 2, size / 2, size / 2 - 2, 0, Math.PI * 2);
  context.clip();
  context.fillStyle = "#0b1017";
  context.fillRect(0, 0, size, size);
  try {
    context.drawImage(canvas, x - source / 2, y - source / 2, source, source, 0, 0, size, size);
  } catch { /* the first frame can be empty; the next one draws */ }
  context.restore();
  context.beginPath();
  context.arc(size / 2, size / 2, size / 2 - 2, 0, Math.PI * 2);
  context.strokeStyle = "rgba(160, 190, 225, .8)";
  context.lineWidth = 2;
  context.stroke();
}

// Double-clicking a spot brings it to the middle of the view over a short animation, so the
// eye can follow what moved instead of being teleported.
canvas.addEventListener("dblclick", (event) => {
  const box = canvas.getBoundingClientRect();
  const target = renderer.screenToAngles(event.clientX - box.left, event.clientY - box.top);
  if (!target) return;
  const fromYaw = renderer.yaw;
  const fromPitch = renderer.pitch;
  let targetYaw = target.azimuth;
  while (targetYaw - fromYaw > Math.PI) targetYaw -= 2 * Math.PI;
  while (targetYaw - fromYaw < -Math.PI) targetYaw += 2 * Math.PI;
  const started = performance.now();
  const step = (now) => {
    const t = Math.min(1, (now - started) / 320);
    const ease = t < 0.5 ? 2 * t * t : 1 - ((-2 * t + 2) ** 2) / 2;
    renderer.yaw = fromYaw + (targetYaw - fromYaw) * ease;
    renderer.pitch = fromPitch + (target.elevation - fromPitch) * ease;
    needsDraw = true;
    if (t < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
});

"""What these numbers are, and what they are not.

The same sentence goes into the scan panel, the JSON, the DXF (as 999 comments) and the CSV
(as a leading ``#`` line) so a file that leaves the app still carries its caveat.
"""

ACCURACY = (
    "Measured from the scan's own range and angle data: ranges are the scanner's stored values "
    "quantised by its storage factor (1 mm for a .fls grid, 1 µm for a .f3s leaf), angles come "
    "from the panorama mapping, and a pick snaps to the nearest return within ±3 cells. "
    "Absolute positions inherit the registration, which may be a declaration rather than a "
    "survey, so check one known dimension before treating a distance as control."
)

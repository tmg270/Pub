"""HTML pages.

These are server-rendered shells, not templates: the client fetches JSON and builds the
interface itself. Keeping the pages static means the Content-Security-Policy can forbid
inline script entirely (only ``style`` allows ``unsafe-inline`` for the few computed sizes).
"""

from __future__ import annotations

# The mark is inline SVG: no font, no image request, and it scales with the header. A compass
# rose is what a viewer of scan data is looking at, so it says more than an initial would.
MARK = (
    '<svg class="mark" viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
    '<circle cx="12" cy="12" r="9.2" fill="none" stroke="currentColor" stroke-width="1.3"/>'
    '<path d="M12 4.6 15 12 12 19.4 9 12Z" fill="currentColor" opacity=".85"/>'
    '<path d="M12 4.6 15 12H9Z" fill="currentColor"/>'
    '</svg>'
)

import html
import json
from pathlib import Path

from html import escape

from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from . import auth, projects
from .web import client_ip

STATIC = Path(__file__).with_name("static")


def build_id() -> str:
    """A stamp that changes when any interface file changes."""
    newest = 0
    for path in STATIC.rglob("*"):
        if path.is_file():
            newest = max(newest, int(path.stat().st_mtime))
    return str(newest or 1)

router = APIRouter()

NAV_OPEN = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<link rel="stylesheet" href="/static/{build}/app.css">
<link rel="icon" href="/static/{build}/favicon.svg" type="image/svg+xml">
</head>
<body class="{body_class}">
<header class="bar">
  <a class="brand" href="/">{mark}uBIM<span class="dot">·</span><span class="muted">viewer</span></a>
  <nav class="nav">{nav}</nav>
  <div class="who">{who}</div>
</header>
<main class="page">
"""

NAV_CLOSE = """</main>
<footer class="foot"><span>uBIM viewer</span><span id="status" class="status"></span></footer>
<script type="module" src="/static/{build}/js/{script}"></script>
</body>
</html>
"""


def _boot_json(payload: dict) -> str:
    """JSON for a data block. ``<`` is escaped so a name can never close the element."""
    return json.dumps(payload).replace("<", "\\u003c")


def page(request: Request, *, title: str, body: str, script: str, body_class: str = "") -> HTMLResponse:
    """Render a page inside the shared shell: navigation, the session's name, the script and the CSS build stamp."""
    session = getattr(request.state, "session", None)
    links = ['<a href="/">Projects</a>']
    if session is not None and auth.can(session.role, "admin"):
        links.append('<a href="/admin">Admin</a>')
    who = (
        f'<span class="chip">{escape(session.name)}</span> '
        f'<form method="post" action="/logout" class="inline">'
        f'<input type="hidden" name="csrf" value="{escape(session.csrf)}">'
        f'<button class="link" type="submit">Sign out</button></form>'
        if session is not None
        else '<a href="/login">Sign in</a>'
    )
    stamp = build_id()
    html = NAV_OPEN.format(
        title=escape(title), body_class=escape(body_class), nav="".join(links), who=who, build=stamp,
        mark=MARK
    )
    html += body
    html += NAV_CLOSE.format(script=script, build=stamp)
    return HTMLResponse(html)


def _require(request: Request) -> RedirectResponse | None:
    """The session, or a redirect target when the deployment requires a login and there is none."""
    if request.state.session is None and request.app.state.config.require_login:
        return RedirectResponse("/login", status_code=303)
    return None


@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """The project list, with a map view for the projects that declare a position."""
    redirect = _require(request)
    if redirect:
        return redirect
    return page(
        request,
        title="uBIM viewer",
        script="home.js",
        body='<section id="home" class="home">'
             '<div class="home-head"><h1>Projects</h1>'
             '<div class="seg" id="home-view" role="group" aria-label="View">'
             '<button type="button" data-view="list" aria-pressed="true">List</button>'
             '<button type="button" data-view="map" aria-pressed="false">Map</button></div></div>'
             '<div id="projects" class="cards" aria-live="polite">Loading…</div>'
             '<div id="home-map" class="home-map" hidden>'
             '<canvas id="home-map-canvas" aria-label="Project map"></canvas>'
             '<div class="map-tools"><button type="button" id="map-in" aria-label="Zoom in">+</button>'
             '<button type="button" id="map-out" aria-label="Zoom out">−</button></div>'
             '<p id="map-note" class="muted small"></p></div></section>',
    )


@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """The sign-in form, or a redirect home when already signed in."""
    if request.state.session is not None:
        return RedirectResponse("/", status_code=303)
    body = """<section class="gate">
  <h1>Sign in</h1>
  <form method="post" action="/login" class="stack" autocomplete="on">
    <label>User <input name="name" autocomplete="username" required autofocus></label>
    <label>Password <input name="password" type="password" autocomplete="current-password" required></label>
    <button type="submit" class="primary">Sign in</button>
  </form>
  <p class="muted small">Have an invite code? Redeem it below.</p>
  <form method="post" action="/invite" class="stack">
    <label>Invite code <input name="code" required placeholder="ABCD-EFGH"></label>
    <label>User name <input name="name" required></label>
    <label>Password <input name="password" type="password" required minlength="8"></label>
    <button type="submit">Redeem invite</button>
  </form>
</section>"""
    return page(request, title="Sign in", script="login.js", body=body)


@router.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request):
    """The administration page; its tabs are filled by admin.js from the API."""
    redirect = _require(request)
    if redirect:
        return redirect
    session = request.state.session
    if session is None or not auth.can(session.role, "admin"):
        return HTMLResponse("<h1>Not found</h1>", status_code=404)
    body = """<section id="admin" class="admin">
  <h1>Administration</h1>
  <nav class="tabs" role="tablist">
    <button role="tab" data-tab="users" aria-selected="true">Users</button>
    <button role="tab" data-tab="invites" aria-selected="false">Invites</button>
    <button role="tab" data-tab="shares" aria-selected="false">Shares</button>
    <button role="tab" data-tab="audit" aria-selected="false">Audit</button>
    <button role="tab" data-tab="scans" aria-selected="false">Scans</button>
    <button role="tab" data-tab="library" aria-selected="false">Library</button>
    <button role="tab" data-tab="system" aria-selected="false">System</button>
  </nav>
  <div id="tab-body" class="tab-body">Loading…</div>
</section>"""
    return page(request, title="Administration", script="admin.js", body=body)


@router.get("/p/{slug}", response_class=HTMLResponse)
async def project_page(request: Request, slug: str):
    """A project: its scans, the plan, the drawings and the declared position."""
    redirect = _require(request)
    if redirect:
        return redirect
    found = projects.project(request.app.state.store, slug)
    if found is None:
        return HTMLResponse("<h1>Project not found</h1>", status_code=404)
    body = f"""<section id="project" data-slug="{html.escape(found['slug'])}">
  <p class="muted small"><a href="/">Projects</a> / {html.escape(found['name'])}</p>
  <img id="project-picture" class="project-picture" alt="" hidden>
  <div class="project-head"><h1>{html.escape(found['name'])}</h1>
    <p class="muted" id="project-meta">Loading…</p></div>
  <div class="project-crs">
    <label>CRS <input id="project-crs" maxlength="64" placeholder="EPSG:27700, or a local grid name"></label>
    <button type="button" class="button ghost" id="project-crs-save">Declare CRS</button>
    <p class="muted small" id="project-crs-note">Declared, never applied: neither FARO format states a coordinate reference system, so this is a note carried with the project and repeated in the drawing export.</p>
  </div>
  <section id="site-plan" class="site-plan" hidden>
    <div class="plan-head"><h2>Site plan</h2><p class="muted small" id="plan-note"></p>
      <button type="button" class="button ghost" id="plan-build" hidden>Build site plan</button>
      <button type="button" class="button ghost" id="plan-aerial-toggle" hidden>Aerial imagery</button>
      <button type="button" class="button ghost" id="plan-fill" aria-pressed="false">Fill gaps</button></div>
    <div class="plan-stage" id="plan-stage">
      <div class="plan-aerial" id="plan-aerial" hidden></div>
      <img id="plan-image" alt="Top-down site plan made from the scan returns">
      <div id="plan-dots"></div>
      <div id="plan-handles"></div>
      <div class="plan-probe" id="plan-probe" hidden></div>
    </div>
  </section>
  <section id="drawings" class="site-plan" hidden>
    <div class="plan-head"><h2>Drawings</h2><p class="muted small" id="drawing-note">Imported CAD lines are drawn in every scan of this project.</p></div>
    <div class="drawing-tools">
      <input type="file" id="drawing-file" accept=".dxf,text/plain" aria-label="DXF file">
      <button type="button" class="button ghost" id="drawing-import">Import DXF</button>
    </div>
    <div class="drawing-frame">
      <p class="muted small" id="frame-note">A drawing carries its own coordinates. Declare where they sit
      in the scans, or leave this empty when the drawing is already in the scan's frame.</p>
      <div class="drawing-tools">
        <input id="frame-x" inputmode="decimal" placeholder="Origin X" aria-label="Drawing origin X">
        <input id="frame-y" inputmode="decimal" placeholder="Origin Y" aria-label="Drawing origin Y">
        <input id="frame-z" inputmode="decimal" placeholder="Origin Z" aria-label="Drawing origin Z">
        <input id="frame-rotation" inputmode="decimal" placeholder="Rotation °" aria-label="Rotation in degrees">
        <input id="frame-scale" inputmode="decimal" placeholder="Scale" aria-label="Scale">
        <button type="button" class="button ghost" id="frame-save">Save placement</button>
        <button type="button" class="button ghost" id="frame-clear">Clear</button>
      </div>
    </div>
    <ul id="drawing-list" class="muted small"></ul>
  </section>
  <section id="placement" class="site-plan" hidden>
    <div class="plan-head"><h2>Map position</h2>
      <p class="muted small">Where this project sits in the world, so it can appear on the map.
      A position is either typed here or read from a scan's own GPS, and the note says which.</p></div>
    <div class="drawing-tools">
      <input id="place-lat" inputmode="decimal" placeholder="Latitude" aria-label="Latitude">
      <input id="place-lon" inputmode="decimal" placeholder="Longitude" aria-label="Longitude">
      <button type="button" class="button ghost" id="place-save">Save position</button>
      <button type="button" class="button ghost" id="place-clear">Clear</button>
      <select id="place-scan" aria-label="Scan whose GPS to use"></select>
      <button type="button" class="button ghost" id="place-gps">Use scan GPS</button>
      <span class="muted small" id="place-note"></span>
    </div>
  </section>
  <div id="scans" class="cards" aria-live="polite">Loading…</div>
</section>"""
    return page(request, title=found["name"], script="project.js", body=body)


@router.get("/p/{slug}/{scan}", response_class=HTMLResponse)
async def scan_page(request: Request, slug: str, scan: str):
    """The panorama viewer for one scan."""
    redirect = _require(request)
    if redirect:
        return redirect
    store = request.app.state.store
    found = projects.project(store, slug)
    if found is None or projects.scan(store, found["id"], scan) is None:
        return HTMLResponse("<h1>Scan not found</h1>", status_code=404)
    boot = _boot_json({"project": found["slug"], "scan": scan})
    body = f"""<section class="project" data-slug="{escape(slug)}" data-scan="{escape(scan)}">
  <div class="project-head"><h1>{escape(found['name'])} · {escape(scan)}</h1><p class="muted" id="project-meta"></p></div>
  <div class="viewer" id="viewer" data-slug="{escape(slug)}" data-scan="{escape(scan)}">
    <canvas id="pano" tabindex="0" aria-label="Panoramic view"></canvas>
    <canvas id="overlay" aria-hidden="true"></canvas>
    <div class="toolbar" id="toolbar" role="toolbar" aria-label="Viewer tools"></div>
    <canvas id="compass" class="compass" width="132" height="132" aria-label="View direction" hidden></canvas>
    <canvas id="loupe" class="loupe" width="180" height="180" aria-label="Loupe" hidden></canvas>
    <div class="hint" id="hint"></div>
    <div class="loading" id="loading">Loading scan…</div>
    <aside class="panel" id="panel" hidden></aside>
    <script type="application/json" id="boot">{boot}</script>
  </div>
</section>"""
    return page(request, title=f"{found['name']} · {scan}", script="viewer.js", body=body, body_class="full")


@router.post("/login")
async def do_login(request: Request, name: str = Form(...), password: str = Form(...)):
    """Check the credentials, start a session, and send the browser back to where it was going."""
    store = request.app.state.store
    config = request.app.state.config
    user_id = auth.authenticate(store, name, password)
    ip = client_ip(request)
    if user_id is None:
        store.audit("login", None, name, ip, 401)
        return RedirectResponse("/login?failed=1", status_code=303)
    session = auth.create_session(
        store, user_id, hours=config.session_hours, ip=ip, agent=request.headers.get("user-agent")
    )
    store.audit("login", user_id, name, ip, 200)
    response = RedirectResponse("/", status_code=303)
    response.set_cookie(
        "ubim_sid", session.id, httponly=True, samesite="lax", secure=config.secure_cookies,
        max_age=config.session_hours * 3600, path="/",
    )
    return response


@router.post("/logout")
async def do_logout(request: Request, csrf: str = Form(None)):
    """End the session and clear the cookie; the CSRF token is checked first."""
    store = request.app.state.store
    session = request.state.session
    if session is not None and csrf and auth.csrf_ok(session, csrf):
        auth.destroy_session(store, session.id)
        store.audit("logout", session.user_id, "", client_ip(request), 200)
    response = RedirectResponse("/login", status_code=303)
    response.delete_cookie("ubim_sid", path="/")
    return response


@router.post("/invite")
async def redeem(request: Request, code: str = Form(...), name: str = Form(...), password: str = Form(...)):
    """Turn an invitation code into a user, then sign that user in."""
    store = request.app.state.store
    config = request.app.state.config
    try:
        user_id = auth.redeem_invite(store, code, name, password)
    except ValueError as exc:
        from urllib.parse import quote

        return RedirectResponse(f"/login?error={quote(str(exc))}", status_code=303)
    session = auth.create_session(
        store, user_id, hours=config.session_hours, ip=client_ip(request),
        agent=request.headers.get("user-agent"),
    )
    store.audit("invite.redeem", user_id, name, client_ip(request), 200)
    response = RedirectResponse("/", status_code=303)
    response.set_cookie(
        "ubim_sid", session.id, httponly=True, samesite="lax", secure=config.secure_cookies,
        max_age=config.session_hours * 3600, path="/",
    )
    return response


@router.get("/healthz")
async def healthz(request: Request):
    """A liveness answer for the container health check: version and ok."""
    return {"ok": True, "version": request.app.state.config.app_version}

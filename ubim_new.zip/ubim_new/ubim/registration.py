"""Scan registration: the rigid transform from a scan's own frame to the project frame.

A measurement is stored in the frame of the scan it was taken in (azimuth, elevation,
range), because that is what the instrument measured. To draw it in a neighbouring scan, or
to place scan locations on a site plan, those coordinates have to cross into a shared frame.
That crossing is a rigid transform per scan — a rotation about the vertical and a translation
— which is what a registration provides.

Nothing here guesses. A scan with no transform is treated as being at the origin with no
rotation, and the caller is expected to say so: the plan marks such scans "position not
registered" rather than pretending the identity is a survey.
"""

from __future__ import annotations

import math

#: The identity transform, used for a scan whose registration is unknown.
IDENTITY = (
    (1.0, 0.0, 0.0, 0.0),
    (0.0, 1.0, 0.0, 0.0),
    (0.0, 0.0, 1.0, 0.0),
    (0.0, 0.0, 0.0, 1.0),
)

Matrix = tuple[tuple[float, float, float, float], ...]


def pose_matrix(x: float = 0.0, y: float = 0.0, z: float = 0.0, yaw_deg: float = 0.0) -> Matrix:
    """A 4x4 transform from a scan position and a heading, in degrees anticlockwise from +X."""
    yaw = math.radians(float(yaw_deg))
    cos, sin = math.cos(yaw), math.sin(yaw)
    return (
        (cos, -sin, 0.0, float(x)),
        (sin, cos, 0.0, float(y)),
        (0.0, 0.0, 1.0, float(z)),
        (0.0, 0.0, 0.0, 1.0),
    )


def is_identity(matrix: Matrix | None) -> bool:
    """Whether a matrix is (within rounding) the identity, which is the common case for an unregistered scan."""
    if matrix is None:
        return True
    return all(abs(matrix[r][c] - IDENTITY[r][c]) < 1e-9 for r in range(4) for c in range(4))


def multiply(a: Matrix, b: Matrix) -> Matrix:
    """Compose two 4x4 transforms, the left applied after the right."""
    return tuple(
        tuple(sum(a[r][k] * b[k][c] for k in range(4)) for c in range(4)) for r in range(4)
    )


def inverse(matrix: Matrix) -> Matrix:
    """Inverse of a rigid transform: transpose the rotation and undo the translation."""
    rotation = [[matrix[r][c] for c in range(3)] for r in range(3)]
    translation = [matrix[r][3] for r in range(3)]
    out = [[0.0] * 4 for _ in range(4)]
    for r in range(3):
        for c in range(3):
            out[r][c] = rotation[c][r]
        out[r][3] = -sum(rotation[c][r] * translation[c] for c in range(3))
    out[3][3] = 1.0
    return tuple(tuple(row) for row in out)


def apply(matrix: Matrix, point: tuple[float, float, float]) -> tuple[float, float, float]:
    """Transform one point by a 4x4 matrix."""
    x, y, z = point
    return (
        matrix[0][0] * x + matrix[0][1] * y + matrix[0][2] * z + matrix[0][3],
        matrix[1][0] * x + matrix[1][1] * y + matrix[1][2] * z + matrix[1][3],
        matrix[2][0] * x + matrix[2][1] * y + matrix[2][2] * z + matrix[2][3],
    )


def local_from_world(world: tuple[float, float, float], pose: Matrix) -> tuple[float, float, float]:
    """The point in the frame of the scan that produced ``pose``."""
    return apply(inverse(pose), world)


def azimuth_elevation(point: tuple[float, float, float]) -> tuple[float, float, float]:
    """Angles and distance for a point in a scan frame, in the viewer's convention.

    The convention matches :func:`ubim.measure.to_xyz`: X forward, Y left, Z up, azimuth
    measured anticlockwise from +X. Returning angles rather than a matrix means the client
    keeps working in the only units it understands.
    """
    x, y, z = point
    radius = math.sqrt(x * x + y * y + z * z)
    if radius < 1e-9:
        return 0.0, 0.0, 0.0
    azimuth = math.degrees(math.atan2(y, x)) % 360.0
    elevation = math.degrees(math.asin(max(-1.0, min(1.0, z / radius))))
    return azimuth, elevation, radius


def project(
    world: tuple[float, float, float], pose: Matrix, elevation_limit_deg: float = 90.0
) -> dict:
    """Express a project-frame point in one scan's frame.

    ``visible`` is false when the direction falls outside the scan's elevation band: the point
    exists, but that scan did not look there, so drawing it would invent a line of sight.
    """
    local = local_from_world(world, pose)
    azimuth, elevation, radius = azimuth_elevation(local)
    return {
        "az": round(azimuth, 4),
        "el": round(elevation, 4),
        "r": round(radius, 4),
        "visible": abs(elevation) <= elevation_limit_deg and radius > 1e-6,
    }


def parse(raw) -> Matrix | None:
    """Read a stored transform, tolerating absence and the JSON array form."""
    if raw is None:
        return None
    if isinstance(raw, (list, tuple)):
        values = raw
    else:
        import json

        try:
            values = json.loads(raw)
        except (TypeError, ValueError):
            return None
    if not values:
        return None
    if len(values) == 4 and all(isinstance(row, (list, tuple)) and len(row) == 4 for row in values):
        return tuple(tuple(float(value) for value in row) for row in values)
    if len(values) in (4, 6, 7) and all(isinstance(value, (int, float)) for value in values):
        return pose_matrix(float(values[0]), float(values[1]), float(values[2]), float(values[3]))
    return None


def dump(matrix: Matrix) -> list:
    """A matrix as plain nested lists, for JSON."""
    return [[float(value) for value in row] for row in matrix]

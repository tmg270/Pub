"""Marker package for the API modules.

Routes live in ``api.py`` and the ``api_*`` modules; this package exists so that the router
namespace is explicit rather than implied by filenames."""


"""The scanner's own GPS fix, when the file carries one.

Both formats keep a text attribute block: ``Main`` in a ``.fls`` and ``ScanInfo_0`` in a
``.f3s``. Among the attributes is ``GPSNMEA``, a run of sentences the scanner logged at the
time of the scan. A GGA sentence with a non-zero fix quality carries a latitude, a longitude
and an altitude, which is the only geographic statement either format makes.

What it is not: a survey. The fix is what the scanner's own receiver managed, typically a few
metres to tens of metres, and RMC's course-over-ground is the direction the scanner was
*travelling*, not the way it was pointing — so nothing here orients a scene.
"""

from __future__ import annotations

import re
import zlib
from pathlib import Path

from .formats.cfb import OleContainer, FormatError

MAX_ATTRIBUTE_BYTES = 512 * 1024
GPS_ATTRIBUTE = "GPSNMEA"


def _inflate_if_needed(data: bytes) -> bytes:
    """``ScanInfo_0`` is gzip deflate; some writers omit the trailer, so be tolerant."""
    if not data.startswith(b"\x1f\x8b"):
        return data
    for wbits in (16 + zlib.MAX_WBITS, -15):
        try:
            return zlib.decompressobj(wbits).decompress(data)
        except zlib.error:
            continue
    return data


def attribute_block(path: str | Path) -> str:
    """The text attribute block of a scan, whichever format it is."""
    with OleContainer(path) as container:
        for name in ("ScanInfo_0", "Main"):
            if container.has(name):
                return _inflate_if_needed(container.read(name, MAX_ATTRIBUTE_BYTES)).decode("latin-1")
    raise FormatError("no attribute block (ScanInfo_0 or Main)")


def _value(text: str, name: str) -> str | None:
    """The value of a named attribute in a ``Main`` text block, or None."""
    hit = re.search(r'Name "%s"\s*\n?\s*Value "([^"]*)"' % re.escape(name), text)
    return hit.group(1) if hit else None


def ddmm_to_degrees(value: str) -> float | None:
    """``5322.2706`` is 53 degrees and 22.2706 minutes, not fifty-three thousand."""
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    degrees = int(number / 100)
    minutes = number - degrees * 100
    if minutes >= 60 or degrees > 180:
        return None
    return degrees + minutes / 60.0


def parse(nmea: str | None) -> dict | None:
    """A fix from the logged sentences, or ``None`` when the scanner had none.

    Sentences arrive as literal text with ``\\n`` between them; the value in the attribute
    block escapes the newlines rather than storing them.
    """
    if not nmea:
        return None
    lines = [line.strip() for line in re.split(r"\\n|\r?\n", nmea) if line.strip()]
    fix = {"source": "nmea", "quality": 0, "satellites": None, "hdop": None,
           "altitudeM": None, "geoidM": None, "utc": None, "date": None}
    for line in lines:
        fields = line.lstrip("$").split("*")[0].split(",")
        kind = fields[0][2:] if len(fields[0]) > 2 else ""
        try:
            if kind == "GGA" and len(fields) >= 10:
                quality = int(fields[6] or 0)
                if quality <= 0:
                    continue
                lat = ddmm_to_degrees(fields[2])
                lon = ddmm_to_degrees(fields[4])
                if lat is None or lon is None or lat > 90.0 or lon > 180.0:
                    continue
                fix.update({
                    "lat": round(-lat if fields[3] == "S" else lat, 6),
                    "lon": round(-lon if fields[5] == "W" else lon, 6),
                    "quality": quality,
                    "satellites": int(fields[7]) if fields[7] else None,
                    "hdop": float(fields[8]) if fields[8] else None,
                    "altitudeM": float(fields[9]) if fields[9] else None,
                    "geoidM": float(fields[11]) if len(fields) > 11 and fields[11] else None,
                    "utc": fields[1] or None,
                })
            elif kind == "RMC" and len(fields) >= 10:
                if fields[2] != "A":
                    continue
                if "lat" not in fix:
                    lat = ddmm_to_degrees(fields[3])
                    lon = ddmm_to_degrees(fields[5])
                    if lat is None or lon is None or lat > 90.0 or lon > 180.0:
                        continue
                    fix.update({
                        "lat": round(-lat if fields[4] == "S" else lat, 6),
                        "lon": round(-lon if fields[6] == "W" else lon, 6),
                        "utc": fields[1] or fix["utc"],
                        "date": fields[9] or None,
                    })
        except (ValueError, IndexError):
            continue
    if "lat" not in fix:
        return None
    return fix


def read(path: str | Path) -> dict | None:
    """The fix recorded with a scan, or ``None`` when it has none or cannot be read."""
    try:
        return parse(_value(attribute_block(path), GPS_ATTRIBUTE))
    except (FormatError, OSError, ValueError):
        return None

"""Geometry for measurements: lengths, areas, planes and heights.

The store keeps azimuth, elevation and range, which is the raw truth. Everything a surveyor
reads off a measurement — a length, an area, how far the points stray from a plane — is
computed here from those, in metres, and returned alongside the stored points so the client
never has to do trigonometry of its own and cannot drift from the server.

A measurement with any point lacking a range is a direction-only measurement: it reports the
angles but no lengths, rather than pretending a number exists.
"""

from __future__ import annotations

import math
from typing import Iterable

#: Spec M2: beyond this range the height of a pick is less certain, so the readout says so
#: rather than presenting a millimetre figure it cannot support.
WARN_SPAN_M = 20.0


def to_xyz(point: dict) -> tuple[float, float, float] | None:
    """Cartesian metres in the scan frame, or None when the point has no range."""
    radius = point.get("r")
    if radius is None:
        return None
    azimuth = math.radians(float(point.get("az", 0.0)))
    elevation = math.radians(float(point.get("el", 0.0)))
    return (
        radius * math.cos(elevation) * math.cos(azimuth),
        radius * math.cos(elevation) * math.sin(azimuth),
        radius * math.sin(elevation),
    )


def _distance(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    """Straight-line distance between two points."""
    return math.dist(a, b)


def _newell(points: list[tuple[float, float, float]]) -> tuple[tuple[float, float, float], float]:
    """Vector area of a closed polygon (Newell), plus its magnitude."""
    nx = ny = nz = 0.0
    for index, current in enumerate(points):
        following = points[(index + 1) % len(points)]
        nx += (current[1] - following[1]) * (current[2] + following[2])
        ny += (current[2] - following[2]) * (current[0] + following[0])
        nz += (current[0] - following[0]) * (current[1] + following[1])
    vector = (nx / 2.0, ny / 2.0, nz / 2.0)
    return vector, math.sqrt(nx * nx + ny * ny + nz * nz) / 2.0


def _plane(points: list[tuple[float, float, float]]) -> dict | None:
    """Best-fit plane through the points (least squares), with residual and inclination."""
    if len(points) < 3:
        return None
    count = len(points)
    cx = sum(p[0] for p in points) / count
    cy = sum(p[1] for p in points) / count
    cz = sum(p[2] for p in points) / count
    # Small symmetric 3x3 scatter matrix; the normal is its smallest eigenvector. Solving it
    # directly keeps numpy out of this module, which the tests import on its own.
    sxx = sxy = sxz = syy = syz = szz = 0.0
    for x, y, z in points:
        dx, dy, dz = x - cx, y - cy, z - cz
        sxx += dx * dx
        sxy += dx * dy
        sxz += dx * dz
        syy += dy * dy
        syz += dy * dz
        szz += dz * dz
    # Cofactor matrix rows give candidate normals; pick the shortest cross product pair.
    candidates = [
        ((syy * szz - syz * syz, syz * sxz - sxy * szz, sxy * syz - syy * sxz)),
        ((syz * sxz - sxy * szz, sxx * szz - sxz * sxz, sxy * sxz - sxx * syz)),
        ((sxy * syz - syy * sxz, sxy * sxz - sxx * syz, sxx * syy - sxy * sxy)),
    ]
    normal: tuple[float, float, float] | None = None
    best = -1.0
    for vector in candidates:
        length = math.sqrt(sum(component * component for component in vector))
        if length > best:
            best = length
            normal = vector
    if normal is None or best <= 0.0:
        return None
    length = math.sqrt(sum(component * component for component in normal))
    nx, ny, nz = (component / length for component in normal)
    residuals = [abs((x - cx) * nx + (y - cy) * ny + (z - cz) * nz) for x, y, z in points]
    rms = math.sqrt(sum(value * value for value in residuals) / count)
    return {
        "normal": {"x": round(nx, 5), "y": round(ny, 5), "z": round(nz, 5)},
        "rmsMetres": round(rms, 4),
        "maxResidualMetres": round(max(residuals), 4),
        "centroid": {"x": round(cx, 3), "y": round(cy, 3), "z": round(cz, 3)},
        # Inclination of the plane from horizontal, in degrees.
        "inclinationDeg": round(math.degrees(math.acos(max(-1.0, min(1.0, abs(nz))))), 2),
    }


def metrics(feature: dict) -> dict:
    """Computed values for one stored feature. Never raises on incomplete data."""
    points: Iterable[dict] = feature.get("points") or []
    points = list(points)
    result: dict = {
        "kind": feature.get("kind"),
        "pointCount": len(points),
        "complete": bool(points) and all(point.get("r") is not None for point in points),
        # A range can be measured and still give a doubtful height (spec M2): the pick snapped
        # a long way, the return stands alone, or it sits at the edge of the sweep. The flag is
        # carried with the point so the number is never presented as more certain than it is.
        "heightUncertain": any(point.get("uncertain") for point in points),
    }
    xyz = [to_xyz(point) for point in points]
    if not result["complete"]:
        result["note"] = "at least one point has no range, so lengths are unavailable"
        return result

    heights = [point[2] for point in xyz]
    result["heightRange"] = {"min": round(min(heights), 3), "max": round(max(heights), 3)}
    if len(xyz) >= 2:
        segments = [_distance(xyz[i], xyz[i + 1]) for i in range(len(xyz) - 1)]
        result["segments"] = [round(value, 3) for value in segments]
        result["length"] = round(sum(segments), 3)
        result["distance"] = round(_distance(xyz[0], xyz[-1]), 3)
        result["verticalDrop"] = round(abs(xyz[0][2] - xyz[-1][2]), 3)
        # Signed vertical change: positive is rising, which is what a surveyor expects to read.
        result["verticalSigned"] = round(xyz[-1][2] - xyz[0][2], 3)
        result["plan"] = round(math.hypot(xyz[-1][0] - xyz[0][0], xyz[-1][1] - xyz[0][1]), 3)
    if feature.get("kind") in ("area", "polygon") and len(xyz) >= 3:
        vector, area = _newell(xyz)
        result["area"] = round(area, 4)
        result["perimeter"] = round(sum(_distance(xyz[i], xyz[(i + 1) % len(xyz)]) for i in range(len(xyz))), 3)
        result["plane"] = _plane(xyz)
        result["centroid"] = {
            "x": round(sum(point[0] for point in xyz) / len(xyz), 3),
            "y": round(sum(point[1] for point in xyz) / len(xyz), 3),
            "z": round(sum(point[2] for point in xyz) / len(xyz), 3),
        }
        if vector != (0.0, 0.0, 0.0):
            result["facingDeg"] = round(math.degrees(math.atan2(vector[1], vector[0])) % 360.0, 2)
    if len(xyz) == 1:
        result["centroid"] = {"x": round(xyz[0][0], 3), "y": round(xyz[0][1], 3), "z": round(xyz[0][2], 3)}
        result["groundHeight"] = round(xyz[0][2], 3)
    if result.get("length", 0.0) > WARN_SPAN_M:
        result["warning"] = f"spans more than {WARN_SPAN_M:.0f} m, heights beyond that range are less certain"
    return result

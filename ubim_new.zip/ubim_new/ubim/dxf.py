"""Reading 2D CAD drawings (DXF) so they can be laid over a scan.

Only the entities that carry a line on a site plan are read: LINE, LWPOLYLINE, POLYLINE
(with its VERTEX records), POINT, CIRCLE and TEXT. Everything else is skipped rather than
guessed at, and the report says how many entities were skipped so an import that looks empty
can be explained.

Coordinates are drawing coordinates. A DXF with no elevation is a flat drawing, and a flat
drawing has no height relative to a scan — that is reported, not invented: :func:`read`
returns ``flat`` true when every vertex sits at Z=0.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

#: $INSUNITS value -> metres per drawing unit. 0 is "unitless" and is treated as metres,
#: because a site plan in millimetres would come out a thousand times too large, which is
#: obvious on the plan and fixable by re-importing with the right units.
_UNITS = {2: 0.3048, 4: 0.001, 5: 0.01, 6: 1.0, 7: 1000.0, 8: 0.0000254, 9: 0.0254, 10: 914.4}

_KNOWN = (
    "LINE", "LWPOLYLINE", "POLYLINE", "VERTEX", "SEQEND", "POINT", "CIRCLE", "TEXT",
    "MTEXT", "ARC", "INSERT", "HATCH", "DIMENSION", "SOLID", "3DFACE",
)
_NON_ENTITY = {
    "SECTION", "ENDSEC", "EOF", "TABLE", "ENDTAB", "BLOCK", "ENDBLK", "CLASSES", "OBJECTS",
    "SEQEND",  # terminates a POLYLINE; not an entity of its own
}


# The AutoCAD Colour Index, as far as it is used in practice: the first nine are the drawing
# colours, 250-255 the grey ramp. Anything else keeps the app's own colour rather than a guess.
ACI_COLOURS = {
    1: "#ff0000", 2: "#ffff00", 3: "#00ff00", 4: "#00ffff", 5: "#0000ff",
    6: "#ff00ff", 7: "#ffffff", 8: "#808080", 9: "#c0c0c0",
    250: "#333333", 251: "#505050", 252: "#696969", 253: "#828282", 254: "#bebebe", 255: "#ffffff",
}


def aci_colour(code) -> str | None:
    """A hex colour for an ACI number, or None for by-layer/unknown."""
    try:
        return ACI_COLOURS.get(int(float(code)))
    except (TypeError, ValueError):
        return None


def _lineweight(value) -> float | None:
    """DXF group 370 is hundredths of a millimetre; -1 means by-layer and -3 default."""
    try:
        hundredths = float(value)
    except (TypeError, ValueError):
        return None
    if hundredths < 0:
        return None
    return round(hundredths / 100.0, 3)


@dataclass
class Shape:
    """One drawing entity: its kind, layer, points and any text."""
    kind: str
    points: list[tuple[float, float, float]] = field(default_factory=list)
    label: str | None = None
    colour: str | None = None
    width_mm: float | None = None


@dataclass
class Drawing:
    """A drawing on its way to DXF: entities, layer table and the declared frame."""
    shapes: list[Shape] = field(default_factory=list)
    units: float = 1.0
    unit_code: int = 0
    skipped: int = 0
    flat: bool = True
    closed: int = 0


def _pairs(text: str):
    """DXF group code / value pairs, in file order."""
    lines = [line.strip() for line in text.splitlines()]
    index = 0
    while index + 1 < len(lines):
        try:
            yield int(lines[index]), lines[index + 1]
        except ValueError:
            yield None, lines[index + 1]
        index += 2


def _number(value, default: float = 0.0) -> float:
    """A float from a DXF group value, or the default when it is not a number."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _point(current: dict, x: str = "10", y: str = "20", z: str = "30") -> tuple[float, float, float]:
    """A point from the group values of one entity, with axes defaulting to zero."""
    return (_number(current.get(x)), _number(current.get(y)), _number(current.get(z)))


def read(text: str) -> Drawing:
    """Parse the entities of a DXF text into shapes in drawing units."""
    drawing = Drawing()
    entity: str | None = None
    current: dict = {}
    polyline: Shape | None = None
    polyline_pending = False
    pending_units = False

    def flush() -> None:
        """Write the buffered entities out, then the layer table and the terminator."""
        nonlocal current, polyline
        kind = (entity or "").upper()
        colour = aci_colour(current.get("62"))
        width = _lineweight(current.get("370"))
        first = len(drawing.shapes)  # this entity's shapes, so the colours can be attached below
        if kind == "LINE":
            drawing.shapes.append(Shape("line", [_point(current, "10", "20", "30"), _point(current, "11", "21", "31")]))
        elif kind == "LWPOLYLINE":
            xs = current.get("10s") or []
            ys = current.get("20s") or []
            zs = current.get("30s") or []
            points = [
                (_number(x), _number(ys[index]) if index < len(ys) else 0.0, _number(zs[index]) if index < len(zs) else 0.0)
                for index, x in enumerate(xs)
            ]
            if len(points) >= 2:
                if str(current.get("70", "0")).strip() in ("1", "129"):
                    points.append(points[0])
                    drawing.closed += 1
                drawing.shapes.append(Shape("polyline", points))
            else:
                drawing.skipped += 1
        elif kind == "VERTEX":
            if polyline is not None:
                polyline.points.append(_point(current))
        elif kind == "POLYLINE":
            pass  # its vertices are collected as they are met
        elif kind == "POINT":
            drawing.shapes.append(Shape("point", [_point(current)]))
        elif kind == "CIRCLE":
            centre = _point(current)
            radius = abs(_number(current.get("40")))
            if radius > 0:
                ring = [
                    (
                        centre[0] + radius * math.cos(step * math.pi / 12),
                        centre[1] + radius * math.sin(step * math.pi / 12),
                        centre[2],
                    )
                    for step in range(24)
                ]
                ring.append(ring[0])
                drawing.shapes.append(Shape("polyline", ring))
                drawing.closed += 1
            else:
                drawing.skipped += 1
        elif kind in ("TEXT", "MTEXT"):
            label = _clean(str(current.get("1", "")))
            if label:
                drawing.shapes.append(Shape("point", [_point(current)], label))
        elif kind:
            drawing.skipped += 1
        if kind == "POLYLINE" and polyline is not None:
            # The header carries the colour; the vertices arrive later and are drawn by SEQEND.
            polyline.colour = colour
            polyline.width_mm = width
        if colour is not None or width is not None:
            for made in drawing.shapes[first:]:
                if made.colour is None:
                    made.colour = colour
                if made.width_mm is None:
                    made.width_mm = width
        current = {}

    for code, value in _pairs(text):
        if code is None:
            continue
        if code == 9:
            pending_units = value.strip().upper() == "$INSUNITS"
            continue
        if pending_units and code != 0:
            pending_units = False
            try:
                drawing.unit_code = int(float(value))
            except (TypeError, ValueError):
                drawing.unit_code = 0
            drawing.units = _UNITS.get(drawing.unit_code, 1.0)
            continue
        if code == 0:
            flush()
            token = value.strip().upper()
            if token in _NON_ENTITY:
                entity = None
                if token == "ENDSEC" and polyline is not None:
                    if len(polyline.points) >= 2:
                        drawing.shapes.append(polyline)
                    polyline = None
                continue
            if token in _KNOWN:
                entity = token
                if token == "POLYLINE":
                    polyline = Shape("polyline", [], None)
                    polyline_pending = True  # its colour arrives with the header, before SEQEND
                continue
            entity = None
            drawing.skipped += 1
            continue
        if entity is None:
            continue
        if entity == "LWPOLYLINE" and code in (10, 20, 30):
            bucket = current.setdefault(f"{code}s", [])
            if isinstance(bucket, list):
                bucket.append(value)
            continue
        current[str(code)] = value
    flush()
    if polyline is not None and len(polyline.points) >= 2:
        drawing.shapes.append(polyline)

    for shape in drawing.shapes:
        if any(abs(point[2]) > 1e-9 for point in shape.points):
            drawing.flat = False
            break
    drawing.shapes = [
        Shape(
            shape.kind,
            [(x * drawing.units, y * drawing.units, z * drawing.units) for (x, y, z) in shape.points],
            shape.label,
            shape.colour,
            shape.width_mm,
        )
        for shape in drawing.shapes
        if len(shape.points) >= (2 if shape.kind in ("line", "polyline") else 1)
    ]
    return drawing


def _clean(value: str) -> str:
    """Tidy a text value: no NULs, no run of spaces."""
    return re.sub(r"\s+", " ", value.replace("\x00", " ")).strip()[:120]


def extent(drawing: Drawing) -> dict | None:
    """Drawing extent in metres, so an import can be checked against the site."""
    xs = [point[0] for shape in drawing.shapes for point in shape.points]
    ys = [point[1] for shape in drawing.shapes for point in shape.points]
    if not xs or not ys:
        return None
    return {"minX": min(xs), "maxX": max(xs), "minY": min(ys), "maxY": max(ys)}

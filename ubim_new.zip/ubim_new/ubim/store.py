"""SQLite persistence: users, sessions, projects, shares, layers, features, audit.

One file, standard library only. Every write goes through :class:`Store` so that the same
transaction boundaries are used everywhere, and soft deletes record an undo group so the
"undo last delete" behaviour from the Java app can be reproduced exactly.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL UNIQUE,
    email         TEXT,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'viewer',
    created       INTEGER NOT NULL,
    disabled      INTEGER NOT NULL DEFAULT 0,
    settings      TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS sessions (
    id        TEXT PRIMARY KEY,
    user_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created   INTEGER NOT NULL,
    last_seen INTEGER NOT NULL,
    expires   INTEGER NOT NULL,
    csrf      TEXT NOT NULL,
    ip        TEXT,
    agent     TEXT
);

CREATE TABLE IF NOT EXISTS invites (
    code       TEXT PRIMARY KEY,
    role       TEXT NOT NULL DEFAULT 'viewer',
    created    INTEGER NOT NULL,
    expires    INTEGER NOT NULL,
    used_by    INTEGER REFERENCES users(id),
    used_at    INTEGER,
    created_by INTEGER REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS projects (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    slug     TEXT NOT NULL UNIQUE,
    name     TEXT NOT NULL,
    path     TEXT NOT NULL,
    revision TEXT,
    status   TEXT NOT NULL DEFAULT 'ready',
    meta     TEXT NOT NULL DEFAULT '{}',
    lat      REAL,
    crs      TEXT,
    lon      REAL,
    created  INTEGER NOT NULL,
    updated  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    key     TEXT NOT NULL,
    value   TEXT NOT NULL,
    PRIMARY KEY (user_id, key)
);

CREATE TABLE IF NOT EXISTS scans (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name       TEXT NOT NULL,
    path       TEXT NOT NULL,
    kind       TEXT NOT NULL,
    rows       INTEGER,
    cols       INTEGER,
    size       INTEGER,
    mtime      INTEGER,
    meta       TEXT NOT NULL DEFAULT '{}',
    -- Rigid transform from the scan frame to the project frame, as 16 JSON numbers.
    -- Empty means "not registered", which is not the same as "at the origin".
    pose       TEXT NOT NULL DEFAULT '[]',
    created    INTEGER NOT NULL,
    UNIQUE (project_id, name)
);

CREATE TABLE IF NOT EXISTS shares (
    token      TEXT PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    role       TEXT NOT NULL DEFAULT 'viewer',
    created    INTEGER NOT NULL,
    expires    INTEGER,
    created_by INTEGER REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS layers (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name       TEXT NOT NULL,
    owner_id   INTEGER REFERENCES users(id),
    colour     TEXT NOT NULL DEFAULT '#ffcc00',
    visible    INTEGER NOT NULL DEFAULT 1,
    created    INTEGER NOT NULL,
    updated    INTEGER NOT NULL,
    deleted_at INTEGER,
    deleted_by INTEGER
);

CREATE TABLE IF NOT EXISTS features (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    layer_id   INTEGER NOT NULL REFERENCES layers(id) ON DELETE CASCADE,
    kind       TEXT NOT NULL,
    geom       TEXT NOT NULL,
    label      TEXT,
    created    INTEGER NOT NULL,
    created_by INTEGER,
    deleted_at INTEGER,
    deleted_by INTEGER,
    undo_group TEXT
);

CREATE TABLE IF NOT EXISTS drawings (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name       TEXT NOT NULL,
    geom       TEXT NOT NULL,
    meta       TEXT NOT NULL DEFAULT '{}',
    created    INTEGER NOT NULL,
    created_by INTEGER,
    deleted_at INTEGER,
    deleted_by INTEGER
);

CREATE INDEX IF NOT EXISTS drawings_project ON drawings(project_id, deleted_at);

-- How a project's drawings are placed in the scan frames. A DXF carries coordinates in
-- whatever system it was drawn in; this row is the declaration that turns those into the
-- scan's own metres: subtract the origin, scale by the drawing's unit, rotate by the angle
-- between the drawing's +X and the scan's forward direction.
CREATE TABLE IF NOT EXISTS drawing_frames (
    project_id INTEGER PRIMARY KEY REFERENCES projects(id) ON DELETE CASCADE,
    origin_x   REAL NOT NULL DEFAULT 0,
    origin_y   REAL NOT NULL DEFAULT 0,
    origin_z   REAL NOT NULL DEFAULT 0,
    rotation   REAL NOT NULL DEFAULT 0,
    scale      REAL NOT NULL DEFAULT 1,
    created    INTEGER NOT NULL,
    created_by INTEGER
);

CREATE TABLE IF NOT EXISTS feature_revisions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    feature_id INTEGER NOT NULL,
    project_id INTEGER NOT NULL,
    version    INTEGER NOT NULL,
    kind       TEXT NOT NULL,
    geom       TEXT NOT NULL,
    label      TEXT,
    layer_id   INTEGER NOT NULL,
    action     TEXT NOT NULL,
    created    INTEGER NOT NULL,
    created_by INTEGER,
    UNIQUE (feature_id, version)
);

CREATE INDEX IF NOT EXISTS revisions_feature ON feature_revisions(feature_id);
CREATE INDEX IF NOT EXISTS features_layer ON features(layer_id, deleted_at);
CREATE INDEX IF NOT EXISTS scans_project ON scans(project_id);

CREATE TABLE IF NOT EXISTS audit (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      INTEGER NOT NULL,
    user_id INTEGER,
    action  TEXT NOT NULL,
    detail  TEXT,
    ip      TEXT,
    status  INTEGER NOT NULL DEFAULT 200
);

CREATE INDEX IF NOT EXISTS audit_ts ON audit(ts);

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


def now() -> int:
    """The current time as an integer epoch second, which is what every created/updated column stores."""
    return int(time.time())


class Store:
    """Thread-safe access to one SQLite file.

    Connections are per thread (SQLite objects are not shareable) and every connection is
    opened with ``check_same_thread=False`` only for the connection that owns it.
    """

    def __init__(self, path: Path):
        """Point the store at a database file; the connection is made per thread on first use."""
        self.path = Path(path)
        self._local = threading.local()
        self._init_lock = threading.Lock()
        self.init()

    # -- connections -----------------------------------------------------
    def connect(self) -> sqlite3.Connection:
        """The calling thread's connection, created and configured on first use."""
        connection = getattr(self._local, "connection", None)
        if connection is None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            connection = sqlite3.connect(self.path, timeout=30.0, isolation_level=None)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA busy_timeout=30000")
            connection.execute("PRAGMA foreign_keys=ON")
            self._local.connection = connection
        return connection

    def close(self) -> None:
        """Close this thread's connection."""
        connection = getattr(self._local, "connection", None)
        if connection is not None:
            connection.close()
            self._local.connection = None

    def migrate(self, connection: sqlite3.Connection) -> None:
        """Add columns that a database created by an older build does not have."""
        columns = {row[1] for row in connection.execute("PRAGMA table_info(scans)")}
        if columns and "pose" not in columns:
            connection.execute("ALTER TABLE scans ADD COLUMN pose TEXT NOT NULL DEFAULT '[]'")
        placed = {row[1] for row in connection.execute("PRAGMA table_info(projects)")}
        if placed and "lat" not in placed:
            connection.execute("ALTER TABLE projects ADD COLUMN lat REAL")
            connection.execute("ALTER TABLE projects ADD COLUMN lon REAL")
        if placed and "crs" not in placed:
            # Declared only. Neither FARO format states a coordinate reference system, so this
            # is what a person wrote down, and nothing in the app reprojects because of it.
            connection.execute("ALTER TABLE projects ADD COLUMN crs TEXT")
        if placed and "location_source" not in placed:
            # Where a position came from: a person typed it, or it was read off a scan's GPS.
            connection.execute("ALTER TABLE projects ADD COLUMN location_source TEXT")

    def init(self) -> None:
        """Create the schema and run the migrations, under a lock so two workers cannot race."""
        with self._init_lock:
            connection = self.connect()
            connection.executescript(SCHEMA)
            self.migrate(connection)
            connection.commit()

    # -- helpers ---------------------------------------------------------
    def query(self, sql: str, args: tuple = ()) -> list[sqlite3.Row]:
        """Every row the statement returns, as mappings."""
        return list(self.connect().execute(sql, args))

    def one(self, sql: str, args: tuple = ()) -> sqlite3.Row | None:
        """The first row the statement returns, as a mapping, or None."""
        return self.connect().execute(sql, args).fetchone()

    def scalar(self, sql: str, args: tuple = ()):
        """The first column of the first row, or None."""
        row = self.one(sql, args)
        return None if row is None else row[0]

    def execute(self, sql: str, args: tuple = ()) -> int:
        """Run a statement and return its cursor, committing as it goes."""
        cursor = self.connect().execute(sql, args)
        return cursor.lastrowid or cursor.rowcount

    def transaction(self):
        """Context manager giving an explicit transaction."""
        return _Transaction(self.connect())

    # -- meta ------------------------------------------------------------
    def get_meta(self, key: str, default: str | None = None) -> str | None:
        """A value from the small key/value table the application keeps for its own state."""
        value = self.scalar("SELECT value FROM meta WHERE key = ?", (key,))
        return default if value is None else value

    def set_meta(self, key: str, value: str) -> None:
        """Store a value in the key/value table, replacing any previous one."""
        self.execute(
            "INSERT INTO meta(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )

    def get_json_meta(self, key: str, default=None):
        """A JSON value from the key/value table, or the default when it is missing or malformed."""
        raw = self.get_meta(key)
        if raw is None:
            return default
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return default

    # -- audit -----------------------------------------------------------
    def audit(self, action: str, user_id: int | None = None, detail="", ip: str | None = None, status: int = 200) -> None:
        """Record a write: who, what, from where and how it went."""
        if not isinstance(detail, str):
            detail = json.dumps(detail, separators=(",", ":"), default=str)
        self.execute(
            "INSERT INTO audit(ts, user_id, action, detail, ip, status) VALUES(?,?,?,?,?,?)",
            (now(), user_id, action, detail[:4000], ip, status),
        )


class _Transaction:
    """Commits on a clean exit and rolls back on any exception, so a route cannot half-write."""
    def __init__(self, connection: sqlite3.Connection):
        """Hold the connection the transaction runs on."""
        self.connection = connection

    def __enter__(self) -> sqlite3.Connection:
        """Begin an immediate transaction, so two writers cannot interleave."""
        self.connection.execute("BEGIN IMMEDIATE")
        return self.connection

    def __exit__(self, exc_type, exc, tb) -> None:
        """Commit on a clean exit and roll back on any exception."""
        if exc_type is None:
            self.connection.execute("COMMIT")
        else:
            self.connection.execute("ROLLBACK")

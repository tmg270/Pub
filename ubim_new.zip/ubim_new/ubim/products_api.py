"""Glue between the HTTP routes and the product code.

Everything the API needs to know about a scan's products lives here, so the routes stay
free of filesystem details. Paths are always derived from the scan path in the database,
never from anything in the request.
"""

from __future__ import annotations

import json
import shutil
import math
from pathlib import Path

import numpy as np

from .config import Config
from .formats.fls import FlsFile
from .products import build as intensity_build
from .products import depth as depth_product, photo as photo_build
from .products import intensity as I
from .products import plan as plan_build
from .products import pyramid
from .projects import product_root


def mapping() -> dict:
    """The intensity ramp definitions, as the API reports them."""
    return dict(I.MAPPING)


def open_scan(path: Path) -> FlsFile:
    """Open a scan for reading, choosing the reader by suffix."""
    return FlsFile(path)


def product_dir(scan_path: Path, config: Config) -> Path:
    """Where a scan's products live: beside the scan, under the data root when that is not writable."""
    return product_root(scan_path, config)


def summary(scan_path: Path, config: Config) -> dict:
    """What products exist for this scan, and whether they match the scan on disk."""
    root = product_dir(scan_path, config)
    intensity_meta = intensity_build.load_meta(root)
    depth_meta = depth_product.load_meta(root)
    return {
        "root": str(root),
        "intensity": {
            "built": intensity_meta is not None,
            "fresh": intensity_build.is_fresh(intensity_meta, scan_path),
            "width": (intensity_meta or {}).get("width"),
            "height": (intensity_meta or {}).get("height"),
            "ramps": (intensity_meta or {}).get("ramps", []),
        },
        "depth": {
            "built": depth_meta is not None,
            "width": (depth_meta or {}).get("width"),
            "height": (depth_meta or {}).get("height"),
            "maxRaw": (depth_meta or {}).get("maxRaw"),
        },
        "photo": {
            "built": photo_build.load_meta(root) is not None,
            "available": Path(scan_path).suffix.lower() == ".fls",
            "width": (photo_build.load_meta(root) or {}).get("width"),
            "height": (photo_build.load_meta(root) or {}).get("height"),
        },
        "plan": {
            "built": plan_build.load(root) is not None,
            "size": (plan_build.load(root) or {}).get("size"),
            "cellMetres": (plan_build.load(root) or {}).get("cellMetres"),
        },
    }


def intensity_meta(scan_path: Path, config: Config) -> dict | None:
    """The intensity manifest, or None."""
    root = product_dir(scan_path, config)
    meta = intensity_build.load_meta(root)
    if meta is None:
        return None
    meta = dict(meta)
    meta["fresh"] = intensity_build.is_fresh(meta, scan_path)
    meta["tiles"] = {
        ramp: f"/api/p/{{project}}/s/{{scan}}/intensity/{ramp}/{{z}}/{{col}}/{{row}}.png"
        for ramp in meta.get("ramps", [])
    }
    return meta


def intensity_tile(scan_path: Path, config: Config, ramp: str, level: int, col: int, row: int) -> Path | None:
    """The path of one intensity tile, or None when it is outside the manifest."""
    root = product_dir(scan_path, config) / intensity_build.INTENSITY_DIR
    return pyramid.find_tile(root, ramp, level, col, row)


def depth_meta(scan_path: Path, config: Config) -> dict | None:
    """The depth manifest, or None."""
    root = product_dir(scan_path, config)
    meta = depth_product.load_meta(root)
    if meta is None:
        return None
    meta = dict(meta)
    meta["tiles"] = "/api/p/{project}/s/{scan}/depth/{z}/{col}/{row}.png"
    return meta


def depth_tile(scan_path: Path, config: Config, level: int, col: int, row: int) -> Path | None:
    """The path of one depth tile, or None."""
    root = product_dir(scan_path, config) / "depth_tiles"
    return pyramid.find_tile(root, "grey", level, col, row)


def depth_ready(scan_path: Path, config) -> bool:
    """True when a range product exists for this scan (built by the job or another process)."""
    return depth_product.load_meta(product_dir(scan_path, config)) is not None


def pick(scan_path: Path, config: Config, azimuth_deg: float, elevation_deg: float, snap: bool = True) -> dict | None:
    """Distance at a direction. Angles arrive in degrees because that is what the client has.

    With ``snap`` on (the default, spec M3a) an empty pixel falls back to the nearest real
    return within three grid cells, and the reply carries ``snapped`` plus how far it moved.
    """
    import math

    root = product_dir(scan_path, config)
    meta = depth_product.load_meta(root)
    if meta is None:
        return None
    hit = depth_product.sample(root, meta, math.radians(azimuth_deg), math.radians(elevation_deg))
    if hit is None and snap:
        hit = depth_product.nearest(root, meta, math.radians(azimuth_deg), math.radians(elevation_deg))
    if hit is None:
        return None
    hit.setdefault("snapped", False)
    # A measured range is not the same as a trustworthy height (spec M2). Say when it is thin:
    # the snapped cell has little support around it, the pick moved more than one cell, or the
    # cell is at the top or bottom edge of the sweep.
    local = depth_product.neighbourhood(root, meta, int(hit["x"]), int(hit["y"]))
    offset = hit.get("cellOffset") or {"x": 0, "y": 0}
    moved = max(abs(int(offset["x"])), abs(int(offset["y"])))
    uncertain = []
    if local["support"] < 3:
        uncertain.append("isolated-return")
    if moved > 1:
        uncertain.append("snapped-far")
    if local["edge"]:
        uncertain.append("grid-edge")
    hit["support"] = local["support"]
    hit["heightUncertain"] = bool(uncertain)
    hit["uncertainBecause"] = uncertain
    # Cartesian position in the scan frame, for distances and areas in the viewer.
    az = math.radians(azimuth_deg)
    el = math.radians(elevation_deg)
    r = float(hit["raw"])
    return {
        **hit,
        "metres": hit.get("metres"),
        "azimuthDeg": azimuth_deg,
        "elevationDeg": elevation_deg,
        "position": {"x": r * math.cos(el) * math.cos(az), "y": r * math.cos(el) * math.sin(az), "z": r * math.sin(el)},
    }


#: What a build costs per output pixel, in bytes. The figures are upper bounds: the level-0
#: RGB surface plus one pyramid level, and the uint32 range grid plus its pyramid. The plan is a
#: fixed raster rather than one pixel per scan column, and the photograph is sized from its own
#: header, so both are handled separately.
_BYTES_PER_KIND = {"intensity": 4.0, "depth": 5.0}
PLAN_MIB = 32.0


def _level0(scan_path: Path) -> tuple[int, int] | None:
    """Native product size, read from the file header only."""
    suffix = scan_path.suffix.lower()
    try:
        if suffix == ".f3s":
            from .formats.f3s import COLS as width, ROWS as height

            return int(width), int(height)
        from .formats.fls import FlsFile

        with FlsFile(scan_path) as scan:
            return I.level0_size(scan.header)
    except Exception:  # noqa: BLE001 - an unreadable header is reported by the build itself
        return None


def _photo_mib(scan_path: Path) -> float:
    """Peak cost of tiling a photograph: one decoded RGB copy of it, plus a quarter again."""
    try:
        source = photo_build._source_for(scan_path)
        if source is None:
            return 0.0
        from PIL import Image

        with Image.open(source) as image:
            width, height = image.size  # header only, no pixels decoded
        return round(width * height * 3 * 1.25 / (1 << 20), 1)
    except Exception:  # noqa: BLE001 - an estimate must never stop a build
        return 0.0


def estimate_mib(scan_path: Path, kinds: list[str]) -> dict:
    """Rough memory each requested kind would need, and the total.

    Spec C4 asks for caps rather than an out-of-memory kill. The numbers are computed from the
    header's own geometry, so they cost nothing to produce and are shown before a build starts.
    """
    size = _level0(scan_path)
    if size is None:
        return {"pixels": None, "perKind": {}, "totalMiB": None}
    width, height = size
    pixels = width * height
    per_kind = {}
    for kind in kinds:
        if kind == "plan":
            per_kind[kind] = PLAN_MIB
        elif kind == "photo":
            per_kind[kind] = _photo_mib(scan_path)
        else:
            per_kind[kind] = round(pixels * _BYTES_PER_KIND.get(kind, 4.0) / (1 << 20), 1)
    return {"pixels": pixels, "perKind": per_kind, "totalMiB": round(sum(per_kind.values()), 1)}


def build_products(scan_path: Path, config: Config, kinds: list[str], progress=None) -> dict:
    """Build the requested products. Raises if the disk guard or the memory cap would be crossed."""
    estimate = estimate_mib(scan_path, kinds)
    if estimate["totalMiB"] is not None and estimate["totalMiB"] > config.max_build_mb:
        raise MemoryError(
            f"this build needs about {estimate['totalMiB']:.0f} MiB and the cap is "
            f"{config.max_build_mb} MiB (UBIM_MAX_BUILD_MB); build one product at a time or raise the cap"
        )
    root = product_dir(scan_path, config)
    guard = config.disk_guard_gb * (1 << 30)
    free = shutil.disk_usage(root).free
    if free < guard:
        raise RuntimeError(f"only {free / (1 << 30):.1f} GiB free, the guard is {config.disk_guard_gb:.1f} GiB")
    result = {}
    # Spec C2: when both products are asked for, the scan is decoded once. The combined build
    # finishes both from the kept raw image and the range grid, and is byte-identical to the
    # separate builds (test_dual_build proves it on the reference scan).
    combined = False
    if {"intensity", "depth"} <= set(kinds) and scan_path.suffix.lower() == ".fls":
        from .products import dual

        result.update(dual.build(scan_path, root, progress))
        combined = True
    if "intensity" in kinds and not combined:
        if scan_path.suffix.lower() == ".f3s":
            # The 2026 format keeps colour in its trailing record bytes, not a scalar
            # intensity. Render the colour luma so a scan is still viewable, and say so in
            # the manifest; a real intensity product still wins when one exists.
            from .formats.f3s import F3sFile

            scan = F3sFile.read(scan_path)
            result["intensity"] = intensity_build.build_from_luma(root, scan.intensity(), scan_path, progress)
        else:
            result["intensity"] = intensity_build.build(root, scan_path, progress)
    if "depth" in kinds and not combined:
        result["depth"] = depth_product.build(root, scan_path, progress)
    # The plan is a raster of the range product, so it can only be built after it.
    if "photo" in kinds:
        result["photo"] = photo_build.build(root, scan_path, progress)
    if "plan" in kinds:
        result["plan"] = plan_build.build(root, progress, name=scan_path.name)
    return result


def forget(scan_path: Path, config: Config) -> None:
    """Remove a scan's products, leaving the source file untouched."""
    root = product_dir(scan_path, config)
    if root.exists():
        shutil.rmtree(root, ignore_errors=True)


def pano_fallback(scan_path: Path, config: Config, max_size: int = 4096) -> Path | None:
    """A JPEG panorama for a scan that has no FARO images, made from its colour product.

    A ``.f3s`` project may carry no ``WebShareData/Images`` at all, and then the viewer has
    nothing to draw. The colour product already holds every pixel, so the largest level that
    fits is stitched once and cached beside it. The image is the scan's own colour, not a
    recolour of FARO's grey, and the response says so in a header.
    """
    from PIL import Image

    root = product_dir(scan_path, config)
    meta = intensity_build.load_meta(root)
    if meta is None:
        return None
    levels = [level for level in meta.get("levels") or [] if level.get("cols") and level.get("rows")]
    if not levels:
        return None
    # Prefer the smallest level that still covers the requested width, then downscale it; that
    # is sharper than upscaling a smaller level and no more work.
    wider = [level for level in levels if int(level["width"]) >= max_size]
    level = min(wider, key=lambda l: l["width"]) if wider else max(levels, key=lambda l: l["width"])
    target = root / f"pano_luma_{int(max_size)}_f2.jpg"
    if target.exists():
        return target
    tile = int(level.get("tile") or 512)
    surface = Image.new("RGB", (int(level["cols"]) * tile, int(level["rows"]) * tile), (0, 0, 0))
    folder = root / "intensity" / "grey" / f"L{level['z']}"
    drawn = 0
    for x in range(int(level["cols"])):
        for y in range(int(level["rows"])):
            path = folder / str(x) / f"{y}.png"
            if not path.exists():
                continue
            with Image.open(path) as piece:
                surface.paste(piece.convert("RGB"), (x * tile, y * tile))
            drawn += 1
    if drawn == 0:
        return None
    surface = surface.crop((0, 0, int(level["width"]), int(level["height"])))
    # The grid is sparse where the scanner saw the ground at a grazing angle, and rendering
    # only the cells that hold a point leaves thin dark slivers through the surface. Fill
    # those from a coarser copy of the same scan: it is interpolation of the scan's own
    # colour, not invention, and it only touches pixels that hold nothing.
    # Spread what the scan did see into the gaps: a maximum filter first, so a thin sliver
    # takes its colour from the nearest returns around it, then a blur so the fill is a
    # surface rather than a set of dots.
    from PIL import ImageFilter

    spread = surface.filter(ImageFilter.MaxFilter(7)).filter(ImageFilter.GaussianBlur(3))
    holes = surface.convert("L").point(lambda value: 255 if value < 8 else 0)
    surface = Image.composite(spread, surface, holes)
    if surface.width > max_size:
        height = max(1, round(surface.height * max_size / surface.width))
        surface = surface.resize((max_size, height), Image.LANCZOS)
    surface.save(target, "JPEG", quality=82)
    return target


def photo_meta(scan_path: Path, config: Config) -> dict | None:
    """The photograph manifest, or None."""
    return photo_build.load_meta(product_dir(scan_path, config))


def photo_tile(scan_path: Path, config: Config, level: int, col: int, row: int) -> Path | None:
    """The path of one photograph tile, or None."""
    return photo_build.tile_path(product_dir(scan_path, config), level, col, row)


def plan_meta(scan_path: Path, config: Config) -> dict | None:
    """The plan manifest, or None."""
    return plan_build.load(product_dir(scan_path, config))


def plan_probe(scan_path: Path, config: Config, x: float, y: float) -> dict | None:
    """What the scan sees at a point on its own site plan.

    The plan is a top-down raster in the scan's frame, so a hovered pixel names a ground
    position and nothing more: the distance from the scanner and the bearing follow from the
    coordinates, but the elevation of whatever is there has to come from the range product.
    Rather than invent a height from the shading, the depth grid is searched along that bearing
    for the return closest to the hovered distance, and its elevation is reported — with
    ``hit: false`` when nothing is close enough to claim.
    """
    root = product_dir(scan_path, config)
    plan = plan_build.load(root)
    if plan is None:
        return None
    bounds = plan.get("bounds") or {}
    if not all(key in bounds for key in ("minX", "minY", "maxX", "maxY")):
        return None
    if not (bounds["minX"] <= x <= bounds["maxX"] and bounds["minY"] <= y <= bounds["maxY"]):
        return None
    distance = math.hypot(x, y)
    azimuth = math.degrees(math.atan2(y, x))
    out = {
        "x": round(x, 2), "y": round(y, 2),
        "distanceM": round(distance, 2),
        "azimuthDeg": round(azimuth % 360.0, 1),
        "hit": False,
        "nearRangeM": None,
        "nearElevationDeg": None,
        "elevationDeg": None,
        "heightM": None,
        "rangeM": None,
    }
    meta = depth_product.load_meta(root)
    if meta is None or distance <= 1e-6:
        return out
    grid = depth_product.read_grid(root, meta)
    from .products.intensity import AZ0_DEG

    width = int(meta["width"])
    col = int(round((AZ0_DEG - azimuth) * width / 360.0)) % width
    # The bearing is stored anticlockwise from +X in the products, and the hovered azimuth is
    # measured the same way, so one column is the whole answer.
    column = np.asarray(grid[:, col], dtype=np.float64)
    factor = float(meta.get("distFact") or 100000.0)
    ranges = column / factor
    usable = np.isfinite(ranges) & (ranges > 0)
    if not usable.any():
        return out
    rows = np.nonzero(usable)[0]
    nearest = rows[np.argmin(np.abs(ranges[rows] - distance))]
    best = float(ranges[nearest])
    from .products.intensity import TOP_DEG, SPAN_DEG

    out["nearRangeM"] = round(best, 2)
    out["nearElevationDeg"] = round(float(TOP_DEG - nearest * SPAN_DEG / int(meta["height"])), 1)
    # The plan keeps a pixel for ground the range product only sampled coarsely, so a gap here
    # is normal. Report the closest real return on that bearing instead of pretending there is
    # nothing, and only claim a hit when it is genuinely near the hovered distance.
    if abs(best - distance) > max(2.0, distance * 0.25):
        return out
    elevation = TOP_DEG - nearest * SPAN_DEG / int(meta["height"])
    out.update({
        "hit": True,
        "rangeM": round(best, 2),
        "elevationDeg": round(float(elevation), 1),
        "heightM": round(float(best * math.sin(math.radians(elevation))), 2),
    })
    return out


def plan_scaled(scan_path: Path, config: Config, size: int, filled: bool = False) -> Path | None:
    """The plan at a requested width, so a page can ask for what it will display."""
    return plan_build.scaled(product_dir(scan_path, config), size, filled)


def plan_tile(scan_path: Path, config: Config, level: int, col: int, row: int) -> Path | None:
    """The path of one plan tile, or None."""
    return plan_build.tile_path(product_dir(scan_path, config), level, col, row)


def plan_image(scan_path: Path, config: Config, filled: bool = False) -> Path | None:
    """The plan image path for the filled or outlined variant."""
    name = plan_build.PLAN_FILLED if filled else plan_build.PLAN_NAME
    path = product_dir(scan_path, config) / name
    return path if path.exists() else None

"""Background jobs for product building.

One small thread pool, jobs tracked in memory with their progress. A job is deliberately
not persisted: if the process restarts, the product manifest on disk is the truth and the job
is simply started again. Progress is reported through a callback so the builder code does
not need to know about HTTP.
"""

from __future__ import annotations

import logging
import threading
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .config import Config
from .store import Store

log = logging.getLogger("ubim.jobs")

_JOBS: dict[str, dict] = {}
_LOCK = threading.Lock()
_POOL: ThreadPoolExecutor | None = None
_POOL_SIZE = 0


def _pool(size: int) -> ThreadPoolExecutor:
    """The worker pool, created once and reused so a second build does not spawn a second set of threads."""
    global _POOL, _POOL_SIZE
    with _LOCK:
        if _POOL is None or _POOL_SIZE != size:
            _POOL = ThreadPoolExecutor(max_workers=size, thread_name_prefix="ubim-job")
            _POOL_SIZE = size
        return _POOL


def get(job_id: str) -> dict | None:
    """A copy of the job's state, or None when the id is unknown."""
    with _LOCK:
        job = _JOBS.get(job_id)
        return dict(job) if job else None


def list_recent(limit: int = 20) -> list[dict]:
    """The most recent jobs, newest first, for the admin Scans panel."""
    with _LOCK:
        jobs = sorted(_JOBS.values(), key=lambda job: job["created"], reverse=True)[:limit]
        return [dict(job) for job in jobs]


def _update(job_id: str, **fields) -> None:
    """Change fields of a job under the lock and stamp the update time."""
    with _LOCK:
        job = _JOBS.get(job_id)
        if job is not None:
            job.update(fields)


def start(store: Store, config: Config, scan_path: Path, kinds: list[str]) -> dict:
    """Queue a build for one scan and return the job id; the caller does not wait."""
    from . import products_api

    job_id = uuid.uuid4().hex[:12]
    job = {
        "id": job_id,
        "scan": scan_path.name,
        "kinds": kinds,
        "state": "queued",
        "progress": 0.0,
        "stage": "",
        "message": "",
        "created": int(time.time()),
        "started": None,
        "finished": None,
    }
    with _LOCK:
        _JOBS[job_id] = job

    def progress(stage: str, fraction: float) -> None:
        """Report a build's stage and counts to the job record, which is what the interface polls."""
        _update(job_id, stage=stage, progress=max(0.0, min(1.0, float(fraction))))

    def work() -> None:
        """The pool's task: build the products, then record success or the failure message."""
        _update(job_id, state="running", started=int(time.time()))
        started = time.monotonic()
        try:
            result = products_api.build_products(scan_path, config, kinds, progress)
            _update(
                job_id, state="done", progress=1.0, stage="done",
                finished=int(time.time()), seconds=round(time.monotonic() - started, 2),
                result={k: {"width": v.get("width"), "height": v.get("height"), "seconds": v.get("seconds")} for k, v in result.items()},
            )
            store.audit("product.build", None, {"scan": scan_path.name, "kinds": kinds}, None, 200)
        except Exception as exc:  # noqa: BLE001 - a failed job must not kill the pool
            log.exception("job %s failed", job_id)
            _update(job_id, state="failed", stage="failed", message=str(exc),
                    trace=traceback.format_exc()[-2000:], finished=int(time.time()))
            store.audit("product.build", None, {"scan": scan_path.name, "error": str(exc)}, None, 500)

    _pool(config.workers).submit(work)
    return dict(job)


def shutdown() -> None:
    """Stop accepting work and join the pool; called on application shutdown."""
    global _POOL
    with _LOCK:
        if _POOL is not None:
            _POOL.shutdown(wait=False, cancel_futures=True)
            _POOL = None

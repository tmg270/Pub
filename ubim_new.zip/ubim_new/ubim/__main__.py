"""``python -m ubim`` — run the server.

Kept deliberately thin: configuration comes from the environment (see :mod:`ubim.config`),
and the only arguments are the ones you want to override while developing.
"""

from __future__ import annotations

import argparse
import logging
import os


def main(argv: list[str] | None = None) -> int:
    """Run the server: parse ``--host``/``--port``/``--data-dir``, load the configuration and serve the app."""
    parser = argparse.ArgumentParser(prog="ubim", description="uBIM viewer server")
    parser.add_argument("--host", default=None, help="bind address (default 0.0.0.0)")
    parser.add_argument("--port", type=int, default=None, help="port (default 8431)")
    parser.add_argument("--data-dir", default=None, help="data directory (default /data)")
    parser.add_argument("--log-level", default="info")
    parser.add_argument(
        "--set-password",
        metavar="NAME",
        default=None,
        help="set this user's password, then exit without serving (use for a lost admin password)",
    )
    parser.add_argument(
        "--password",
        default=None,
        help="the new password for --set-password; read from UBIM_ADMIN_PASSWORD or stdin when omitted",
    )
    args = parser.parse_args(argv)

    if args.data_dir:
        os.environ["UBIM_DATA_DIR"] = args.data_dir
    if args.host:
        os.environ["UBIM_HOST"] = args.host
    if args.port:
        os.environ["UBIM_PORT"] = str(args.port)

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    from .app import create_from_env
    from .config import load

    if args.set_password:
        return _set_password(args.set_password, args.password)

    app = create_from_env()
    config = load()

    import uvicorn

    uvicorn.run(app, host=config.host, port=config.port, log_level=args.log_level, access_log=True)
    return 0


def _set_password(name: str, value: str | None) -> int:
    """Apply a password change to the store and exit, without starting the server.

    Reads the password from ``--password``, then ``UBIM_ADMIN_PASSWORD``, then stdin, so it can
    be used non-interactively in a container and still not have to travel on a command line.
    """
    import sys

    from .auth import set_password
    from .config import load
    from .store import Store

    config = load()
    if value is None:
        value = os.environ.get("UBIM_ADMIN_PASSWORD") or ""
    if not value:
        if sys.stdin.isatty():
            import getpass

            value = getpass.getpass(f"new password for {name}: ")
        else:
            value = sys.stdin.readline().strip()
    if not value:
        print("no password given", file=sys.stderr)
        return 2

    store = Store(config.db_path)
    store.init()
    try:
        set_password(store, name, value)
    except ValueError as error:
        print(error, file=sys.stderr)
        return 1
    print(f"password updated for {name} in {config.db_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""``python -m ubim`` — run the server.

Kept deliberately thin: configuration comes from the environment (see :mod:`ubim.config`),
and the only arguments are the ones you want to override while developing.
"""

from __future__ import annotations

import argparse
import logging
import os


def main(argv: list[str] | None = None) -> int:
    """Run the server: parse ``--host``/``--port``/``--data-dir``, load the configuration and serve the app."""
    parser = argparse.ArgumentParser(prog="ubim", description="uBIM viewer server")
    parser.add_argument("--host", default=None, help="bind address (default 0.0.0.0)")
    parser.add_argument("--port", type=int, default=None, help="port (default 8431)")
    parser.add_argument("--data-dir", default=None, help="data directory (default /data)")
    parser.add_argument("--log-level", default="info")
    args = parser.parse_args(argv)

    if args.data_dir:
        os.environ["UBIM_DATA_DIR"] = args.data_dir
    if args.host:
        os.environ["UBIM_HOST"] = args.host
    if args.port:
        os.environ["UBIM_PORT"] = str(args.port)

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    from .app import create_from_env
    from .config import load

    app = create_from_env()
    config = load()

    import uvicorn

    uvicorn.run(app, host=config.host, port=config.port, log_level=args.log_level, access_log=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Readers for the on-disk scan containers.

``fls`` is the FARO laser-scan container (OLE compound file with deflated range strips),
``f3s`` the 2026 sample layout (a compound file with ten-byte leaf records), and ``cfb`` the
small compound-file reader they both use."""


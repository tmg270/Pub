"""FARO ``.fls`` reader: header, OLE streams, varint columns, angles.

Everything here was measured against a real file (SCAN_085, 191,418,368 B) and the
decode is checked by ``tests/test_fls_real.py`` against a reference sha256. The format
notes live in ``docs/FORMATS.md``; the short version:

* ``Main`` is text with ``Name "X"\\nValue N`` pairs.
* ``Scans/1/DistN`` and ``Scans/1/GreyN`` are raw-deflate streams (the gzip trailer may
  be missing) whose text header ends at ``{ ``; after that come varint records.
* A record is a signed delta from the previous row in the same column: bit 7 means
  another byte follows, bit 6 is the sign, bits 0-5 are the low magnitude bits, later
  bytes carry 7 bits least-significant first. Every column starts at 0.
* ``Scans/1/Calib`` holds one (double angle, double reserved) pair per column; the local
  azimuth is ``-angle``. A linear model is wrong by up to about 1 degree.

Nothing in this module writes to the source file, and every allocation is bounded by a
constant that is checked before the allocation happens.
"""

from __future__ import annotations

import re
import zlib
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .cfb import FormatError, OleContainer, StreamTooLarge

# Hostile-file bounds (the viewer's R22). Checked before allocating.
MAX_DIM = 40_000
MAX_CELLS = 200_000_000
MAX_STREAM = 0x1900_0000  # 419,430,400 B, the pack's ceiling for one inflated stream
MAX_HEADER = 8 << 20
MAX_HLS = 4096
MAX_CALIB = 0x400_0000
MAX_EXTRA_RECORDS = 4  # see decode: FARO's streams carry a couple of trailing records

#: Row shift fitted on SCAN_085 (docs/FORMATS.md). Never re-fit from one overlap.
ROW_SHIFT = 8.0


@dataclass(frozen=True)
class FlsHeader:
    """The geometry a FARO scan declares: image size, angular spans, offsets, camera calibration and the elevation of the first row."""
    rows: int
    cols: int
    row_start: float
    row_end: float
    col_end: float
    unit: float
    grey_bits: int
    dist_fact: float
    vert_factor: float

    def row_step(self) -> float:
        """Degrees of elevation per row, from the header's row span."""
        return (self.row_start - self.row_end) / self.rows

    def elevation(self, row: float) -> float:
        """Elevation in radians for a fractional row, with the fitted shift applied."""
        return self.row_start - (row + ROW_SHIFT) * self.row_step()

    def row_for(self, elevation: float) -> float:
        """The row for an elevation, including the header's vertical offset."""
        return (self.row_start - elevation) / self.row_step() - ROW_SHIFT

    def elevation_deg(self, row: float) -> float:
        """Elevation in degrees, for reporting and for the client's mapping constants."""
        return float(np.degrees(self.elevation(row)))


@dataclass(frozen=True)
class StreamRect:
    """One data stream and the grid rectangle it holds."""

    name: str
    kind: str  # "Dist" | "Grey"
    index: int
    col0: int
    col1: int
    row0: int
    row1: int

    @property
    def cols(self) -> int:
        """How many columns the stream covers."""
        return self.col1 - self.col0

    @property
    def rows(self) -> int:
        """How many rows the stream covers."""
        return self.row1 - self.row0


def inflate_gzip_prefix(raw: bytes, max_bytes: int) -> bytes:
    """Inflate a gzip stream that may be missing its trailer.

    FARO writes a normal gzip header but sometimes stops before the 8-byte trailer, so
    ``zlib.decompress(raw, 31)`` fails. We skip the header ourselves and run raw deflate
    with an output ceiling.
    """
    if len(raw) < 10 or raw[0] != 0x1F or raw[1] != 0x8B or raw[2] != 8:
        raise FormatError("not a gzip stream")
    flags = raw[3]
    pos = 10
    if flags & 0x04:  # FEXTRA
        if pos + 2 > len(raw):
            raise FormatError("truncated gzip extra field")
        pos += 2 + int.from_bytes(raw[pos : pos + 2], "little")
    for bit in (0x08, 0x10):  # FNAME, FCOMMENT
        if flags & bit:
            end = raw.find(b"\x00", pos)
            if end < 0:
                raise FormatError("truncated gzip name")
            pos = end + 1
    if flags & 0x02:  # FHCRC
        pos += 2
    if pos >= len(raw):
        raise FormatError("gzip header past end of stream")
    engine = zlib.decompressobj(-15)
    out = bytearray()
    step = 1 << 20
    body = raw[pos:]
    for start in range(0, len(body), step):
        chunk = engine.decompress(body[start : start + step], max_bytes + 1 - len(out))
        out += chunk
        if len(out) > max_bytes:
            raise StreamTooLarge(f"stream inflates past {max_bytes} B")
        if engine.eof:
            break
    return bytes(out)


def _attr_double(main: str, name: str, default: float) -> float:
    """A numeric attribute from the ``Main`` text block, or the default when absent."""
    hit = re.search(r'Name "%s"\s*\n\s*Value (-?[0-9.eE+-]+)' % re.escape(name), main)
    return float(hit.group(1)) if hit else default


def _attr_int(main: str, name: str) -> int:
    """An integer attribute from the ``Main`` text block, or the default when absent."""
    hit = re.search(r'Name "%s"\s*\n\s*Value (-?\d+)' % re.escape(name), main)
    return int(hit.group(1)) if hit else -1


def read_header(container: OleContainer) -> FlsHeader:
    """The scan geometry the file declares: columns, rows, angular spans, offsets and the camera calibration."""
    main = container.read("Main", MAX_HEADER).decode("latin-1")
    rows = _attr_int(main, "NumRows")
    cols = _attr_int(main, "NumCols")
    row_start = _attr_double(main, "RowStartAngle", float("nan"))
    row_end = _attr_double(main, "RowEndAngle", float("nan"))
    col_end = _attr_double(main, "ColEndAngle", 2 * np.pi)
    dist_fact = _attr_double(main, "StorageDistFact", 100000.0)
    vert = _attr_double(main, "VertResolutionFactor", 1.0)
    grey_bits = _attr_int(main, "NumGreyBits")

    problems = []
    if not 0 < rows <= MAX_DIM:
        problems.append(f"NumRows {rows}")
    if not 0 < cols <= MAX_DIM:
        problems.append(f"NumCols {cols}")
    if rows > 0 and cols > 0 and rows * cols > MAX_CELLS:
        problems.append(f"{rows}x{cols} cells above {MAX_CELLS}")
    if not (row_start == row_start and row_end == row_end):  # NaN check
        problems.append("row angles missing")
    elif not row_start > row_end:
        problems.append("row angles not descending")
    if not 0 < col_end <= 2 * np.pi + 1e-6:
        problems.append(f"ColEndAngle {col_end}")
    if not 1.0 <= dist_fact <= 1e7:
        problems.append(f"StorageDistFact {dist_fact}")
    if problems:
        raise FormatError("unsupported scan header: " + ", ".join(problems))
    return FlsHeader(
        rows=rows,
        cols=cols,
        row_start=row_start,
        row_end=row_end,
        col_end=col_end,
        unit=1.0 / dist_fact,
        grey_bits=grey_bits,
        dist_fact=dist_fact,
        vert_factor=vert,
    )


def read_rect(container: OleContainer, name: str, kind: str, index: int, header: FlsHeader) -> StreamRect:
    """The rectangle one stream covers, and the kind of data it holds."""
    hls_name = name + ".hls"
    if not container.has(hls_name):
        raise FormatError(f"{name} has no .hls")
    text = inflate_gzip_prefix(container.read(hls_name, MAX_HLS), MAX_HLS).decode("latin-1")
    hit = re.search(r"DataRect\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)", text)
    if not hit:
        raise FormatError(f"{hls_name} has no DataRect")
    c0, r0, c1, r1 = (int(value) for value in hit.groups())
    if r0 != 0 or r1 != header.rows or c0 < 0 or c1 > header.cols or c1 <= c0:
        raise FormatError(f"unsupported DataRect {c0} {r0} {c1} {r1}")
    return StreamRect(name=name, kind=kind, index=index, col0=c0, col1=c1, row0=r0, row1=r1)


def list_streams(container: OleContainer, header: FlsHeader) -> list[StreamRect]:
    """Dist and Grey streams, in index order, with their rectangles checked."""
    found: list[StreamRect] = []
    names = set(container.entries())
    for kind in ("Dist", "Grey"):
        for index in range(16):
            name = f"Scans/1/{kind}{index}"
            if name not in names:
                break
            found.append(read_rect(container, name, kind, index, header))
    return found


def streams_of(streams: list[StreamRect], kind: str) -> list[StreamRect]:
    """The streams of one kind: range, grey, colour or distance."""
    hits = [item for item in streams if item.kind == kind]
    hits.sort(key=lambda item: item.col0)
    return hits


def read_azimuths(container: OleContainer, header: FlsHeader) -> np.ndarray | None:
    """Per-column local azimuth in radians (``-angle`` from the Calib table).

    Returns ``None`` when the table is absent or unusable, so callers must have a
    fallback that is clearly marked as approximate.
    """
    if not container.has("Scans/1/Calib"):
        return None
    raw = container.read("Scans/1/Calib", MAX_CALIB)
    head = raw[:64].decode("latin-1")
    hit = re.search(r"HorCalibData (\d+) \{ ", head)
    if not hit:
        return None
    count = int(hit.group(1))
    start = hit.end()
    if count != header.cols or start + 16 * count > len(raw):
        return None
    table = np.frombuffer(raw, dtype="<f8", offset=start, count=count * 2).reshape(count, 2)
    angles = table[:, 0].astype(np.float64)
    if not np.all(np.isfinite(angles)) or np.abs(angles).max() > 4 * np.pi:
        return None
    return -angles


def _count_records(chunk: np.ndarray) -> int:
    """How many column records a deflated chunk holds, counted from its stop bits."""
    return int(np.count_nonzero((chunk & 0x80) == 0))


class VarintColumns:
    """One inflated data stream, decoded in column bands.

    The stream holds ``rows`` records per column, column-major. A whole-stream record
    index would cost 4 bytes per cell; instead we keep an anchor every
    :data:`ANCHOR_BYTES` bytes (about 100 anchors for SCAN_085) and scan inside one
    window on demand. Peak extra memory for a 512-column band is under 40 MiB.
    """

    ANCHOR_BYTES = 1 << 18
    BAND_COLUMNS = 512

    def __init__(self, data: bytes, header: FlsHeader, rect: StreamRect) -> None:
        """Read one stream's deflated body and index the columns inside it."""
        self.header = header
        self.rect = rect
        marker = data.find(b"{ ", 0, 4096)
        if marker < 0:
            raise FormatError(f"{rect.name}: no data start")
        self._body = np.frombuffer(data, dtype=np.uint8, offset=marker + 2)
        self._anchors: list[tuple[int, int]] = []
        self._build_anchors()
        expected = rect.cols * header.rows
        found = self.record_count()
        if found < expected:
            raise FormatError(f"{rect.name}: {found} records, expected {expected}")
        if found - expected > MAX_EXTRA_RECORDS:
            raise FormatError(f"{rect.name}: {found - expected} trailing records")
        self._expected = expected

    # -- index -----------------------------------------------------------
    def _build_anchors(self) -> None:
        """Find the start of each column's record, so a strip can be decoded without scanning the stream again."""
        body = self._body
        total = 0
        pos = 0
        self._anchors = [(0, 0)]
        while pos < body.size:
            end = min(body.size, pos + self.ANCHOR_BYTES)
            total += _count_records(body[pos:end])
            self._anchors.append((end, total))
            pos = end

    def record_count(self) -> int:
        """How many columns the stream holds."""
        return self._anchors[-1][1]

    def _end_of(self, record: int) -> int:
        """Byte offset of the terminating byte of ``record`` (the last byte of it)."""
        if record < 0 or record >= self.record_count():
            raise FormatError(f"record {record} out of range")
        low, high = 0, len(self._anchors) - 1
        while low < high:  # last anchor whose record count is <= record
            mid = (low + high + 1) // 2
            if self._anchors[mid][1] <= record:
                low = mid
            else:
                high = mid - 1
        start, base = self._anchors[low]
        need = record - base
        pos = start
        body = self._body
        while pos < body.size:
            end = min(body.size, pos + self.ANCHOR_BYTES)
            ends = np.flatnonzero((body[pos:end] & 0x80) == 0)
            if need < ends.size:
                return pos + int(ends[need])
            need -= ends.size
            pos = end
        raise FormatError("record index past end of stream")

    def _start_of(self, record: int) -> int:
        """Byte offset of the first byte of ``record``; every column starts at 0."""
        return 0 if record == 0 else self._end_of(record - 1) + 1

    # -- decode ----------------------------------------------------------
    def deltas(self, first_column: int, columns: int) -> np.ndarray:
        """Signed row-to-row deltas for a band, shape ``(columns, rows)``, int32."""
        rows = self.header.rows
        if first_column < 0 or columns <= 0 or first_column + columns > self.rect.cols:
            raise FormatError("band outside stream")
        first = first_column * rows
        last = (first_column + columns) * rows - 1
        begin = self._start_of(first)
        finish = self._end_of(last) + 1
        return decode_varints(self._body[begin:finish], rows * columns, rows)

    def values(self, first_column: int = 0, columns: int | None = None) -> np.ndarray:
        """Running (absolute) values for a band, shape ``(columns, rows)``, int32."""
        columns = self.rect.cols if columns is None else columns
        band = self.deltas(first_column, columns)
        return np.cumsum(band, axis=1, dtype=np.int32)

    def bands(self, size: int | None = None):
        """Yield ``(first_column, values)`` over the stream without holding it all."""
        size = size or self.BAND_COLUMNS
        for start in range(0, self.rect.cols, size):
            take = min(size, self.rect.cols - start)
            yield start, self.values(start, take)


def decode_varints(blob: np.ndarray, records: int, rows: int) -> np.ndarray:
    """Decode ``records`` varints into an int32 array shaped ``(records // rows, rows)``.

    Vectorised: find every terminating byte, gather the fixed-width window in front of
    each record, mask out bytes past the record's end, then assemble magnitude and sign.
    No per-value Python loop, which is what makes 43 M cells a four-second job.
    """
    ends = np.flatnonzero((blob & 0x80) == 0)
    if ends.size < records:
        raise FormatError(f"stream ended after {ends.size} of {records} records")
    ends = ends[:records]
    starts = np.empty(records, dtype=np.int64)
    starts[0] = 0
    starts[1:] = ends[:-1] + 1
    lengths = ends - starts + 1
    longest = int(lengths.max())
    if longest > 5:
        raise FormatError(f"varint longer than 5 bytes ({longest})")
    if starts.min() < 0 or int(ends[-1]) >= blob.size:
        raise FormatError("record outside stream")
    steps = np.arange(longest, dtype=np.int64)
    positions = starts[:, None] + steps[None, :]
    valid = steps[None, :] < lengths[:, None]
    gathered = blob[np.minimum(positions, blob.size - 1)].astype(np.int32)
    first = gathered[:, 0]
    negative = (first & 0x40) != 0
    magnitude = (first & 0x3F).astype(np.int64)
    shift = 6
    for step in range(1, longest):
        chunk = np.where(valid[:, step], (gathered[:, step].astype(np.int64) & 0x7F) << shift, 0)
        magnitude |= chunk
        shift += 7
    deltas = np.where(negative, -magnitude, magnitude)
    if deltas.size != records:
        raise FormatError("decode produced the wrong record count")
    return deltas.astype(np.int32).reshape(records // rows, rows)


class FlsFile:
    """A ``.fls`` opened for reading: header, streams, angles, per-band decode."""

    def __init__(self, path: str | Path) -> None:
        """Open a FARO scan container, read its header, and index its streams; nothing is decoded yet."""
        self.path = Path(path)
        self.container = OleContainer(self.path)
        try:
            self.header = read_header(self.container)
            self.streams = list_streams(self.container, self.header)
            self.azimuths = read_azimuths(self.container, self.header)
        except Exception:
            self.container.close()
            raise

    def __enter__(self) -> "FlsFile":
        """Use the scan as a context manager."""
        return self

    def __exit__(self, *exc_info: object) -> None:
        """Close the scan however the block ends."""
        self.close()

    def close(self) -> None:
        """Release the container handle."""
        self.container.close()

    def streams_of(self, kind: str) -> list[StreamRect]:
        """This scan's streams of one kind."""
        return streams_of(self.streams, kind)

    def _inflate(self, rect: StreamRect) -> tuple[bytes, float]:
        """Decompress one stream's body, refusing a size the header did not lead us to expect."""
        raw_size = self.container.size(rect.name)
        raw = self.container.read(rect.name, MAX_STREAM)
        inflated = inflate_gzip_prefix(raw, MAX_STREAM)
        head = inflated[:256].decode("latin-1", "replace")
        wanted = "DistDataFormat 1" if rect.kind == "Dist" else "ColorDataFormat 1"
        if wanted not in head:
            raise FormatError(f"{rect.name}: expected {wanted}")
        return inflated, raw_size

    def columns(self, kind: str) -> VarintColumns:
        """The first stream of a kind. Multi-stream grids use :meth:`all_columns`."""
        hits = self.streams_of(kind)
        if not hits:
            raise FormatError(f"no {kind} stream")
        data, _ = self._inflate(hits[0])
        return VarintColumns(data, self.header, hits[0])

    def all_columns(self, kind: str):
        """Yield ``(rect, VarintColumns)`` for every stream of a kind."""
        for rect in self.streams_of(kind):
            data, _ = self._inflate(rect)
            yield rect, VarintColumns(data, self.header, rect)

    # -- angles ----------------------------------------------------------
    @property
    def azimuths_deg(self) -> np.ndarray | None:
        """The Calib azimuth table in degrees, or ``None`` when the scan has no table."""
        return None if self.azimuths is None else np.degrees(self.azimuths)

    def azimuth(self, column: int) -> float:
        """The azimuth of a column, from the camera calibration when the file carries one, else from the header's span."""
        if self.azimuths is not None:
            return float(self.azimuths[column])
        return -column * self.header.col_end / self.header.cols

    def elevation(self, row: float) -> float:
        """The elevation of a row, from the header's span."""
        return self.header.elevation(row)


class GreyStats:
    """The R0.2 measurements, accumulated band by band so the grid is never held whole.

    Order matters: feed bands in column order from column 0 or the sha256 is meaningless.
    """

    def __init__(self) -> None:
        """Accumulators for the grey histogram and its percentiles."""
        import hashlib

        self._digest = hashlib.sha256()
        self.cells = 0
        self.zero = 0
        self.negatives = 0
        self.maximum = 0
        self.above_2047 = 0
        self._nonzero_sum = 0
        self._nonzero_count = 0
        self._hist = np.zeros(1 << 16, dtype=np.int64)

    def add(self, block: np.ndarray) -> None:
        """Add a decoded grey block to the histogram and the checksum."""
        flat = np.ascontiguousarray(block, dtype=np.int32).reshape(-1)
        if flat.size == 0:
            return
        self.cells += int(flat.size)
        self.zero += int(np.count_nonzero(flat == 0))
        self.negatives += int(np.count_nonzero(flat < 0))
        self.maximum = max(self.maximum, int(flat.max()))
        self.above_2047 += int(np.count_nonzero(flat > 2047))
        positive = flat[flat > 0]
        if positive.size:
            self._nonzero_sum += int(positive.sum())
            self._nonzero_count += int(positive.size)
            self._hist += np.bincount(np.clip(positive, 0, (1 << 16) - 1), minlength=1 << 16)
        self._digest.update(flat.astype("<i4").tobytes())

    def result(self) -> dict[str, object]:
        """The histogram, its percentile bounds and the digest, as written into the product manifest."""
        percentiles: dict[str, int] = {}
        if self._nonzero_count:
            cumulative = np.cumsum(self._hist)
            for label, fraction in (("p1", 0.01), ("p50", 0.5), ("p99", 0.99)):
                percentiles[label] = int(np.searchsorted(cumulative, fraction * self._nonzero_count, side="left"))
        return {
            "cells": self.cells,
            "zero": self.zero,
            "negatives": self.negatives,
            "max": self.maximum,
            "above_2047": self.above_2047,
            "mean_nonzero": (self._nonzero_sum / self._nonzero_count) if self._nonzero_count else 0.0,
            "sum": self._nonzero_sum,
            "percentiles": percentiles,
            "sha256": self._digest.hexdigest(),
        }


def grey_statistics(values) -> dict[str, object]:
    """Convenience wrapper: feed an iterable of blocks through :class:`GreyStats`."""
    stats = GreyStats()
    for block in values:
        stats.add(block)
    return stats.result()

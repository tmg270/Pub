"""Bounded reader for the OLE/CFB containers FARO writes (``.fls``, ``.f3s``).

Only what the viewer needs: list the streams, ask how big one is, and read it with a
hard ceiling so a hostile or broken file cannot make us allocate a gigabyte. Every call
takes the ceiling from the caller; nothing here trusts a length inside the file.

``olefile`` parses the sector table and the directory. This module adds the caps and the
error types the rest of the app raises, and it guarantees we never touch the file after
``close()``.
"""

from __future__ import annotations

import os
from typing import Iterable

import olefile


class FormatError(Exception):
    """The file is not a FARO container we can read."""


class StreamTooLarge(FormatError):
    """A stream is bigger than the caller's ceiling, checked before reading it."""


class OleContainer:
    """A read-only OLE file with per-read byte limits."""

    #: A pathological directory can list millions of entries; FARO files have a few hundred.
    MAX_ENTRIES = 20_000

    def __init__(self, path: str | os.PathLike[str]) -> None:
        """Open a compound file for reading; the streams are listed but not read yet."""
        self.path = os.fspath(path)
        if not os.path.isfile(self.path):
            raise FormatError(f"not a file: {self.path}")
        try:
            self._ole = olefile.OleFileIO(self.path, raise_defects=olefile.DEFECT_INCORRECT)
        except (OSError, ValueError, IndexError, AttributeError) as exc:
            raise FormatError(f"not an OLE container: {exc}") from exc
        try:
            entries = ["/".join(part) for part in self._ole.listdir(streams=True, storages=False)]
        except (OSError, ValueError, IndexError) as exc:
            self.close()
            raise FormatError(f"unreadable directory: {exc}") from exc
        if len(entries) > self.MAX_ENTRIES:
            self.close()
            raise FormatError(f"too many streams: {len(entries)}")
        self._entries = sorted(entries)

    # -- context manager -------------------------------------------------
    def __enter__(self) -> "OleContainer":
        """Use the container as a context manager."""
        return self

    def __exit__(self, *exc_info: object) -> None:
        """Close the container however the block ends."""
        self.close()

    def close(self) -> None:
        """Release the underlying OLE handle; closing twice is harmless."""
        ole = getattr(self, "_ole", None)
        if ole is not None:
            try:
                ole.close()
            except OSError:
                pass
            self._ole = None

    # -- queries ---------------------------------------------------------
    def entries(self) -> list[str]:
        """Every stream path the compound file holds."""
        return list(self._entries)

    def __contains__(self, name: str) -> bool:
        """Whether a stream with this path exists."""
        return name in self._entries

    def has(self, name: str) -> bool:
        """Whether a stream with this path exists."""
        return name in self._entries

    def size(self, name: str) -> int:
        """The stored size of one stream, without reading it."""
        self._require_open()
        if name not in self._entries:
            raise FormatError(f"no stream {name}")
        try:
            return int(self._ole.get_size(name))
        except (OSError, ValueError, KeyError) as exc:
            raise FormatError(f"bad size for {name}: {exc}") from exc

    # -- reads -----------------------------------------------------------
    def read(self, name: str, max_bytes: int) -> bytes:
        """Read a whole stream, refusing anything above ``max_bytes`` before allocating."""
        size = self.size(name)
        if size > max_bytes:
            raise StreamTooLarge(f"{name} is {size} B, limit {max_bytes} B")
        self._require_open()
        try:
            with self._ole.openstream(name) as handle:
                data = handle.read(max_bytes + 1)
        except (OSError, ValueError) as exc:
            raise FormatError(f"cannot read {name}: {exc}") from exc
        if len(data) > max_bytes:
            raise StreamTooLarge(f"{name} grew past {max_bytes} B")
        return data

    def read_prefix(self, name: str, max_bytes: int) -> bytes:
        """Read at most ``max_bytes`` from the front of a stream (headers, ``.hls``)."""
        self._require_open()
        try:
            with self._ole.openstream(name) as handle:
                return handle.read(max_bytes)
        except (OSError, ValueError) as exc:
            raise FormatError(f"cannot read {name}: {exc}") from exc

    def matching(self, prefix: str) -> list[str]:
        """Streams whose name starts with ``prefix``, sorted by the number they carry."""
        hits = [value for value in self._entries if value.startswith(prefix)]
        return sorted(hits, key=_numeric_suffix)

    def _require_open(self) -> None:
        """Refuse to read from a container that has been closed, rather than failing obscurely later."""
        if getattr(self, "_ole", None) is None:
            raise FormatError("container is closed")


def _numeric_suffix(name: str) -> tuple[int, str]:
    """The trailing number of a stream name, used to sort ``_0``, ``_1`` … in file order."""
    tail = name.rsplit("/", 1)[-1]
    digits = "".join(ch for ch in tail if ch.isdigit())
    return (int(digits) if digits else -1, name)


def require(condition: bool, message: str) -> None:
    """Assert a condition with a message naming what the file was expected to contain."""
    if not condition:
        raise FormatError(message)


def first_matching(names: Iterable[str], pattern: str) -> str | None:
    """The first stream name matching a regular expression, or None."""
    import re

    rx = re.compile(pattern)
    for name in names:
        if rx.search(name):
            return name
    return None

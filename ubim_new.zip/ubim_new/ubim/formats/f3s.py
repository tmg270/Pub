"""FARO ``.f3s`` reader: the iQscene point octree, ported from ``F3sDepth.java``.

A ``.f3s`` is an OLE/CFB container, like a ``.fls``. The octree description is the
gzip-compressed ``DataBase`` stream plus ``Nodes_<n>`` streams; the points live in
``PointData/FullDensity/OctreeLeaf_<n>`` streams. Those streams come in two shapes and
the Java reference handles both:

* inner page (``OctreeNode``): ``LeafIndexInfo`` rows (``NodeID``, ``StartIndex``,
  ``NumPoints``), then the byte marker ``PointData `` and, packed in header order,
  ``NumPoints x 10`` bytes of records. ``StartIndex`` is not an offset into the page.
* leaf page (``OctreeLeaf``): ancestry index rows, ``PointData ``,
  ``OctreeLeafPointData`` (``NumScanPoints``), ``ScanPoints `` and that many records.
  Only the page's own count is stored; the ancestor rows repeat counts from other pages.

A record is three little-endian int16 (x, y, z in 1/65536 of a node box) followed by
three RGB bytes and a constant 0xFF byte. The record has no scalar intensity; a
luminance can only be derived from the RGB, which :meth:`F3sFile.intensity` does.

The stored coordinate bits are mapped through the file's construction grid. As in the
Java, centred and corner global maps are voted on against the declared node boxes; if
neither fits, the per-node map ``box + (int16 + 32768) / 65536 * size`` is used, gated by
a plausibility test (median range 1-150 m, at most 0.01% of points inside 0.3 m). Both
samples in this project take the per-node map. The Java's own note records the same on
its checked file.

UNKNOWN: the container declares no unit string (``scale`` therefore carries the Java's
map name, and :attr:`F3sFile.range_scale` carries the inferred unit); the 0xFF byte has
no known meaning; the RGB channel order is assumed R, G, B.

Ranges are returned as stored, in micrometres. The Java multiplies by ``1e-6`` to get
metres; that factor is exposed as :attr:`F3sFile.range_scale` and never applied silently.

World frame: ``DataBase`` declares ``OriginWS``, ``EdgeLengthWS`` and ``NumCellsInRow``,
the construction grid the coordinates are quantised into. A stored cell ``c`` maps to
the world point ``originWS + c / NumCellsInRow * EdgeLengthWS`` metres, which is the
frame :meth:`F3sFile.world_xyz` reconstructs. The scan's own ``Position`` and
``Transformation`` attributes live in ``ScanInfo_0``; both samples store an identity
transformation and an empty position, so their scanner sits at the world origin.
"""

from __future__ import annotations

import math
import re
from pathlib import Path

import numpy as np

from .cfb import FormatError, OleContainer, StreamTooLarge
from .fls import inflate_gzip_prefix

#: Equirectangular grid, the same one ``F3sDepth`` builds (2*pi/10240 step, +90..-90 deg).
COLS = 10240
ROWS = 5120
ROW_START = math.pi / 2.0
ROW_END = -math.pi / 2.0
COL_END = math.pi * 2.0
ROW_STEP = (ROW_START - ROW_END) / ROWS

#: Metres per stored range unit, from the Java's ``UNIT``. Not applied by ``ranges()``.
RANGE_SCALE = 1.0e-6

# Hostile-file bounds, as in ``F3sDepth``. Checked before allocating.
MAX_POINTS = 800_000_000
MAX_POINT_STREAM_BYTES = 64 << 20
MAX_POINT_BYTES = 8 << 30
MAX_NODES = 2_000_000
MAX_NODE_STREAMS = 10_000
MAX_NODE_STREAM = 32 << 20
MAX_POINT_STREAMS = 32_768
HEADER_WINDOW = 8_000_000
CHUNK = 1_000_000

INSIDE_NUM, INSIDE_DEN = 9900, 10_000
NEAR_NUM, NEAR_DEN = 1, 10_000
NEAR_ORIGIN_M = 0.3
MEDIAN_MIN_M, MEDIAN_MAX_M = 1, 150
MAX_RANGE_M = 2_000.0

_CENTRED, _CORNER, _LOCAL = 1, 2, 3

_ORIGIN = re.compile(r"OriginWS\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)")
_EDGE = re.compile(r"EdgeLengthWS\s+([-+0-9.eE]+)")
_CELLS = re.compile(r"NumCellsInRow\s+(\d+)")
_COUNT = re.compile(r"NumScanPoints\s+(\d+)")
_GROUP = re.compile(r"NodeID\s+(\d+)\s+StartIndex\s+(\d+)\s+NumPoints\s+(\d+)")
_BOX = re.compile(r"NodeBox\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)")
_NODE_ID = re.compile(r"UniqueNodeID\s+(\d+)")
_LEAF_ID = re.compile(r"UniqueLeafId\s+(\d+)")
_EMPTY_INDEX = re.compile(r"NumIndexInfos\s+0\b")
_POINT_DATA = b"PointData "
_SCAN_POINTS = b"ScanPoints "
_LEAF_POINT_DATA = b"OctreeLeafPointData"
_WS = b" \t\r\n"
_BRACES = b" \t\r\n{}"


class F3sFile:
    """One decoded ``.f3s`` scan. Build it with :meth:`read`.

    ``scale`` is the coordinate map the file uses, the value ``F3sDepth.scale()``
    returns: ``"centred"``, ``"corner"`` or ``"local"``. These files declare no unit
    string, so the map name is the only scale the container carries.
    """

    width = COLS
    height = ROWS
    #: Metres per stored range unit. ``ranges()`` returns the raw units.
    range_scale = RANGE_SCALE
    #: The container declares no unit string; ranges are micrometres by inference.
    unit = "UNKNOWN"

    def __init__(self, point_count: int, scale: str, ranges: np.ndarray, intensity: np.ndarray | None,
                 origin: tuple[float, float, float], edge_length: float, grid_cells: int,
                 transform: tuple[float, ...] | None, scan_position: tuple[float, float, float] | None):
        """A decoded 2026 sample: its point count, its scale statement and the assembled range image."""
        self.point_count = int(point_count)
        self.scale = scale
        self._ranges = ranges
        self._intensity = intensity
        #: World-frame corner of the octree construction grid, metres (``OriginWS``).
        self.origin = origin
        #: Construction grid edge in metres (``EdgeLengthWS``), and cells per edge.
        self.edge_length = edge_length
        self.grid_cells = grid_cells
        #: ``ScanInfo_0`` Transformation (16 numbers, order as stored) or ``None``.
        self.transform = transform
        #: ``ScanInfo_0`` Position (world frame) or ``None`` when the attribute is empty.
        self.scan_position = scan_position

    # -- public contract -------------------------------------------------
    @classmethod
    def read(cls, path: str | Path) -> "F3sFile":
        """Stream the octree into a dense range raster. One stream is held at a time."""
        path = Path(path)
        with OleContainer(path) as cfb:
            if not cfb.has("DataBase"):
                raise FormatError(f"{path.name}: no octree description (DataBase)")
            database = _text_stream(cfb.read("DataBase", MAX_NODE_STREAM), "DataBase")
            grid = _grid(database)
            boxes: dict[int, tuple[int, int, int, int]] = {}
            _collect_nodes(database, boxes)
            node_streams = 0
            point_names: list[str] = []
            for name in cfb.entries():
                if re.fullmatch(r"Nodes_[0-9]{1,6}", name):
                    node_streams += 1
                    if node_streams > MAX_NODE_STREAMS:
                        raise FormatError("too many node streams")
                    _collect_nodes(_text_stream(cfb.read(name, MAX_NODE_STREAM), name), boxes)
                elif re.fullmatch(r"PointData/FullDensity/OctreeLeaf_[0-9]{1,7}", name):
                    point_names.append(name)
            if not boxes:
                raise FormatError(f"{path.name}: no octree leaves")
            if not point_names:
                raise FormatError(f"{path.name}: no point stream")
            if len(point_names) > MAX_POINT_STREAMS:
                raise FormatError("too many point streams")
            point_names.sort(key=_stream_number)

            declared = -1
            if cfb.has("PointData/FullDensity/Header"):
                header = _text_stream(cfb.read("PointData/FullDensity/Header", 1_000_000), "header")
                found = _COUNT.search(header)
                if found:
                    declared = int(found.group(1))
            sizes = [cfb.size(name) for name in point_names]
            _check_budget(sizes, declared)

            transform = None
            scan_position = None
            if cfb.has("ScanInfo_0"):
                meta = _text_stream(cfb.read("ScanInfo_0", MAX_NODE_STREAM), "ScanInfo_0")
                position = _attr_numbers(meta, "Position")
                if position is not None and len(position) >= 3:
                    scan_position = (position[0], position[1], position[2])
                matrix = _attr_numbers(meta, "Transformation")
                if matrix is not None and len(matrix) == 16:
                    transform = tuple(matrix)

            raster = np.zeros(ROWS * COLS, dtype=np.uint32)
            grey = np.zeros(ROWS * COLS, dtype=np.uint8)
            tally = _Tally()
            stats = _RangeStats()
            total = 0
            for name in point_names:
                raw = cfb.read(name, MAX_POINT_STREAM_BYTES)
                for box, xyz, rgb in _walk(raw, boxes):
                    total += len(xyz)
                    _tally_add(tally, grid, box, xyz)
                    _local_add(grid, box, xyz, rgb, raster, grey, stats)
            if total == 0:
                raise FormatError(f"{path.name}: no returns")
            if declared >= 0 and declared != total:
                raise FormatError(f"{path.name}: point count mismatch ({total} != {declared})")

            mode = tally.choose()
            if mode == _LOCAL:
                if not stats.plausible():
                    raise FormatError(f"{path.name}: point scale does not match octree boxes")
            else:
                # The per-node pass was only a vote. Bin again through the chosen global map.
                raster = np.zeros(ROWS * COLS, dtype=np.uint32)
                grey = np.zeros(ROWS * COLS, dtype=np.uint8)
                for name in point_names:
                    raw = cfb.read(name, MAX_POINT_STREAM_BYTES)
                    for box, xyz, rgb in _walk(raw, boxes):
                        _global_add(grid, mode, xyz, rgb, raster, grey)
            used = int(np.count_nonzero(raster))
            if used == 0:
                raise FormatError(f"{path.name}: no returns in the grid")
        return cls(
            total,
            {_CENTRED: "centred", _CORNER: "corner", _LOCAL: "local"}[mode],
            raster.reshape(ROWS, COLS),
            grey.reshape(ROWS, COLS),
            grid.origin,
            grid.edge,
            grid.cells,
            transform,
            scan_position,
        )

    def world_xyz(self, cell) -> np.ndarray:
        """World-frame metres for octree cell coordinates (``OriginWS`` frame)."""
        return np.asarray(cell, dtype=np.float64) * (self.edge_length / self.grid_cells) + np.asarray(self.origin)

    def ranges(self) -> np.ndarray:
        """``(height, width)`` uint32 raster of stored range units; 0 means no return.

        The array is cached on the instance; treat it as read-only.
        """
        return self._ranges

    def intensity(self) -> np.ndarray | None:
        """``(height, width)`` uint8 luminance of the nearest return, or ``None``.

        The records carry RGB, not a scalar intensity: this is ``0.299 R + 0.587 G +
        0.114 B`` of the point with the smallest range in each cell. A black point and
        an empty cell are both 0.
        """
        return self._intensity


# -- container / text ----------------------------------------------------
def _stream_number(name: str) -> int:
    """The number at the end of a stream name (``…_012``), for putting leaves in order."""
    tail = name.rsplit("_", 1)[-1]
    return int(tail) if tail.isdigit() else -1


def _text_stream(raw: bytes, what: str) -> str:
    """The text of a metadata stream, gunzipped or deflated when the file stores it that way."""
    if raw[:3] == b"\x1f\x8b\x08":
        raw = inflate_gzip_prefix(raw, MAX_NODE_STREAM)
    elif raw[:2] == b"\x1f\x8b":
        raise FormatError(f"{what}: gzip method is not deflate")
    return raw.decode("latin-1")


def _attr_numbers(text: str, name: str) -> list[float] | None:
    """Numbers from the first ``Name "<name>"`` attribute that carries a ``Value`` line."""
    at = 0
    while True:
        at = text.find(f'Name "{name}"', at)
        if at < 0:
            return None
        end = text.find("}", at)
        value = re.search(r"Value\s+([-+0-9.eE \t]+)", text[at:end])
        if value:
            return [float(part) for part in value.group(1).split()]
        at = end


def _marker(raw: bytes, marker: bytes, start: int = 0) -> int:
    """First occurrence not glued to a preceding letter (``NumScanPoints`` vs ``ScanPoints``)."""
    i = start
    while True:
        i = raw.find(marker, i)
        if i < 0:
            return -1
        if i == 0 or not (65 <= raw[i - 1] <= 90 or 97 <= raw[i - 1] <= 122):
            return i
        i += 1


def _skip_space(raw: bytes, at: int) -> int:
    """Advance past whitespace in raw text."""
    while at < len(raw) and raw[at] in _WS:
        at += 1
    return at


def _closer(raw: bytes, end: int) -> None:
    """The index of the closing delimiter that balances the opener before ``end``."""
    if end < 0 or end > len(raw):
        raise FormatError("point data truncated")
    if raw[end:].strip(_BRACES):
        raise FormatError("point tail is not a closer")


def _block(text: str, at: int) -> int:
    """End (exclusive) of the brace block starting at ``at``."""
    depth = 0
    for end in range(at, len(text)):
        char = text[end]
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return end + 1
    raise FormatError("unclosed octree node")


def _grid(database: str):
    """The octree grid the file describes: origin, cell edge and cell count, read from the database stream."""
    origin = _ORIGIN.search(database)
    edge = _EDGE.search(database)
    cells = _CELLS.search(database)
    if not origin or not edge or not cells:
        raise FormatError("unsupported octree grid")
    try:
        x, y, z = (float(origin.group(i)) for i in (1, 2, 3))
        length = float(edge.group(1))
        n = int(cells.group(1))
    except ValueError as exc:
        raise FormatError("unsupported octree grid") from exc
    if not all(math.isfinite(v) for v in (x, y, z, length)) or max(abs(x), abs(y), abs(z)) > 1.0e8:
        raise FormatError("unsupported octree grid")
    if not (0 < length <= 1.0e7) or not (2 <= n <= 1_000_000):
        raise FormatError("unsupported octree grid")
    return _Grid((x, y, z), length, n)


def _collect_nodes(text: str, boxes: dict[int, tuple[int, int, int, int]]) -> None:
    """The octree nodes the database announces, with their boxes, in file order."""
    at = text.find("OctreeBaseNode")
    while at >= 0:
        opening = text.find("{", at)
        if opening < 0:
            return
        end = _block(text, opening)
        body = text[opening:end]
        box = _BOX.search(body)
        node = _NODE_ID.search(body)
        if box and node:
            node_id = int(node.group(1))
            x, y, z, size = (int(v) for v in box.groups())
            if not (0 < size <= 1_000_000):
                raise FormatError("bad node box")
            if node_id in boxes:
                raise FormatError("duplicate octree node")
            if len(boxes) >= MAX_NODES:
                raise FormatError("too many octree nodes")
            boxes[node_id] = (x, y, z, size)
        at = text.find("OctreeBaseNode", end)


def _check_budget(sizes: list[int], declared: int) -> None:
    """Refuse a file whose declared leaf count exceeds what one build may allocate."""
    if len(sizes) > MAX_POINT_STREAMS:
        raise FormatError("too many point streams")
    total = 0
    for size in sizes:
        if size < 0 or size > MAX_POINT_STREAM_BYTES:
            raise StreamTooLarge(f"point stream is {size} B, limit {MAX_POINT_STREAM_BYTES} B")
        total += size
        if total > MAX_POINT_BYTES:
            raise StreamTooLarge("too many point bytes")
    if declared > MAX_POINTS:
        raise FormatError("too many points")


# -- point streams -------------------------------------------------------
def _records(raw: bytes, start: int, count: int):
    """``count`` records at ``start`` as (int16 xyz view, rgb view)."""
    end = start + count * 10
    if count < 0 or start < 0 or end > len(raw):
        raise FormatError("point data truncated")
    blob = raw[start:end]
    xyz = np.frombuffer(blob, dtype="<i2").reshape(count, 5)[:, :3]
    rgb = np.frombuffer(blob, dtype=np.uint8).reshape(count, 10)[:, 6:9]
    return xyz, rgb


def _walk(raw: bytes, boxes: dict[int, tuple[int, int, int, int]]):
    """Yield ``(box, xyz, rgb)`` chunks from one point stream."""
    point_at = _marker(raw, _POINT_DATA)
    if point_at < 0 or point_at > HEADER_WINDOW:
        raise FormatError("no point payload")
    after = point_at + len(_POINT_DATA)
    leaf_at = _skip_space(raw, after)
    if raw[leaf_at:leaf_at + len(_LEAF_POINT_DATA)] == _LEAF_POINT_DATA:
        scan_at = _marker(raw, _SCAN_POINTS, after)
        if scan_at < 0 or scan_at > HEADER_WINDOW:
            raise FormatError("no leaf payload")
        head = raw[:scan_at].decode("latin-1")
        leaf = _LEAF_ID.search(head)
        if not leaf:
            raise FormatError("no leaf id")
        node = int(leaf.group(1))
        counts = _COUNT.findall(head)
        if not counts:
            raise FormatError("no leaf point count")
        count = int(counts[-1])
        box = boxes.get(node)
        if box is None:
            raise FormatError("point node has no octree box")
        start = scan_at + len(_SCAN_POINTS)
        for offset in range(0, count, CHUNK):
            part = min(CHUNK, count - offset)
            xyz, rgb = _records(raw, start + offset * 10, part)
            yield box, xyz, rgb
        _closer(raw, start + count * 10)
        return

    head = raw[:point_at].decode("latin-1")
    groups = [(int(m.group(1)), int(m.group(3))) for m in _GROUP.finditer(head)]
    if not groups and not _EMPTY_INDEX.search(head):
        raise FormatError("no point groups")
    cursor = after
    for node, count in groups:
        box = boxes.get(node)
        if box is None:
            raise FormatError("point node has no octree box")
        for offset in range(0, count, CHUNK):
            part = min(CHUNK, count - offset)
            xyz, rgb = _records(raw, cursor + offset * 10, part)
            yield box, xyz, rgb
        cursor += count * 10
    _closer(raw, cursor)


# -- coordinate maps -----------------------------------------------------
class _Grid:
    """The octree grid the file declares: lower corner, cell edge and cell counts."""
    __slots__ = ("origin", "edge", "cells")

    def __init__(self, origin, edge: float, cells: int) -> None:
        """A grid definition: lower corner, edge length and cell count."""
        self.origin = origin
        self.edge = edge
        self.cells = cells


def _local_xyz(grid: _Grid, box, xyz):
    """``cell = box + (int16 + 32768)/65536*size``, then the grid's metre map."""
    scale = box[3] * grid.edge / grid.cells / 65536.0
    axes = []
    for axis, sample in enumerate(xyz.T):
        base = grid.origin[axis] + box[axis] * grid.edge / grid.cells
        axes.append(base + (sample.astype(np.float64) + 32768.0) * scale)
    return axes[0], axes[1], axes[2]


def _global_xyz(grid: _Grid, mode: int, xyz):
    """World coordinates for the points of a node, for the file's coordinate mode."""
    edge = grid.edge
    if mode == _CENTRED:
        base = edge / 2.0
        return tuple(grid.origin[a] + base + xyz[:, a].astype(np.float64) * (edge / 65536.0)
                     for a in range(3))
    return tuple(grid.origin[a] + (xyz[:, a].astype(np.int32) & 0xFFFF) * (edge / 65536.0)
                 for a in range(3))


def _global_cells(grid: _Grid, mode: int, xyz):
    """Grid cells for the points of a node, for the file's coordinate mode."""
    if mode == _CENTRED:
        return grid.cells / 2.0 + xyz.astype(np.float64) * (grid.cells / 65536.0)
    return (xyz.astype(np.int32) & 0xFFFF) * (grid.cells / 65536.0)


def _in_box(cells, box) -> np.ndarray:
    """Which points fall inside a node's box."""
    inside = np.ones(cells.shape[0], dtype=bool)
    for axis in range(3):
        low = box[axis] - 1.0e-3
        high = box[axis] + box[3] + 1.0e-3
        inside &= (cells[:, axis] >= low) & (cells[:, axis] <= high)
    return inside


class _Tally:
    """Box vote between the two global maps, as in ``F3sDepth.Tally``."""

    __slots__ = ("small", "all")

    def __init__(self) -> None:
        """Counts for deciding which coordinate mode the file actually uses."""
        self.small = [0, 0, 0]
        self.all = [0, 0, 0]

    def choose(self) -> int:
        """The mode with the most points inside a node's box; centred before corner on a tie."""
        seen, centred, corner = self.small if self.small[0] > 0 else self.all
        if seen <= 0:
            raise FormatError("point scale does not match octree boxes")
        centred_ok = centred * INSIDE_DEN >= seen * INSIDE_NUM
        corner_ok = corner * INSIDE_DEN >= seen * INSIDE_NUM
        if centred_ok and corner_ok:
            raise FormatError("ambiguous point scale")
        if centred_ok:
            return _CENTRED
        if corner_ok:
            return _CORNER
        return _LOCAL


def _tally_add(tally: _Tally, grid: _Grid, box, xyz) -> None:
    """Record one node's evidence for the coordinate modes."""
    count = int(xyz.shape[0])
    tally.all[0] += count
    small = box[3] * 2 < grid.cells
    if small:
        tally.small[0] += count
    for mode, slot in ((_CENTRED, 1), (_CORNER, 2)):
        hits = int(_in_box(_global_cells(grid, mode, xyz), box).sum())
        tally.all[slot] += hits
        if small:
            tally.small[slot] += hits


class _RangeStats:
    """Range histogram for the per-node map gate, as in ``F3sDepth.RangeStats``."""

    __slots__ = ("bins", "seen", "near")

    def __init__(self) -> None:
        """A histogram of ranges, for deciding whether the file's ranges are plausible."""
        self.bins = np.zeros(201, dtype=np.int64)
        self.seen = 0
        self.near = 0

    def add(self, ranges: np.ndarray) -> None:
        """Add a node's ranges to the histogram and the plausibility counters."""
        good = np.isfinite(ranges) & (ranges > 0) & (ranges <= MAX_RANGE_M)
        values = ranges[good]
        if values.size == 0:
            return
        self.seen += int(values.size)
        self.near += int((values < NEAR_ORIGIN_M).sum())
        bins = np.minimum(values.astype(np.int64), 200)
        self.bins += np.bincount(bins, minlength=201)

    def plausible(self) -> bool:
        """Whether the ranges look like a scan of a room rather than a mis-scaled grid."""
        if self.seen == 0 or self.near * NEAR_DEN > self.seen * NEAR_NUM:
            return False
        rank = self.seen // 2
        passed = 0
        for index, count in enumerate(self.bins):
            passed += int(count)
            if passed > rank:
                return MEDIAN_MIN_M <= index <= MEDIAN_MAX_M
        return False


# -- raster --------------------------------------------------------------
def _scatter(raster, grey, flat, um, lum) -> None:
    """Keep the smallest range (and its luminance) per cell."""
    if flat.size == 0:
        return
    order = np.lexsort((um, flat))
    ordered = flat[order]
    starts = np.flatnonzero(np.r_[True, ordered[1:] != ordered[:-1]])
    index = ordered[starts]
    best = um[order][starts].astype(np.uint32)
    current = raster[index]
    # 0 is "no return", so it must never win a minimum.
    write = (current == 0) | (best < current)
    if not write.any():
        return
    index = index[write]
    raster[index] = best[write]
    if grey is not None:
        grey[index] = lum[order][starts][write].astype(np.uint8)


def _cells_for(x, y, z):
    """Raster cells for a local point, with its ground radius and height."""
    ground = np.hypot(x, y)
    ranges = np.hypot(ground, z)
    azimuth = np.arctan2(y, x)
    elevation = np.arctan2(z, ground)
    col = np.floor(-azimuth / COL_END * COLS + 0.5).astype(np.int64) % COLS
    row = np.floor((ROW_START - elevation) / ROW_STEP + 0.5).astype(np.int64)
    row = np.where(row == ROWS, ROWS - 1, row)
    return ground, ranges, col, row


def _luma(rgb) -> np.ndarray:
    """Perceived brightness of RGB, for the grey channel."""
    r = rgb[:, 0].astype(np.float64)
    g = rgb[:, 1].astype(np.float64)
    b = rgb[:, 2].astype(np.float64)
    return np.floor(0.299 * r + 0.587 * g + 0.114 * b + 0.5)


def _local_add(grid, box, xyz, rgb, raster, grey, stats) -> None:
    """Paint one local node's points into the raster, grey image and statistics."""
    x, y, z = _local_xyz(grid, box, xyz)
    ground, ranges, col, row = _cells_for(x, y, z)
    stats.add(ranges)
    um = np.floor(ranges / RANGE_SCALE + 0.5)
    keep = (ranges > 1.0e-3) & (ranges <= MAX_RANGE_M) & (row >= 0) & (row < ROWS) & (um > 0)
    if not keep.any():
        return
    flat = row[keep] * COLS + col[keep]
    _scatter(raster, grey, flat, um[keep].astype(np.int64), _luma(rgb)[keep])


def _global_add(grid, mode, xyz, rgb, raster, grey) -> None:
    """Paint one node whose points are already in world coordinates."""
    x, y, z = _global_xyz(grid, mode, xyz)
    ground, ranges, col, row = _cells_for(x, y, z)
    um = np.floor(ranges / RANGE_SCALE + 0.5)
    keep = (ranges > 1.0e-3) & (ranges <= MAX_RANGE_M) & (row >= 0) & (row < ROWS) & (um > 0)
    if not keep.any():
        return
    flat = row[keep] * COLS + col[keep]
    _scatter(raster, grey, flat, um[keep].astype(np.int64), _luma(rgb)[keep])

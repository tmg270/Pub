"""Building the intensity product.

Two passes over the scan: one histogram to find the per-scan normalisation bounds, then the
render. The rendered grid is held in memory for the pyramid because the pyramid needs to
halve it anyway; at 10 136 x 5 086 that is 51 MB, inside the pack's 384 MiB budget for one
worker.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np

from ..formats.fls import FlsFile
from . import intensity as I
from . import pyramid
from .render import level0_strips

INTENSITY_DIR = "intensity"
META_NAME = "intensity.json"


def build(product: Path, scan_path: Path, progress=None) -> dict:
    """Build one product from a scan, dispatching on the kind; the caller gets a manifest path and progress counts."""
    product = Path(product)
    product.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    with FlsFile(scan_path) as scan:
        if scan.azimuths is None:
            raise ValueError("intensity needs the Calib azimuth table")
        histogram = I.grey_histogram(scan)
        lo, hi = I.grey_bounds(histogram)
        raw_max = int(max(i for i in range(histogram.size) if histogram[i]))
        width, height = I.level0_size(scan.header)
        values = np.zeros((height, width), dtype=np.uint8)
        for x0, strip in level0_strips(scan, lo, hi):
            values[:, x0 : x0 + strip.shape[1]] = strip
            if progress is not None:
                progress("intensity.render", x0 / max(1, width))
        elevation_top = scan.header.elevation_deg(0.0)
        azimuths = scan.azimuths_deg
    return _finish_intensity(
        product, scan_path, values, started, progress, lo, hi, raw_max,
        elevation_top, float(azimuths[0]) if azimuths is not None else None,
        float(azimuths[-1]) if azimuths is not None else None,
    )


def values_from_raw(raw, lo: float, hi: float, strip: int = 512) -> np.ndarray:
    """Normalise a pre-sampled raw grey image the way the render pass does.

    ``raw`` is the level-0 image *before* normalisation and the filters, which is what the
    combined builder keeps while it decodes once (spec C2). The filters run on the normalised
    strip, exactly as they do in :func:`render_strip`.
    """
    from .intensity import suppress_column_lines, despeckle, fill_slivers

    height, width = raw.shape
    out = np.zeros((height, width), dtype=np.uint8)
    for x0 in range(0, width, strip):
        block = np.asarray(raw[:, x0 : x0 + strip], dtype=np.int32)
        out[:, x0 : x0 + block.shape[1]] = suppress_column_lines(despeckle(fill_slivers(I.normalise_band(block, lo, hi))))
    return out


def _finish_intensity(product: Path, scan_path: Path, values, started, progress, lo, hi, raw_max,
                      elevation_top, azimuth_first, azimuth_last) -> dict:
    """Shared tail of an intensity build: tiles, manifest, timings."""
    product = Path(product)
    width, height = int(values.shape[1]), int(values.shape[0])
    rendered = time.monotonic()
    mapping = dict(I.MAPPING)

    lut = I.rainbow_stops()

    def grey(block: np.ndarray) -> np.ndarray:
        """The grey ramp: intensity mapped through the product's percentile bounds."""
        return block

    def rainbow(block: np.ndarray) -> np.ndarray:
        """The rainbow ramp: the same intensity through a colour table."""
        return lut[block]

    levels = pyramid.build(
        values, product / INTENSITY_DIR, {"grey": grey, "rainbow": rainbow},
        meta={"kind": "intensity", "source": scan_path.name, "mapping": mapping},
        progress=(lambda level, total, written: progress("intensity.tiles", level / 8)) if progress else None,
    )

    meta = {
        "product": "intensity",
        "source": scan_path.name,
        "sourceSize": scan_path.stat().st_size,
        "sourceMtime": int(scan_path.stat().st_mtime * 1000),
        "width": width,
        "height": height,
        "lo": lo,
        "hi": hi,
        "rawMax": raw_max,
        "nonZeroPixels": int(np.count_nonzero(values)),
        "mapping": mapping,
        "elevationTopDeg": elevation_top,
        "azimuthFirstDeg": azimuth_first,
        "azimuthLastDeg": azimuth_last,
        "levels": levels["levels"],
        "tile": levels["tile"],
        "ramps": levels["ramps"],
        "builtAt": int(time.time()),
        "seconds": round(time.monotonic() - started, 2),
        "secondsRender": round(rendered - started, 2),
    }
    (product / META_NAME).write_text(json.dumps(meta, indent=1))
    return meta


def build_from_luma(product: Path, luma: np.ndarray, scan_path: Path, progress=None) -> dict:
    """Colour product for a ``.f3s`` scan, from the colour channels the file actually stores.

    This is deliberately *not* called intensity: the 2026 format has RGB in its trailing
    bytes and no scalar intensity, so the panorama is built from the luminance of that colour.
    The manifest says where it came from (``derivedFrom``), the viewer labels the mode
    accordingly, and a real intensity product still takes precedence when one exists.
    """
    product = Path(product)
    product.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    # The grid is sparse where the beam skipped a column, and those cells come out dark:
    # fill the thin gaps from their neighbours so the surface is a surface. The decoder
    # stores what it found; the filling is reported by the product, not invented silently.
    values = I.suppress_column_lines(I.fill_slivers(np.ascontiguousarray(luma.astype(np.uint8))))
    height, width = values.shape
    if progress is not None:
        progress("intensity.render", 1.0)
    lut = I.rainbow_stops()

    def grey(block: np.ndarray) -> np.ndarray:
        """The grey ramp: intensity mapped through the product's percentile bounds."""
        return block

    def rainbow(block: np.ndarray) -> np.ndarray:
        """The rainbow ramp: the same intensity through a colour table."""
        return lut[block]

    levels = pyramid.build(
        values, product / INTENSITY_DIR, {"grey": grey, "rainbow": rainbow},
        meta={"kind": "colour", "source": scan_path.name, "mapping": dict(I.MAPPING)},
        progress=(lambda level, total, written: progress("intensity.tiles", level / 8)) if progress else None,
    )
    meta = {
        "product": "intensity",
        "derivedFrom": "f3s colour luma",
        "filled": "thin gaps interpolated from neighbouring cells",
        "source": scan_path.name,
        "sourceSize": scan_path.stat().st_size,
        "sourceMtime": int(scan_path.stat().st_mtime * 1000),
        "width": width,
        "height": height,
        "lo": 0,
        "hi": 255,
        "rawMax": 255,
        "nonZeroPixels": int(np.count_nonzero(values)),
        "mapping": dict(I.MAPPING),
        "elevationTopDeg": float(I.TOP_DEG),
        "azimuthFirstDeg": 0.0,
        "azimuthLastDeg": 360.0,
        "levels": levels["levels"],
        "tile": levels["tile"],
        "ramps": levels["ramps"],
        "builtAt": int(time.time()),
        "seconds": round(time.monotonic() - started, 2),
        "secondsRender": 0.0,
    }
    (product / META_NAME).write_text(json.dumps(meta, indent=1))
    return meta


def load_meta(product: Path) -> dict | None:
    """A product's manifest, or None when the product has not been built."""
    path = Path(product) / META_NAME
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None


def is_fresh(meta: dict | None, scan_path: Path) -> bool:
    """A product is fresh when it was built from this exact file, by version."""
    if meta is None:
        return False
    try:
        stat = scan_path.stat()
    except OSError:
        return False
    return (
        meta.get("sourceSize") == stat.st_size
        and meta.get("sourceMtime") == int(stat.st_mtime * 1000)
    )

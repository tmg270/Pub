"""One decode pass feeding every product that needs the scan body (spec C2).

Building intensity and depth separately walks the scan three times: once for the grey
histogram, once for the grey render, once for the range strips. The streams are the same
bytes each time. This module walks them once, keeping the sampled raw grey image next to the
range grid, then finishes both products from what it kept.

The raw grey image is a scratch file, not a product: it is uint16 because raw intensity runs to
1819 on the reference scan, and it is deleted once the tiles exist. Peak memory stays at one
strip plus the uint8 image the pyramid needs, which is what the separate builds already cost.
"""

from __future__ import annotations

import time
from pathlib import Path

import numpy as np

from ..formats.fls import FlsFile
from . import build as B
from . import depth as D
from . import intensity as I
from .render import decode_columns

RAW_NAME = "_raw_grey.u16"


def _render_from_scratch(scan, raw, lo: float, hi: float, progress=None) -> np.ndarray:
    """Normalise the kept raw image the way the separate render pass would.

    The strip boundaries, the wrap split and the filter order come from the same helpers the
    sequential build uses, so the two builds produce the same pixels; only the decode is shared.
    """
    calib = scan.azimuths
    width, height = I.level0_size(scan.header)
    values = np.zeros((height, width), dtype=np.uint8)
    for x0 in range(0, width, 512):
        plan = I.plan_strip(scan.header, calib, x0, 512)
        cut = I.wrap_split(plan.columns)
        spans = [(0, cut), (cut, plan.width - cut)] if cut < plan.width else [(0, plan.width)]
        parts = []
        for start, count in spans:
            sub = I.plan_strip(scan.header, calib, plan.x0 + start, count)
            block = np.asarray(raw[:, sub.x0 : sub.x0 + sub.width], dtype=np.int32)
            parts.append(B.values_from_raw(block, lo, hi))
        strip = np.concatenate(parts, axis=1) if len(parts) > 1 else parts[0]
        values[:, plan.x0 : plan.x0 + strip.shape[1]] = strip
        if progress is not None:
            progress("intensity.render", plan.x0 / max(1, width))
    return values


def build(scan_path: Path, product: Path, progress=None) -> dict:
    """Build the intensity and depth products from a single decode of ``scan_path``."""
    scan_path = Path(scan_path)
    product = Path(product)
    product.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    scratch = product / RAW_NAME
    with FlsFile(scan_path) as scan:
        if scan.azimuths is None:
            raise ValueError("the combined build needs the Calib azimuth table")
        width, height = I.level0_size(scan.header)
        raw = np.memmap(scratch, dtype=np.uint16, mode="w+", shape=(height, width))
        raw[:] = 0
        cache: dict = {}
        histogram = np.zeros(1 << 16, dtype=np.int64)

        def on_strip(_x0: int, subs: list) -> None:
            """Hand a strip's progress to the caller's callback, if there is one."""
            for sub in subs:
                c0, c1 = I.scan_column_range(sub)
                grey = decode_columns(scan, c0, c1, cache, kind="Grey")
                # Every decoded value counts, in or out of the scanned band, exactly as
                # :func:`ubim.products.intensity.grey_histogram` would count it.
                positive = grey[grey > 0]
                if positive.size:
                    histogram[:] += np.bincount(
                        np.clip(positive, 0, (1 << 16) - 1), minlength=1 << 16
                    )
                block = I.sample_strip(sub, grey, c0)
                raw[:, sub.x0 : sub.x0 + sub.width] = np.clip(block, 0, 65535).astype(np.uint16)

        grid_meta = D.build_grid(scan, product / D.GRID_NAME, progress, on_strip=on_strip)
        elevation_top = scan.header.elevation_deg(0.0)
        azimuths = scan.azimuths_deg
    raw.flush()
    lo, hi = I.grey_bounds(histogram)
    raw_max = int(max(i for i in range(histogram.size) if histogram[i]))

    values = _render_from_scratch(scan, raw, lo, hi, progress)
    intensity_meta = B._finish_intensity(
        product, scan_path, values, started, progress, lo, hi, raw_max,
        elevation_top, float(azimuths[0]) if azimuths is not None else None,
        float(azimuths[-1]) if azimuths is not None else None,
    )
    depth_meta = D._finish_depth(product, scan_path, grid_meta, progress, elevation_top=elevation_top)
    try:
        scratch.unlink()
    except OSError:
        pass
    return {"intensity": intensity_meta, "depth": depth_meta}

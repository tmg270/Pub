"""Render the level-0 intensity image for a scan, strip by strip.

Decoding is column-major and the output is written in column strips, so the scan band we
hold is exactly the band we need: about 9 MB of source for a 512-pixel strip of
SCAN_085, plus the strip itself. Nothing full-size is ever allocated (the pack's R20).

``python -m ubim.products.render --fls FILE --out DIR`` writes ``level0.png`` plus the
per-scan ``meta.json`` and prints the measurements.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
from PIL import Image

from ..formats.fls import FlsFile
from . import intensity as I


def kind_streams(scan: FlsFile, cache: dict, kind: str = "Grey") -> list:
    """Inflate and index a scan's streams once, not once per strip."""
    if kind not in cache:
        cache[kind] = list(scan.all_columns(kind))
    return cache[kind]


def decode_columns(scan: FlsFile, c0: int, c1: int, cache: dict | None = None, kind: str = "Grey") -> np.ndarray:
    """Raw values for global scan columns ``[c0, c1)``, shape ``(c1-c0, rows)`` int32."""
    pieces = []
    cache = {} if cache is None else cache
    for rect, columns in kind_streams(scan, cache, kind):
        lo = max(c0, rect.col0)
        hi = min(c1, rect.col1)
        if hi > lo:
            pieces.append(columns.values(lo - rect.col0, hi - lo).astype(np.int32, copy=False))
    if not pieces:
        raise ValueError(f"no grey data for columns {c0}..{c1}")
    return np.concatenate(pieces, axis=0)


def level0_strips(scan: FlsFile, lo: float, hi: float, strip: int = 512):
    """Yield ``(x0, uint8 image strip)`` for the whole level-0 image, in column order."""
    calib = scan.azimuths
    if calib is None:
        raise ValueError("this scan has no Calib azimuth table")
    width, height = I.level0_size(scan.header)
    cache: dict = {}
    for x0 in range(0, width, strip):
        plan = I.plan_strip(scan.header, calib, x0, strip)
        cut = I.wrap_split(plan.columns)
        if cut < plan.width:
            parts = []
            for start, count in ((0, cut), (cut, plan.width - cut)):
                sub = I.plan_strip(scan.header, calib, plan.x0 + start, count)
                c0, c1 = I.scan_column_range(sub)
                parts.append(I.render_strip(sub, decode_columns(scan, c0, c1, cache), c0, lo, hi))
            yield plan.x0, np.concatenate(parts, axis=1)
            continue
        c0, c1 = I.scan_column_range(plan)
        yield plan.x0, I.render_strip(plan, decode_columns(scan, c0, c1, cache), c0, lo, hi)


def render_level0(scan: FlsFile, lo: float, hi: float) -> np.ndarray:
    """The whole level-0 image. For tests and previews; the tiler streams instead."""
    width, height = I.level0_size(scan.header)
    out = np.zeros((height, width), dtype=np.uint8)
    for x0, strip in level0_strips(scan, lo, hi):
        out[:, x0 : x0 + strip.shape[1]] = strip
    return out


def main(argv: list[str] | None = None) -> int:
    """Command line entry: render a scan's products into a folder, with a progress line."""
    parser = argparse.ArgumentParser(description="Render the level-0 intensity image")
    parser.add_argument("--fls", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--strip", type=int, default=512)
    args = parser.parse_args(argv)

    started = time.monotonic()
    with FlsFile(args.fls) as scan:
        t_header = time.monotonic()
        histogram = I.grey_histogram(scan)
        lo, hi = I.grey_bounds(histogram)
        t_bounds = time.monotonic()
        total = 0
        width = height = 0
        peak = 0
        out_dir = Path(args.out)
        out_dir.mkdir(parents=True, exist_ok=True)
        canvas = None
        for x0, strip in level0_strips(scan, lo, hi, args.strip):
            if canvas is None:
                height, width = strip.shape[0], I.level0_size(scan.header)[0]
                canvas = np.zeros((height, width), dtype=np.uint8)
            canvas[:, x0 : x0 + strip.shape[1]] = strip
            total += int(np.count_nonzero(strip))
            peak = max(peak, strip.nbytes)
        t_render = time.monotonic()
        Image.fromarray(canvas, mode="L").save(out_dir / "level0.png")
        meta = {
            "width": width,
            "height": height,
            "lo": lo,
            "hi": hi,
            "rawMax": int(max(i for i in range(histogram.size) if histogram[i])),
            "nonZeroPixels": total,
            "mapping": I.MAPPING,
            "source": Path(args.fls).name,
            "sourceSize": Path(args.fls).stat().st_size,
            "sourceMtime": int(Path(args.fls).stat().st_mtime * 1000),
        }
        (out_dir / "meta.json").write_text(json.dumps(meta, indent=2))
        print(json.dumps({
            **meta,
            "secondsHeader": round(t_header - started, 2),
            "secondsBounds": round(t_bounds - t_header, 2),
            "secondsRender": round(t_render - t_bounds, 2),
            "peakStripBytes": peak,
        }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

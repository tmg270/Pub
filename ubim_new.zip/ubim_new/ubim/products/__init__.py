"""Product builders: range grids, intensity images, plan renders and tile pyramids.

Every builder writes beside the scan (``<scan>.ubim/``) and never touches the source file.
``dual`` builds intensity and depth from one decode; the rest build one product each."""


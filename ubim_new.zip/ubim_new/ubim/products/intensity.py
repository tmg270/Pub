"""High-resolution laser intensity map: angles, normalisation, band rendering.

The geometry is the viewer's, not an approximation of it. A pixel at column ``x`` of an
intensity image is azimuth ``az0 - 2*pi*x/width``; a pixel at row ``y`` is elevation
``top - y*span/height``. Those three constants are the ones the panorama client uses, so
a pixel in this image and a pixel on the pano sphere are the same direction. Any change
here must be made in ``static/js/gl.js`` too, which is why the numbers are served to
the client from :data:`MAPPING` instead of being typed twice.

Sampling is nearest neighbour between neighbouring scan cells only (R32 allows nearest or
linear between neighbours; we do nearest, which never invents a value that no cell holds,
and record it in the manifest).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..formats.cfb import FormatError
from ..formats.fls import FlsHeader

#: Panorama mapping constants (project.ts). Fitted on SCAN_085, not tunable per scan.
AZ0_DEG = -0.07
TOP_DEG = 90.18
SPAN_DEG = 180.65

MAPPING = {"az0Deg": AZ0_DEG, "topDeg": TOP_DEG, "spanDeg": SPAN_DEG}

#: Output pixel values: 0 means "no intensity value here", 1-255 is the normalised map.
OUTPUT_MIN = 1
OUTPUT_MAX = 255

#: Normalisation percentiles (R31).
LO_PERCENTILE = 0.5
HI_PERCENTILE = 99.5


def level0_size(header: FlsHeader) -> tuple[int, int]:
    """Native level-0 size: one pixel per scan column, square angular pixels."""
    width = header.cols
    height = int(round(width * SPAN_DEG / 360.0))
    return width, height


def pixel_azimuth(width: int) -> np.ndarray:
    """Azimuth in radians for every output column, wrapped to (-pi, pi]."""
    x = np.arange(width, dtype=np.float64)
    alpha = np.radians(AZ0_DEG) - 2.0 * np.pi * x / width
    return np.pi - np.mod(np.pi - alpha, 2.0 * np.pi)


def pixel_elevation(height: int) -> np.ndarray:
    """Elevation in radians for every output row (row 0 is the top of the pano)."""
    y = np.arange(height, dtype=np.float64)
    return np.radians(TOP_DEG) - y * np.radians(SPAN_DEG) / height


def source_columns(azimuths: np.ndarray, width: int) -> np.ndarray:
    """Nearest scan column for every output column, using the Calib table.

    The table is per scan and non-linear: a linear ``col*360/cols`` model is wrong by up
    to about 1 degree on SCAN_085, which is 23 pixels at 8190 wide, so it is never used
    when the table exists.
    """
    if azimuths is None:
        raise FormatError("intensity needs the Calib azimuth table")
    table = np.asarray(azimuths, dtype=np.float64)
    wrapped = np.pi - np.mod(np.pi - table, 2.0 * np.pi)
    order = np.argsort(wrapped, kind="stable")
    sorted_angles = wrapped[order]
    targets = pixel_azimuth(width)
    index = np.searchsorted(sorted_angles, targets)
    index = np.clip(index, 1, sorted_angles.size - 1)
    before = sorted_angles[index - 1]
    after = sorted_angles[index]
    choose_after = np.abs((after - targets + np.pi) % (2 * np.pi) - np.pi) < np.abs(
        (targets - before + np.pi) % (2 * np.pi) - np.pi
    )
    picked = np.where(choose_after, index, index - 1)
    return order[picked].astype(np.int32)


def source_rows(header: FlsHeader, height: int) -> np.ndarray:
    """Nearest scan row for every output row, or -1 outside the scanned band."""
    elevations = pixel_elevation(height)
    rows = np.round(header.row_for(elevations)).astype(np.int64)
    valid = (rows >= 0) & (rows < header.rows)
    return np.where(valid, rows, -1).astype(np.int32)


def normalise_band(values: np.ndarray, lo: float, hi: float) -> np.ndarray:
    """Linear map of raw grey to 1-255; raw 0 stays 0, everything else clamps.

    ``lo``/``hi`` are the per-scan percentiles from :func:`grey_bounds`. A degenerate
    range (constant image, or a single value) must not divide by zero: it maps every
    non-zero cell to the top of the scale.
    """
    out = np.zeros(values.shape, dtype=np.uint8)
    if hi <= lo:
        out[values > 0] = OUTPUT_MAX
        return out
    scaled = (values.astype(np.float64) - lo) * ((OUTPUT_MAX - OUTPUT_MIN) / (hi - lo)) + OUTPUT_MIN
    scaled = np.clip(np.rint(scaled), OUTPUT_MIN, OUTPUT_MAX)
    positive = values > 0
    out[positive] = scaled[positive].astype(np.uint8)
    return out


def grey_bounds(histogram: np.ndarray) -> tuple[float, float]:
    """p0.5 and p99.5 of the non-zero cells, from a histogram of raw values."""
    counts = np.asarray(histogram, dtype=np.float64).reshape(-1)
    counts[0] = 0.0  # raw 0 means "no grey value", never part of the distribution
    total = counts.sum()
    if total <= 0:
        return 0.0, 0.0
    cumulative = np.cumsum(counts)
    low = np.searchsorted(cumulative, total * LO_PERCENTILE / 100.0, side="left")
    high = np.searchsorted(cumulative, total * HI_PERCENTILE / 100.0, side="left")
    return float(low), float(high)


def rainbow_stops() -> np.ndarray:
    """The web client's rainbow ramp, as 8-bit RGB for t = 0..255.

    ``static/js/intensityRamp.js`` holds the same three-stop formula; the server builds
    rainbow tiles from raw values so the client never re-colours a grey texture.
    """
    t = np.arange(256, dtype=np.float64) / 255.0
    hue = ((1.0 - t) * 240.0) / 60.0
    chroma = 1.0 - np.abs(np.mod(hue, 2.0) - 1.0)
    rgb = np.zeros((256, 3), dtype=np.float64)
    band1 = hue < 1
    band2 = (hue >= 1) & (hue < 2)
    band3 = (hue >= 2) & (hue < 3)
    band4 = hue >= 3
    rgb[band1] = np.stack([np.ones(band1.sum()), chroma[band1], np.zeros(band1.sum())], axis=1)
    rgb[band2] = np.stack([chroma[band2], np.ones(band2.sum()), np.zeros(band2.sum())], axis=1)
    rgb[band3] = np.stack([np.zeros(band3.sum()), np.ones(band3.sum()), chroma[band3]], axis=1)
    rgb[band4] = np.stack([np.zeros(band4.sum()), chroma[band4], np.ones(band4.sum())], axis=1)
    return np.clip(np.rint(rgb * 255.0), 0, 255).astype(np.uint8)


@dataclass(frozen=True)
class StripPlan:
    """One strip of output columns: which scan columns feed which output column."""

    width: int
    height: int
    x0: int
    columns: np.ndarray  # source column per output column in this strip
    rows: np.ndarray  # source row per output row, -1 outside the scanned band


def plan_strip(header: FlsHeader, azimuths: np.ndarray, x0: int, width: int) -> StripPlan:
    """Plan a strip of ``width`` output columns starting at ``x0``."""
    total_w, total_h = level0_size(header)
    x0 = max(0, x0)
    x1 = min(total_w, x0 + width)
    columns = source_columns(azimuths, total_w)[x0:x1]
    return StripPlan(
        width=max(0, x1 - x0),
        height=total_h,
        x0=x0,
        columns=columns,
        rows=source_rows(header, total_h),
    )


def wrap_split(columns: np.ndarray) -> int:
    """Index where the source columns wrap around the azimuth seam, or ``len`` if none."""
    if columns.size < 2:
        return columns.size
    steps = np.diff(columns.astype(np.int64))
    jumps = np.flatnonzero(np.abs(steps) > 4)
    return int(jumps[0] + 1) if jumps.size else int(columns.size)


def fill_slivers(image: np.ndarray, passes: int = 2, neighbours: int = 3) -> np.ndarray:
    """Replace thin empty runs with the mean of the values around them.

    A scan of a surface at a grazing angle leaves one or two empty cells along the beam
    pattern; rendered as they are, those cells become dark vertical slivers through the
    surface. A cell is only filled when at least ``neighbours`` of its eight neighbours hold
    a value, so a real hole — sky, or beyond the scanner's reach — is left alone.
    """
    filled = image.copy()
    for _ in range(passes):
        empty = filled == 0
        if not empty.any():
            break
        total = np.zeros(filled.shape, dtype=np.float64)
        count = np.zeros(filled.shape, dtype=np.int16)
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                shifted = np.roll(np.roll(filled, dy, axis=0), dx, axis=1).astype(np.float64)
                total += shifted
                count += shifted > 0
        take = empty & (count >= neighbours)
        filled[take] = np.clip(total[take] / count[take], 1, 255).astype(np.uint8)
    return filled


def despeckle(image: np.ndarray, margin: int = 18, floor: int = 24) -> np.ndarray:
    """Remove thin dark lines that the beam pattern leaves across a surface.

    A cell that is much darker than all of its neighbours is a missing return, not a shadow:
    the scanner's pattern skips a column here and there and a 1-pixel dark line runs down the
    surface. Replace those with the median of what is around them, and leave a dark area that
    is dark all the way across alone, because there the neighbours are dark too.
    """
    if image.size == 0:
        return image
    planes = []
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            planes.append(np.roll(np.roll(image, dy, axis=0), dx, axis=1))
    median = np.median(np.stack(planes), axis=0)
    dark = (image.astype(np.int16) + margin < median) & (median > floor)
    out = image.copy()
    out[dark] = median[dark].astype(np.uint8)
    return out


def suppress_column_lines(image: np.ndarray, reach: int = 4, margin: int = 12, floor: int = 20) -> np.ndarray:
    """Replace the vertical dark lines that a skipped scan column leaves behind.

    Comparing a pixel with its neighbours *along the row* is what tells a vertical line from
    a real edge: a line is darker than the surface to its left and right, while a corner is
    not. Cells without a return come out dark in the product, and at the resolution of the
    product they run for hundreds of rows.
    """
    if image.size == 0 or image.shape[1] < 2 * reach + 1:
        return image
    out = image.astype(np.int16)
    # Pad rather than roll: a wrapped neighbour would compare one edge of the image with the
    # other and "fix" a line that is not there.
    padded = np.pad(out, ((0, 0), (reach, reach)), mode="edge")
    for step in range(1, reach + 1):
        left = padded[:, reach - step : reach - step + out.shape[1]]
        right = padded[:, reach + step : reach + step + out.shape[1]]
        nearby = np.minimum(left, right)
        take = (out + margin < nearby) & (nearby > floor)
        out[take] = nearby[take]
    return np.clip(out, 0, 255).astype(np.uint8)


def sample_strip(plan: StripPlan, source: np.ndarray, source_col0: int) -> np.ndarray:
    """Raw grey arranged into the output grid: the sampling half of :func:`render_strip`.

    Kept separate so a combined build can hold the raw image and normalise it later, once it
    knows the per-scan bounds (spec C2).
    """
    out = np.zeros((plan.height, plan.width), dtype=np.int32)
    if plan.width == 0 or source.size == 0:
        return out
    wanted_cols = plan.columns.astype(np.int64) - source_col0
    inside = (wanted_cols >= 0) & (wanted_cols < source.shape[0])
    usable_rows = plan.rows >= 0
    if not inside.any() or not usable_rows.any():
        return out
    clipped_cols = np.clip(wanted_cols, 0, source.shape[0] - 1)
    clipped_rows = np.clip(plan.rows, 0, source.shape[1] - 1)
    taken = source[clipped_cols][:, clipped_rows].T  # (height, width)
    mask = usable_rows[:, None] & inside[None, :]
    out[mask] = taken[mask]
    return out


def render_strip(plan: StripPlan, source: np.ndarray, source_col0: int, lo: float, hi: float) -> np.ndarray:
    """Render one strip: raw grey in, ``(height, width)`` uint8 out, 0 where there is no value.

    ``source`` is ``(columns, rows)`` raw grey for source columns from ``source_col0``.
    Output pixels outside the scanned elevation band are 0, as are cells with raw grey 0.
    """
    raw = sample_strip(plan, source, source_col0)
    out = normalise_band(raw, lo, hi)
    return suppress_column_lines(despeckle(fill_slivers(out)))


def scan_column_range(plan: StripPlan) -> tuple[int, int]:
    """The contiguous span of source columns a strip needs (call :func:`wrap_split` first)."""
    return int(plan.columns.min()), int(plan.columns.max()) + 1


def grey_histogram(scan) -> np.ndarray:
    """Histogram of all non-zero grey values in a scan, without holding the grid."""
    histogram = np.zeros(1 << 16, dtype=np.int64)
    for _rect, columns in scan.all_columns("Grey"):
        for _first, block in columns.bands():
            positive = block[block > 0]
            if positive.size:
                histogram += np.bincount(np.clip(positive, 0, (1 << 16) - 1), minlength=1 << 16)
    return histogram

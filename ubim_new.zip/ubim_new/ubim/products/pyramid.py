"""Tile pyramid writer shared by the intensity and depth products.

Tiles are 512x512 PNGs named ``<ramp>/L<level>/<col>/<row>.png``. Empty tiles are not
written at all: a hole is cheaper than a file full of zeros, and the client treats a missing
tile as transparent. Levels are built by halving the grid, and every level records its own
dimensions in the manifest so a client never has to guess.

Writes go to ``<target>.part`` first and are renamed at the end, so a half-built product is
never visible as a finished one (the manifest is the last thing written).
"""

from __future__ import annotations

import json
import math
import shutil
import time
from pathlib import Path

import numpy as np
from PIL import Image

TILE = 512
MAX_LEVELS = 9


def tile_path(root: Path, ramp: str, level: int, col: int, row: int) -> Path:
    """Where one tile of an intensity pyramid is stored."""
    return root / ramp / f"L{level}" / str(col) / f"{row}.png"


def _halve(values: np.ndarray) -> np.ndarray:
    """2x2 box average, with odd edges padded by repeating the last row/column."""
    height, width = values.shape
    if height % 2:
        values = np.vstack([values, values[-1:]])
    if width % 2:
        values = np.hstack([values, values[:, -1:]])
    block = values.reshape(values.shape[0] // 2, 2, values.shape[1] // 2, 2)
    averaged = block.mean(axis=(1, 3))
    # Keep the source's own range. Clipping a raw depth grid (hundreds of thousands of units)
    # to 255 turns every level below the first into black, which is what a "blank" depth view
    # actually was.
    if values.dtype == np.uint16:
        return np.clip(np.rint(averaged), 0, 65535).astype(np.uint16)
    if values.dtype.itemsize > 1:
        return np.clip(np.rint(averaged), 0, np.iinfo(values.dtype).max).astype(values.dtype)
    return np.clip(np.rint(averaged), 0, 255).astype(np.uint8)


def build(
    values: np.ndarray,
    root: Path,
    ramps: dict,
    *,
    progress=None,
    meta: dict | None = None,
    min_level_size: int = TILE,
) -> dict:
    """Write every level of a pyramid and return its manifest.

    ``ramps`` maps a ramp name to a callable turning a value block into an image array.
    A block that is entirely empty (all zeros) writes no file for any ramp.
    """
    if values.ndim != 2:
        raise ValueError("pyramid needs a 2-D array")
    root = Path(root)
    part = root.with_name(root.name + ".part")
    if part.exists():
        shutil.rmtree(part)
    part.mkdir(parents=True, exist_ok=True)

    levels = []
    current = values
    total_tiles = 0
    started = time.monotonic()
    for level in range(MAX_LEVELS):
        height, width = current.shape
        cols = math.ceil(width / TILE)
        rows = math.ceil(height / TILE)
        written = 0
        occupied = []
        for col in range(cols):
            for row in range(rows):
                block = current[row * TILE : (row + 1) * TILE, col * TILE : (col + 1) * TILE]
                if not block.any():
                    continue
                occupied.append([col, row])
                for name, produce in ramps.items():
                    image = produce(block)
                    target = tile_path(part, name, level, col, row)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    Image.fromarray(image).save(target, format="PNG", compress_level=1)
                    written += 1
        total_tiles += written
        levels.append(
            {
                "z": level,
                "width": width,
                "height": height,
                "cols": cols,
                "rows": rows,
                "tiles": written,
                # Which tiles exist: the client asks for these and nothing else, so empty
                # areas cost no requests and no 404s in the console.
                "tileIndex": occupied,
            }
        )
        if progress is not None:
            progress(level, len(levels), written)
        if width <= min_level_size and height <= min_level_size:
            break
        current = _halve(current)

    manifest = {
        "version": 1,
        "tile": TILE,
        "ramps": list(ramps),
        "levels": levels,
        "width": int(values.shape[1]),
        "height": int(values.shape[0]),
        "tilesWritten": total_tiles,
        "builtAt": int(time.time()),
        "seconds": round(time.monotonic() - started, 2),
        **(meta or {}),
    }
    (part / "manifest.json").write_text(json.dumps(manifest, indent=1))
    if root.exists():
        shutil.rmtree(root)
    part.rename(root)
    return manifest


def read_manifest(root: Path) -> dict | None:
    """An intensity pyramid's manifest, or None."""
    path = Path(root) / "manifest.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None


def find_tile(root: Path, ramp: str, level: int, col: int, row: int) -> Path | None:
    """Resolve a tile inside a built product, validating the indices against the manifest."""
    manifest = read_manifest(root)
    if manifest is None or ramp not in manifest.get("ramps", []):
        return None
    if level < 0 or level >= len(manifest["levels"]):
        return None
    shape = manifest["levels"][level]
    if not (0 <= col < shape["cols"] and 0 <= row < shape["rows"]):
        return None
    path = tile_path(root, ramp, level, col, row)
    return path if path.exists() else None

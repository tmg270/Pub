"""Depth (range) product.

The distances are decoded from ``Scans/1/Dist*`` with the same reader as the grey map and
written into the same angular grid as the intensity image, so a pixel at (x, y) in either
product is the same direction in the world. The grid is kept on disk as a flat array rather
than in memory: at 10 136 x 5 086 it is about 100 MB, and picking a point only needs one
cell.

Values are stored raw, and the scale comes from ``StorageDistFact`` in the scan header: the
largest range in SCAN_085 is 15 876 675 units against a factor of 100 000, which is 158.8 m —
a believable distance for the buildings in that scene. That is an inference from the data,
not from a FARO document, so the viewer reports raw units next to metres and the factor is
kept in the manifest. Anyone measuring something critical should check one known distance
against SCENE before trusting the absolute scale.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np

from ..formats.fls import FlsFile
from . import intensity as I
from . import pyramid
from .render import decode_columns

GRID_NAME = "depth.grid"
META_NAME = "depth.json"


def build_grid(scan: FlsFile, target: Path, progress=None, on_strip=None) -> dict:
    """Decode every range stream into the angular grid and write it to ``target``."""
    calib = scan.azimuths
    if calib is None:
        raise ValueError("depth needs the Calib azimuth table")
    width, height = I.level0_size(scan.header)
    cache: dict = {}
    peak = 0
    maximum = 0
    filled = 0
    dtype = np.uint32
    started = time.monotonic()

    grid = np.memmap(target, dtype=dtype, mode="w+", shape=(height, width))
    grid[:] = 0
    for x0 in range(0, width, 512):
        plan = I.plan_strip(scan.header, calib, x0, 512)
        cut = I.wrap_split(plan.columns)
        parts = []
        subs = []
        spans = [(0, cut), (cut, plan.width - cut)] if cut < plan.width else [(0, plan.width)]
        for start, count in spans:
            sub = I.plan_strip(scan.header, calib, plan.x0 + start, count)
            c0, c1 = I.scan_column_range(sub)
            source = decode_columns(scan, c0, c1, cache, kind="Dist")
            peak = max(peak, source.nbytes)
            wanted_cols = np.clip(sub.columns.astype(np.int64) - c0, 0, source.shape[0] - 1)
            wanted_rows = np.clip(sub.rows, 0, source.shape[1] - 1)
            block = source[wanted_cols][:, wanted_rows].T
            mask = (sub.rows >= 0)[:, None] & ((sub.columns.astype(np.int64) - c0 >= 0) & (sub.columns.astype(np.int64) - c0 < source.shape[0]))[None, :]
            block = np.where(mask, block, 0)
            parts.append(block)
            subs.append(sub)
        strip = np.concatenate(parts, axis=1)
        maximum = max(maximum, int(strip.max()))
        if maximum > np.iinfo(dtype).max:
            raise ValueError(f"range value {maximum} does not fit in {dtype.__name__}")
        filled += int(np.count_nonzero(strip))
        grid[:, x0 : x0 + strip.shape[1]] = strip
        if on_strip is not None:
            # The same strip plan is offered to another product, so a combined build decodes
            # each stream once (spec C2) instead of walking the scan again.
            on_strip(plan.x0, subs)
        if progress is not None:
            progress("depth", x0 / max(1, width))
    grid.flush()
    del grid
    return {
        "width": width,
        "height": height,
        "dtype": np.dtype(dtype).name,
        "metresPerUnit": 1.0 / float(scan.header.dist_fact),
        "maxRaw": maximum,
        "filled": filled,
        "peakSourceBytes": peak,
        "secondsDecode": round(time.monotonic() - started, 2),
        "distFact": float(scan.header.dist_fact),
    }


def read_grid(product: Path, meta: dict) -> np.memmap:
    """The range grid as a memory-mapped uint32 array, so a tile read does not load 200 MiB."""
    return np.memmap(Path(product) / GRID_NAME, dtype=np.dtype(meta["dtype"]), mode="r", shape=(meta["height"], meta["width"]))


def build_f3s(product: Path, scan_path: Path, progress=None) -> dict:
    """Depth product for a ``.f3s`` scan.

    The 2026 format is an octree, not a strip grid: its reader already produces an
    equirectangular range raster, so there is nothing to de-strip. Ranges are stored in
    micrometres (``F3sFile.range_scale``), which is why ``distFact`` is 1e6 rather than the
    .fls value. Nothing is rescaled here; the grid keeps the file's own integers.
    """
    from ..formats.f3s import F3sFile

    product = Path(product)
    product.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    if progress is not None:
        progress("depth.read", 0.0)
    scan = F3sFile.read(scan_path)
    if progress is not None:
        progress("depth.read", 0.35)
    ranges = scan.ranges()
    height, width = ranges.shape
    filled = int(np.count_nonzero(ranges))
    maximum = int(ranges.max())
    target = product / GRID_NAME
    grid = np.memmap(target, dtype=np.uint32, mode="w+", shape=(height, width))
    for y0 in range(0, height, 512):
        grid[y0 : y0 + 512] = ranges[y0 : y0 + 512]
        if progress is not None:
            progress("depth.write", 0.35 + 0.35 * (y0 + 512) / height)
    grid.flush()
    del grid
    meta = {
        "width": width,
        "height": height,
        "dtype": "uint32",
        "metresPerUnit": float(scan.range_scale),
        "maxRaw": maximum,
        "filled": filled,
        "secondsDecode": round(time.monotonic() - started, 2),
        "distFact": 1.0 / float(scan.range_scale),
        "pointCount": scan.point_count,
        "coordinateMap": scan.scale,
    }
    return _finish_depth(product, scan_path, meta, progress, elevation_top=None)


def build(product: Path, scan_path: Path, progress=None) -> dict:
    """Build the whole depth product: grid file plus a display pyramid."""
    if Path(scan_path).suffix.lower() == ".f3s":
        return build_f3s(product, scan_path, progress)
    product = Path(product)
    product.mkdir(parents=True, exist_ok=True)
    with FlsFile(scan_path) as scan:
        meta = build_grid(scan, product / GRID_NAME, progress)
        mapping = dict(I.MAPPING)
        elevation_top = scan.header.elevation_deg(0.0)
    return _finish_depth(product, scan_path, meta, progress, elevation_top=elevation_top)


def _finish_depth(product: Path, scan_path: Path, meta: dict, progress, elevation_top: float | None) -> dict:
    """Shared tail: a grey display pyramid plus the manifest."""
    product = Path(product)
    mapping = dict(I.MAPPING)
    if elevation_top is None:
        elevation_top = float(I.TOP_DEG)
    grid = read_grid(product, meta)
    maximum = max(1, int(meta["maxRaw"]))
    # A linear ramp over the true maximum makes a room black: the tail (sky through a window,
    # a stray return down the street) is hundreds of metres out, so a wall at four metres lands
    # at one or two out of 255. Display against a high percentile instead and keep the true
    # maximum in the manifest, where it still answers "how far does this scan reach".
    filled = grid[grid > 0]
    display = int(np.percentile(filled, 95)) if filled.size else maximum
    display = max(1, min(display, maximum))
    gamma = 0.5

    def grey(block):
        # Display only: clip at the band and take a square root so a wall at four metres is
        # legible instead of a two-out-of-255 smudge. The stored grid keeps every raw value.
        """The depth ramp: range mapped through the product's bounds."""
        normalised = np.clip(block.astype(np.float32) / display, 0.0, 1.0)
        return np.clip(np.rint(np.power(normalised, gamma) * 255.0), 0, 255).astype(np.uint8)

    levels = pyramid.build(
        grid, product / "depth_tiles", {"grey": grey},
        meta={"kind": "depth", "source": scan_path.name, "mapping": mapping,
              "elevationTopDeg": elevation_top, "maxRaw": maximum},
        progress=(lambda level, total, written: progress("depth.tiles", level / 8)) if progress else None,
    )
    meta.update({
        "product": "depth",
        "maxMetres": round(meta["maxRaw"] / float(meta.get("distFact") or 100000.0), 3),
        "rampMaxRaw": display,
        "rampMaxMetres": round(display / float(meta.get("distFact") or 100000.0), 3),
        "rampGamma": gamma,
        "rampNote": "display only: clipped at the 95th percentile of filled cells, square-root gamma",
        "levels": levels["levels"],
        "mapping": mapping,
        "tile": levels["tile"],
        "elevationTopDeg": elevation_top,
        "builtAt": int(time.time()),
    })
    (product / META_NAME).write_text(json.dumps(meta, indent=1))
    return meta


def load_meta(product: Path) -> dict | None:
    """A depth product's manifest, or None when it has not been built."""
    path = Path(product) / META_NAME
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None


def neighbourhood(product: Path, meta: dict, x: int, y: int, cells: int = 2) -> dict:
    """How much return there is around one cell, and whether the cell sits at the grid edge.

    Spec M2 wants a per-pick "height uncertain" flag. A range can be perfectly measured and
    still give an untrustworthy height: a single return with nothing beside it is often a
    railing wire or a stray, and a cell on the first or last row is at the edge of the sweep.
    """
    grid = read_grid(product, meta)
    width, height = int(meta["width"]), int(meta["height"])
    rows = np.arange(max(0, y - cells), min(height, y + cells + 1))
    cols = (x + np.arange(-cells, cells + 1)) % width
    window = np.asarray(grid[np.ix_(rows, cols)], dtype=np.float64)
    return {
        "support": int((window > 0).sum()),
        "window": int(window.size),
        "edge": bool(y <= 1 or y >= height - 2),
    }


def sample(product: Path, meta: dict, azimuth_rad: float, elevation_rad: float) -> dict | None:
    """Raw range at a direction, using the same azimuth/elevation model as the products."""
    grid = read_grid(product, meta)
    width, height = meta["width"], meta["height"]
    # Invert the mapping the products were built with: x from azimuth, y from elevation.
    az0 = np.radians(I.AZ0_DEG)
    x = int(round(((az0 - azimuth_rad) % (2 * np.pi)) / (2 * np.pi) * width)) % width
    y = int(round((np.radians(I.TOP_DEG) - elevation_rad) / np.radians(I.SPAN_DEG) * height))
    if y < 0 or y >= height:
        return None
    raw = int(grid[y, x])
    if raw == 0:
        return None
    factor = float(meta.get("distFact") or 100000.0)
    return {
        "x": x,
        "y": y,
        "raw": raw,
        "distFact": factor,
        "metres": round(raw / factor, 4),
        "maxRaw": meta.get("maxRaw"),
    }


def nearest(product: Path, meta: dict, azimuth_rad: float, elevation_rad: float, cells: int = 3) -> dict | None:
    """Nearest non-zero return within ``cells`` grid cells of a direction.

    Spec M3a: with snapping on, an empty pixel takes the closest real return nearby instead of
    reporting no point. The reply says how far it moved, so a snapped pick is never presented
    as an exact one.
    """
    grid = read_grid(product, meta)
    width, height = meta["width"], meta["height"]
    az0 = np.radians(I.AZ0_DEG)
    x = int(round(((az0 - azimuth_rad) % (2 * np.pi)) / (2 * np.pi) * width)) % width
    y = int(round((np.radians(I.TOP_DEG) - elevation_rad) / np.radians(I.SPAN_DEG) * height))
    if y < 0 or y >= height:
        return None
    rows = np.arange(max(0, y - cells), min(height, y + cells + 1))
    cols = (x + np.arange(-cells, cells + 1)) % width
    window = grid[np.ix_(rows, cols)]
    found = window > 0
    if not found.any():
        return None
    # Distance in cells, then the smallest one; ties go to the first in scan order.
    row_offset = np.broadcast_to(rows[:, None] - y, window.shape)
    col_offset = np.broadcast_to(cols[None, :] - x, window.shape)
    distance = np.sqrt(row_offset ** 2 + col_offset ** 2)
    distance = np.where(found, distance, np.inf)
    flat = int(np.argmin(distance))
    row_index, col_index = np.unravel_index(flat, window.shape)
    raw = int(window[row_index, col_index])
    factor = float(meta.get("distFact") or 100000.0)
    snapped_az = float(az0 - 2.0 * np.pi * int(cols[col_index]) / width)
    snapped_el = float(np.radians(I.TOP_DEG) - (int(rows[row_index])) * np.radians(I.SPAN_DEG) / height)
    return {
        "x": int(cols[col_index]),
        "y": int(rows[row_index]),
        "raw": raw,
        "distFact": factor,
        "metres": round(raw / factor, 4),
        "maxRaw": meta.get("maxRaw"),
        "snapped": True,
        "cellOffset": {"x": int(col_offset[row_index, col_index]), "y": int(row_offset[row_index, col_index])},
        "snappedAzimuthDeg": round(float(np.degrees(snapped_az)), 4),
        "snappedElevationDeg": round(float(np.degrees(snapped_el)), 4),
    }

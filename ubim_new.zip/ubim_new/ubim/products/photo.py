"""A photographic panorama as a tile pyramid.

The viewer used to draw the FARO panorama as one JPEG capped at 4096 wide, which throws away
most of a 10136-pixel scan image and goes soft as soon as you zoom. This product keeps the
native pixels in 512-pixel tiles and successive levels, the same shape the intensity and depth
products use, so the viewer can load only the detail the user is looking at.

The source is the scan's own WebShare photograph. A ``.f3s`` has no photograph — its colour
product is a render of the point colours — so the photo product is only built for a scan that
has one.
"""

from __future__ import annotations

import json
import math
import shutil
import time
from pathlib import Path

from PIL import Image

from .intensity import MAPPING

TILE = 512
META_NAME = "photo.json"
TILE_DIR = "photo_tiles"
MAX_LEVELS = 8


def _source_for(scan_path: Path) -> Path | None:
    """The best WebShare photograph for this scan, found beside it.

    A FARO tree keeps imagery under ``<revision>/WebShareData/Images``; the scan itself sits in
    ``<revision>/Scans``. Walking up a few levels covers both the revision layout and a flat
    export of it.
    """
    if scan_path.suffix.lower() != ".fls":
        return None
    for up in (1, 2, 3):
        try:
            revision = scan_path.parents[up]
        except IndexError:
            break
        images_dir = revision / "WebShareData" / "Images"
        if not images_dir.is_dir():
            continue
        best = None
        for candidate in sorted(images_dir.rglob("*")):
            if candidate.suffix.lower() not in (".jpg", ".jpeg", ".png"):
                continue
            try:
                with Image.open(candidate) as image:
                    size = image.size[0] * image.size[1]
            except OSError:
                continue
            if best is None or size > best[0]:
                best = (size, candidate)
        if best is not None:
            return best[1]
    # A flat export keeps the panorama beside the scan rather than under WebShareData: prefer
    # the grey image, then any image at all, largest first.
    for folder in (scan_path.parent, scan_path.parent.parent):
        if not folder.is_dir():
            continue
        found = []
        for candidate in sorted(folder.glob("*")):
            if candidate == scan_path or candidate.suffix.lower() not in (".jpg", ".jpeg", ".png"):
                continue
            try:
                with Image.open(candidate) as image:
                    found.append((image.size[0] * image.size[1], "grey" in candidate.name.lower(), candidate))
            except OSError:
                continue
        if found:
            found.sort(key=lambda item: (item[1], item[0]), reverse=True)
            return found[0][2]
    return None


def build(product: Path, scan_path: Path, progress=None) -> dict:
    """Tile the scan's photograph. Raises when the scan has no photograph to tile."""
    product = Path(product)
    source = _source_for(Path(scan_path))
    if source is None:
        raise ValueError("this scan has no WebShare photograph to tile")
    started = time.monotonic()
    part = product / (TILE_DIR + ".part")
    if part.exists():
        shutil.rmtree(part)
    part.mkdir(parents=True, exist_ok=True)

    with Image.open(source) as opened:
        image = opened.convert("RGB")
    width, height = image.size
    levels = []
    current = image
    for level in range(MAX_LEVELS):
        cols = math.ceil(current.size[0] / TILE)
        rows = math.ceil(current.size[1] / TILE)
        occupied = []
        for col in range(cols):
            for row in range(rows):
                box = (col * TILE, row * TILE, min((col + 1) * TILE, current.size[0]), min((row + 1) * TILE, current.size[1]))
                block = current.crop(box)
                if not block.getbbox():
                    continue  # fully black or transparent: no request needed
                target = part / f"L{level}" / str(col) / f"{row}.png"
                target.parent.mkdir(parents=True, exist_ok=True)
                # PNG, not JPEG: the source is already a JPEG, and re-encoding 512-pixel crops
                # gives each tile its own DC, which shows as a faint rectangle in a flat sky.
                block.save(target, "PNG", compress_level=6)
                occupied.append([col, row])
        levels.append({
            "z": level,
            "width": current.size[0],
            "height": current.size[1],
            "cols": cols,
            "rows": rows,
            "tileIndex": occupied,
            "tiles": len(occupied),
        })
        if progress is not None:
            progress(f"photo.tiles {level}", (level + 1) / MAX_LEVELS)
        if current.size[0] <= TILE and current.size[1] <= TILE:
            break
        current = current.resize((max(1, current.size[0] // 2), max(1, current.size[1] // 2)), Image.LANCZOS)

    target_dir = product / TILE_DIR
    if target_dir.exists():
        shutil.rmtree(target_dir)
    part.rename(target_dir)
    manifest = {
        "product": "photo",
        "source": source.name,
        "sourceSize": [width, height],
        "width": width,
        "height": height,
        "tile": TILE,
        "levels": levels,
        "derivedFrom": "WebShare photograph",
        "builtAt": int(time.time()),
        "seconds": round(time.monotonic() - started, 2),
        "mapping": dict(MAPPING),
    }
    (product / META_NAME).write_text(json.dumps(manifest, indent=1))
    return manifest


def load_meta(product: Path) -> dict | None:
    """A photograph product's manifest, or None."""
    path = Path(product) / META_NAME
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return None


def tile_path(product: Path, level: int, col: int, row: int) -> Path | None:
    """Where one tile of the photograph pyramid is stored."""
    path = Path(product) / TILE_DIR / f"L{level}" / str(col) / f"{row}.png"
    return path if path.exists() else None


def is_fresh(product: Path, scan_path: Path) -> bool:
    """Whether the product was built from the scan as it stands now, by size, mtime and digest."""
    meta = load_meta(product)
    if meta is None:
        return False
    try:
        built = int(meta.get("builtAt") or 0)
        return built >= int(Path(scan_path).stat().st_mtime)
    except OSError:
        return False

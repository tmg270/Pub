"""Top-down site plan, made from the range product.

Spec section 6 (P1-P3) wants a plan view of the site with the scans placed on it. A real
WebShare project ships plan imagery, but a folder of loose scans does not, and the plan must
still show where the scan stood. So this builds one from the data that exists: every range
cell is unprojected into the scan frame and rasterised into a top-down grid, keeping the
highest return per cell. Nothing is interpolated: a cell with no return stays empty, which is
why a single scan shows a ring of ground rather than a filled rectangle.

Heights are in metres above the scanner, in the scan's own frame. That frame is only the
survey frame once a registration transform is known; the manifest records which it is.
"""

from __future__ import annotations

import json
import math
import shutil
import time
from pathlib import Path

import numpy as np
from PIL import Image

GRID_NAME = "depth.grid"
META_NAME = "depth.json"
PLAN_NAME = "plan.png"
PLAN_FILLED = "plan-filled.png"
PLAN_TILES = "plan_tiles"
#: 512-pixel tiles, three levels: the page shows the plan at about 700 px, so the top level is
#: what a browser needs, and the finer levels are there for zooming in.
TILE = 512
LEVELS = 3
PLAN_META = "plan.json"

#: Output raster size. 2048 cells across a 200 m site is 10 cm per cell, which is finer than
#: the plan is ever displayed at, and keeps the PNG under a megabyte.
SIZE = 2048
#: Ignore returns beyond this (metres): the tail of a FARO range histogram is noise and sky.
MAX_RANGE_M = 200.0
#: Row blocks processed at once. 128 rows of a 10k-wide grid is 1.3 M cells, about 20 MB of
#: float32 temporaries, so the whole pass stays in cache-friendly memory instead of 800 MB.
BLOCK = 128


def _depth(product: Path, meta: dict) -> tuple[np.ndarray, float]:
    """Load the range grid and its scale from the manifest."""
    from .depth import read_grid

    return read_grid(product, meta), float(meta.get("distFact") or 100000.0)


def _directions(width: int, height: int, y0: int, y1: int) -> tuple[np.ndarray, np.ndarray]:
    """Elevation per row and azimuth per column for one block of rows."""
    from .intensity import AZ0_DEG, SPAN_DEG, TOP_DEG

    rows = np.arange(y0, y1, dtype=np.float64)
    elevation = np.radians(TOP_DEG) - rows * np.radians(SPAN_DEG) / height
    cols = np.arange(width, dtype=np.float64)
    azimuth = np.radians(AZ0_DEG) - 2.0 * np.pi * cols / width
    return elevation, azimuth


def _bounds(grid: np.ndarray, factor: float, height: int, width: int) -> tuple[float, float, float, float]:
    """Extent of the returns, from a sample of rows, clipped to drop the long tail."""
    xs: list[np.ndarray] = []
    ys: list[np.ndarray] = []
    for y0 in range(0, height, max(BLOCK, height // 64)):
        y1 = min(y0 + BLOCK, height)
        elevation, azimuth = _directions(width, height, y0, y1)
        block = grid[y0:y1].astype(np.float32) / factor
        mask = (block > 0) & (block < MAX_RANGE_M)
        if not mask.any():
            continue
        r = block[mask]
        el = np.repeat(elevation[:, None], width, axis=1)[mask]
        az = np.tile(azimuth[None, :], (y1 - y0, 1))[mask]
        xs.append(r * np.cos(el) * np.cos(az))
        ys.append(r * np.cos(el) * np.sin(az))
    if not xs:
        raise ValueError("no returns to build a plan from")
    x = np.concatenate(xs)
    y = np.concatenate(ys)
    lo_x, hi_x = np.percentile(x, [0.2, 99.8])
    lo_y, hi_y = np.percentile(y, [0.2, 99.8])
    span = max(hi_x - lo_x, hi_y - lo_y, 1.0)
    centre_x = (lo_x + hi_x) / 2.0
    centre_y = (lo_y + hi_y) / 2.0
    half = span / 2.0 * 1.05
    return centre_x - half, centre_y - half, centre_x + half, centre_y + half


def fill_gaps(shade: np.ndarray, iterations: int = 2) -> np.ndarray:
    """Close the gaps between returns so a wall reads as a wall, not a dotted line.

    A scan sees through railings and past kerbs, so the honest raster is sparse. Growing the
    occupied cells into the holes, at a dimmer value, answers "what shape is this" without
    pretending the grown area was measured — the dimmer value is the tell.
    """
    occupied = shade > 0
    filled = shade.copy()
    if not occupied.any():
        return filled
    for _ in range(max(1, iterations)):
        grown = filled.copy()
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy or dx:
                    grown = np.maximum(grown, np.roll(np.roll(filled, dy, axis=0), dx, axis=1))
        filled = np.where(occupied, filled, (grown.astype(np.float32) * 0.8).astype(np.uint8))
    return filled


def build(product: Path, progress=None, name: str | None = None) -> dict:
    """Rasterise the range product into a site plan and return its manifest."""
    from . import depth

    product = Path(product)
    meta = depth.load_meta(product)
    if meta is None:
        raise ValueError("plan needs the depth product first")
    grid, factor = _depth(product, meta)
    height, width = int(meta["height"]), int(meta["width"])
    started = time.monotonic()
    if progress is not None:
        progress("plan.bounds", 0.0)
    min_x, min_y, max_x, max_y = _bounds(grid, factor, height, width)
    cell = (max_x - min_x) / SIZE

    top = np.full((SIZE, SIZE), -np.inf, dtype=np.float32)
    count = np.zeros((SIZE, SIZE), dtype=np.uint32)
    total = 0
    blocks = (height + BLOCK - 1) // BLOCK
    for index, y0 in enumerate(range(0, height, BLOCK)):
        y1 = min(y0 + BLOCK, height)
        elevation, azimuth = _directions(width, height, y0, y1)
        block = grid[y0:y1].astype(np.float32) / factor
        mask = (block > 0) & (block < MAX_RANGE_M)
        if mask.any():
            r = block[mask]
            el = np.repeat(elevation[:, None], width, axis=1)[mask]
            az = np.tile(azimuth[None, :], (y1 - y0, 1))[mask]
            x = r * np.cos(el) * np.cos(az)
            y = r * np.cos(el) * np.sin(az)
            z = r * np.sin(el)
            ix = np.clip(((x - min_x) / cell).astype(np.int32), 0, SIZE - 1)
            iy = np.clip(((y - min_y) / cell).astype(np.int32), 0, SIZE - 1)
            flat = iy * SIZE + ix
            np.maximum.at(top.ravel(), flat, z)
            count.ravel()[:] += np.bincount(flat, minlength=SIZE * SIZE).astype(np.uint32)
            total += int(mask.sum())
        if progress is not None:
            progress("plan.raster", (index + 1) / blocks)

    filled = top > -np.inf
    if not filled.any():
        raise ValueError("plan raster is empty")
    z = np.where(filled, top, 0.0)
    lo, hi = np.percentile(z[filled], [1.0, 99.0])
    shade = np.zeros((SIZE, SIZE), dtype=np.uint8)
    if hi > lo:
        normalised = np.clip((z - lo) / (hi - lo), 0.0, 1.0) ** 0.75
        shade = (55 + normalised * 200).astype(np.uint8)
    # Density modulates gently: a lone stray return should look faint, not like solid ground.
    density = 0.55 + 0.45 * np.clip(np.log1p(count.astype(np.float32)) / 4.0, 0.0, 1.0)
    shade = (shade.astype(np.float32) * density).astype(np.uint8)
    shade[~filled] = 0

    image = Image.fromarray(shade, mode="L").convert("RGB")
    image.save(product / PLAN_NAME, format="PNG", compress_level=6)
    densified = fill_gaps(shade)
    Image.fromarray(densified, mode="L").convert("RGB").save(
        product / PLAN_FILLED, format="PNG", compress_level=6)
    # Multi-resolution tiles: the same raster cut for a viewer that zooms, so a page never has
    # to download the whole 2048-pixel plan to show a corner of it.
    tile_root = product / PLAN_TILES
    if tile_root.exists():
        shutil.rmtree(tile_root)
    levels = []
    current = shade.copy()
    for level in range(LEVELS):
        cols = math.ceil(current.shape[1] / TILE)
        rows = math.ceil(current.shape[0] / TILE)
        occupied = []
        for col in range(cols):
            for row in range(rows):
                block = current[row * TILE:(row + 1) * TILE, col * TILE:(col + 1) * TILE]
                if not block.any():
                    continue
                target = tile_root / f"L{level}" / str(col) / f"{row}.png"
                target.parent.mkdir(parents=True, exist_ok=True)
                Image.fromarray(block, mode="L").convert("RGB").save(target, format="PNG", compress_level=6)
                occupied.append([col, row])
        levels.append({"z": level, "width": int(current.shape[1]), "height": int(current.shape[0]),
                       "cols": cols, "rows": rows, "tiles": len(occupied), "tileIndex": occupied})
        if current.shape[0] <= TILE and current.shape[1] <= TILE:
            break
        current = np.asarray(Image.fromarray(current, mode="L").resize(
            (max(1, current.shape[1] // 2), max(1, current.shape[0] // 2)), Image.LANCZOS))
    manifest = {
        "product": "plan",
        "tiles": {"tile": TILE, "levels": levels},
        "size": SIZE,
        "bounds": {"minX": min_x, "minY": min_y, "maxX": max_x, "maxY": max_y},
        "cellMetres": cell,
        "frame": "scan",  # UNKNOWN until a registration transform is applied
        "returns": total,
        "cells": int(filled.sum()),
        "filledImage": PLAN_FILLED,
        "filledCells": int((densified > 0).sum()),
        "heightRange": [float(lo), float(hi)],
        "maxRangeMetres": MAX_RANGE_M,
        # One dot: the scanner stood at the origin of its own frame. Until a registration
        # transform is known the site position of that origin is unknown, so it is marked
        # unplaced rather than drawn at a coordinate the data does not support.
        "scans": [{"name": name or product.parent.name.replace(".ubim", ""), "x": 0.0, "y": 0.0, "placed": False}],
        "builtAt": int(time.time()),
        "seconds": round(time.monotonic() - started, 2),
    }
    (product / PLAN_META).write_text(json.dumps(manifest, indent=1))
    return manifest


def tile_path(product: Path, level: int, col: int, row: int) -> Path | None:
    """Where one tile of the plan pyramid is stored."""
    path = Path(product) / PLAN_TILES / f"L{level}" / str(col) / f"{row}.png"
    return path if path.exists() else None


def scaled(product: Path, size: int, filled: bool = False) -> Path | None:
    """The plan at a requested width, cached beside it. ``filled`` selects the gap-filled copy."""
    meta = load(product)
    if meta is None:
        return None
    native = int(meta.get("size") or SIZE)
    source = Path(product) / (PLAN_FILLED if filled else PLAN_NAME)
    if not source.exists():
        return None
    size = max(256, min(native, int(size)))
    if size >= native:
        return source
    suffix = "-filled" if filled else ""
    target = Path(product) / f"plan{suffix}-{size}.png"
    if not target.exists() or target.stat().st_mtime < source.stat().st_mtime:
        with Image.open(source) as image:
            image.resize((size, size), Image.LANCZOS).save(target, format="PNG", compress_level=6)
    return target


def load(product: Path) -> dict | None:
    """A plan product's manifest, or None."""
    path = Path(product) / PLAN_META
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None

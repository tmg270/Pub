"""uBIM viewer: reading FARO scans, building products, and serving the interface.

The package is deliberately plain: no framework beyond FastAPI, no bundled JavaScript, and no
build step. Modules are grouped by what they do — ``formats`` reads the files, ``products``
turns a scan into tiles, ``api*`` serves it, ``pages`` writes the HTML."""


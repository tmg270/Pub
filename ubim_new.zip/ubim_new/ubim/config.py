"""Runtime configuration, read once at start-up.

Everything has a working default so the container starts with no configuration at all, and
every value can be overridden by an environment variable. Nothing here talks to the network.
"""

from __future__ import annotations

import ipaddress
import os
import secrets
from dataclasses import dataclass, field
from pathlib import Path

#: Product placement: ``beside`` writes ``<scan>.ubim/`` next to the scan, ``data`` keeps
#: every product in the data directory. ``beside`` matches the pack (R10) but needs a
#: writable project tree, so the server falls back to ``data`` when the tree is read-only.
BESIDE = "beside"
DATA = "data"


def _env(name: str, default: str = "") -> str:
    """Read a ``UBIM_``-prefixed environment variable, trimmed, with a default when it is unset."""
    return os.environ.get(f"UBIM_{name}", default).strip()


def _env_int(name: str, default: int) -> int:
    """An integer setting from the environment, falling back to the default when it is not a number."""
    raw = _env(name)
    try:
        return int(raw)
    except ValueError:
        return default


def _env_bool(name: str, default: bool) -> bool:
    """A boolean setting: 1/true/yes/on are true, 0/false/no/off are false, anything else is the default."""
    raw = _env(name).lower()
    if raw in ("1", "true", "yes", "on"):
        return True
    if raw in ("0", "false", "no", "off"):
        return False
    return default


def parse_networks(raw: str) -> list[ipaddress._BaseNetwork]:
    """Parse a comma separated CIDR list; anything invalid raises at start-up, not later."""
    networks = []
    for piece in (p.strip() for p in raw.split(",")):
        if not piece:
            continue
        networks.append(ipaddress.ip_network(piece, strict=False))
    return networks


@dataclass
class Config:
    """Everything the deployment decides: paths, limits, allow list, cookie flags and the instance secret."""
    data_dir: Path
    secret: bytes
    host: str = "0.0.0.0"
    port: int = 8431
    allow_networks: list = field(default_factory=list)
    #: Requests from outside the allow list get this status for every path, including
    #: unknown ones, so the app's shape is not visible (R40).
    deny_status: int = 404
    session_hours: int = 12
    invite_hours: int = 72
    share_hours: int = 24 * 30
    max_upload_mb: int = 512
    disk_guard_gb: float = 10.0
    #: Ceiling on the memory one product build may ask for. A build that would need more is
    #: refused with the figure it wanted rather than being left to fight the kernel (spec C4).
    max_build_mb: int = 2048
    #: Folder whose children are project folders. Discovery is asked for, never watched (C1).
    library_root: Path | None = None
    product_placement: str = BESIDE
    workers: int = 2
    secure_cookies: bool = False
    require_login: bool = True
    allow_anonymous_browse: bool = False
    app_version: str = "0.1.0"

    @property
    def db_path(self) -> Path:
        """The SQLite file holding users, projects, layers and audit rows."""
        return self.data_dir / "ubim.sqlite3"

    @property
    def projects_dir(self) -> Path:
        """Where per-project working files live."""
        return self.data_dir / "projects"

    @property
    def cache_dir(self) -> Path:
        """Where the tile and thumbnail caches live."""
        return self.data_dir / "cache"

    @property
    def thumb_dir(self) -> Path:
        """Where generated thumbnails live."""
        return self.data_dir / "thumbs"

    def ensure_dirs(self) -> None:
        """Create the directories the application writes to, and check they are writable."""
        for path in (self.data_dir, self.projects_dir, self.cache_dir, self.thumb_dir):
            path.mkdir(parents=True, exist_ok=True)

    def allows(self, address: str | None) -> bool:
        """True when the client is inside the allow list (the default is everybody)."""
        if not self.allow_networks:
            return True
        if not address:
            return False
        try:
            ip = ipaddress.ip_address(address)
        except ValueError:
            return False
        if ip.version == 6 and ip.ipv4_mapped is not None:
            ip = ip.ipv4_mapped
        return any(ip in net for net in self.allow_networks)


def _load_secret(data_dir: Path) -> bytes:
    """The instance secret, created on first start and kept with owner-only permissions."""
    path = data_dir / "secret.key"
    if path.exists():
        return path.read_bytes()
    try:
        data_dir.mkdir(parents=True, exist_ok=True)
        secret = secrets.token_bytes(32)
        path.write_bytes(secret)
    except PermissionError as exc:
        # A bind-mounted volume keeps the host's owner; the container runs as its own user, so
        # say which uid cannot write and what to do about it rather than a bare traceback.
        raise SystemExit(
            f"cannot write {path} as uid {os.getuid()}: {exc}. "
            f"Either chown {data_dir} to that uid, run with --user $(id -u):$(id -g), "
            "or use a named volume so the directory belongs to the container."
        ) from exc
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return secret


def load() -> Config:
    """Build the configuration from the environment, and refuse to start on a value that cannot work."""
    data_dir = Path(_env("DATA_DIR", "/data")).expanduser()
    config = Config(
        data_dir=data_dir,
        secret=_load_secret(data_dir),
        host=_env("HOST", "0.0.0.0"),
        port=_env_int("PORT", 8431),
        allow_networks=parse_networks(_env("ALLOW_CIDRS", "")),
        session_hours=_env_int("SESSION_HOURS", 12),
        invite_hours=_env_int("INVITE_HOURS", 72),
        share_hours=_env_int("SHARE_HOURS", 24 * 30),
        max_upload_mb=_env_int("MAX_UPLOAD_MB", 512),
        disk_guard_gb=float(_env("DISK_GUARD_GB", "10")),
        max_build_mb=max(64, _env_int("MAX_BUILD_MB", 2048)),
        library_root=(Path(_env("LIBRARY_ROOT", "")).expanduser() if _env("LIBRARY_ROOT", "") else None),
        product_placement=_env("PRODUCT_PLACEMENT", BESIDE) or BESIDE,
        workers=max(1, _env_int("WORKERS", 2)),
        secure_cookies=_env_bool("SECURE_COOKIES", False),
        require_login=not _env_bool("ALLOW_ANONYMOUS", False),
        allow_anonymous_browse=_env_bool("ALLOW_ANONYMOUS_BROWSE", False),
        app_version=_env("VERSION", "0.1.0"),
    )
    config.ensure_dirs()
    return config

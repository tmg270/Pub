"""Registration: local frames, project frames and the round trip between them.

A survey check is only worth what its worst case is, so these tests use transforms a real
registration could produce (a 90° heading and a 12 m offset) and check both directions.
"""

import math

import pytest

from ubim import registration


def test_identity_round_trip():
    pose = registration.pose_matrix(0, 0, 0, 0)
    world = registration.apply(pose, (3.0, -2.0, 1.5))
    assert world == pytest.approx((3.0, -2.0, 1.5))
    assert registration.local_from_world(world, pose) == pytest.approx((3.0, -2.0, 1.5))


def test_pose_moves_and_rotates():
    pose = registration.pose_matrix(10.0, 0.0, 0.0, 90.0)
    # A point 5 m in front of the scanner lands 5 m along +Y once the scanner faces +Y.
    world = registration.apply(pose, (5.0, 0.0, 0.0))
    assert world == pytest.approx((10.0, 5.0, 0.0), abs=1e-9)


def test_inverse_undoes_the_pose():
    pose = registration.pose_matrix(12.0, -4.0, 0.2, 37.0)
    local = (1.2, 3.4, -0.6)
    world = registration.apply(pose, local)
    assert registration.local_from_world(world, pose) == pytest.approx(local, abs=1e-9)


def test_projection_between_two_scans():
    front = registration.pose_matrix(0.0, 0.0, 0.0, 0.0)
    back = registration.pose_matrix(10.0, 0.0, 0.0, 90.0)
    world = registration.apply(front, (4.0, 0.0, 0.0))  # 4 m in front of the first scanner
    seen = registration.project(world, back)
    # In the second scanner's frame that point is 6 m to its left, so it appears at 90°.
    assert seen["r"] == pytest.approx(6.0, abs=1e-6)
    assert seen["az"] == pytest.approx(90.0, abs=1e-6)
    assert seen["el"] == pytest.approx(0.0, abs=1e-6)
    assert seen["visible"] is True


def test_point_outside_the_elevation_band_is_not_visible():
    pose = registration.pose_matrix(0.0, 0.0, 0.0, 0.0)
    world = registration.apply(pose, (0.5, 0.0, 9.0))  # almost straight up
    seen = registration.project(world, pose, elevation_limit_deg=60.0)
    assert seen["visible"] is False
    assert seen["el"] == pytest.approx(math.degrees(math.asin(9.0 / math.hypot(0.5, 9.0))), abs=1e-4)
    assert seen["r"] == pytest.approx(math.hypot(0.5, 9.0), abs=1e-4)  # stored to 4 dp


def flatten(matrix):
    return [value for row in matrix for value in row]


def test_parse_accepts_a_matrix_and_a_pose():
    expected = flatten(registration.pose_matrix(1, 2, 3, 45))
    assert flatten(registration.parse(registration.dump(registration.pose_matrix(1, 2, 3, 45)))) == pytest.approx(expected)
    assert flatten(registration.parse("[1, 2, 3, 45]")) == pytest.approx(expected)
    assert registration.parse(None) is None
    assert registration.parse("[]") is None
    assert registration.parse("garbage") is None


def test_identity_detection():
    assert registration.is_identity(None)
    assert registration.is_identity(registration.IDENTITY)
    assert not registration.is_identity(registration.pose_matrix(0, 0, 0, 1))

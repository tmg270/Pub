"""Drawings expressed in a scan's frame, at a height the caller chooses.

The importer is checked separately; this is about the projection: a flat plan has to land in
the scan's angular frame, the height must be the caller's decision, and the response has to
say which units it speaks because the overlay draws radians.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"

DXF = """0
SECTION
2
ENTITIES
0
LINE
8
0
10
4.0
20
0.0
11
4.0
21
6.0
0
LINE
8
0
10
4.0
20
6.0
11
-3.0
21
6.0
0
ENDSEC
0
EOF
"""


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        response = test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    folder = tmp_path / "draped"
    folder.mkdir()
    os.symlink(SCAN, folder / "A.fls")
    created = client.post("/api/projects", json={"path": str(folder), "name": "Draped site"})
    assert created.status_code in (200, 201), created.text
    drawing = client.post(f"/api/p/{created.json()['slug']}/drawings", json={"name": "plan.dxf", "text": DXF})
    assert drawing.status_code in (200, 201), drawing.text
    return created.json()


def test_a_flat_drawing_lands_in_the_scan_frame(client, project):
    response = client.get(f"/api/p/{project['slug']}/s/A/drawings?height=1.5")
    assert response.status_code == 200, response.text
    data = response.json()
    assert data["units"] == "degrees"
    assert data["height"] == 1.5
    assert data["features"], "the two lines should have been projected"
    point = data["features"][0]["points"][0]
    assert 0.0 <= point["az"] <= 360.0 and -90.0 <= point["el"] <= 90.0
    assert point["r"] > 0


def test_the_height_moves_the_drawing_up_the_frame(client, project):
    low = client.get(f"/api/p/{project['slug']}/s/A/drawings?height=0").json()["features"][0]["points"][0]
    high = client.get(f"/api/p/{project['slug']}/s/A/drawings?height=3").json()["features"][0]["points"][0]
    assert high["el"] > low["el"]


def test_an_absurd_height_is_refused(client, project):
    assert client.get(f"/api/p/{project['slug']}/s/A/drawings?height=5000").status_code == 400


def test_a_scan_that_does_not_exist_is_a_404(client, project):
    assert client.get(f"/api/p/{project['slug']}/s/nope/drawings").status_code == 404

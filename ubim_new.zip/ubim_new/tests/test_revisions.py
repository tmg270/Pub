"""Feature history: every accepted change is a version, and an older one can be restored.

The value of a revision history is that a delete is not final and a wrong edit is undoable a
week later, so the tests cover exactly those two, not just that rows exist.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from tests.samplefiles import scan_path

SCAN = scan_path() or Path("SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")
ADMIN_PASSWORD = "test-password-not-secret"


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    folder = tmp_path / "proj"
    folder.mkdir()
    os.symlink(SCAN, folder / "A.fls")
    response = client.post("/api/projects", json={"path": str(folder), "name": "History"})
    assert response.status_code == 201, response.text
    return response.json()["slug"]


def create(client, slug, **body):
    body.setdefault("kind", "line")
    body.setdefault("points", [{"az": 0, "el": 0, "r": 2.0}, {"az": 5, "el": 0, "r": 3.0}])
    response = client.post(f"/api/p/{slug}/s/A/features", json=body)
    assert response.status_code == 201, response.text
    return response.json()


def history(client, slug, feature_id):
    return client.get(f"/api/p/{slug}/s/A/features/{feature_id}/revisions").json()["revisions"]


def test_creating_records_the_first_version(client, project):
    feature = create(client, project, label="north wall")
    versions = history(client, project, feature["id"])
    assert [entry["version"] for entry in versions] == [1]
    assert versions[0]["action"] == "create" and versions[0]["label"] == "north wall"


def test_an_edit_can_be_rolled_back(client, project):
    feature = create(client, project)
    edited = client.patch(
        f"/api/p/{project}/s/A/features/{feature['id']}",
        json={"points": [{"az": 90, "el": 0, "r": 9.0}]},
    )
    assert edited.status_code == 200
    assert len(history(client, project, feature["id"])) == 2

    restored = client.post(
        f"/api/p/{project}/s/A/features/{feature['id']}/restore", json={"version": 1}
    )
    assert restored.status_code == 200, restored.text
    listed = client.get(f"/api/p/{project}/s/A/features").json()["features"]
    assert len(listed[0]["points"]) == 2
    assert listed[0]["points"][0]["r"] == pytest.approx(2.0)
    assert [entry["action"] for entry in history(client, project, feature["id"])][-1] == "restore:1"


def test_a_delete_is_recoverable(client, project):
    feature = create(client, project)
    assert client.delete(f"/api/p/{project}/s/A/features/{feature['id']}").status_code == 200
    assert client.get(f"/api/p/{project}/s/A/features").json()["features"] == []

    assert client.post(
        f"/api/p/{project}/s/A/features/{feature['id']}/restore", json={"version": 1}
    ).status_code == 200
    listed = client.get(f"/api/p/{project}/s/A/features").json()["features"]
    assert len(listed) == 1 and listed[0]["id"] == feature["id"]


def test_drafts_are_marked(client, project):
    draft = create(client, project, status="draft")
    assert draft["status"] == "draft"
    final = client.patch(f"/api/p/{project}/s/A/features/{draft['id']}", json={"status": "final"})
    assert final.json()["status"] == "final"


def test_a_missing_version_is_a_404(client, project):
    feature = create(client, project)
    response = client.post(f"/api/p/{project}/s/A/features/{feature['id']}/restore", json={"version": 99})
    assert response.status_code == 404

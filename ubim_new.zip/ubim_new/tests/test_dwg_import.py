"""DWG arrives through a converter (spec D2), and says so when there is none.

No DWG reader ships with Python, so the import converts with dwg2dxf/dwgread when one is on PATH.
The converter is stubbed here: a small script that writes a known DXF, which proves the plumbing
(upload -> base64 -> converter -> parse -> shapes) without needing LibreDWG on the test machine.
"""

from __future__ import annotations

import base64
import os
import stat
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"

DXF = """0
SECTION
2
ENTITIES
0
LINE
8
kerbs
62
1
10
0.0
20
0.0
11
2.0
21
1.0
0
ENDSEC
0
EOF
"""


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        response = test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    folder = tmp_path / "survey"
    folder.mkdir()
    os.symlink(SCAN, folder / "A.fls")
    created = client.post("/api/projects", json={"path": str(folder), "name": "Survey"})
    assert created.status_code in (200, 201), created.text
    return created.json()


def _stub_converter(tmp_path, monkeypatch, body: str) -> Path:
    """A dwg2dxf that writes a fixed DXF to the -o target."""
    binary = tmp_path / "bin"
    binary.mkdir(exist_ok=True)
    dxf = tmp_path / "stub.dxf"
    dxf.write_text(body)
    script = binary / "dwg2dxf"
    script.write_text(f"#!/bin/sh\nwhile [ $# -gt 0 ]; do\n  if [ \"$1\" = \"-o\" ]; then cp {dxf} \"$2\"; exit 0; fi\n  shift\ndone\nexit 1\n")
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    monkeypatch.setenv("PATH", f"{binary}{os.pathsep}{os.environ.get('PATH', '')}")
    return script


def _dwg_bytes() -> bytes:
    # A DWG body is irrelevant to the stub; only the AC10 signature matters.
    return b"AC1032" + b"\0" * 128


def test_a_dwg_is_converted_and_imported(client, project, tmp_path, monkeypatch):
    _stub_converter(tmp_path, monkeypatch, DXF)
    response = client.post(
        f"/api/p/{project['slug']}/drawings",
        json={"name": "plan.dwg", "file": base64.b64encode(_dwg_bytes()).decode()},
    )
    assert response.status_code in (200, 201), response.text
    body = response.json()
    assert body["shapes"] == 1
    assert body["name"] == "plan.dwg"
    listed = client.get(f"/api/p/{project['slug']}/drawings").json()["drawings"]
    assert [item["name"] for item in listed] == ["plan.dwg"]
    # The converted text is what the parser sees, so its colour must survive the conversion.
    from ubim import dwg, dxf as dxf_reader

    parsed = dxf_reader.read(dwg.to_dxf(_dwg_bytes()))
    assert len(parsed.shapes) == 1
    assert parsed.shapes[0].colour == "#ff0000"


def test_without_a_converter_the_refusal_names_the_fix(client, project, monkeypatch, tmp_path):
    empty = tmp_path / "no-tools"
    empty.mkdir()
    monkeypatch.setenv("PATH", str(empty))
    client.headers.pop("X-CSRF-Token", None)
    client.headers["X-CSRF-Token"] = client.get("/api/me").json()["csrf"]
    response = client.post(
        f"/api/p/{project['slug']}/drawings",
        json={"name": "plan.dwg", "file": base64.b64encode(_dwg_bytes()).decode()},
    )
    assert response.status_code == 415
    assert "libredwg-tools" in response.json()["detail"]


def test_a_dxf_sent_as_base64_is_read_without_a_converter(client, project, monkeypatch, tmp_path):
    empty = tmp_path / "no-tools"
    empty.mkdir()
    monkeypatch.setenv("PATH", str(empty))
    response = client.post(
        f"/api/p/{project['slug']}/drawings",
        json={"name": "plan.dxf", "file": base64.b64encode(DXF.encode()).decode()},
    )
    assert response.status_code in (200, 201), response.text
    assert response.json()["shapes"] == 1

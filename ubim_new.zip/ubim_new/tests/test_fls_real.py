"""Real-file gate: the numbers in the pack's 01-context.md must come out exactly.

Runs only when UBIM_FLS is set. A set variable pointing at nothing is a failure, not a
skip, because the gate exists to prove the decoder on a real FARO file.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

import pytest

from ubim.formats.fls import FlsFile, GreyStats

REFERENCE = {
    "cells": 43_260_448,
    "zero": 2_499_780,
    "negatives": 0,
    "max": 2_780,
    "above_2047": 534,
    "mean_nonzero": 653.841,
    "sum": 26_650_989_673,
    "percentiles": {"p1": 6, "p50": 201, "p99": 1787},
    "sha256": "a94f3e1e12feec561a09d8a4022ae3201c7a9357d83817590c7c1c32f9d8975c",
}


def fls_path() -> Path:
    raw = os.environ.get("UBIM_FLS") or ("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls" if Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls").exists() else None)
    if not raw:
        pytest.skip("UBIM_FLS not set")
    path = Path(raw)
    if not path.is_file():
        pytest.fail(f"UBIM_FLS is set to a missing file: {path}")
    return path


@pytest.mark.real
def test_grey_stats_match_reference():
    path = fls_path()
    started = time.monotonic()
    stats = GreyStats()
    with FlsFile(path) as scan:
        header = scan.header
        assert (header.rows, header.cols) == (4268, 10136)
        assert header.grey_bits == 11
        for _rect, columns in scan.all_columns("Grey"):
            for _first, block in columns.bands():
                stats.add(block)
    measured = stats.result()
    elapsed = time.monotonic() - started
    print(f"\nGREY STATS in {elapsed:.1f}s: {measured}")

    assert measured["cells"] == REFERENCE["cells"]
    assert measured["zero"] == REFERENCE["zero"]
    assert measured["negatives"] == REFERENCE["negatives"]
    assert measured["max"] == REFERENCE["max"]
    assert measured["above_2047"] == REFERENCE["above_2047"]
    assert measured["sum"] == REFERENCE["sum"]
    assert abs(measured["mean_nonzero"] - REFERENCE["mean_nonzero"]) < 1e-3
    assert measured["percentiles"] == REFERENCE["percentiles"]
    assert measured["sha256"] == REFERENCE["sha256"]

    assert elapsed < 120, "the pack's budget for a full decode"

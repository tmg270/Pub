"""One decode pass feeding both products (spec C2).

The combined build keeps the sampled raw grey image beside the range grid and finishes both
products from it. The claim is not "similar": it must be the same pixels, so this test compares
it against the separate builds on the reference scan.
"""

from __future__ import annotations

from pathlib import Path

import pytest

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")


@pytest.fixture(scope="module")
def built(tmp_path_factory):
    from ubim.products import build as intensity_build
    from ubim.products import depth as depth_product
    from ubim.products import dual

    root = tmp_path_factory.mktemp("dual")
    combined = root / "combined"
    separate = root / "separate"
    dual.build(SCAN, combined)
    depth_product.build(separate, SCAN)
    intensity_build.build(separate, SCAN)
    return combined, separate


def test_the_range_grid_is_identical(built):
    combined, separate = built
    assert (combined / "depth.grid").read_bytes() == (separate / "depth.grid").read_bytes()


def test_the_depth_manifest_matches(built):
    import json

    combined, separate = built
    a = json.loads((combined / "depth.json").read_text())
    b = json.loads((separate / "depth.json").read_text())
    timings = {"builtAt", "seconds", "secondsRender", "secondsDecode"}
    assert {k: v for k, v in a.items() if k not in timings} == {k: v for k, v in b.items() if k not in timings}


def test_the_intensity_tiles_are_identical(built):
    combined, separate = built
    left = {p.relative_to(separate): p.read_bytes() for p in (separate / "intensity").rglob("*.png")}
    right = {p.relative_to(combined): p.read_bytes() for p in (combined / "intensity").rglob("*.png")}
    assert left and left == right

"""Where the reference scan lives, for the few tests that need real bytes.

The suite is useful without any sample: those tests skip with a reason. When a sample is
present it is looked for in the places it is normally kept — an explicit ``UBIM_FLS``, the
repository root, the folder above it, and the original Java project's folder — so a checkout
that ships one scan works wherever it is unpacked.
"""

from __future__ import annotations

import os
from pathlib import Path

CANDIDATES = ("SCAN_085.fls", "samples/SCAN_085.fls")


#: A real scan is hundreds of megabytes; anything smaller is a placeholder or a dead link.
MIN_BYTES = 1 << 20


def _usable(path: Path) -> bool:
    """Whether a path is a scan rather than a stub: it exists and is large enough to decode."""
    try:
        return path.is_file() and path.stat().st_size >= MIN_BYTES
    except OSError:
        return False


def scan_path() -> Path | None:
    """The first existing reference scan, or None when the suite has none."""
    explicit = os.environ.get("UBIM_FLS")
    if explicit:
        path = Path(explicit).expanduser()
        if _usable(path):
            return path
    here = Path(__file__).resolve().parent
    roots = (here.parent, here.parent.parent, here.parent / "samples")
    for root in roots:
        for name in CANDIDATES:
            path = root / name
            if _usable(path):
                return path
    legacy = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
    return legacy if _usable(legacy) else None

"""Preferences, project placement and the map tiles.

The tile route is checked through its cache and its offline path, not through the network:
a cached tile must be served without a request, and a failed fetch must be a blank tile
rather than an error the page has to handle.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from tests.samplefiles import scan_path

SCAN = scan_path() or Path("SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        response = test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    folder = tmp_path / "placed"
    folder.mkdir()
    os.symlink(SCAN, folder / "A.fls")
    response = client.post("/api/projects", json={"path": str(folder), "name": "Placed site"})
    assert response.status_code in (200, 201), response.text
    return response.json()


def test_view_preference_defaults_to_list_and_remembers_map(client):
    assert client.get("/api/settings").json()["view"] == "list"
    assert client.put("/api/settings", json={"view": "map"}).status_code == 200
    assert client.get("/api/settings").json()["view"] == "map"
    assert client.put("/api/settings", json={"view": "list"}).status_code == 200
    assert client.get("/api/settings").json()["view"] == "list"


def test_view_preference_rejects_unknown_value(client):
    response = client.put("/api/settings", json={"view": "globe"})
    assert response.status_code == 400
    assert "list" in response.json()["detail"]


def test_a_position_always_says_where_it_came_from(client, project):
    """A scan with a GPS fix places its project on import; the label is the honest part."""
    slug = project["slug"]
    listed = client.get("/api/locations").json()["projects"]
    found = next(entry for entry in listed if entry["slug"] == slug)
    assert found["placed"] is True
    assert found["lat"] == pytest.approx(53.2345, abs=1e-6)
    assert found["source"] == "scan GPS (A)"


def test_location_can_be_declared_and_cleared(client, project):
    slug = project["slug"]
    saved = client.put(f"/api/p/{slug}/location", json={"lat": 51.4779, "lon": -0.0015}).json()
    assert saved["placed"] is True
    assert saved["lat"] == pytest.approx(51.4779)
    listed = client.get("/api/locations").json()["projects"]
    assert next(entry for entry in listed if entry["slug"] == slug)["placed"] is True
    assert client.get(f"/api/p/{slug}/location").json()["lat"] == pytest.approx(51.4779)

    cleared = client.put(f"/api/p/{slug}/location", json={}).json()
    assert cleared["placed"] is False
    assert client.get(f"/api/p/{slug}/location").json()["lat"] is None


def test_location_rejects_impossible_coordinates(client, project):
    slug = project["slug"]
    assert client.put(f"/api/p/{slug}/location", json={"lat": 91, "lon": 0}).status_code == 400
    assert client.put(f"/api/p/{slug}/location", json={"lat": 0, "lon": 181}).status_code == 400
    assert client.put(f"/api/p/{slug}/location", json={"lat": "north", "lon": 0}).status_code == 400


def test_tile_comes_from_the_cache_without_network(client):
    data = Path(os.environ["UBIM_DATA_DIR"]) / "cache" / "tiles" / "2" / "1"
    data.mkdir(parents=True)
    (data / "1.png").write_bytes(b"\x89PNG\r\n\x1a\ncached")
    response = client.get("/api/tiles/2/1/1.png")
    assert response.status_code == 200
    assert response.headers["X-Tile-Cache"] == "hit"
    assert response.content.endswith(b"cached")


def test_tile_outside_the_zoom_level_is_refused(client):
    assert client.get("/api/tiles/1/2/0.png").status_code == 400
    assert client.get("/api/tiles/20/0/0.png").status_code == 400


def test_tile_falls_back_to_a_blank_png_when_the_fetch_fails(client, monkeypatch):
    def refuse(*args, **kwargs):
        raise OSError("no network")

    monkeypatch.setattr("ubim.api_settings.urllib.request.urlopen", refuse)
    response = client.get("/api/tiles/0/0/0.png")
    assert response.status_code == 200
    assert response.headers["X-Tile-Cache"] == "offline"
    assert response.headers["content-type"] == "image/png"
    assert response.content.startswith(b"\x89PNG")

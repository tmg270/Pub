"""A project can say which coordinate reference system its numbers are in.

Neither FARO format states one, so this is a declaration: it is stored, shown, and repeated in
the drawing export as a comment. Nothing reprojects because of it.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        response = test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    folder = tmp_path / "surveyed"
    folder.mkdir()
    (folder / "A.fls").symlink_to(SCAN)
    created = client.post("/api/projects", json={"path": str(folder), "name": "Surveyed"})
    assert created.status_code in (200, 201), created.text
    return created.json()


def test_a_project_starts_with_no_declared_crs(client, project):
    data = client.get(f"/api/p/{project['slug']}").json()
    assert data["crs"] is None


def test_importing_a_folder_adopts_the_fix_it_holds(client, project):
    """SCAN_085 recorded its own position, so the project should know where it is."""
    location = client.get(f"/api/p/{project['slug']}").json()["location"]
    assert location["placed"] is True
    assert location["source"] == "scan GPS (A)"
    assert round(location["lat"], 1) == 53.2
    assert round(location["lon"], 1) == -1.4


def test_a_declared_crs_is_stored_and_normalised(client, project):
    saved = client.put(f"/api/p/{project['slug']}/crs", json={"crs": "epsg:27700"})
    assert saved.status_code == 200 and saved.json()["crs"] == "EPSG:27700"
    assert client.get(f"/api/p/{project['slug']}").json()["crs"] == "EPSG:27700"


def test_a_local_grid_name_is_kept_as_written(client, project):
    saved = client.put(f"/api/p/{project['slug']}/crs", json={"crs": "Site grid A"})
    assert saved.json()["crs"] == "Site grid A"


def test_a_bad_epsg_code_is_refused_and_an_empty_one_clears(client, project):
    bad = client.put(f"/api/p/{project['slug']}/crs", json={"crs": "EPSG:abc"})
    assert bad.status_code == 400
    client.put(f"/api/p/{project['slug']}/crs", json={"crs": "EPSG:27700"})
    cleared = client.put(f"/api/p/{project['slug']}/crs", json={"crs": ""})
    assert cleared.json()["crs"] is None
    assert client.get(f"/api/p/{project['slug']}").json()["crs"] is None


def test_the_export_repeats_the_declaration_as_a_comment(client, project):
    client.put(f"/api/p/{project['slug']}/crs", json={"crs": "EPSG:27700"})
    text = client.get(f"/api/p/{project['slug']}/s/A/export.dxf").text
    assert "CRS (declared, not applied): EPSG:27700" in text

"""Interpolation of the thin gaps a scanner's beam pattern leaves in a product.

These are the slivers that made a surface look scratched: a cell with no return came out
dark, and at the resolution of the product it ran for hundreds of rows. The filling must be
narrow — a real hole or a real edge has to survive it.
"""

from __future__ import annotations

import numpy as np

from ubim.products.intensity import fill_slivers, suppress_column_lines


def test_a_one_cell_gap_is_filled_from_its_neighbours():
    image = np.full((12, 12), 120, dtype=np.uint8)
    image[:, 5] = 0
    filled = fill_slivers(image, passes=2)
    assert filled[6, 5] > 0
    assert np.count_nonzero(filled) > np.count_nonzero(image)


def test_a_wide_empty_region_is_left_alone():
    image = np.full((12, 12), 120, dtype=np.uint8)
    image[:, 4:9] = 0
    filled = fill_slivers(image, passes=2)
    assert filled[6, 6] == 0
    assert filled[6, 4] > 0 or filled[6, 8] > 0


def test_a_dark_line_between_bright_neighbours_is_removed():
    image = np.full((20, 20), 160, dtype=np.uint8)
    image[:, 9] = 20
    cleaned = suppress_column_lines(image)
    assert cleaned[10, 9] == 160
    assert cleaned[10, 0] == 160


def test_a_real_step_in_the_surface_survives():
    image = np.full((20, 20), 30, dtype=np.uint8)
    image[:, 10:] = 200
    cleaned = suppress_column_lines(image)
    assert cleaned[10, 9] == 30
    assert cleaned[10, 10] == 200


def test_a_dark_region_that_is_dark_across_its_width_is_not_brightened():
    image = np.full((20, 20), 200, dtype=np.uint8)
    image[:, :6] = 12
    cleaned = suppress_column_lines(image, floor=20)
    assert cleaned[10, 2] == 12

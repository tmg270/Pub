"""Downsampling must keep the source's range, not clip to one byte.

A raw depth grid is stored in hundred-thousandths of a metre, so a 5 m wall is 500000. Clipping
the averaged grid to 255 made every level below the first black, which is what "the depth view
is blank" turned out to be.
"""

from __future__ import annotations

import numpy as np

from ubim.products.pyramid import _halve


def test_halving_a_raw_grid_keeps_its_values():
    grid = np.full((4, 4), 500000, dtype=np.uint32)
    halved = _halve(grid)
    assert halved.dtype == np.uint32
    assert halved.shape == (2, 2)
    assert int(halved.max()) == 500000


def test_halving_an_eight_bit_grid_still_works():
    grid = np.arange(16, dtype=np.uint8).reshape(4, 4)
    halved = _halve(grid)
    assert halved.dtype == np.uint8
    assert int(halved[0, 0]) == 2  # mean of 0, 1, 4, 5


def test_halving_a_sixteen_bit_grid_keeps_its_range():
    grid = np.full((2, 2), 40000, dtype=np.uint16)
    assert int(_halve(grid).max()) == 40000

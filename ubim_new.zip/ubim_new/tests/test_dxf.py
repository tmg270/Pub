"""Reading DXF: entities, units, flat drawings and the shapes that must be refused."""

from __future__ import annotations

import pytest

from ubim import dxf


def group(*pairs: tuple[int, str]) -> str:
    return "\n".join(f"{code}\n{value}" for code, value in pairs)


def drawing(body: str, units: int | None = None) -> str:
    parts = [group((0, "SECTION"), (2, "HEADER"), (9, "$INSUNITS"))]
    if units is not None:
        parts.append(group((70, str(units))))
    parts += [group((0, "ENDSEC"), (0, "SECTION"), (2, "ENTITIES")), body, group((0, "ENDSEC"), (0, "EOF"))]
    return "\n".join(parts)


LWPOLYLINE = group(
    (0, "LWPOLYLINE"), (8, "0"), (90, "4"), (70, "1"),
    (10, "0"), (20, "0"), (10, "10"), (20, "0"), (10, "10"), (20, "5"), (10, "0"), (20, "5"),
)
LINE = group((0, "LINE"), (10, "1"), (20, "2"), (30, "3"), (11, "4"), (21, "5"), (31, "6"))
TEXT = group((0, "TEXT"), (10, "2"), (20, "2"), (1, "MH-01"))
POLYLINE = group(
    (0, "POLYLINE"), (70, "1"),
    (0, "VERTEX"), (10, "0"), (20, "0"),
    (0, "VERTEX"), (10, "5"), (20, "5"),
    (0, "SEQEND"),
)


def test_reads_lines_polylines_and_labels():
    result = dxf.read(drawing(LWPOLYLINE + "\n" + LINE + "\n" + TEXT))
    kinds = [shape.kind for shape in result.shapes]
    assert kinds.count("polyline") == 1 and "line" in kinds
    assert any(shape.label == "MH-01" for shape in result.shapes)
    closed = next(shape for shape in result.shapes if shape.kind == "polyline")
    assert closed.points[0] == closed.points[-1]
    assert result.closed == 1


def test_polyline_with_vertex_records_is_one_shape():
    result = dxf.read(drawing(POLYLINE))
    polylines = [shape for shape in result.shapes if shape.kind == "polyline"]
    assert len(polylines) == 1 and len(polylines[0].points) == 2
    assert result.skipped == 0


def test_millimetres_are_converted_to_metres():
    result = dxf.read(drawing(LINE, units=4))
    assert result.unit_code == 4
    assert result.units == pytest.approx(0.001)
    assert result.shapes[0].points[0] == pytest.approx((0.001, 0.002, 0.003))


def test_a_flat_drawing_is_reported_flat():
    flat = dxf.read(drawing(LWPOLYLINE))
    assert flat.flat is True
    raised = dxf.read(drawing(LINE))
    assert raised.flat is False


def test_unknown_entities_are_counted_not_guessed():
    body = group((0, "SPLINE"), (10, "0"), (20, "0"))
    result = dxf.read(drawing(body))
    assert result.shapes == []
    assert result.skipped == 1


def test_extent_and_empty_input():
    assert dxf.extent(dxf.read(drawing(LWPOLYLINE)))["maxX"] == pytest.approx(10.0)
    empty = dxf.read("")
    assert empty.shapes == [] and dxf.extent(empty) is None

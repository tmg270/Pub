"""Web-level tests: the gate, sessions, CSRF, roles and the measurement routes.

These run against the real scan when it is on this machine and skip the scan-dependent parts
when it is not, so the suite is useful both here and in a bare checkout.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
IMAGE = Path("/mnt/datadump/dsh_projects/ubim/04af88b2-b98c-4bac-91d4-053aa8f3a00e_grey_hd.jpg")
needs_scan = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"


@pytest.fixture()
def app(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    return create_from_env()


@pytest.fixture()
def client(app):
    with TestClient(app) as test_client:
        yield test_client


def sign_in(client, name="admin", password=ADMIN_PASSWORD) -> str:
    response = client.post("/login", data={"name": name, "password": password}, follow_redirects=False)
    assert response.status_code == 303, response.text
    assert "ubim_sid" in client.cookies
    return client.get("/api/me").json()["csrf"]


@pytest.fixture()
def admin(client):
    return sign_in(client)


@pytest.fixture()
def project(client, admin):
    if not SCAN.exists():
        pytest.skip("reference scan not present")
    response = client.post(
        "/api/projects",
        json={"path": str(SCAN.parent), "name": "Reference"},
        headers={"X-CSRF-Token": admin},
    )
    assert response.status_code == 201, response.text
    return response.json()


# -- identity -------------------------------------------------------------

def test_anonymous_is_redirected_to_login(client):
    response = client.get("/", follow_redirects=False)
    assert response.status_code == 303
    assert response.headers["location"] == "/login"
    assert client.get("/api/me").json() == {"authenticated": False}


def test_anonymous_api_is_rejected(client):
    assert client.get("/api/projects").status_code == 401


def test_wrong_password_is_rejected(client):
    response = client.post("/login", data={"name": "admin", "password": "nope"}, follow_redirects=False)
    assert response.status_code == 303
    assert response.headers["location"] == "/login?failed=1"
    assert client.get("/api/me").json() == {"authenticated": False}


def test_sign_in_sets_a_hardened_cookie(app):
    with TestClient(app) as fresh:
        response = fresh.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        joined = "; ".join(response.headers.get_list("set-cookie"))
        assert response.status_code == 303
        assert "ubim_sid=" in joined
        assert "HttpOnly" in joined
        assert "SameSite=lax" in joined


def test_each_login_gets_a_new_session(app):
    with TestClient(app) as fresh:
        first = fresh.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        first_id = fresh.cookies.get("ubim_sid")
        second = fresh.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        second_id = fresh.cookies.get("ubim_sid")
        assert first_id and second_id and first_id != second_id


# -- csrf -----------------------------------------------------------------

def test_unsafe_request_without_csrf_is_refused(client, admin):
    assert client.post("/api/projects", json={"path": "/tmp"}).status_code == 403


def test_unsafe_request_with_wrong_csrf_is_refused(client, admin):
    response = client.post("/api/projects", json={"path": "/tmp"}, headers={"X-CSRF-Token": "bogus"})
    assert response.status_code == 403


def test_csrf_does_not_gate_get(client, admin):
    assert client.get("/api/projects").status_code == 200


# -- gate -----------------------------------------------------------------

def test_gate_hides_everything_outside_the_allow_list(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "gated"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    from ipaddress import ip_network

    from ubim.app import create_from_env

    app = create_from_env()
    app.state.config.allow_networks = [ip_network("10.0.0.0/8")]
    with TestClient(app) as gated:
        body = gated.get("/").text
        assert gated.get("/").status_code == 404
        assert gated.get("/api/projects").status_code == 404
        assert gated.get("/static/app.css").status_code == 404
        # one answer for everything: an outsider cannot tell a real path from a fake one
        assert gated.get("/nope").text == body


def test_allowed_network_gets_in(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "open"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    from ubim.app import create_from_env

    app = create_from_env()
    app.state.config.allow_networks = []
    with TestClient(app) as open_client:
        assert open_client.get("/", follow_redirects=False).status_code == 303


def test_gate_membership_rules():
    from ipaddress import ip_network

    from ubim.config import Config

    config = Config(data_dir=Path("/tmp/x"), secret=b"s", allow_networks=[ip_network("10.0.0.0/8")])
    assert config.allows("10.4.5.6") is True
    assert config.allows("192.168.1.1") is False
    assert config.allows("::1") is False
    assert config.allows("not-an-ip") is False
    assert config.allows(None) is False
    assert Config(data_dir=Path("/tmp/x"), secret=b"s").allows("anything") is True


def test_security_headers(client):
    response = client.get("/login")
    policy = response.headers["content-security-policy"]
    assert "script-src 'self'" in policy
    assert "unsafe-inline" not in policy.split("script-src")[1].split(";")[0]
    assert response.headers["x-content-type-options"] == "nosniff"


# -- roles ----------------------------------------------------------------

def test_viewer_cannot_write(client, admin):
    client.post("/api/admin/invites", json={"role": "viewer", "hours": 1}, headers={"X-CSRF-Token": admin})
    code = client.get("/api/admin/invites").json()["invites"][0]["code"]
    client.post("/invite", data={"code": code, "name": "watcher", "password": "watcher-password"})
    client.post("/logout", headers={"X-CSRF-Token": admin})
    csrf = sign_in(client, "watcher", "watcher-password")
    assert client.get("/api/projects").status_code == 200
    assert client.post("/api/projects", json={"path": "/tmp"}, headers={"X-CSRF-Token": csrf}).status_code == 403


def test_admin_routes_are_admin_only(client, admin):
    client.post("/api/admin/invites", json={"role": "editor", "hours": 1}, headers={"X-CSRF-Token": admin})
    code = client.get("/api/admin/invites").json()["invites"][0]["code"]
    client.post("/invite", data={"code": code, "name": "builder", "password": "builder-password"})
    client.post("/logout", headers={"X-CSRF-Token": admin})
    sign_in(client, "builder", "builder-password")
    assert client.get("/api/projects").status_code == 200
    assert client.get("/api/admin/users").status_code == 403
    assert client.get("/api/admin/audit").status_code == 403


# -- scan routes and 404 parity -------------------------------------------

def test_unknown_project_and_scan_are_404(client, admin):
    assert client.get("/api/p/nope").status_code == 404
    assert client.get("/api/p/nope/s/x/meta").status_code == 404
    assert client.get("/p/nope").status_code == 404


@needs_scan
def test_scan_meta_reports_geometry(client, admin, project):
    response = client.get(f"/api/p/{project['slug']}/s/SCAN_085/meta")
    assert response.status_code == 200
    meta = response.json()
    assert meta["geometry"]["cols"] == 10136
    assert meta["geometry"]["rows"] == 4268
    assert meta["geometry"]["hasAzimuthTable"] is True
    assert meta["mapping"]["az0Deg"] == -0.07


@needs_scan
def test_project_page_lists_scans(client, admin, project):
    page = client.get(f"/p/{project['slug']}")
    assert page.status_code == 200
    assert "project.js" in page.text
    assert f'data-slug="{project["slug"]}"' in page.text
    scan_page = client.get(f"/p/{project['slug']}/SCAN_085")
    assert scan_page.status_code == 200
    assert "viewer.js" in scan_page.text
    assert '"project":' in scan_page.text


@needs_scan
def test_traversal_style_names_are_404(client, admin, project):
    for name in ("..", "../..", "%2e%2e", "SCAN_085.fls", "SCAN_085/"):
        assert client.get(f"/api/p/{project['slug']}/s/{name}/meta").status_code == 404


# -- measurements ---------------------------------------------------------

@needs_scan
def test_measurement_round_trip(client, admin, project):
    base = f"/api/p/{project['slug']}/s/SCAN_085"
    headers = {"X-CSRF-Token": admin}
    created = client.post(
        f"{base}/features",
        json={"kind": "line", "points": [{"az": 0.1, "el": -0.2, "r": 100.0}, {"az": 0.2, "el": -0.25, "r": 200.0}]},
        headers=headers,
    )
    assert created.status_code == 201
    feature = created.json()
    listed = client.get(f"{base}/features").json()
    assert [entry["id"] for entry in listed["features"]] == [feature["id"]]
    assert listed["layers"][0]["name"] == "Measurements"

    dxf = client.get(f"{base}/export.dxf")
    assert dxf.status_code == 200
    assert "POLYLINE" in dxf.text and "VERTEX" in dxf.text
    exported = client.get(f"{base}/export.json").json()
    assert exported["features"][0]["points"][0]["r"] == 100.0

    assert client.post(f"{base}/undo", json={}, headers=headers).json()["reverted"] == 1
    assert client.get(f"{base}/features").json()["features"] == []


@needs_scan
def test_measurement_needs_points_and_csrf(client, admin, project):
    base = f"/api/p/{project['slug']}/s/SCAN_085"
    assert client.post(f"{base}/features", json={"kind": "point", "points": []},
                       headers={"X-CSRF-Token": admin}).status_code == 400
    assert client.post(f"{base}/features", json={"kind": "point", "points": [{"az": 0, "el": 0}]}).status_code == 403
    assert client.post(f"{base}/features", json={"kind": "spiral", "points": [{"az": 0, "el": 0}]},
                       headers={"X-CSRF-Token": admin}).status_code == 400


@needs_scan
def test_imagery_is_served(client, admin, project):
    base = f"/api/p/{project['slug']}/s/SCAN_085"
    thumb = client.get(f"{base}/thumb?size=256")
    assert thumb.status_code == 200 and thumb.headers["content-type"] == "image/jpeg"
    pano = client.get(f"{base}/pano/grey_hd?max_size=1024")
    assert pano.status_code == 200
    assert client.get(f"{base}/pano/grey_hd?max_size=10").status_code == 200  # clamped, not rejected


# -- admin ----------------------------------------------------------------

def test_admin_tabs_have_data(client, admin):
    assert client.get("/api/admin/users").json()["users"][0]["name"] == "admin"
    assert client.get("/api/admin/invites").status_code == 200
    assert client.get("/api/admin/shares").status_code == 200
    audit = client.get("/api/admin/audit").json()
    assert audit["total"] >= 1
    system = client.get("/api/admin/system").json()
    assert system["projects"] >= 0 and "disk" in system


def test_admin_page_renders(client, admin):
    page = client.get("/admin")
    assert page.status_code == 200
    assert "admin.js" in page.text
    assert "Content-Security-Policy" in page.headers

"""Geometry for measurements, checked against shapes whose answer is known by hand."""

import math

from ubim import measure


def pick(x: float, y: float, z: float) -> dict:
    """A stored point that lands on (x, y, z) in metres."""
    radius = math.sqrt(x * x + y * y + z * z)
    if radius == 0.0:
        return {"az": 0.0, "el": 0.0, "r": 0.0}
    return {
        "az": math.degrees(math.atan2(y, x)),
        "el": math.degrees(math.asin(z / radius)),
        "r": radius,
    }


def test_unit_square_has_known_area_and_perimeter():
    square = [pick(5, 5, 0), pick(-5, 5, 0), pick(-5, -5, 0), pick(5, -5, 0)]
    result = measure.metrics({"kind": "area", "points": square})
    assert result["complete"] is True
    assert round(result["area"], 3) == 100.0
    assert round(result["perimeter"], 3) == 40.0
    assert result["plane"]["rmsMetres"] < 0.001
    assert result["plane"]["inclinationDeg"] < 0.01
    assert round(result["centroid"]["z"], 3) == 0.0


def test_line_length_and_drop():
    line = [pick(0, 0, 0), pick(10, 0, 0)]
    result = measure.metrics({"kind": "line", "points": line})
    assert round(result["length"], 3) == 10.0
    assert round(result["distance"], 3) == 10.0
    sloped = [pick(0, 0, 0), pick(6, 8, 3)]
    sloped_result = measure.metrics({"kind": "line", "points": sloped})
    assert round(sloped_result["length"], 3) == 10.44  # 6-8-3 vector
    assert round(sloped_result["verticalDrop"], 3) == 3.0


def test_a_direction_only_point_reports_no_lengths():
    result = measure.metrics({"kind": "line", "points": [pick(0, 0, 0), {"az": 10.0, "el": 5.0, "r": None}]})
    assert result["complete"] is False
    assert "length" not in result
    assert "note" in result


def test_single_point_reports_ground_height():
    result = measure.metrics({"kind": "point", "points": [pick(3, 4, 1.5)]})
    assert result["pointCount"] == 1
    assert round(result["groundHeight"], 3) == 1.5
    assert round(result["centroid"]["x"], 3) == 3.0


def test_long_span_is_flagged():
    result = measure.metrics({"kind": "line", "points": [pick(0, 0, 0), pick(25, 0, 0)]})
    assert "warning" in result


def test_tilted_plane_reports_inclination():
    flat = [pick(0, 0, 0), pick(4, 0, 0), pick(4, 4, 4), pick(0, 4, 4)]
    result = measure.metrics({"kind": "area", "points": flat})
    # A 45 degree plane through those points; the area is the true planar area, not the
    # projection, so it is larger than the 4 m x 4 m footprint would suggest.
    assert 22.0 < result["area"] < 23.5
    assert 40.0 < result["plane"]["inclinationDeg"] < 50.0


def test_one_metre_squares_in_every_plane_area_to_one():
    """Spec M1: a 1 m x 1 m square in XY, in XZ and tilted must each read 1.000 m²."""
    xy = [pick(0, 0, 0), pick(1, 0, 0), pick(1, 1, 0), pick(0, 1, 0)]
    assert round(measure.metrics({"kind": "area", "points": xy})["area"], 3) == 1.0
    xz = [pick(0, 0, 0), pick(1, 0, 0), pick(1, 0, 1), pick(0, 0, 1)]
    assert round(measure.metrics({"kind": "area", "points": xz})["area"], 3) == 1.0
    tilted = [pick(0, 0, 0), pick(1, 0, 0), pick(1, 0.7071, 0.7071), pick(0, 0.7071, 0.7071)]
    assert round(measure.metrics({"kind": "area", "points": tilted})["area"], 3) == 1.0


def test_slope_reports_plan_distance_and_signed_height():
    rising = [pick(0, 0, 0), pick(3, 4, 2)]
    result = measure.metrics({"kind": "line", "points": rising})
    assert round(result["plan"], 3) == 5.0
    assert round(result["verticalSigned"], 3) == 2.0
    falling = measure.metrics({"kind": "line", "points": [pick(0, 0, 5), pick(0, 0, 1)]})
    assert round(falling["verticalSigned"], 3) == -4.0

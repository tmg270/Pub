"""The CSV export: one row per vertex, with the metres those angles imply.

A spreadsheet cannot read a DXF, and a site survey usually ends up in one, so the same marks
have to be available as rows. The angles are the measured ones and the metres follow the
scan's own frame, which the header names rather than implying.
"""

from __future__ import annotations

import csv


def data_only(text: str) -> str:
    """The export starts with a comment line carrying the accuracy caveat; skip it."""
    return "\n".join(line for line in text.splitlines() if not line.startswith("#"))
import io
import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        response = test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    folder = tmp_path / "survey"
    folder.mkdir()
    os.symlink(SCAN, folder / "A.fls")
    created = client.post("/api/projects", json={"path": str(folder), "name": "Survey"})
    assert created.status_code in (200, 201), created.text
    return created.json()


def _line(client, project, label):
    made = client.post(
        f"/api/p/{project['slug']}/s/A/features",
        json={"kind": "line", "label": label, "points": [
            {"az": 10.0, "el": 2.0, "r": 8.0},
            {"az": 14.0, "el": 2.5, "r": 9.0},
        ]},
    )
    assert made.status_code in (200, 201), made.text


def test_the_export_has_a_row_for_every_vertex(client, project):
    _line(client, project, "kerb")
    response = client.get(f"/api/p/{project['slug']}/s/A/export.csv")
    assert response.status_code == 200, response.text
    assert response.headers["content-type"].startswith("text/csv")
    assert "attachment" in response.headers["content-disposition"]
    rows = list(csv.DictReader(io.StringIO(data_only(response.text))))
    assert len(rows) == 2
    assert {row["label"] for row in rows} == {"kerb"}
    assert [row["point_index"] for row in rows] == ["1", "2"]


def test_the_angles_are_the_measured_ones(client, project):
    _line(client, project, "kerb")
    rows = list(csv.DictReader(io.StringIO(data_only(client.get(f"/api/p/{project['slug']}/s/A/export.csv").text))))
    assert float(rows[0]["az_deg"]) == pytest.approx(10.0)
    assert float(rows[0]["r_m"]) == pytest.approx(8.0)
    # X forward, Y left: azimuth ten degrees puts the point slightly left of forward.
    assert float(rows[0]["y_m"]) > 0
    assert float(rows[0]["x_m"]) > float(rows[0]["y_m"])


def test_the_metrics_repeat_on_each_row(client, project):
    _line(client, project, "kerb")
    rows = list(csv.DictReader(io.StringIO(data_only(client.get(f"/api/p/{project['slug']}/s/A/export.csv").text))))
    assert rows[0]["length_m"] == rows[1]["length_m"]
    assert float(rows[0]["length_m"]) > 1.0
    assert rows[0]["scan"] == "A"


def test_an_empty_scan_still_has_a_header(client, project):
    text = client.get(f"/api/p/{project['slug']}/s/A/export.csv").text
    header = data_only(text).splitlines()[0]
    assert header.startswith("scan,feature_id,kind,layer,label,status,point_index")
    assert "inclination_deg" in header

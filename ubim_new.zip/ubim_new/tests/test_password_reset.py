"""Resetting a password from the command line, and what a failed sign-in says.

The first-run password lives in ``initial-admin.txt``. When that file and the database disagree
— a reused volume, or a file copied from another instance — the way out is
``python -m ubim --set-password``, and the login log has to say which part was wrong rather
than leaving "it does not work".
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from ubim.app import create_app, seed
from ubim.auth import authenticate, set_password
from ubim.config import Config
from ubim.store import Store


@pytest.fixture()
def app_and_store(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path))
    config = Config(data_dir=tmp_path, secret=b"s" * 32)
    store = Store(config.db_path)
    store.init()
    seed(store, config)
    return create_app(config, store), store, tmp_path


def test_set_password_replaces_the_hash_and_ends_sessions(app_and_store):
    _, store, data = app_and_store
    original = re.search(r"password: (.+)", (data / "initial-admin.txt").read_text()).group(1)
    assert authenticate(store, "admin", original)
    set_password(store, "admin", "a-different-one")
    assert authenticate(store, "admin", "a-different-one")
    assert authenticate(store, "admin", original) is None
    assert store.query("SELECT id FROM sessions") == []


def test_set_password_refuses_an_unknown_name(app_and_store):
    _, store, _ = app_and_store
    with pytest.raises(ValueError, match="no user named"):
        set_password(store, "nobody", "whatever-1")


def test_the_log_says_why_a_sign_in_failed(app_and_store, caplog):
    app, _, _ = app_and_store
    client = TestClient(app)
    with caplog.at_level("WARNING"):
        client.post("/login", data={"name": "admin", "password": "wrong"}, follow_redirects=False)
    assert "wrong password" in caplog.text
    with caplog.at_level("WARNING"):
        client.post("/login", data={"name": "ghost", "password": "wrong"}, follow_redirects=False)
    assert "no such user" in caplog.text


def test_the_command_line_resets_the_password(app_and_store, monkeypatch, capsys):
    app, store, data = app_and_store
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", "from-the-environment")
    from ubim.__main__ import _set_password

    assert _set_password("admin", None) == 0
    assert authenticate(store, "admin", "from-the-environment")
    assert "password updated" in capsys.readouterr().out

"""Unit tests for the pieces that do not need a scan file: auth, storage, pyramids, depth, DXF.

Everything here is synthetic, so these run on any machine with the venv installed.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from ubim import auth
from ubim.config import Config
from ubim.products import depth, pyramid
from ubim.projects import _image_role, _scan_name, slugify


# -- passwords and sessions ----------------------------------------------

def test_password_hash_round_trip():
    stored = auth.hash_password("correct horse battery")
    assert stored.startswith("scrypt$")
    assert auth.verify_password(stored, "correct horse battery") is True
    assert auth.verify_password(stored, "wrong") is False


def test_password_hash_is_salted():
    assert auth.hash_password("same") != auth.hash_password("same")


def test_verify_survives_rubbish():
    assert auth.verify_password("not-a-hash", "x") is False
    assert auth.verify_password("", "x") is False


def test_roles_have_distinct_capabilities():
    assert auth.can("admin", "manage_users")
    assert auth.can("admin", "manage_shares")
    assert not auth.can("editor", "manage_users")
    assert auth.can("editor", "measure")
    assert auth.can("editor", "edit_layers")
    assert auth.can("viewer", "measure")
    assert not auth.can("viewer", "edit_layers")
    assert not auth.can("viewer", "manage_projects")
    assert auth.can("viewer", "view")
    assert not auth.can("nobody", "view")
    assert not auth.can(None, "view")


# -- storage --------------------------------------------------------------

def make_config(tmp_path):
    return Config(data_dir=tmp_path / "data", secret=b"0123456789abcdef" * 2)


def make_store(tmp_path):
    from ubim.store import Store

    store = Store(tmp_path / "state.db")
    store.init()
    return store


def test_store_creates_its_schema(tmp_path):
    store = make_store(tmp_path)
    tables = {row["name"] for row in store.query("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"users", "sessions", "projects", "scans", "features", "layers", "audit"} <= tables


def test_audit_rows_are_written(tmp_path):
    store = make_store(tmp_path)
    store.audit("test.event", 7, "subject", "10.0.0.1", 201)
    row = store.one("SELECT * FROM audit ORDER BY id DESC")
    assert row["action"] == "test.event"
    assert row["status"] == 201
    assert "subject" in str(dict(row).values()) or "subject" in str(row["detail"])


# -- project naming -------------------------------------------------------

@pytest.mark.parametrize(
    "raw,expected",
    [("SCAN_085", "scan-085"), ("My Yard 2026", "my-yard-2026"), ("  --Odd--  ", "odd"), ("", "project")],
)
def test_slugify(raw, expected):
    assert slugify(raw) == expected


def test_scan_names_and_image_roles():
    assert _scan_name(Path("x/SCAN_085.fls")) == "SCAN_085"
    assert _scan_name(Path("x/SCAN_085.F3S")) == "SCAN_085"
    scan_ids = {"abc123"}
    assert _image_role("abc123_grey_hd.jpg", scan_ids) == ("abc123", "_grey_hd")
    assert _image_role("abc123.jpg", scan_ids) == ("abc123", "")
    assert _image_role("other.jpg", scan_ids) is None


# -- pyramids -------------------------------------------------------------

def grey_ramp(block):
    return np.repeat(np.clip(block, 0, 255).astype(np.uint8)[:, :, None], 3, axis=2)


def test_pyramid_writes_levels_and_skips_empty_blocks(tmp_path):
    values = np.zeros((1024, 1024), dtype=np.uint8)
    values[0:512, 0:512] = 200          # only the top-left quadrant has data
    values[0:40, 900:920] = 60          # and a thin strip on the top edge
    manifest = pyramid.build(values, tmp_path / "p", {"grey": grey_ramp}, min_level_size=256)

    assert manifest["levels"][0]["width"] == 1024
    assert [t for t in (512, 512, 768)]  # sanity: no crash on odd sizes
    level0 = manifest["levels"][0]
    assert level0["cols"] == 2 and level0["rows"] == 2
    assert pyramid.find_tile(tmp_path / "p", "grey", 0, 0, 0) is not None
    # the bottom-right quadrant is empty, so no file was written for it
    assert pyramid.find_tile(tmp_path / "p", "grey", 0, 1, 1) is None
    # a smaller level exists and is half the size
    smaller = manifest["levels"][-1]
    assert smaller["width"] <= 512
    assert not list((tmp_path / "p").rglob("*.part")), "no partial files left behind"


def test_pyramid_manifest_round_trip(tmp_path):
    values = np.arange(512 * 512, dtype=np.uint16).reshape(512, 512) % 250
    pyramid.build(values, tmp_path / "p", {"grey": grey_ramp})
    stored = pyramid.read_manifest(tmp_path / "p")
    assert stored["ramps"] == ["grey"]
    assert stored["levels"][0]["width"] == 512


def test_pyramid_rejects_wrong_shape(tmp_path):
    with pytest.raises(ValueError):
        pyramid.build(np.zeros((4, 4, 3), dtype=np.uint8), tmp_path / "p", {"grey": grey_ramp})


# -- depth sampling -------------------------------------------------------

def test_depth_sample_reads_the_grid(tmp_path):
    product = tmp_path / "depth"
    product.mkdir()
    width, height = 720, 360
    grid = np.zeros((height, width), dtype=np.uint32)
    # column 359 is azimuth 180, column 719 is the seam either side of azimuth 0
    grid[178:182, 358:363] = 1234567
    grid[178:182, 717:720] = 2500000   # the seam: round() lands on column 0, so fill both sides
    grid[178:182, 0:3] = 2500000
    grid.tofile(product / "depth.grid")
    meta = {
        "product": "depth",
        "width": width,
        "height": height,
        "dtype": "uint32",
        "distFact": 100000.0,
        "maxRaw": 2500000,
    }
    (product / "depth.json").write_text(json.dumps(meta))

    loaded = depth.load_meta(product)
    middle = depth.sample(product, loaded, np.pi, 0.0)
    assert middle is not None
    assert middle["raw"] == 1234567
    assert middle["metres"] == pytest.approx(12.3457, abs=1e-6)  # rounded to 4 places

    seam = depth.sample(product, loaded, 0.0, 0.0)
    assert seam is not None and seam["raw"] == 2500000

    empty = depth.sample(product, loaded, np.pi, np.radians(-80.0))
    assert empty is None or empty["raw"] == 0


def test_depth_meta_absent_is_none(tmp_path):
    assert depth.load_meta(tmp_path / "nothing") is None


# -- dxf ------------------------------------------------------------------

def test_dxf_document_has_closed_structure():
    from ubim.api_measure import dxf_document

    features = [
        {"kind": "point", "layer_id": 1, "points": [{"az": 0.1, "el": -0.1, "r": 5.0}]},
        {"kind": "line", "layer_id": 1, "points": [{"az": 0.0, "el": 0.0, "r": 1.0}, {"az": 0.2, "el": 0.0, "r": 2.0}]},
    ]
    text = dxf_document(features, "SCAN_085")
    # The file opens with 999 comment pairs carrying the accuracy caveat, then the sections.
    body = text
    while body.startswith("999\n"):
        body = body.split("\n", 2)[2]
    assert body.startswith("0\nSECTION"), body[:40]
    assert text.rstrip().endswith("EOF")
    assert "8\nL1" in text
    assert text.count("LINE") >= 1
    assert text.count("POINT") >= 1
    assert "0\nENDSEC" in text


def test_labels_are_stripped_of_markup_and_control_characters():
    from ubim.api_measure import LABEL_MAX, clean_label

    assert clean_label("  a<b>\x01c  ") == "abc"
    assert clean_label("<script>alert(1)</script>") == "scriptalert(1)/script"
    assert clean_label("") is None
    assert clean_label(None) is None
    assert len(clean_label("x" * 400)) == LABEL_MAX

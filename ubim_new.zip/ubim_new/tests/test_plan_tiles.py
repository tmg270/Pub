"""The plan ships several resolutions, and each one is served behind the same gate."""

from __future__ import annotations

import json

import numpy as np
from PIL import Image

from ubim.products import plan as plan_build


def _fake_plan(tmp_path, size=2048):
    product = tmp_path / "scan.fls.ubim"
    product.mkdir()
    shade = np.zeros((size, size), dtype=np.uint8)
    shade[size // 4: size // 2, size // 4: size // 2] = 180
    Image.fromarray(shade, mode="L").convert("RGB").save(product / plan_build.PLAN_NAME, format="PNG")
    Image.fromarray(shade, mode="L").convert("RGB").save(product / plan_build.PLAN_FILLED, format="PNG")
    (product / plan_build.PLAN_META).write_text(json.dumps({"product": "plan", "size": size, "builtAt": 1}))
    return product


def test_a_scaled_plan_is_cached_and_smaller(tmp_path):
    product = _fake_plan(tmp_path)
    path = plan_build.scaled(product, 1024)
    assert path is not None and path.name == "plan-1024.png"
    with Image.open(path) as image:
        assert image.size == (1024, 1024)
    assert plan_build.scaled(product, 1024) == path  # cached, not rebuilt
    filled = plan_build.scaled(product, 1024, filled=True)
    assert filled.name == "plan-filled-1024.png"


def test_a_requested_size_is_clamped_to_the_native_plan(tmp_path):
    product = _fake_plan(tmp_path)
    assert plan_build.scaled(product, 99999).name == plan_build.PLAN_NAME
    with Image.open(plan_build.scaled(product, 100)) as image:
        assert image.size == (256, 256)  # the floor, not a postage stamp


def test_tiles_are_missing_where_the_plan_is_blank(tmp_path):
    product = _fake_plan(tmp_path)
    assert plan_build.tile_path(product, 0, 0, 0) is None
    assert plan_build.tile_path(product, 0, 9, 9) is None


def test_a_plan_without_a_meta_is_not_scaled(tmp_path):
    product = tmp_path / "empty"
    product.mkdir()
    assert plan_build.scaled(product, 1024) is None
    assert plan_build.load(product) is None

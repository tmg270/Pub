"""Registration routes: storing a transform and projecting a measurement between scans.

Two scans are symlinked to the same file, because the routes only need a file to point at;
the geometry under test is the transform, not the decode.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        response = test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    folder = tmp_path / "proj"
    folder.mkdir()
    for name in ("A.fls", "B.fls"):
        os.symlink(SCAN, folder / name)
    response = client.post("/api/projects", json={"path": str(folder), "name": "Two scans"})
    assert response.status_code == 201, response.text
    return response.json()


def pose(client, slug, scan, **body):
    return client.post(f"/api/p/{slug}/s/{scan}/pose", json=body)


def test_pose_is_recorded_and_reported(client, project):
    response = pose(client, project["slug"], "A", x=12.5, y=-3.0, z=0.1, yawDeg=37)
    assert response.status_code == 200, response.text
    assert response.json()["registered"] is True
    assert response.json()["position"] == pytest.approx([12.5, -3.0, 0.1])

    scans = client.get(f"/api/p/{project['slug']}").json()["scans"]
    entry = next(item for item in scans if item["name"] == "A")
    assert entry["registered"] is True
    other = next(item for item in scans if item["name"] == "B")
    assert other["registered"] is False and other["position"] is None


def test_measurement_is_projected_into_a_registered_neighbour(client, project):
    slug = project["slug"]
    assert pose(client, slug, "A", x=0, y=0, z=0, yawDeg=0).status_code == 200
    assert pose(client, slug, "B", x=10, y=0, z=0, yawDeg=90).status_code == 200

    created = client.post(
        f"/api/p/{slug}/s/A/features",
        json={"kind": "point", "points": [{"az": 0.0, "el": 0.0, "r": 4.0}]},
    )
    assert created.status_code in (200, 201), created.text

    seen = client.get(f"/api/p/{slug}/s/B/features").json()["features"]
    assert len(seen) == 1
    feature = seen[0]
    assert feature["from_other_scan"] is True
    assert feature["source_scan"] == "A"
    assert feature["points"][0]["az"] == pytest.approx(90.0, abs=1e-3)
    assert feature["points"][0]["r"] == pytest.approx(6.0, abs=1e-3)


def test_without_both_transforms_the_measurement_stays_in_its_own_scan(client, project):
    slug = project["slug"]
    assert pose(client, slug, "A", x=0, y=0, z=0, yawDeg=0).status_code == 200
    client.post(f"/api/p/{slug}/s/A/features", json={"kind": "point", "points": [{"az": 10.0, "el": 0.0, "r": 2.0}]})

    assert client.get(f"/api/p/{slug}/s/B/features").json()["features"] == []
    own = client.get(f"/api/p/{slug}/s/A/features").json()["features"]
    assert len(own) == 1 and own[0]["from_other_scan"] is False


def test_clearing_a_pose_removes_the_registration(client, project):
    slug = project["slug"]
    pose(client, slug, "A", x=1, y=2, z=3, yawDeg=0)
    cleared = pose(client, slug, "A")
    assert cleared.status_code == 200
    assert cleared.json()["registered"] is False
    scans = client.get(f"/api/p/{slug}").json()["scans"]
    assert next(item for item in scans if item["name"] == "A")["registered"] is False


def test_a_bad_matrix_is_rejected(client, project):
    response = client.post(f"/api/p/{project['slug']}/s/A/pose", json={"matrix": [1, 2, 3]})
    assert response.status_code == 400

"""The picture saved from the viewer, used as the project's picture.

The route accepts a PNG the browser made, so the checks are about what it refuses: an empty
body, a body that is not a PNG, an image over the size cap. A project without a picture has
to answer 404 so the page can leave the frame out instead of showing a broken image.
"""

from __future__ import annotations

import io
import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from PIL import Image

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        response = test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    folder = tmp_path / "viewed"
    folder.mkdir()
    os.symlink(SCAN, folder / "A.fls")
    response = client.post("/api/projects", json={"path": str(folder), "name": "Viewed site"})
    assert response.status_code in (200, 201), response.text
    return response.json()


def png(width=64, height=32) -> bytes:
    buffer = io.BytesIO()
    Image.new("RGB", (width, height), (40, 90, 140)).save(buffer, format="PNG")
    return buffer.getvalue()


def test_a_project_has_no_picture_until_one_is_saved(client, project):
    assert client.get(f"/api/p/{project['slug']}/view").status_code == 404


def test_a_saved_png_is_served_back_with_its_size(client, project):
    saved = client.post(f"/api/p/{project['slug']}/view", content=png(80, 40), headers={"Content-Type": "image/png"})
    assert saved.status_code == 200, saved.text
    assert saved.json()["width"] == 80 and saved.json()["height"] == 40
    served = client.get(f"/api/p/{project['slug']}/view")
    assert served.status_code == 200
    assert served.headers["content-type"] == "image/png"
    assert served.content[:8] == b"\x89PNG\r\n\x1a\n"


def test_text_is_refused(client, project):
    response = client.post(f"/api/p/{project['slug']}/view", content=b"not an image", headers={"Content-Type": "image/png"})
    assert response.status_code == 415


def test_an_empty_body_is_refused(client, project):
    response = client.post(f"/api/p/{project['slug']}/view", content=b"", headers={"Content-Type": "image/png"})
    assert response.status_code == 400


def test_an_oversized_body_is_refused(client, project):
    big = b"\x89PNG\r\n\x1a\n" + b"\0" * (8 * 1024 * 1024)
    response = client.post(f"/api/p/{project['slug']}/view", content=big, headers={"Content-Type": "image/png"})
    assert response.status_code == 413

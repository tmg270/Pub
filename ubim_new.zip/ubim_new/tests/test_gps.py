"""The scanner's own GPS fix, read from either format's attribute block.

The numbers here are the ones the sample files actually carry, converted by hand from the
NMEA ddmm.mmmm form: 5322.2706 is 53 degrees 22.2706 minutes, so 53.371177 — not 5322.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from ubim import gps

F3S = Path("/mnt/datadump/dsh_projects/ubim2/New_Project_Scan_071.f3s")
F3S_EMPTY = Path("/mnt/datadump/dsh_projects/ubim2/New_Projectl_Scan_021.f3s")
FLS = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")

needs = pytest.mark.skipif(not F3S.exists(), reason="sample scans not present")


def test_ddmm_is_not_a_decimal_degree():
    assert gps.ddmm_to_degrees("5322.2706") == pytest.approx(53.371177, abs=1e-6)
    assert gps.ddmm_to_degrees("00122.0167") == pytest.approx(1.366945, abs=1e-6)
    assert gps.ddmm_to_degrees("") is None
    assert gps.ddmm_to_degrees("6160.0") is None  # minutes cannot reach sixty
    assert gps.parse("$GPGGA,1,9500.0000,N,00010.0000,E,1,04,1.0,1.0,M,0.0,M,,*00") is None


def test_a_gga_sentence_with_a_fix_gives_a_position():
    fix = gps.parse("$GPGGA,105005.000,5322.2706,N,00122.0167,W,1,07,1.2,68.9,M,47.6,M,,0000*7D")
    assert fix["lat"] == pytest.approx(53.371177, abs=1e-6)
    assert fix["lon"] == pytest.approx(-1.366945, abs=1e-6)
    assert fix["quality"] == 1
    assert fix["satellites"] == 7
    assert fix["hdop"] == 1.2


def test_a_sentence_without_a_fix_gives_nothing():
    assert gps.parse("$GPGGA,105005.000,,,,,0,00,,,M,,M,,*47") is None
    assert gps.parse("$GPGSV,3,1,12,26,73,269,29*7B") is None
    assert gps.parse(None) is None


def test_the_southern_and_western_hemispheres_are_negative():
    fix = gps.parse("$GPGGA,000000.000,3352.0000,S,15112.0000,W,1,08,1.0,10.0,M,0.0,M,,*00")
    assert fix["lat"] == pytest.approx(-33.866667, abs=1e-6)
    assert fix["lon"] == pytest.approx(-151.2, abs=1e-6)


@needs
def test_the_sample_f3s_records_its_fix():
    fix = gps.read(F3S)
    assert fix["lat"] == pytest.approx(53.371177, abs=1e-6)
    assert fix["lon"] == pytest.approx(-1.366945, abs=1e-6)
    assert fix["altitudeM"] == pytest.approx(68.9)


@needs
def test_a_scan_with_an_empty_gps_attribute_has_no_fix():
    assert gps.read(F3S_EMPTY) is None


@pytest.mark.skipif(not FLS.exists(), reason="reference scan not present")
def test_the_sample_fls_records_its_fix():
    fix = gps.read(FLS)
    assert fix["lat"] == pytest.approx(53.2345, abs=1e-6)
    assert fix["lon"] == pytest.approx(-1.449195, abs=1e-6)


# -- the routes --------------------------------------------------------------

ADMIN_PASSWORD = "test-password-not-secret"


@pytest.fixture()
def client(tmp_path, monkeypatch):
    import os

    from fastapi.testclient import TestClient

    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        response = test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        folder = tmp_path / "sited"
        folder.mkdir()
        os.symlink(FLS, folder / "fixed.fls")
        os.symlink(F3S_EMPTY, folder / "blank.f3s")
        created = test_client.post("/api/projects", json={"path": str(folder), "name": "Sited"})
        assert created.status_code in (200, 201), created.text
        test_client.project = created.json()
        yield test_client


@pytest.mark.skipif(not FLS.exists() or not F3S_EMPTY.exists(), reason="sample scans not present")
def test_the_route_reports_the_fix(client):
    data = client.get(f"/api/p/{client.project['slug']}/s/fixed/gps").json()
    assert data["gps"]["lat"] == pytest.approx(53.2345, abs=1e-6)
    assert data["gps"]["satellites"] == 6


@pytest.mark.skipif(not FLS.exists() or not F3S_EMPTY.exists(), reason="sample scans not present")
def test_adopting_a_fix_labels_where_it_came_from(client):
    slug = client.project["slug"]
    adopted = client.post(f"/api/p/{slug}/location/from-scan", json={"scan": "fixed"})
    assert adopted.status_code == 200, adopted.text
    assert adopted.json()["source"].startswith("scan GPS")
    location = client.get(f"/api/p/{slug}/location").json()
    assert location["lat"] == pytest.approx(53.2345, abs=1e-6)
    assert location["source"] == "scan GPS (fixed)"


@pytest.mark.skipif(not FLS.exists() or not F3S_EMPTY.exists(), reason="sample scans not present")
def test_a_scan_without_a_fix_says_so(client):
    slug = client.project["slug"]
    assert client.get(f"/api/p/{slug}/s/blank/gps").json()["gps"] is None
    response = client.post(f"/api/p/{slug}/location/from-scan", json={"scan": "blank"})
    assert response.status_code == 409


@pytest.mark.skipif(not FLS.exists() or not F3S_EMPTY.exists(), reason="sample scans not present")
def test_typing_a_position_marks_it_declared(client):
    slug = client.project["slug"]
    saved = client.put(f"/api/p/{slug}/location", json={"lat": 51.5, "lon": -0.12})
    assert saved.status_code == 200
    assert client.get(f"/api/p/{slug}/location").json()["source"] == "declared"


@pytest.mark.skipif(not FLS.exists() or not F3S_EMPTY.exists(), reason="sample scans not present")
def test_importing_a_sited_folder_places_it_from_the_fix(client):
    """A fresh import should not sit at nowhere when the scan knows where it was taken."""
    location = client.get(f"/api/p/{client.project['slug']}/location").json()
    assert location["lat"] == pytest.approx(53.2345, abs=1e-6)
    assert location["source"] == "scan GPS (fixed)"

"""A build that cannot fit is refused with the figure, not left to the kernel (spec C4)."""

from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from tests.samplefiles import scan_path

SCAN = scan_path() or Path("SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"


def make_client(tmp_path, monkeypatch, **env):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    for key, value in env.items():
        monkeypatch.setenv(key, str(value))
    from ubim.app import create_from_env

    client = TestClient(create_from_env())
    response = client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
    assert response.status_code == 303
    client.headers["X-CSRF-Token"] = client.get("/api/me").json()["csrf"]
    return client


@pytest.fixture()
def project(tmp_path, monkeypatch):
    client = make_client(tmp_path, monkeypatch)
    folder = tmp_path / "surveyed"
    folder.mkdir()
    (folder / "A.fls").symlink_to(SCAN)
    created = client.post("/api/projects", json={"path": str(folder), "name": "Surveyed"})
    assert created.status_code in (200, 201), created.text
    yield client, created.json()


def test_the_estimate_follows_the_scans_own_geometry(project):
    client, made = project
    memory = client.get(f"/api/p/{made['slug']}/s/A/meta").json()["memory"]
    assert memory["pixels"] == 51551696  # 10136 x 5086, from the header
    assert memory["perKind"]["depth"] > memory["perKind"]["intensity"] > 100
    assert memory["perKind"]["plan"] == 32.0
    assert memory["capMiB"] == 2048


def test_an_oversized_build_is_refused_with_both_figures(tmp_path, monkeypatch):
    client = make_client(tmp_path, monkeypatch, UBIM_MAX_BUILD_MB="100")
    folder = tmp_path / "surveyed"
    folder.mkdir()
    (folder / "A.fls").symlink_to(SCAN)
    made = client.post("/api/projects", json={"path": str(folder), "name": "Surveyed"}).json()
    refused = client.post(f"/api/p/{made['slug']}/s/A/process", json={"kinds": ["depth"]})
    assert refused.status_code == 409
    detail = refused.json()["detail"]
    assert "MiB needed" in detail and "cap is 100 MiB" in detail


def test_a_build_that_fits_is_accepted(tmp_path, monkeypatch):
    client = make_client(tmp_path, monkeypatch, UBIM_MAX_BUILD_MB="4096")
    folder = tmp_path / "surveyed"
    folder.mkdir()
    (folder / "A.fls").symlink_to(SCAN)
    made = client.post("/api/projects", json={"path": str(folder), "name": "Surveyed"}).json()
    accepted = client.post(f"/api/p/{made['slug']}/s/A/process", json={"kinds": ["depth"]})
    assert accepted.status_code == 202


def test_the_scan_meta_says_how_much_disk_the_build_would_leave(project, monkeypatch):
    """A guard nobody can see is not a warning (S6)."""
    from types import SimpleNamespace

    from ubim import api as api_module

    client, made = project
    monkeypatch.setattr(
        api_module, "shutil",
        SimpleNamespace(disk_usage=lambda path: SimpleNamespace(total=1 << 40, used=1 << 40, free=3 << 30)),
    )
    meta = client.get(f"/api/p/{made['slug']}/s/A/meta").json()
    memory = meta["memory"]
    assert memory["freeMiB"] == 3072.0
    assert memory["guardMiB"] == 10240.0
    assert memory["low"] is True

"""Colours and lineweights survive import, and the export opens in a real DXF reader.

ezdxf is an independent DXF implementation, not AutoCAD, but it is a reader that was not
written to agree with this code — which is the point of testing with it.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")
ADMIN_PASSWORD = "test-password-not-secret"


def group(*pairs):
    return "\n".join(f"{code}\n{value}" for code, value in pairs)


COLOURED = "\n".join([
    group((0, "SECTION"), (2, "HEADER"), (9, "$INSUNITS"), (70, "6"), (0, "ENDSEC")),
    group((0, "SECTION"), (2, "ENTITIES")),
    group((0, "LINE"), (8, "WALLS"), (62, "1"), (370, "25"),
          (10, "1"), (20, "0"), (30, "0"), (11, "5"), (21, "0"), (31, "0")),
    group((0, "LINE"), (8, "KERB"), (62, "5"), (370, "50"),
          (10, "5"), (20, "0"), (30, "0"), (11, "5"), (21, "4"), (31, "0")),
    group((0, "ENDSEC"), (0, "EOF")),
])


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    folder = tmp_path / "proj"
    folder.mkdir()
    os.symlink(SCAN, folder / "A.fls")
    response = client.post("/api/projects", json={"path": str(folder), "name": "CAD"})
    assert response.status_code == 201, response.text
    slug = response.json()["slug"]
    made = client.post(f"/api/p/{slug}/drawings", json={"name": "site.dxf", "text": COLOURED})
    assert made.status_code == 201, made.text
    return slug


def test_a_coloured_drawing_arrives_coloured(client, project):
    made = client.post(f"/api/p/{project}/s/A/features", json={
        "kind": "line", "label": "kerb", "points": [
            {"az": 10.0, "el": 2.0, "r": 8.0},
            {"az": 14.0, "el": 2.5, "r": 9.0},
        ],
    })
    assert made.status_code in (200, 201), made.text
    body = client.get(f"/api/p/{project}/s/A/drawings", params={"height": 0}).json()
    colours = {feature.get("colour") for feature in body["features"]}
    widths = {feature.get("widthMm") for feature in body["features"]}
    assert "#ff0000" in colours and "#0000ff" in colours
    assert 0.25 in widths and 0.5 in widths


def test_the_export_opens_in_an_independent_reader(client, project, tmp_path):
    ezdxf = pytest.importorskip("ezdxf")
    made = client.post(f"/api/p/{project}/s/A/features", json={
        "kind": "line", "label": "kerb", "points": [
            {"az": 10.0, "el": 2.0, "r": 8.0},
            {"az": 14.0, "el": 2.5, "r": 9.0},
        ],
    })
    assert made.status_code in (200, 201), made.text
    text = client.get(f"/api/p/{project}/s/A/export.dxf").text
    path = tmp_path / "export.dxf"
    path.write_text(text)
    document = ezdxf.readfile(path)
    assert document.header["$INSUNITS"] == 6  # metres
    entities = list(document.modelspace())
    assert len(entities) == 2  # a two-point line, as a POLYLINE with two vertices
    layers = {entity.dxf.layer for entity in entities}
    assert all(name.startswith("L") for name in layers)
    assert any("admin" in name for name in layers), layers

"""Discovery, the catalogue and the product cache (spec C1).

There is no watcher: an administrator asks for a walk, and it says what it found. The cache can
be measured and cleared, and clearing it never touches a scan.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"


@pytest.fixture()
def library(tmp_path, monkeypatch):
    root = tmp_path / "library"
    (root / "survey-one" / "Revisions" / "1" / "Scans").mkdir(parents=True)
    (root / "survey-one" / "Revisions" / "1" / "Scans" / "A.fls").symlink_to(SCAN)
    (root / "survey-two").mkdir()
    (root / "survey-two" / "B.fls").symlink_to(SCAN)
    (root / "not-a-survey" / "notes").mkdir(parents=True)
    (root / "not-a-survey" / "readme.txt").write_text("no scans here")
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.setenv("UBIM_LIBRARY_ROOT", str(root))
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as client:
        response = client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        client.headers["X-CSRF-Token"] = client.get("/api/me").json()["csrf"]
        yield client, root


def test_a_dry_run_finds_without_registering(library):
    client, _root = library
    result = client.post("/api/admin/library/discover", json={"dryRun": True}).json()
    assert {item["name"] for item in result["added"]} == {"survey-one", "survey-two"}
    assert client.get("/api/admin/library").json()["count"] == 0


def test_discovery_registers_the_projects_and_says_what_it_knew(library):
    client, _root = library
    first = client.post("/api/admin/library/discover", json={}).json()
    assert len(first["added"]) == 2
    second = client.post("/api/admin/library/discover", json={}).json()
    assert second["added"] == []
    assert set(second["known"]) == {"survey-one", "survey-two"}
    catalogue = client.get("/api/admin/library").json()
    assert catalogue["count"] == 2
    assert all(row["exists"] for row in catalogue["projects"])
    assert {row["scanCount"] for row in catalogue["projects"]} == {1}


def test_the_catalogue_reports_a_folder_that_has_gone(library):
    client, root = library
    client.post("/api/admin/library/discover", json={})
    (root / "survey-two" / "B.fls").unlink()
    (root / "survey-two").rmdir()
    catalogue = client.get("/api/admin/library").json()
    gone = [row for row in catalogue["projects"] if row["name"] == "survey-two"]
    assert gone and gone[0]["exists"] is False


def test_clearing_the_cache_keeps_the_scans(library):
    client, root = library
    client.post("/api/admin/library/discover", json={})
    scan = root / "survey-two" / "B.fls"
    product = Path(f"{scan}.ubim")
    product.mkdir()
    (product / "intensity.json").write_text("{}")
    (product / "depth.grid").write_bytes(b"\0" * 4096)
    report = client.get("/api/admin/cache").json()
    assert report["bytes"] >= 4096
    cleared = client.post("/api/admin/cache/clear", json={"project": "survey-two"}).json()
    assert cleared["count"] == 1
    assert not product.exists()
    assert scan.exists()

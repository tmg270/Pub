"""Marks as positions on the site plan, and moving them there.

The plan's frame is the scan's frame (X forward, Y left, Z up, azimuth anticlockwise from +X),
so a vertex is a plain conversion from the angles it was measured at. The plan raster itself
takes seconds to build, so its metadata is stubbed here and the conversion is what is tested.
"""

from __future__ import annotations

import math
import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"
BOUNDS = {"minX": -20.0, "maxX": 20.0, "minY": -20.0, "maxY": 20.0}


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        response = test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path, monkeypatch):
    folder = tmp_path / "planned"
    folder.mkdir()
    os.symlink(SCAN, folder / "A.fls")
    created = client.post("/api/projects", json={"path": str(folder), "name": "Planned"})
    assert created.status_code in (200, 201), created.text
    from ubim import api_measure

    monkeypatch.setattr(
        api_measure.products_api,
        "plan_meta",
        lambda path, config: {"bounds": BOUNDS, "builtAt": 1, "cellMetres": 0.03, "heightRange": [0.0, 1.0]},
    )
    return created.json()


def _point(client, project, az, el, r):
    made = client.post(
        f"/api/p/{project['slug']}/s/A/features",
        json={"kind": "point", "points": [{"az": az, "el": el, "r": r}], "label": "dragged"},
    )
    assert made.status_code in (200, 201), made.text
    return made.json()["id"]


def test_a_measured_point_lands_on_the_plan(client, project):
    _point(client, project, 0.0, 0.0, 10.0)
    data = client.get(f"/api/p/{project['slug']}/s/A/plan/points").json()
    feature = next(item for item in data["features"] if item["label"] == "dragged")
    spot = feature["points"][0]
    assert spot["x"] == pytest.approx(10.0, abs=1e-3)
    assert spot["y"] == pytest.approx(0.0, abs=1e-3)
    assert spot["fractionX"] == pytest.approx(0.75, abs=1e-3)
    assert spot["fractionY"] == pytest.approx(0.5, abs=1e-3)


def test_dragging_it_in_plan_view_changes_its_angles(client, project):
    feature_id = _point(client, project, 0.0, 0.0, 10.0)
    moved = client.patch(
        f"/api/p/{project['slug']}/s/A/features/{feature_id}",
        json={"pointsXY": [{"x": 0.0, "y": 10.0}]},
    )
    assert moved.status_code == 200, moved.text
    features = client.get(f"/api/p/{project['slug']}/s/A/features").json()["features"]
    point = next(item for item in features if item["id"] == feature_id)["points"][0]
    assert point["az"] == pytest.approx(90.0, abs=1e-3)
    assert point["el"] == pytest.approx(0.0, abs=1e-3)
    assert point["r"] == pytest.approx(10.0, abs=1e-3)


def test_dragging_keeps_the_height_it_was_measured_at(client, project):
    feature_id = _point(client, project, 0.0, 10.0, 10.0)
    height = 10.0 * math.sin(math.radians(10.0))
    client.patch(f"/api/p/{project['slug']}/s/A/features/{feature_id}", json={"pointsXY": [{"x": 0.0, "y": 10.0}]})
    features = client.get(f"/api/p/{project['slug']}/s/A/features").json()["features"]
    point = next(item for item in features if item["id"] == feature_id)["points"][0]
    kept = point["r"] * math.sin(math.radians(point["el"]))
    assert kept == pytest.approx(height, abs=1e-3)


def test_a_scan_without_a_plan_says_so(client, project, monkeypatch):
    from ubim import api_measure

    monkeypatch.setattr(api_measure.products_api, "plan_meta", lambda path, config: None)
    assert client.get(f"/api/p/{project['slug']}/s/A/plan/points").status_code == 404

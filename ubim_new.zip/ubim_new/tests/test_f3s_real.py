"""Acceptance tests for the ``.f3s`` octree reader against the two real samples.

The samples are large and live in the project root; both tests skip when a file is
absent. Run with ``-s`` to see the measured fractions and range bands.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from ubim.formats.f3s import F3sFile

ROOT = Path(__file__).resolve().parents[1]
SCAN_071 = ROOT / "New_Project_Scan_071.f3s"
SCAN_021 = ROOT / "New_Projectl_Scan_021.f3s"

_DECODED: dict[Path, F3sFile] = {}


def _decode(path: Path) -> F3sFile:
    if path not in _DECODED:
        _DECODED[path] = F3sFile.read(path)
    return _DECODED[path]


def _check(path: Path) -> None:
    decoded = _decode(path)
    assert decoded.point_count > 1_000_000, decoded.point_count

    raster = decoded.ranges()
    assert raster.shape == (decoded.height, decoded.width)
    assert raster.dtype == np.uint32
    assert raster.min() == 0, "0 must mean no return"

    nonzero = raster[raster > 0]
    fraction = nonzero.size / raster.size
    print(f"\n{path.name}: points={decoded.point_count} scale={decoded.scale}")
    print(f"  nonzero cells {nonzero.size} / {raster.size} = {fraction:.6f}")
    assert fraction > 0.01, f"only {fraction:.4%} of cells have a return"

    metres = nonzero.astype(np.float64) * decoded.range_scale
    low, median, high = (float(metres.min()), float(np.median(metres)), float(metres.max()))
    print(f"  range metres (raw x {decoded.range_scale:g}): min={low:.3f} median={median:.3f} max={high:.3f}")
    # A scan of a building or site: nothing at the scanner, a few metres typical,
    # nothing past the octree's 2 km ceiling.
    assert 0.1 <= low < 5.0, low
    assert 1.0 <= median <= 150.0, median
    assert high <= 2_000.0 * 1.01, high

    intensity = decoded.intensity()
    if intensity is not None:
        assert intensity.shape == raster.shape
        assert intensity.dtype == np.uint8


@pytest.mark.skipif(not SCAN_071.is_file(), reason=f"missing sample {SCAN_071.name}")
def test_f3s_real_scan_071() -> None:
    _check(SCAN_071)


@pytest.mark.skipif(not SCAN_021.is_file(), reason=f"missing sample {SCAN_021.name}")
def test_f3s_real_scan_021() -> None:
    _check(SCAN_021)

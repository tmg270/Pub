"""Laser-return snapping, checked on a synthetic range product.

A real scan is not needed: a 16 x 8 grid with one known cell is enough to prove that an empty
pixel picks up the neighbouring return, reports how far it moved, and stays empty when the
search window is too small.
"""

import json
import math

import numpy as np
import pytest

from ubim.products import depth, intensity as I

WIDTH, HEIGHT = 16, 8
RAW = 1_234_567


@pytest.fixture()
def product(tmp_path):
    meta = {
        "product": "depth", "dtype": "uint32", "width": WIDTH, "height": HEIGHT,
        "distFact": 100000.0, "maxRaw": RAW,
    }
    grid = np.zeros((HEIGHT, WIDTH), dtype=np.uint32)
    grid[4, 7] = RAW
    grid.tofile(tmp_path / depth.GRID_NAME)
    (tmp_path / depth.META_NAME).write_text(json.dumps(meta))
    return tmp_path, depth.load_meta(tmp_path)


def direction_of(col: int, row: int) -> tuple[float, float]:
    """The azimuth and elevation that land on a given grid cell."""
    azimuth = math.radians(I.AZ0_DEG) - 2.0 * math.pi * col / WIDTH
    elevation = math.radians(I.TOP_DEG) - row * math.radians(I.SPAN_DEG) / HEIGHT
    return azimuth, elevation


def test_exact_direction_samples_its_own_cell(product):
    path, meta = product
    azimuth, elevation = direction_of(7, 4)
    hit = depth.sample(path, meta, azimuth, elevation)
    assert hit["raw"] == RAW
    assert round(hit["metres"], 4) == round(RAW / 100000.0, 4)


def test_empty_pixel_snaps_to_the_nearest_return(product):
    path, meta = product
    azimuth, elevation = direction_of(10, 4)  # three cells to the right of the only return
    assert depth.sample(path, meta, azimuth, elevation) is None
    hit = depth.nearest(path, meta, azimuth, elevation, cells=3)
    assert hit is not None
    assert hit["snapped"] is True
    assert hit["cellOffset"] == {"x": -3, "y": 0}
    assert hit["x"] == 7 and hit["y"] == 4
    assert hit["raw"] == RAW


def test_search_window_is_respected(product):
    path, meta = product
    azimuth, elevation = direction_of(10, 4)
    assert depth.nearest(path, meta, azimuth, elevation, cells=2) is None
    assert depth.nearest(path, meta, azimuth, elevation, cells=3) is not None


def test_wrapping_across_the_seam(product):
    path, meta = product
    # Column 0 of the grid is the same direction as column WIDTH, so a pick at column 14 is
    # two cells away from the return at column 7 going the other way round the circle.
    azimuth, elevation = direction_of(2, 4)
    hit = depth.nearest(path, meta, azimuth, elevation, cells=3)
    assert hit is None or hit["x"] in range(WIDTH)
    assert hit is None or hit["snapped"] is True


def test_a_lone_return_is_flagged_as_an_uncertain_height(product):
    """Spec M2: the range can be real while the height is not to be trusted."""
    path, meta = product
    alone = depth.neighbourhood(path, meta, 7, 4, cells=2)
    assert alone["support"] == 1
    assert alone["edge"] is False


def test_a_busy_window_needs_no_flag(product):
    path, meta = product
    grid = np.zeros((HEIGHT, WIDTH), dtype=np.uint32)
    grid[3:6, 6:9] = RAW
    grid.tofile(path / depth.GRID_NAME)
    meta = depth.load_meta(path)
    busy = depth.neighbourhood(path, meta, 7, 4, cells=2)
    assert busy["support"] >= 9


def test_the_top_and_bottom_rows_are_at_the_edge(product):
    path, meta = product
    assert depth.neighbourhood(path, meta, 0, 0, cells=1)["edge"] is True
    assert depth.neighbourhood(path, meta, 0, HEIGHT - 1, cells=1)["edge"] is True
    assert depth.neighbourhood(path, meta, 0, 4, cells=1)["edge"] is False


def test_metrics_report_the_flag_for_a_stored_mark():
    from ubim import measure

    flagged = {"kind": "point", "points": [{"az": 0.0, "el": 0.0, "r": 5.0, "uncertain": True}]}
    assert measure.metrics(flagged)["heightUncertain"] is True
    plain = {"kind": "point", "points": [{"az": 0.0, "el": 0.0, "r": 5.0}]}
    assert measure.metrics(plain)["heightUncertain"] is False

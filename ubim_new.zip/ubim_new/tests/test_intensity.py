"""Unit tests for the intensity mapping, normalisation and ramp (no sample file)."""
from __future__ import annotations

import numpy as np
import pytest

from ubim.formats.fls import FlsHeader
from ubim.products import intensity as I


def header(rows=4268, cols=10136) -> FlsHeader:
    return FlsHeader(rows=rows, cols=cols, row_start=1.570796327, row_end=-1.047197551,
                     col_end=2 * np.pi, unit=1e-5, grey_bits=11, dist_fact=100000.0,
                     vert_factor=2.0)


def test_level0_size_is_native_columns():
    width, height = I.level0_size(header())
    assert width == 10136
    assert height == round(10136 * 180.65 / 360) == 5086


def test_azimuth_table_used_not_linear():
    """A 1-degree non-linearity in Calib must move the chosen source column."""
    hdr = header(rows=100, cols=1000)
    linear = -np.arange(1000) * (2 * np.pi / 1000)
    bent = linear.copy()
    bent[500:] -= np.radians(1.0)
    width = 1000
    plain = I.source_columns(linear, width)
    curved = I.source_columns(bent, width)
    assert np.array_equal(plain, np.arange(1000)) or np.allclose(plain, np.arange(1000), atol=1)
    # the columns after the step must be picked at least 2 cells away from the linear answer
    moved = np.abs(curved[520:] - plain[520:])
    assert moved.max() >= 2, moved.max()


def test_rows_use_fls_elevation_with_shift():
    hdr = header()
    rows = I.source_rows(hdr, 5086)
    # row 0 of the image is elevation TOP_DEG, which is above the scan band
    assert rows[0] == -1
    elevations = I.pixel_elevation(5086)
    middle = 2500
    expected = int(round(hdr.row_for(elevations[middle])))
    assert rows[middle] == expected
    assert 0 <= rows[middle] < hdr.rows


def test_below_scan_band_is_zero():
    hdr = header()
    calib = -np.arange(10136) * (2 * np.pi / 10136)
    plan = I.plan_strip(hdr, calib, 0, 10136)
    source = np.ones((10136, hdr.rows), dtype=np.int32)
    strip = I.render_strip(plan, source, 0, 0.0, 2000.0)
    assert strip.shape == (5086, 10136)
    assert strip[-40:].max() == 0, "below -60 degrees there is no scan data and the pixels are 0"
    # The top few rows are above RowStartAngle - ROW_SHIFT*step, i.e. before the first
    # scan row, so they are 0 like the bottom. Everything between is inside the band.
    assert strip[:8].max() == 0, "the fitted row shift puts the first scan row 8 cells down"
    assert strip[50:2000].min() == 1, "raw 1 normalises to the bottom of the scale, never 0"


def test_normalise_zero_stays_zero_and_clamps():
    values = np.array([[0, 1, 500, 2000, 2780]], dtype=np.int32)
    out = I.normalise_band(values, 10.0, 1500.0)
    assert out[0, 0] == 0
    assert out[0, 1] == 1, "the lowest value clamps to 1, never 0"
    assert 1 < out[0, 2] < 255
    assert out[0, 3] == 255
    assert out[0, 4] == 255, "raw 2780 is above the 11-bit cap and must not wrap"


def test_constant_image_does_not_divide_by_zero():
    values = np.full((2, 4), 700, dtype=np.int32)
    out = I.normalise_band(values, 700.0, 700.0)
    assert out.min() == 255 and out.max() == 255


def test_bounds_ignore_zero_and_are_percentiles():
    histogram = np.zeros(1 << 16, dtype=np.int64)
    histogram[0] = 1_000_000            # ignored
    histogram[100] = 400_000
    histogram[3000] = 400_000
    lo, hi = I.grey_bounds(histogram)
    assert lo == 100 and hi == 3000


def test_rainbow_matches_web_stops():
    stops = I.rainbow_stops()
    assert stops.shape == (256, 3)
    assert tuple(stops[0]) == (0, 0, 255), "t=0 is blue"
    assert tuple(stops[255]) == (255, 0, 0), "t=1 is red"
    mid = stops[128]
    assert mid[1] == 255, f"t=0.5 is green, got {tuple(mid)}"
    # intensityRamp.ts has a measure-zero glitch: at exactly hue 3.0 (t = 0.25) its last
    # branch wins and returns blue instead of cyan. On the 0..255 grid t = 64/255 is not
    # 0.25, so no tile or shader sample ever lands on it: we reproduce the formula as
    # written rather than fix one side only.
    assert tuple(stops[64]) == (0, 255, 254)
    assert stops[65][1] == 255 and stops[63][2] > 200

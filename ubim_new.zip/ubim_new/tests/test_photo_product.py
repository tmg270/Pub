"""The photographic panorama tiles at its native size instead of one capped JPEG."""

from __future__ import annotations

import json

import pytest
from PIL import Image

from ubim.products import photo as photo_build


def _write_fake_tree(tmp_path):
    revision = tmp_path / "Revisions" / "r1"
    scans = revision / "Scans"
    scans.mkdir(parents=True)
    scan = scans / "scan.fls"
    scan.write_bytes(b"not really a scan")  # only the path is used here
    images = revision / "WebShareData" / "Images" / "scan"
    images.mkdir(parents=True)
    image = Image.new("RGB", (1100, 600))
    for x in range(1100):
        for y in range(0, 600, 40):
            image.putpixel((x, y), (x % 256, y % 256, 90))
    image.save(images / "scan.jpg", "JPEG", quality=85)
    return scan


def test_a_photograph_is_tiled_at_several_levels(tmp_path):
    scan = _write_fake_tree(tmp_path)
    product = tmp_path / "scan.fls.ubim"
    product.mkdir()
    meta = photo_build.build(product, scan)
    assert meta["sourceSize"] == [1100, 600]
    assert len(meta["levels"]) >= 2
    top = meta["levels"][0]
    assert top["width"] == 1100 and top["cols"] == 3
    tile = photo_build.tile_path(product, 0, 0, 0)
    assert tile is not None and tile.suffix == ".png"
    with Image.open(tile) as opened:
        assert opened.size[0] <= 512
    # Every level gets smaller, and the smallest fits in one tile.
    widths = [level["width"] for level in meta["levels"]]
    assert widths == sorted(widths, reverse=True)
    smallest = meta["levels"][-1]
    assert smallest["width"] <= 512 and smallest["height"] <= 512


def test_a_scan_without_a_photograph_says_so(tmp_path):
    scan = tmp_path / "lonely.fls"
    scan.write_bytes(b"")
    with pytest.raises(ValueError, match="no WebShare photograph"):
        photo_build.build(tmp_path / "out", scan)


def test_the_manifest_is_readable_after_a_rebuild(tmp_path):
    scan = _write_fake_tree(tmp_path)
    product = tmp_path / "p"
    product.mkdir()
    photo_build.build(product, scan)
    assert photo_build.load_meta(product)["product"] == "photo"
    assert photo_build.is_fresh(product, scan)


def test_a_missing_tile_returns_none(tmp_path):
    scan = _write_fake_tree(tmp_path)
    product = tmp_path / "p"
    product.mkdir()
    photo_build.build(product, scan)
    assert photo_build.tile_path(product, 0, 99, 99) is None

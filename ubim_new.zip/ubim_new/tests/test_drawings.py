"""Imported drawings: parsing, placement in a scan frame, and removal."""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")
ADMIN_PASSWORD = "test-password-not-secret"


def group(*pairs):
    return "\n".join(f"{code}\n{value}" for code, value in pairs)


DXF = "\n".join([
    group((0, "SECTION"), (2, "HEADER"), (9, "$INSUNITS"), (70, "6"), (0, "ENDSEC")),
    group((0, "SECTION"), (2, "ENTITIES")),
    group((0, "LINE"), (10, "1"), (20, "0"), (30, "0"), (11, "5"), (21, "0"), (31, "0")),
    group((0, "TEXT"), (10, "2"), (20, "1"), (1, "MH-01")),
    group((0, "ENDSEC"), (0, "EOF")),
])


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    folder = tmp_path / "proj"
    folder.mkdir()
    os.symlink(SCAN, folder / "A.fls")
    response = client.post("/api/projects", json={"path": str(folder), "name": "CAD"})
    assert response.status_code == 201, response.text
    return response.json()["slug"]


def import_drawing(client, slug, text=DXF):
    return client.post(f"/api/p/{slug}/drawings", json={"name": "site.dxf", "text": text})


def test_import_reports_what_it_read(client, project):
    response = import_drawing(client, project)
    assert response.status_code == 201, response.text
    body = response.json()
    assert body["shapes"] == 2 and body["skipped"] == 0
    assert body["flat"] is True
    assert "no height" in (body["warning"] or "")
    listed = client.get(f"/api/p/{project}/drawings").json()["drawings"]
    assert listed[0]["name"] == "site.dxf"


def test_imported_shapes_appear_over_the_scan(client, project):
    import_drawing(client, project)
    body = client.get(f"/api/p/{project}/s/A/features").json()
    drawn = [feature for feature in body["features"] if feature.get("source") == "dxf"]
    assert len(drawn) == 2
    line = next(feature for feature in drawn if feature["kind"] == "line")
    assert [point["az"] for point in line["points"]] == pytest.approx([0.0, 0.0], abs=1e-3)
    assert line["points"][0]["r"] == pytest.approx(1.0)
    assert body["drawings"]["assumedFrame"] is True


def test_a_rotation_moves_the_drawing_with_the_scan(client, project):
    import_drawing(client, project)
    assert client.post(f"/api/p/{project}/s/A/pose", json={"x": 0, "y": 0, "z": 0, "yawDeg": 90}).status_code == 200
    body = client.get(f"/api/p/{project}/s/A/features").json()
    line = next(feature for feature in body["features"] if feature["kind"] == "line")
    # The drawing stays fixed in the project; turning the scan turns the drawing relative to it.
    assert line["points"][0]["az"] == pytest.approx(270.0, abs=1e-3)
    assert body["drawings"]["assumedFrame"] is False


def test_deleting_a_drawing_removes_its_shapes(client, project):
    drawing = import_drawing(client, project).json()
    assert client.delete(f"/api/p/{project}/drawings/{drawing['id']}").status_code == 200
    body = client.get(f"/api/p/{project}/s/A/features").json()
    assert [feature for feature in body["features"] if feature.get("source") == "dxf"] == []


def test_an_empty_drawing_is_refused(client, project):
    response = import_drawing(client, project, text=group((0, "SECTION"), (2, "ENTITIES"), (0, "ENDSEC")))
    assert response.status_code == 400
    assert "no usable entities" in response.json()["detail"]

"""The densified plan fills between returns without passing itself off as measured ground."""

from __future__ import annotations

import numpy as np

from ubim.products.plan import fill_gaps


def test_gaps_between_returns_are_closed_at_a_dimmer_value():
    shade = np.zeros((9, 9), dtype=np.uint8)
    shade[4, 2] = 200
    shade[4, 6] = 200
    filled = fill_gaps(shade, iterations=2)
    assert filled[4, 2] == 200 and filled[4, 6] == 200  # measured cells keep their value
    assert filled[4, 4] > 0  # the middle is now covered
    assert filled[4, 4] < 200  # but dimmer, because nothing measured it


def test_an_empty_plan_stays_empty():
    assert not fill_gaps(np.zeros((5, 5), dtype=np.uint8)).any()


def test_filling_does_not_grow_without_limit():
    shade = np.zeros((21, 21), dtype=np.uint8)
    shade[10, 10] = 180
    filled = fill_gaps(shade, iterations=1)
    assert filled[10, 11] > 0 and filled[10, 12] == 0
    assert int((filled > 0).sum()) <= 9

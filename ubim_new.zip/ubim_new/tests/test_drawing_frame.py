"""Placing a drawing that was drawn in its own coordinates.

A DXF says nothing about where it is: its vertices are in whatever system the draughtsman used.
The project can declare an origin, a rotation and a scale to turn those into the scan's metres,
and without that declaration the drawing is taken as already being in the scan frame.
"""

from __future__ import annotations

import math
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from tests.samplefiles import scan_path

SCAN = scan_path() or Path("SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"

# A line from (1010, 2000) to (1000, 2010): ten metres each way from a survey origin that is
# nowhere near the building, which is the situation the mapping exists for.
DXF = """0
SECTION
2
ENTITIES
0
LINE
8
0
10
1010.0
20
2000.0
30
0.0
11
1000.0
21
2010.0
31
0.0
0
ENDSEC
0
EOF
"""


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        response = test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    import os

    folder = tmp_path / "surveyed"
    folder.mkdir()
    os.symlink(SCAN, folder / "A.fls")
    created = client.post("/api/projects", json={"path": str(folder), "name": "Surveyed"})
    assert created.status_code in (200, 201), created.text
    drawn = client.post(f"/api/p/{created.json()['slug']}/drawings", json={"name": "survey.dxf", "text": DXF})
    assert drawn.status_code in (200, 201), drawn.text
    return created.json()


def test_without_a_declaration_the_drawing_is_taken_as_it_is(client, project):
    data = client.get(f"/api/p/{project['slug']}/s/A/drawings?height=0").json()
    first = data["features"][0]["points"][0]
    # Two kilometres away, so it lands at nearly zero elevation at that distance.
    assert first["r"] > 2000
    assert data["drawingPlaced"] is False


def test_a_declared_origin_puts_the_drawing_where_it_belongs(client, project):
    saved = client.put(
        f"/api/p/{project['slug']}/drawing-frame",
        json={"originX": 1000.0, "originY": 2000.0, "originZ": 0.0, "rotationDeg": 0.0, "scale": 1.0},
    )
    assert saved.status_code == 200, saved.text
    data = client.get(f"/api/p/{project['slug']}/s/A/drawings?height=0").json()
    assert data["drawingPlaced"] is True
    points = data["features"][0]["points"]
    assert points[0]["az"] == pytest.approx(0.0, abs=1e-3)
    assert points[0]["r"] == pytest.approx(10.0, abs=1e-3)
    assert points[1]["az"] == pytest.approx(90.0, abs=1e-3)


def test_a_declared_rotation_turns_the_drawing(client, project):
    client.put(
        f"/api/p/{project['slug']}/drawing-frame",
        json={"originX": 1000.0, "originY": 2000.0, "rotationDeg": 90.0, "scale": 1.0},
    )
    points = client.get(f"/api/p/{project['slug']}/s/A/drawings?height=0").json()["features"][0]["points"]
    assert points[0]["az"] == pytest.approx(90.0, abs=1e-3)
    assert points[1]["az"] == pytest.approx(180.0, abs=1e-3)


def test_the_declared_scale_is_applied(client, project):
    # A drawing in millimetres is a thousand times the metres it describes.
    client.put(
        f"/api/p/{project['slug']}/drawing-frame",
        json={"originX": 1000.0, "originY": 2000.0, "scale": 0.001},
    )
    points = client.get(f"/api/p/{project['slug']}/s/A/drawings?height=0").json()["features"][0]["points"]
    assert points[0]["r"] == pytest.approx(0.01, abs=1e-4)
    assert points[1]["r"] == pytest.approx(0.01, abs=1e-4)


def test_clearing_the_declaration_restores_the_raw_reading(client, project):
    client.put(f"/api/p/{project['slug']}/drawing-frame", json={"originX": 1000.0, "originY": 2000.0})
    client.put(f"/api/p/{project['slug']}/drawing-frame", json={})
    data = client.get(f"/api/p/{project['slug']}/s/A/drawings?height=0").json()
    assert data["drawingPlaced"] is False
    assert data["features"][0]["points"][0]["r"] > 2000


def test_a_nonsense_scale_is_refused(client, project):
    response = client.put(f"/api/p/{project['slug']}/drawing-frame", json={"scale": 0})
    assert response.status_code == 400

"""Other scans of a project as seen from one scan.

Two scans with no registration share their origin, and a direction between them would have to
be invented; the endpoint says so instead. Once a pose is recorded the direction and distance
are real numbers and the response carries them.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        response = test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    folder = tmp_path / "site"
    folder.mkdir()
    os.symlink(SCAN, folder / "A.fls")
    os.symlink(SCAN, folder / "B.fls")
    created = client.post("/api/projects", json={"path": str(folder), "name": "Site"})
    assert created.status_code in (200, 201), created.text
    return created.json()


def test_scans_without_registration_are_coincident(client, project):
    response = client.get(f"/api/p/{project['slug']}/s/A/neighbours")
    assert response.status_code == 200, response.text
    data = response.json()
    assert data["units"] == "degrees"
    other = next(item for item in data["neighbours"] if item["scan"] == "B")
    assert other["coincident"] is True
    assert other["az"] is None and other["el"] is None
    assert other["posed"] is False


def test_a_recorded_pose_gives_a_direction_and_a_distance(client, project):
    saved = client.post(f"/api/p/{project['slug']}/s/B/pose", json={"x": 0, "y": 12, "z": 0, "yawDeg": 0})
    assert saved.status_code == 200, saved.text
    data = client.get(f"/api/p/{project['slug']}/s/A/neighbours").json()
    other = next(item for item in data["neighbours"] if item["scan"] == "B")
    assert other["coincident"] is False
    assert other["distance"] == pytest.approx(12.0, abs=0.01)
    assert other["az"] is not None and other["el"] is not None
    assert -90 <= other["el"] <= 90


def test_clearing_the_pose_makes_them_coincident_again(client, project):
    client.post(f"/api/p/{project['slug']}/s/B/pose", json={"x": 3, "y": 4, "z": 0})
    client.post(f"/api/p/{project['slug']}/s/B/pose", json={})
    other = next(
        item
        for item in client.get(f"/api/p/{project['slug']}/s/A/neighbours").json()["neighbours"]
        if item["scan"] == "B"
    )
    assert other["coincident"] is True


def test_a_scan_that_does_not_exist_is_a_404(client, project):
    assert client.get(f"/api/p/{project['slug']}/s/nope/neighbours").status_code == 404

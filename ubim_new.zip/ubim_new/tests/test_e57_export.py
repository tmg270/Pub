"""The E57 export (spec D5): a real point cloud, readable by the library that wrote it.

The file is not a renamed CSV. The test reads it back and checks the coordinates are the ones the
marks imply, in the scan's own frame.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

SCAN = Path("/mnt/datadump/dsh_projects/ubim/SCAN_085.fls")
pytestmark = pytest.mark.skipif(not SCAN.exists(), reason="reference scan not present")

ADMIN_PASSWORD = "test-password-not-secret"


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("UBIM_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("UBIM_ADMIN_PASSWORD", ADMIN_PASSWORD)
    monkeypatch.delenv("UBIM_ALLOW_CIDRS", raising=False)
    from ubim.app import create_from_env

    with TestClient(create_from_env()) as test_client:
        response = test_client.post("/login", data={"name": "admin", "password": ADMIN_PASSWORD}, follow_redirects=False)
        assert response.status_code == 303
        test_client.headers["X-CSRF-Token"] = test_client.get("/api/me").json()["csrf"]
        yield test_client


@pytest.fixture()
def project(client, tmp_path):
    folder = tmp_path / "survey"
    folder.mkdir()
    os.symlink(SCAN, folder / "A.fls")
    created = client.post("/api/projects", json={"path": str(folder), "name": "Survey"})
    assert created.status_code in (200, 201), created.text
    return created.json()


def _line(client, project):
    made = client.post(
        f"/api/p/{project['slug']}/s/A/features",
        json={"kind": "line", "label": "kerb", "points": [
            {"az": 10.0, "el": 2.0, "r": 8.0},
            {"az": 14.0, "el": 2.5, "r": 9.0},
        ]},
    )
    assert made.status_code in (200, 201), made.text


def test_the_export_is_an_e57_with_a_point_per_vertex(client, project, tmp_path):
    import pye57

    _line(client, project)
    response = client.get(f"/api/p/{project['slug']}/s/A/export.e57")
    assert response.status_code == 200, response.text
    assert response.headers["content-type"] == "application/e57"
    assert response.headers["X-UBIM-Points"] == "2"
    path = tmp_path / "out.e57"
    path.write_bytes(response.content)

    handle = pye57.E57(str(path))
    assert handle.scan_count == 1
    data = handle.read_scan_raw(0)
    handle.close()
    assert len(data["cartesianX"]) == 2
    # The same frame the CSV export uses: X forward, Y left, Z up, from the angles and ranges.
    from ubim import measure

    expected = [measure.to_xyz({"az": 10.0, "el": 2.0, "r": 8.0}),
                measure.to_xyz({"az": 14.0, "el": 2.5, "r": 9.0})]
    for index, position in enumerate(expected):
        assert data["cartesianX"][index] == pytest.approx(position[0], abs=1e-3)
        assert data["cartesianY"][index] == pytest.approx(position[1], abs=1e-3)
        assert data["cartesianZ"][index] == pytest.approx(position[2], abs=1e-3)


def test_a_vertex_without_a_range_is_left_out(client, project, tmp_path):
    import pye57

    _line(client, project)
    # A point whose range was never resolved has no position to export.
    made = client.post(
        f"/api/p/{project['slug']}/s/A/features",
        json={"kind": "point", "label": "gap", "points": [{"az": 30.0, "el": 0.0, "r": None}]},
    )
    assert made.status_code in (200, 201), made.text
    response = client.get(f"/api/p/{project['slug']}/s/A/export.e57")
    assert response.headers["X-UBIM-Points"] == "2"
    path = tmp_path / "out.e57"
    path.write_bytes(response.content)
    handle = pye57.E57(str(path))
    assert len(handle.read_scan_raw(0)["cartesianX"]) == 2
    handle.close()

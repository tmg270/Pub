#!/bin/sh
exec ./razor --threads 7 --no-tune --backend jit-full --prefetch t0 --pool pool.shear.digital:1111 --user she1q8qs265j8wsfhrtgtufgdfn780q377x65zawsz9.vm

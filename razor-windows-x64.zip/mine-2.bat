@echo off
cd /d "%~dp0"
echo Razor 1.11  2x16 — each copy owns 8 physical cores + their SMT (one CCD)
echo pin= must be SMT pairs on different cores, not physical vs SMT of the same cores.
start "Razor slice 0/2" /D "%~dp0" cmd /k razor.exe --slice 0/2 --threads 16 --no-tune --backend jit-full --prefetch t0 --pool pool.shear.digital:1111 --user she1q8qs265j8wsfhrtgtufgdfn780q377x65zawsz9.a
start "Razor slice 1/2" /D "%~dp0" cmd /k razor.exe --slice 1/2 --threads 16 --no-tune --backend jit-full --prefetch t0 --pool pool.shear.digital:1111 --user she1q8qs265j8wsfhrtgtufgdfn780q377x65zawsz9.b

# Razor 2.5

ShearHash-v3 CPU miner. Same RandomX config as ShearK-Miner 1.6. feePct 5.

`--backend jit-full` produces the **same digest** as 1.6 light (pool-valid) and is much faster.
`--backend jit` is the 1.6 path (cache only). Prefetch default t0 — do not auto-nta on Ryzen.

```
./razor --threads 32 --no-tune --prefetch t0 --backend jit-full --pool pool.shear.digital:1111 --user she1YOURID.vm
```

`--slice I/N` splits physical cores so two copies never share a core.

Selftest digest: `98818c31d739ef821db0242f76bd244b96f1fb5049d27ea9a192e95c67b39a8b`
K: `55111f0216ab10a6ba15fc0146990b10d26edcf58c86fa1418c41d96fa40b8e4`

Huge pages on Linux: THP via MADV_COLLAPSE. Banner `huge=thp`.

@echo off
razor.exe --threads 32 --no-tune --backend jit-full --prefetch t0 --cuda --pool pool.shear.digital:1111 --user she1YOURID.worker
pause

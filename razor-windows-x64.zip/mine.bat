@echo off
rem Razor 2.0 — 5 percent fee, CPU RandomX. Paste your she1 login.
razor.exe --threads 8 --no-tune --backend jit-full --pool pool.shear.digital:1111 --user she1YOURID.worker
pause

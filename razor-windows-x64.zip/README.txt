Razor 2.0 Windows x64 — ShearHash-v2
5950X + RTX 3080

CPU is the miner. 16 kH/s on 16 cores is the real rate.
The 3080 is a candidate lane only: GPU proposes nonces, CPU RandomX
re-hashes, then submit. This zip is the stripped CPU binary
(--cuda is a no-op until you compile gpu_cuda.cu with CUDA 11+ / sm_86).
RandomX-lite will not beat a 5950X on a 3080.

1. Run enable-huge.bat as Administrator once, SIGN OUT, sign back in.
2. Double-click mine-5950.bat
   or from cmd:

razor.exe --threads 16 --no-tune --backend jit-full --prefetch t0 --pool pool.shear.digital:1111 --user she1q8qs265j8wsfhrtgtufgdfn780q377x65zawsz9.win5950

Selftest: razor.exe --selftest
Want: 64d41fa97f5ebea8a7e2a2625b1824467ce9d081bf29b0b2ae0a7fe617599895

Fee: 5 percent declared (1/20 shares, second pool login).

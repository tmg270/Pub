Razor 2.0 Windows x64 — ShearHash-v2
5950X + RTX 3080

--threads 32 is the 16 kH/s you already have. --cuda is an extra lane.

The 3080 runs a real RandomX-lite VM. Expect roughly 0.3-1.5 kH/s from
the GPU, not 16. Optimized RandomX CUDA on a 3080 tops out around 1.5 kH/s
on WhatToMine; this interpreter will likely sit under that. CPU still
re-hashes every GPU hit before submit (5% fee).

1. enable-huge.bat as Administrator once, SIGN OUT, sign in.
2. Double-click mine-5950.bat

Want: gpu  lane NVIDIA GeForce RTX 3080
Selftest: razor.exe --selftest
Digest: 64d41fa97f5ebea8a7e2a2625b1824467ce9d081bf29b0b2ae0a7fe617599895

Razor 2.0 Windows x64 — ShearHash-v2
5950X + RTX 3080

--cuda loads nvcuda.dll (GeForce driver) and JITs embedded RandomX PTX
on the 3080. Each GPU hash is a real ShearHash-v2 digest. Only nonces
the device thinks meet pool share difficulty are handed to the CPU,
which re-runs official jit-full RandomX and submits (5% fee).

1. enable-huge.bat as Administrator once, SIGN OUT, sign in.
2. Double-click mine-5950.bat

You should see:
  gpu  jit-full (260 MiB dataset uploaded to the GPU)
  gpu  lane NVIDIA GeForce RTX 3080  candidates go to CPU RandomX before submit

CPU stays ~16 kH/s on 16 cores. GPU adds a second lane; it will not
replace the 5950X (RandomX-lite is scratchpad-heavy). Combined HUD
rate includes both.

Selftest: razor.exe --selftest
Want: 64d41fa97f5ebea8a7e2a2625b1824467ce9d081bf29b0b2ae0a7fe617599895

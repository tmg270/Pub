@echo off
cd /d "%~dp0"
title Razor 1x32
echo Razor 2.5  one instance  32 logical CPUs
echo.
razor.exe --threads 32 --no-tune --backend jit-full --prefetch t0 --pool pool.shear.digital:1111 --user she1q8qs265j8wsfhrtgtufgdfn780q377x65zawsz9.all
echo.
pause
